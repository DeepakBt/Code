﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MOAMC_WhiteH_MOT.DataAccessLayer
{
    class DataAccess
    {
        public static string StringDecrypt(string input)
        {
            string key = string.Empty;
            key = ConfigurationManager.AppSettings["AMC"];
            byte[] inputArray = Convert.FromBase64String(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
        string con;
        public DataAccess()
        {
            con = StringDecrypt(ConfigurationManager.ConnectionStrings["MOAMC"].ConnectionString);
        }
        public DataTable ExecuteDataTable(ref SqlCommand cmd, string spName)
        {
            SqlCommand _cmd = default(SqlCommand);
            SqlDataAdapter _adapter = default(SqlDataAdapter);
            DataSet _ds = default(DataSet);
            SqlConnection _cnn = default(SqlConnection);
            _cmd = new SqlCommand();
            _adapter = new SqlDataAdapter();
            _cnn = new SqlConnection(con);
            if ((_cnn.State == ConnectionState.Open))
            {
                _cnn.Close();
            }
            else
            {
                _cnn.Open();
            }
            _cmd = cmd;
            _cmd.Connection = _cnn;
            _cmd.CommandText = spName;
            _cmd.CommandType = CommandType.StoredProcedure;
            _cmd.CommandTimeout = 50000;
            _adapter.SelectCommand = _cmd;
            _ds = new DataSet();
            try
            {
                _adapter.Fill(_ds, "DTTable");
            }
            catch (Exception ex)
            {
                _cmd.Dispose();
                throw ex;
            }
            finally
            {
                if ((_cnn.State == ConnectionState.Open))
                {
                    _cnn.Close();
                }
                _cnn.Dispose();
                _cmd.Dispose();
                _adapter.Dispose();
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            return _ds.Tables["DTTable"]; ;
        }

        public DataSet ExecuteDataSet(ref SqlCommand cmd, string spName)
        {
            SqlCommand _cmd = default(SqlCommand);
            SqlDataAdapter _adapter = default(SqlDataAdapter);
            DataSet _ds = default(DataSet);
            SqlConnection _cnn = default(SqlConnection);
            _cmd = new SqlCommand();
            _adapter = new SqlDataAdapter();
            _cnn = new SqlConnection(con);
            if ((_cnn.State == ConnectionState.Open))
            {
                _cnn.Close();
            }
            else
            {
                _cnn.Open();
            }
            _cmd = cmd;
            _cmd.Connection = _cnn;
            _cmd.CommandText = spName;
            _cmd.CommandType = CommandType.StoredProcedure;
            _cmd.CommandTimeout = 50000;
            _adapter.SelectCommand = _cmd;
            _ds = new DataSet();
            try
            {
                _adapter.Fill(_ds, "DSTable");
            }
            catch (Exception ex)
            {
                _cmd.Dispose();
                throw ex;
            }
            finally
            {
                if ((_cnn.State == ConnectionState.Open))
                {
                    _cnn.Close();
                }
                _cnn.Dispose();
                _cmd.Dispose();
                _adapter.Dispose();
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            return _ds;
        }
    }
}
