﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using static MOAMC_WhiteH_MOT.Model.PerformanceInfo;
using System.Timers;
using System.Threading;
using Timer = System.Timers.Timer;
using System.Management;
using System.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using MOAMC_WhiteH_MOT.Model;
using MOAMC_WhiteH_MOT.DataAccessLayer;

namespace MOAMC_WhiteH_MOT
{
    public partial class MonitorServices : ServiceBase
    {
        Timer timer = new Timer();
        string LogFile = string.Empty;
        int IntervalTime = Convert.ToInt32(ConfigurationManager.AppSettings.Get("IntervalTime"));
        string ErrorFolder = Convert.ToString(ConfigurationManager.AppSettings.Get("Error"));
        string InfoFolder = Convert.ToString(ConfigurationManager.AppSettings.Get("Info"));
        string ToEmail = Convert.ToString(ConfigurationManager.AppSettings.Get("ToEmail"));
        int HDDWarrningSizeinGB = Convert.ToInt32(ConfigurationManager.AppSettings.Get("HDDWarrningSizeinGB"));
        int RAMWarrningSizeinGB = Convert.ToInt32(ConfigurationManager.AppSettings.Get("RAMWarrningSizeinGB"));
        int DuritionInDay = Convert.ToInt32(ConfigurationManager.AppSettings.Get("DuritionInDay"));
        string FolderLocation = Convert.ToString(ConfigurationManager.AppSettings.Get("LocationToDelete"));
        string ExtensionToCheck = Convert.ToString(ConfigurationManager.AppSettings.Get("ExtensionToCheck"));
        string CPUWarrningPercentage = Convert.ToString(ConfigurationManager.AppSettings.Get("CPUWarrningPercentage"));
        int CPUCheckTimeInSec = Convert.ToInt32(ConfigurationManager.AppSettings.Get("CPUCheckTimeInSec"));
        string BackGroundService = Convert.ToString(ConfigurationManager.AppSettings.Get("BackGroundService"));
        string DBTableDetails = Convert.ToString(ConfigurationManager.AppSettings.Get("DBTable"));
        string CheckDBTableAllTime = Convert.ToString(ConfigurationManager.AppSettings.Get("CheckDBTableAllTime"));
        string TargetDBConnection = ConfigurationManager.ConnectionStrings["TargetDBServer"].ConnectionString;
        string URLsLink = Convert.ToString(ConfigurationManager.AppSettings.Get("URLs"));
        string SSLURLs = Convert.ToString(ConfigurationManager.AppSettings.Get("SSLURLs"));
        string HDObjecSizeLocation = Convert.ToString(ConfigurationManager.AppSettings.Get("HDObjecSizeLocation"));
        int HDObjecTopSize= Convert.ToInt32(ConfigurationManager.AppSettings.Get("HDObjecTopSize"));
        int HDDObjectWarrningSizeinMB = Convert.ToInt32(ConfigurationManager.AppSettings.Get("HDDObjectWarrningSizeinMB"));
        List<DataList> LsData = new List<DataList>();
        public MonitorServices()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                ServicetxtLog(InfoFolder, "Info", "Service Statred", MethodBase.GetCurrentMethod().Name.ToString());
                timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
                timer.Interval = IntervalTime;
                timer.Enabled = true;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
            }
        }
        public void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            try
            {
                ServicetxtLog(InfoFolder, "Info", "Started", MethodBase.GetCurrentMethod().Name.ToString());
                ServiceWorker();
                ServicetxtLog(InfoFolder, "Info", "End", MethodBase.GetCurrentMethod().Name.ToString());
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
            }
        }

        public void ServiceWorker()
        {
            try
            {
                ServicetxtLog(InfoFolder, "Info", "Start", MethodBase.GetCurrentMethod().Name.ToString());
                CheckHWSW();
                if (!File.Exists(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)+ ConfigurationManager.AppSettings.Get("LogFile").ToString() + "Info\\Log_Del" + "_" + DateTime.Now.Year.ToString() + DateTime.Now.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt"))
                {
                    DeleteReq();
                }
                ServicetxtLog(InfoFolder, "Info", "End", MethodBase.GetCurrentMethod().Name.ToString());
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
            }
        }

        public void CheckHWSW()
        {
            try
            {
                HWSWInfo HWinfoObj = new HWSWInfo();
                ServicetxtLog(InfoFolder, "Info", "Start", MethodBase.GetCurrentMethod().Name.ToString());
                if (CheckDBTableAllTime.ToUpper() == "YES")
                {
                    HWinfoObj.TableDataRes = DBTableInfo();
                    ServicetxtLog(InfoFolder, "Info", "DBAccessCount", MethodBase.GetCurrentMethod().Name.ToString(), false, true);
                }
                else
                {
                    if (!File.Exists(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + ConfigurationManager.AppSettings.Get("LogFile").ToString() + "Info\\Log_DB" + "_" + DateTime.Now.Year.ToString() + DateTime.Now.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt"))
                    {
                        HWinfoObj.TableDataRes = DBTableInfo();
                        ServicetxtLog(InfoFolder, "Info", "DBAccessCount", MethodBase.GetCurrentMethod().Name.ToString(), false, true);
                    }
                }
                HWinfoObj.HDD = CheckHDD();
                HWinfoObj.HDOSize = HDObjectSize();
                HWinfoObj.MemoryInfo = CheckVMemeoryInfo();
                HWinfoObj.CPUUtilization = GetCPUUsage();
                HWinfoObj.ServerRebootTime = GetLastRebootTime();
                HWinfoObj.BGServiceStatus = GetServiceStatus();
                HWinfoObj.URLStatus = GetURLStatus();
                HWinfoObj.SSLDetails = CheckSSL();
                string XMLData = ObjectToXMLString(HWinfoObj);

                DataAccess da = new DataAccess();
                SqlCommand cmd;
                DataTable dt;
                dt = new DataTable();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@To", ToEmail);
                cmd.Parameters.AddWithValue("@WarringSize", HDDWarrningSizeinGB);
                cmd.Parameters.AddWithValue("@Server", GetLocalIPAddress());
                cmd.Parameters.AddWithValue("@WarringSizeRAM", RAMWarrningSizeinGB);
                cmd.Parameters.AddWithValue("@WarrningCPU", CPUWarrningPercentage);
                cmd.Parameters.AddWithValue("@WarrningHDObjSize", HDDObjectWarrningSizeinMB);
                dt = da.ExecuteDataTable(ref cmd, "USP_SERVER_SERVICES_MAINTAINANCE_IDEATHON");
                if (Convert.ToInt16(dt.Rows[0][0]) == 1)
                {
                    ServicetxtLog(InfoFolder, "Info", "End", MethodBase.GetCurrentMethod().Name.ToString());
                }
                else
                {
                    ServicetxtLog(InfoFolder, "Error", Convert.ToString(dt.Rows[0][1]), MethodBase.GetCurrentMethod().Name.ToString());
                }
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
            }
        }

        protected override void OnStop()
        {
            ServicetxtLog(InfoFolder, "Info", "Service Stopped", MethodBase.GetCurrentMethod().Name.ToString());
        }

        //******************************************************Utilities***************************************************//

        public List<DriveObjectSize> HDObjectSize()
        {
            List<DriveObjectSize> ObjD = new List<DriveObjectSize>();
            try
            {
                string[] LstLocation = HDObjecSizeLocation.Split(';');

                foreach (string D in LstLocation)
                {
                    
                    List<DataList> NewLsObj = new List<DataList>();
                    LsData = new List<DataList>();
                    NewLsObj = DirectorySearch(@"" + Convert.ToString(D) + @":\");
                    List<DataList> SortedList = NewLsObj.OrderByDescending(o => o.SizeInMB).ToList();
                    if (SortedList.Count() > 0)
                    {
                        string[] Location = new string[HDObjecTopSize];
                        string[] SizeInMB = new string[HDObjecTopSize];
                        string[] SizeInGB = new string[HDObjecTopSize];
                        List<DataList> ObjL = new List<DataList>();
                        if(SortedList.Count()< HDObjecTopSize)
                        {
                            HDObjecTopSize = SortedList.Count();
                        }
                        for (int i = 0; i < HDObjecTopSize; i++)
                        {
                            DriveObjectSize O = new DriveObjectSize();
                            O.SrNo = Convert.ToString(i + 1);
                            O.Location = SortedList[i].Location;
                            O.SizeInMB = SortedList[i].SizeInMB.ToString("#.##");
                            O.SizeInGB= SortedList[i].SizeInGB.ToString("#.##");
                            ObjD.Add(O);
                        }
                    }
                }
                return ObjD;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                return ObjD;
            }
        }
        
        public List<DataList> DirectorySearch(string dir)
        {
            try
            {
                foreach (string d in Directory.GetDirectories(dir))
                {
                    DataList Obj = new DataList();
                    DirectoryInfo info = new DirectoryInfo(d);
                    decimal totalSize;
                    try
                    {
                        totalSize = info.EnumerateFiles().Sum(file => file.Length);
                    }
                    catch (Exception ex)
                    {
                        totalSize = 0;
                    }

                    decimal sizeInMB = (totalSize / 1024) / 1024;
                    Obj.SizeInMB = sizeInMB;
                    if (sizeInMB > 0)
                    {
                        Obj.SizeInGB = sizeInMB / 1024;
                    }
                    else
                    {
                        Obj.SizeInGB = 0;
                    }
                    Obj.Location = d;
                    LsData.Add(Obj);
                    DirectorySearch(d);
                }
                return LsData;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Could not find a part of the path"))
                {
                    ServicetxtLog(ErrorFolder, "Info", "Given Drive Not Exists", MethodBase.GetCurrentMethod().Name.ToString());
                }
                else
                {
                    ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                }
                return LsData;
            }
        }

        public void DeleteReq()
        {
            try
            {
                ServicetxtLog(InfoFolder, "Info", "Started", MethodBase.GetCurrentMethod().Name.ToString());
                string[] LocationArray = FolderLocation.Split(';');
                string[] ExtenstionArray = ExtensionToCheck.Split(';');
                foreach (string strDir in LocationArray)
                {
                    for (int i = 0; i < ExtenstionArray.Length; i++)
                    {
                        DeleteFile(strDir, ExtenstionArray[i]);
                    }
                }
                ServicetxtLog(InfoFolder, "Info", "End", MethodBase.GetCurrentMethod().Name.ToString());
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
            }
        }

        public void DeleteFile(string Location, string Extension)
        {
            try
            {
                string[] filePaths = Directory.GetFiles(Location, "*" + Extension);
                foreach (string strFile in filePaths)
                {
                    DateTime FileCreatedOn = File.GetCreationTime(strFile);
                    TimeSpan ts = DateTime.Now - FileCreatedOn;
                    //if (ts.TotalMinutes > DuritionInDay)
                    if (ts.TotalDays > DuritionInDay)
                    {
                        File.Delete(strFile);
                        ServicetxtLog(InfoFolder, "Info", "DeleteFile : " + strFile, MethodBase.GetCurrentMethod().Name.ToString(), true);
                    }
                }
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
            }
        }

        public List<SSLDetails> CheckSSL()
        {
            List<SSLDetails> ObjRes = new List<SSLDetails>();
            try
            {
                string SSLSingleURL = string.Empty;
                string[] URLs = SSLURLs.Split(';');
                for (int i = 0; i < URLs.Length; i++)
                {
                    SSLSingleURL = URLs[i];
                    SSLDetails ObjSsl = new SSLDetails();
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(SSLSingleURL);
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    response.Close();
                    X509Certificate cert = request.ServicePoint.Certificate;
                    X509Certificate2 cert2 = new X509Certificate2(cert);
                    ObjSsl.URL = SSLSingleURL;
                    ObjSsl.Name = cert2.GetIssuerName();
                    ObjSsl.ExpirationDate = Convert.ToDateTime(cert2.GetExpirationDateString()).ToString("dd/MMM/yyyy hh:mm:ss:tt");
                    ObjRes.Add(ObjSsl);
                }
                return ObjRes;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return ObjRes;
            }

        }

        public List<UrlsCheckData> GetURLStatus()
        {
            List<UrlsCheckData> ObjLstURLdata = new List<UrlsCheckData>();
            string URL = string.Empty;
            try
            {

                string[] URLs = URLsLink.Split(';');
                for (int i = 0; i < URLs.Length; i++)
                {
                    URL = URLs[i];
                    UrlsCheckData ObjURL = new UrlsCheckData();
                    ObjURL.URL = URL;
                    ObjURL.StatusMessage = CheckUrlStatus(URL);
                    ObjLstURLdata.Add(ObjURL);
                }
                return ObjLstURLdata;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", URL + " : " + ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return ObjLstURLdata;
            }
        }

        public List<BackGroundService> GetServiceStatus()
        {
            List<BackGroundService> ObjListService = new List<BackGroundService>();
            try
            {
                string[] BGServiceArry = BackGroundService.Split(';');
                string ServiceStatus = string.Empty;
                string SerName = string.Empty;
                for (int i = 0; i < BGServiceArry.Length; i++)
                {
                    SerName = BGServiceArry[i];
                    BackGroundService BgService = new BackGroundService();
                    ServiceController sc = new ServiceController(SerName);
                    try
                    {
                        switch (sc.Status)
                        {
                            case ServiceControllerStatus.Running: ServiceStatus = "Running"; break;
                            case ServiceControllerStatus.Stopped: ServiceStatus = "Stopped"; break;
                            case ServiceControllerStatus.Paused: ServiceStatus = "Paused"; break;
                            case ServiceControllerStatus.StopPending: ServiceStatus = "Stopping"; break;
                            case ServiceControllerStatus.StartPending: ServiceStatus = "Starting"; break;
                            default: ServiceStatus = "Status Changing"; break;
                        }
                        BgService.ServiceName = SerName;
                        BgService.ServiceStatus = ServiceStatus;
                    }
                    catch (Exception ex)
                    {
                        BgService.ServiceName = SerName;
                        BgService.ServiceStatus = "Service Not Found";
                        ServicetxtLog(InfoFolder, "Info", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                    }
                    ObjListService.Add(BgService);
                }
                return ObjListService;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return ObjListService;
            }
        }

        public string CheckUrlStatus(string Website)
        {
            try
            {
                var request = WebRequest.Create(Website) as HttpWebRequest;
                request.Method = "HEAD";
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;


                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        return "Up and Running";
                    }
                    else
                    {
                        return "Not Responding";
                    }
                }
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", Website + " : " + ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                return ex.Message;
            }
        }
        public string GetLastRebootTime()
        {
            try
            {
                //ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2","SELECT * FROM Win32_OperatingSystem");
                //foreach (ManagementObject queryObj in searcher.Get())
                //{
                //    Console.WriteLine("-----------------------------------");
                //    Console.WriteLine("Win32_OperatingSystem instance");
                //    Console.WriteLine("-----------------------------------");
                //    Console.WriteLine("LastBootUpTime: {0}", queryObj["LastBootUpTime"]);
                //}

                PerformanceCounter pc = new PerformanceCounter("System", "System Up Time");
                pc.NextValue();
                TimeSpan ts = TimeSpan.FromSeconds(pc.NextValue());
                DateTime dt = DateTime.Now - ts;
                string RebootTime = dt.ToString("dd/MMM/yyyy hh:mm:ss:tt");
                return RebootTime;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                return "Cant Read Reboot Time";
            }
        }

        public List<CPUUtil> GetCPUUsage()
        {
            List<CPUUtil> ObjCPUList = new List<CPUUtil>();
            try
            {
                int CountSec = CPUCheckTimeInSec;
                var process_cpu = new PerformanceCounter("Processor Information", "% Processor Time", "_Total");

                for (int i = 0; i <= CountSec; i++)
                {
                    CPUUtil ObjUtil = new CPUUtil();
                    ObjUtil.CPUUsagePercentage = Convert.ToDecimal(process_cpu.NextValue());
                    ObjUtil.Servertime = DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss:tt");
                    ObjCPUList.Add(ObjUtil);
                    Thread.Sleep(1000);
                }
                ObjCPUList.RemoveAt(0);
                return ObjCPUList;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return ObjCPUList;
            }
        }

        public VMemeoryInfoModel CheckVMemeoryInfo()
        {
            VMemeoryInfoModel ObjMem = new VMemeoryInfoModel();
            try
            {
                long TotalMemeory = GetTotalMemoryInMiB();
                long FreeMemory = GetPhysicalAvailableMemoryInMiB();
                ObjMem.FreeMemory = FreeMemory / 1024;
                ObjMem.TotalMemory = TotalMemeory / 1024;
                ObjMem.FreePercentage = Math.Round((Convert.ToDecimal(ObjMem.FreeMemory) / Convert.ToDecimal(ObjMem.TotalMemory)) * 100, 2);
                return ObjMem;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                return ObjMem;
            }
        }

        public Int64 GetPhysicalAvailableMemoryInMiB()
        {
            try
            {
                PerformanceInformation pi = new PerformanceInformation();
                if (GetPerformanceInfo(out pi, Marshal.SizeOf(pi)))
                {
                    return Convert.ToInt64((pi.PhysicalAvailable.ToInt64() * pi.PageSize.ToInt64() / 1048576));
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return -1;
            }
        }

        public Int64 GetTotalMemoryInMiB()
        {
            try
            {
                PerformanceInformation pi = new PerformanceInformation();
                if (GetPerformanceInfo(out pi, Marshal.SizeOf(pi)))
                {
                    return Convert.ToInt64((pi.PhysicalTotal.ToInt64() * pi.PageSize.ToInt64() / 1048576));
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return -1;
            }
        }

        public List<DriveInfoModel> CheckHDD()
        {
            List<DriveInfoModel> HDDList = new List<DriveInfoModel>();
            try
            {
                ServicetxtLog(InfoFolder, "Info", "Start", MethodBase.GetCurrentMethod().Name.ToString());
                DriveInfo[] drives = DriveInfo.GetDrives();
                foreach (DriveInfo drive in drives)
                {
                    if (drive.IsReady)
                    {
                        DriveInfoModel ObjHDD = new DriveInfoModel();
                        ObjHDD.Name = drive.Name;
                        ObjHDD.TotalSize = Convert.ToInt64(drive.TotalSize / Math.Pow(1024, 3));
                        ObjHDD.FreeSize = Convert.ToInt64(drive.TotalFreeSpace / Math.Pow(1024, 3));
                        ObjHDD.FreePercentage = Math.Round((Convert.ToDecimal(ObjHDD.FreeSize) / Convert.ToDecimal(ObjHDD.TotalSize)) * 100, 2);
                        HDDList.Add(ObjHDD);
                    }
                    else
                    {
                        ServicetxtLog(InfoFolder, "Info", drive.Name + " drive is not ready please check harddisk or network drive", MethodBase.GetCurrentMethod().Name.ToString());
                    }
                }
                ServicetxtLog(InfoFolder, "Info", "End", MethodBase.GetCurrentMethod().Name.ToString());
                return HDDList;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                return HDDList;
            }
        }

        public string GetLocalIPAddress()
        {
            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());
                foreach (var ip in host.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        return ip.ToString();
                    }
                }
                ServicetxtLog(ErrorFolder, "Info", "no network adapters found", MethodBase.GetCurrentMethod().Name.ToString());
                return "no network adapters found";
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                //throw;
                return "";
            }
        }

        public List<TableDataRes> DBTableInfo()
        {
            SqlConnection conn = new SqlConnection(TargetDBConnection);
            List<TableDataRes> ObjListTable = new List<TableDataRes>();
            try
            {
                StringBuilder Sb = new StringBuilder();
                List<TableData> ObjTB = new List<TableData>();
                Sb.Append("DECLARE @Query VARCHAR(MAX),@DBName VARCHAR(100),@TableName VARCHAR(100),@Schema VARCHAR(50),@XMLData XML,@Count INT,@MaxCount INT,@LimitCount BIGINT");
                if (DBTableDetails != "")
                {
                    string[] DBTableArray = DBTableDetails.Split(';');
                    for (int i = 0; i < DBTableArray.Count(); i++)
                    {
                        string[] TablesDetails = DBTableArray[i].Split('.');
                        TableData ObjData = new TableData();
                        ObjData.DBName = TablesDetails[0];
                        ObjData.SchemaName = TablesDetails[1];
                        ObjData.TableName = TablesDetails[2];
                        ObjData.LimitCount = Convert.ToInt64(TablesDetails[3]);
                        ObjTB.Add(ObjData);
                    }
                    string XMLData = ObjectToXMLString(ObjTB);
                    Sb.Append(" SET @XMLData='" + XMLData + "' ");
                    Sb.Append("IF  OBJECT_ID('tempdb..#TempTBLDetails') IS NOT NULL DROP TABLE #TempTBLDetails SELECT IDENTITY(INT) AS ID,DBName = Node.Data.value('(DBName)[1]', 'VARCHAR(100)')," +
                                "TableName = Node.Data.value('(TableName)[1]', 'VARCHAR(100)'),SchemaName = Node.Data.value('(SchemaName)[1]', 'VARCHAR(100)')," +
                                "LimitCount = Node.Data.value('(LimitCount)[1]', 'BIGINT') INTO #TempTBLDetails FROM  @XMLData.nodes('/ArrayOfTableData/TableData') Node(Data)  " +
                                "SET @Count = 1 SELECT @MaxCount = MAX(ID) FROM #TempTBLDetails SET @Query = ''" +
                                " WHILE @Count<=@MaxCount" +
                                    " BEGIN SELECT @DBName = DBName, @TableName = TableName, @Schema = SchemaName,@LimitCount=LimitCount FROM #TempTBLDetails Where ID=@Count" +
                                    " SELECT @Query = ISNULL(@Query, '') + ' SELECT ' + CAST(@Count AS VARCHAR(MAX)) + ' AS ''ID'','''+CAST(@DBName AS VARCHAR(MAX))+'.'+CAST(@Schema AS VARCHAR(MAX))+'.'+CAST(@TableName AS VARCHAR(MAX))+''' AS ''Table'', SUM(p.rows) AS ''RowCount'','+CAST(@LimitCount AS VARCHAR(MAX))+' AS ''LimitCount'' " +
                                    " FROM '+CAST(@DBName AS VARCHAR(MAX))+'.sys.partitions AS p " +
                                    " INNER JOIN '+CAST(@DBName AS VARCHAR(MAX))+'.sys.tables AS t ON p.[object_id] = t.[object_id]" +
                                    " INNER JOIN '+CAST(@DBName AS VARCHAR(MAX))+'.sys.schemas AS s ON s.[schema_id] = t.[schema_id] WHERE t.name = '''+CAST(@TableName AS VARCHAR(MAX))+'''" +
                                    " AND s.name = '''+CAST(@Schema AS VARCHAR(MAX))+''' AND p.index_id IN(0, 1) UNION ALL' SET @DBName = NULL SET @TableName = NULL SET @Schema = NULL" +
                                    " SET @Count = @Count + 1 END " +
                                    " SELECT @Query=REVERSE(@Query) SELECT @Query = (REVERSE(Right(@Query, Len(@Query) - 9))) EXEC(@Query)");

                    DataTable dt = new DataTable();
                    SqlCommand cmd = new SqlCommand(Sb.ToString(), conn);
                    if ((conn.State == ConnectionState.Closed))
                    {
                        conn.Open();
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    conn.Close();
                    da.Dispose();
                    foreach (DataRow dr in dt.Rows)
                    {
                        TableDataRes ObjRes = new TableDataRes();
                        ObjRes.ID = Convert.ToInt32(dr["ID"]);
                        ObjRes.LimitCount = Convert.ToInt64(dr["LimitCount"]);
                        ObjRes.RowCount = Convert.ToInt64(dr["RowCount"]);
                        ObjRes.Table = Convert.ToString(dr["Table"]);
                        ObjListTable.Add(ObjRes);
                    }
                    return ObjListTable;
                }
                else
                {
                    ServicetxtLog(InfoFolder, "Info", "DBTable details are blank", MethodBase.GetCurrentMethod().Name.ToString());
                    return ObjListTable;
                }
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                throw;
            }
            finally
            {
                if ((conn.State == ConnectionState.Open))
                {
                    conn.Close();
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }

        public string ObjectToXMLString<T>(T objT)
        {
            string strXML = string.Empty;
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlSerializer xmlSerializer = new XmlSerializer(objT.GetType());
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, objT);
                    xmlStream.Position = 0;
                    xmlDoc.Load(xmlStream);
                    strXML = Convert.ToString(xmlDoc.InnerXml);
                }
                return strXML;
            }
            catch (Exception ex)
            {
                ServicetxtLog(ErrorFolder, "Error", ex.Message.ToString(), MethodBase.GetCurrentMethod().Name.ToString());
                throw;
            }
        }

        public void ServicetxtLog(string Folder, string MsgType, string ErrorMsg, string MethoName)
        {
            LogFile = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + ConfigurationManager.AppSettings.Get("LogFile").ToString();
            LogFile = LogFile + Folder + "\\Log" + "_" + DateTime.Now.Year.ToString() + DateTime.Now.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
            File.AppendAllText(LogFile, "\n" + DateTime.Now.ToString() + " Method :" + MethoName + " " + MsgType + ":" + ErrorMsg);
        }
        public void ServicetxtLog(string Folder, string MsgType, string ErrorMsg, string MethoName, bool isDeleteFlag)
        {
            LogFile = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + ConfigurationManager.AppSettings.Get("LogFile").ToString();
            LogFile = LogFile + Folder + "\\Log_Del" + "_" + DateTime.Now.Year.ToString() + DateTime.Now.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
            File.AppendAllText(LogFile, "\n" + DateTime.Now.ToString() + " Method :" + MethoName + " " + MsgType + ":" + ErrorMsg);
        }
        public void ServicetxtLog(string Folder, string MsgType, string ErrorMsg, string MethoName, bool isDeleteFlag, bool isDB)
        {
            LogFile = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + ConfigurationManager.AppSettings.Get("LogFile").ToString();
            LogFile = LogFile + Folder + "\\Log_DB" + "_" + DateTime.Now.Year.ToString() + DateTime.Now.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
            File.AppendAllText(LogFile, "\n" + DateTime.Now.ToString() + " Method :" + MethoName + " " + MsgType + ":" + ErrorMsg);
        }
    }
}
