﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


namespace MOAMC_WhiteH_MOT.Model
{
    public class DriveInfoModel
    {
        public string Name { get; set; }
        public long TotalSize { get; set; }
        public long FreeSize { get; set; }
        public decimal FreePercentage { get; set; }
    }

    public class DriveObjectSize
    {
        public string SrNo { get; set; }
        public string Location { get; set; }
        public string SizeInMB { get; set; }
        public string SizeInGB { get; set; }
    }

    public class VMemeoryInfoModel
    {
        public long TotalMemory { get; set; }
        public long FreeMemory { get; set; }
        public decimal FreePercentage { get; set; }
    }
    public class BackGroundService
    {
        public string ServiceName { get; set; }
        public string ServiceStatus { get; set; }
    }
    public class DataList
    {
        public string Location { get; set; }
        public decimal SizeInMB { get; set; }
        public decimal SizeInGB { get; set; }
    }

    public class HWSWInfo
    {
        public List<DriveInfoModel> HDD { get; set; }
        public List<DriveObjectSize> HDOSize { get; set; }
        public VMemeoryInfoModel MemoryInfo { get; set; }
        public List<CPUUtil> CPUUtilization { get; set; }
        public string ServerRebootTime { get; set; }
        public List<BackGroundService> BGServiceStatus { get; set; }
        public List<TableDataRes> TableDataRes { get; set; }
        public List<UrlsCheckData> URLStatus { get; set; }
        public List<SSLDetails> SSLDetails { get; set; }
    }
    public class PerformanceInfo
    {
        [DllImport("psapi.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetPerformanceInfo([Out] out PerformanceInformation PerformanceInformation, [In] int Size);
        [StructLayout(LayoutKind.Sequential)]
        public struct PerformanceInformation
        {
            public int Size;
            public IntPtr CommitTotal;
            public IntPtr CommitLimit;
            public IntPtr CommitPeak;
            public IntPtr PhysicalTotal;
            public IntPtr PhysicalAvailable;
            public IntPtr SystemCache;
            public IntPtr KernelTotal;
            public IntPtr KernelPaged;
            public IntPtr KernelNonPaged;
            public IntPtr PageSize;
            public int HandlesCount;
            public int ProcessCount;
            public int ThreadCount;
        }
    }
    public class CPUUtil
    {
        public decimal CPUUsagePercentage { get; set; }
        public string Servertime { get; set; }
    }
    public class TableData
    {
        public string DBName { get; set; }
        public string TableName { get; set; }
        public string SchemaName { get; set; }
        public long LimitCount { get; set; }
    }

    public class TableDataRes
    {
        public int ID { get; set; }
        public string Table { get; set; }
        public long RowCount { get; set; }
        public long LimitCount { get; set; }
    }
    public class UrlsCheckData
    {
        public string URL { get; set; }
        public string StatusMessage { get; set; }
    }
    public class SSLDetails
    {
        public string URL { get; set; }
        public string Name { get; set; }
        public string ExpirationDate { get; set; }
    }
}
