﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace MOAMC_WhiteH_MOT
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            //ServiceBase[] ServicesToRun;
            //ServicesToRun = new ServiceBase[]
            //{
            //    new MonitorServices()
            //};
            //ServiceBase.Run(ServicesToRun);
            MonitorServices ObjSer = new MonitorServices();
            ObjSer.ServiceWorker();
        }
    }
}
