﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using BoardMeetingAPI.Model;
using Microsoft.Extensions.Configuration;
using Dapper;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace BoardMeetingAPI.Repository
{
    public class Login
    {
        private readonly IConfiguration Iconfiguration;
        public string ConString;
        public string ErrorLog = string.Empty;
        public string Key = string.Empty;
        public Login(IConfiguration iconfiguration)
        {
            Iconfiguration = iconfiguration;
            ConString = Iconfiguration["DBConnection:BoardMeetingCon"];
            ErrorLog= Iconfiguration["ErrorLog"];
            Key= Iconfiguration["SecretKey"];
        }
        public IsAuthResponse IsAuth(LoginModel ObjLoginModel)
        {
            try
            {
                IsAuthResponse ObjIsAuthResponse = new IsAuthResponse();
                bool IsAuth = false;
                using (var connection = new SqlConnection(ConString))
                {
                    var ResData = connection.QuerySingle("usp_CheckBoardLogin", new
                    {
                        LoginId = ObjLoginModel.LoginId,
                        Password = ObjLoginModel.Password
                    }, commandType: CommandType.StoredProcedure);
                    {
                        if (Convert.ToBoolean(ResData.IsValid) == true)
                        {
                            IsAuth = true;
                            ObjIsAuthResponse.IsValid = IsAuth;
                            var tokenHandler = new JwtSecurityTokenHandler();
                            var key = Encoding.ASCII.GetBytes(Key);
                            var tokenDescriptor = new SecurityTokenDescriptor
                            {
                                Subject = new ClaimsIdentity(new Claim[]
                                {
                                    new Claim(ClaimTypes.Name,ObjLoginModel.LoginId)
                                }),
                                Expires = DateTime.UtcNow.AddDays(7),
                                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                            };
                            var token = tokenHandler.CreateToken(tokenDescriptor);
                            ObjIsAuthResponse.Token = tokenHandler.WriteToken(token);
                        }
                    }
                    return ObjIsAuthResponse;
                }
            }
            catch (Exception Ex)
            {
                Utilities.Utilities.LogErrors(ErrorLog, "IsAuth", Convert.ToString(Ex.Message));
                throw;
            }
        }
    }
}
