﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BoardMeetingAPI.Repository;
using BoardMeetingAPI.Model;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
namespace BoardMeetingAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration _configuration;
        public LoginController(IConfiguration Configuration)
        {
            _configuration = Configuration;
        }

        //[Authorize]
        //[HttpGet]
        //public ActionResult TestAuthUser()
        //{
        //    return Ok("Auth");
        //}

        [HttpPost]
        public ActionResult AuthUser([FromBody]LoginModel ObjLoginModel)
        {
            Login ObjLogin = new Login(_configuration);
            return Ok(ObjLogin.IsAuth(ObjLoginModel));
        }
    }
}