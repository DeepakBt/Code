﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;

namespace BAL
{
   public class SurveyBAL
    {
        SqlCommand cmd;
        public QuestionList GetQuestions(CommonFilters objFilter)
        {
            try
            {
                cmd = new SqlCommand();
                DataSet dsResult;
                QuestionList objQuestionList = new QuestionList();
                cmd.Parameters.AddWithValue("@Flag", objFilter.Flag);
                cmd.Parameters.AddWithValue("@OptionId", objFilter.OptionId);
                cmd.Parameters.AddWithValue("@POptionId", objFilter.POptionId);

                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_SURVEY_QUESTIONS");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        objQuestionList.Questions = new List<Question>();

                        foreach (DataRow Qr in dsResult.Tables[0].Rows)
                        {
                            Question objQuestions = new Question();
                            objQuestions.Options = new List<QuestionOption>();
                            objQuestions.QuestionId = Convert.ToInt32(Qr["QuestionId"]);
                            objQuestions.Questions = Convert.ToString(Qr["Question"]);
                            objQuestions.HasChild = Convert.ToBoolean(Qr["HasChild"] == DBNull.Value ? false : Qr["HasChild"]);
                            objQuestions.UserPreference = Convert.ToBoolean(Qr["UserPreference"] == DBNull.Value ? false : Qr["UserPreference"]);
                            foreach (DataRow Or in dsResult.Tables[1].Rows)
                            {
                                if (objQuestions.QuestionId == Convert.ToInt32(Or["QuestionId"]))
                                {
                                    QuestionOption objOptions = new QuestionOption();
                                    objOptions.OptionId = Convert.ToInt32(Or["OptionId"]);
                                    objOptions.Option = Convert.ToString(Or["Options"]);
                                    objQuestions.Options.Add(objOptions);
                                }
                            }
                            objQuestionList.Questions.Add(objQuestions);
                        }
                    }
                }
                return objQuestionList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertSurvey(string SurveyXML)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", SurveyXML);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_SURVEY_SAVE_SURVEY_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
