﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using DAL;
using Newtonsoft.Json;

namespace BAL
{
    public static class Utilities
    {
        static SqlCommand cmd;
        private static ATLoggerClass.ATFileLogger log = new ATLoggerClass.ATFileLogger();
        public static string dtToJson(DataTable dt)
        {
            try
            {
                if (dt != null)
                {
                    System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                    List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                    Dictionary<string, object> row;
                    foreach (DataRow dr in dt.Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (DataColumn col in dt.Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    return serializer.Serialize(rows);
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string dsToJson(DataSet ds)
        {
            try
            {
                return JsonConvert.SerializeObject(ds, Newtonsoft.Json.Formatting.Indented);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ObjectToXMLString<T>(T objT)
        {
            string strXML = string.Empty;
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlSerializer xmlSerializer = new XmlSerializer(objT.GetType());
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, objT);
                    xmlStream.Position = 0;
                    xmlDoc.Load(xmlStream);
                    strXML = Convert.ToString(xmlDoc.InnerXml);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strXML;
        }

        public static string ApplicationPath()
        {
            try
            {
                string lAppName = System.Web.HttpContext.Current.Server.MapPath(Convert.ToString(ConfigurationSettings.AppSettings["LogFolder"]));
                string lExecutionPath = System.IO.Path.GetDirectoryName(lAppName);
                return lExecutionPath;
            }
            catch (System.Exception ex)
            {
                return string.Empty;
            }
        }

        public static void ApiErrorLog(string ErrorMsg, string ErrorActionMethod, string ErrorSource)
        {
            log = new ATLoggerClass.ATFileLogger();
            log.Path = Utilities.ApplicationPath() + "\\Log";
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@ErrMsg", ErrorMsg);
                cmd.Parameters.AddWithValue("@ActionMethod", ErrorActionMethod);
                cmd.Parameters.AddWithValue("@ErrorSource", ErrorSource);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_LOG_API_ERROR");
            }
            catch (Exception ex)
            {
                log.Log("ApiErrorLog :" + ex.Message + " ErrorMsg : " + ErrorMsg + " ErrorActionMethod : " + ErrorActionMethod + " ErrorSource : " + ErrorSource);
            }
        }
        public static List<int> AllIndexesOf(this string str, string value)
        {
            try
            {
                if (String.IsNullOrEmpty(value))
                    throw new ArgumentException("the string to find may not be empty", "value");
                List<int> indexes = new List<int>();
                for (int index = 0; ; index += value.Length)
                {
                    index = str.IndexOf(value, index);
                    if (index == -1)
                        return indexes;
                    indexes.Add(index);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string AddOrdinal(int num)
        {
            try
            {
                if (num <= 0) return num.ToString();

                switch (num % 100)
                {
                    case 11:
                    case 12:
                    case 13:
                        return num + "th";
                }

                switch (num % 10)
                {
                    case 1:
                        return num + "st";
                    case 2:
                        return num + "nd";
                    case 3:
                        return num + "rd";
                    default:
                        return num + "th";
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
