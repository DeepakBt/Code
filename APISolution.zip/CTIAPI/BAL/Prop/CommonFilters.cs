﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
   public class CommonFilters
    {
        public int? Flag { get; set; }
        public int? OptionId { get; set; }
        public int? POptionId { get; set; }
    }
}
