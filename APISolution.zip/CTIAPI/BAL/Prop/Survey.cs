﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class Survey
    {
        public string EmpName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string OptionId { get; set; }
        public string Location { get; set; }
    }
    public class QuestionList
    {
        public List<Question> Questions { get; set; }
    }
    public class Question
    {
        public int QuestionId { get; set; }
        public string Questions { get; set; }
        public bool HasChild { get; set; }
        public bool UserPreference { get; set; }
        public List<QuestionOption> Options { get; set; }
    }
    public class QuestionOption
    {
        public int OptionId { get; set; }
        public string Option { get; set; }
    }
}
