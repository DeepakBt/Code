﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class CTIData
    {
        public string ID { get; set; }
        public int CHANNEL_NO { get; set; }
        public string REMARK { get; set; }
        public string START_DATE { get; set; }
        public string START_TIME { get; set; }
        public string DURATION { get; set; }
        public string CALLERPHN { get; set; }
        public string CALLERNAME { get; set; }
        public string CALL_TYPE { get; set; }
        public string CALLEDPHN { get; set; }
        public string CALLEDNAME { get; set; }
        public string CHANNEL_TYPE { get; set; }
        public string AGENT_NAME { get; set; }
        public string FILE_NAME { get; set; }
        public string USER_NAME { get; set; }
        public string PASSWORD { get; set; }
    }
}
