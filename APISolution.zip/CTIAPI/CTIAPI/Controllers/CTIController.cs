﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BAL;
using BAL.Prop;
namespace AppApi.Controllers
{
    public class CTIController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        public IHttpActionResult PostCTIData(List<CTIData> objLstCTI)
        {
            string JsonResponse = string.Empty;
            CTIBAL objCTIBAL = new CTIBAL();
            try
            {
                JsonResponse = objCTIBAL.InsertCTIData(Utilities.ObjectToXMLString(objLstCTI));
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message, @"CTI\PostCTIData", "API");
                throw new HttpResponseException(badRequest);
            }
        }
    }
}
