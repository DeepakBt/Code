﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BAL;
using BAL.Prop;

namespace CTIAPI.Controllers
{
    public class SurveyController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetSurveyQuestions(CommonFilters objFilter)
        {
            try
            {
                SurveyBAL objSurveyBAL = new SurveyBAL();
                QuestionList objQuestionList = new QuestionList();
                objQuestionList = objSurveyBAL.GetQuestions(objFilter);
                return Ok(objQuestionList);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Survey\GetSurveyQuestions", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult PostSurvey(Survey objSurvey)
        {
            SurveyBAL objSurveyBAL = new SurveyBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (objSurvey != null)
                {
                    JsonResponse = objSurveyBAL.InsertSurvey(Utilities.ObjectToXMLString(objSurvey));
                }
                else
                {
                    throw new Exception("Fill Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Survey\PostSurvey", "API");
                throw new HttpResponseException(badRequest);
            }
        }
    }
}
