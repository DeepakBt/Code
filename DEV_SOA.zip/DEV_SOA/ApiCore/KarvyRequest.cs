﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Newtonsoft.Json;

namespace karvyAPI
{
    public class KarvyRequest
    {
        public static string CreateHTTPRequest(string APIName, string serviceUrl, string inputJson)
        {
            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(serviceUrl + "/" + APIName));
            httpRequest.Accept = "application/json";
            httpRequest.ContentType = "application/json";
            httpRequest.Method = "POST";

            byte[] bytes = Encoding.UTF8.GetBytes(inputJson);

            using (Stream stream = httpRequest.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Close();
            }
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string result = "";
            try
            {

                using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
                {
                    using (Stream stream = httpResponse.GetResponseStream())
                    {
                        string s = (new StreamReader(stream)).ReadToEnd();
                        result = JsonConvert.DeserializeObject(s).ToString();
                        return result;
                        //   return httpRequest;
                    }
                }
            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\KarvyAPIError.txt", "\r\n" + DateTime.Now.ToString() + " " + APIName + " Error : " + ex.Message);
                return "";
            }
        }

        public static string GenerateAccountStatementMF(string serviceUrl, string inputJson, string FilePath)
        {
            try
            {
                string filename = "";
                string url = serviceUrl + inputJson;
                WebClient webC = new WebClient();
                File.AppendAllText("D:\\KarvyAPIError.txt", "GenerateAccountStatementMF FinalURL : " + url);
                string s = webC.DownloadString(url);
                XmlDocument xmlData = new XmlDocument();
                xmlData.LoadXml(s);
                string result = xmlData.GetElementsByTagName("SoaStreame")[0].InnerXml;
                string PanNo = xmlData.GetElementsByTagName("Pan")[0].InnerXml;
                if (s.Contains("Success"))
                {
                    byte[] fileData = Convert.FromBase64String(result);
                    filename = PanNo.Trim() + "_AccountStatement_" + Guid.NewGuid().ToString() + ".pdf";
                    FileStream oFileStream = new FileStream(FilePath + filename, FileMode.Create);
                    oFileStream.Write(fileData, 0, fileData.Length);
                    oFileStream.Close();
                    return filename;
                }
                else
                {
                    return "";
                }

            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\KarvyAPIError.txt", "\r\n" + DateTime.Now.ToString() + " GenerateAccountStatementMF Error : " + ex.Message);
                return "";
            }
        }

        public static string DateConvert(string date, string format)
        {
            string newString = string.Empty;
            if (!string.IsNullOrEmpty(date))
            {
                if (date.Contains('-'))
                {
                    date = date.Replace('-', '/');
                }
                DateTime dt = DateTime.ParseExact(date, "d/M/yyyy", CultureInfo.InvariantCulture);
                newString = dt.ToString(format);
            }
            return newString;
        }
    }
}
