﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ApiCore.Validation
{
    public class DateFormatValidationAttribute : ValidationAttribute
    {
        public string dateFormat;
        public DateFormatValidationAttribute(string format)
        {
            this.dateFormat = format;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            try
            {
               DateTime.ParseExact(Convert.ToString(value), dateFormat, System.Globalization.CultureInfo.InvariantCulture);
              return ValidationResult.Success;
            }
            catch
            {

            }
            return new ValidationResult("Date must be in format : " + dateFormat);
        }
    }

}
