﻿using ApiCore.Exceptions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Configuration;
namespace ApiCore.Helpers
{
    public static class Utilities
    {
        public static string ObjectToXMLString<T>(T objT)
        {
            string strXML = string.Empty;
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlSerializer xmlSerializer = new XmlSerializer(objT.GetType());
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, objT);
                    xmlStream.Position = 0;
                    xmlDoc.Load(xmlStream);
                    strXML = Convert.ToString(xmlDoc.InnerXml);
                }
            }
            catch (Exception ex)
            {
                throw new NoDataException(false);
            }
            return strXML;
        }
        public static string CreateHTTPPOSTRequest(string serviceUrl, string inputJson)
        {
            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(serviceUrl));
            httpRequest.Accept = "application/json";
            httpRequest.ContentType = "application/json";
            httpRequest.Method = "POST";

            byte[] bytes = Encoding.UTF8.GetBytes(inputJson);

            using (Stream stream = httpRequest.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Close();
            }
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string result = "";
            try
            {

                using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
                {
                    using (Stream stream = httpResponse.GetResponseStream())
                    {
                        string s = (new StreamReader(stream)).ReadToEnd();
                        result = JsonConvert.DeserializeObject(s).ToString();
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\UtilitiesCreateHTTPPOSTRequest.txt", "\r\n" + DateTime.Now.ToString() + " " + serviceUrl + " Error : " + ex.Message);
                return "";
            }
        }
        public static string CreateHTTPGETRequest(string serviceUrl)
        {
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(serviceUrl);
                request.Method = "GET";
                request.Accept = "application/json";
                request.ContentType = "application/json";

                var content = string.Empty;

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    using (var stream = response.GetResponseStream())
                    {
                        using (var sr = new StreamReader(stream))
                        {
                            content = sr.ReadToEnd();
                        }
                    }
                }
                return content;
            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\UtilitiesCreateHTTPGETRequest.txt", "\r\n" + DateTime.Now.ToString() + " " + serviceUrl + " Error : " + ex.Message);
                return "";
            }
        }
        public static bool ContainsXHTML(string input)
        {
            try
            {
                if (input == "" || input == null)
                {
                    return false;
                }
                XElement x = XElement.Parse("<wrapper>" + input + "</wrapper>");
                return !(x.DescendantNodes().Count() == 1 && x.DescendantNodes().First().NodeType == XmlNodeType.Text);
            }
            catch (XmlException ex)
            {
                if (input.Contains(">") || input.Contains("<"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool CheckSpecialChar(string input)
        {
            try
            {
                //var regexItem = new Regex(@"^[a-zA-Z0-9 ._%$#/&@!*,;-]*$");
                if (input == "" || input == null)
                {
                    return false;
                }
                else if (input.Contains(">") || input.Contains("<"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
        }
        public static void LogErrors(string ErrorLogFile, string MethodName, string Message)
        {
            ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
            File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + MethodName + " \r ERROR:" + Message);
        }

        public static string DateDiffInYear(DateTime Dt1, DateTime Dt2)
        {
            string YearMonth = "";
            DateTime zeroTime = new DateTime(1, 1, 1);
            TimeSpan span = Dt2 - Dt1;
            int years = (zeroTime + span).Year - 1;
            int months = (zeroTime + span).Month - 1;
            YearMonth = Convert.ToString(years) + "." + Convert.ToString(months);
            return YearMonth;
        }

        public static string StringEncrypt(string input)
        {
            string key = string.Empty;
            key = ConfigurationManager.AppSettings["MyKey"];
            byte[] inputArray = UTF8Encoding.UTF8.GetBytes(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        public static string StringDecrypt(string input)
        {
            string key = string.Empty;
            key = ConfigurationManager.AppSettings["MyKey"];
            byte[] inputArray = Convert.FromBase64String(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }

        public static void ConvertToFile(string Path, string FileName, string FileExtension, string Base64String)
        {
            try
            {
                byte[] BinData = Convert.FromBase64String(Base64String);
                FileName = FileName + "." + FileExtension;
                Path = Path + FileName;
                using (FileStream FileWriter = new FileStream(Path, FileMode.Create, FileAccess.Write))
                {
                    FileWriter.Write(BinData, 0, BinData.Length);
                }
               // File.WriteAllBytes(Path, Convert.FromBase64String(Base64String));
            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\UtilitiesCreateHTTPPOSTRequest.txt", "\r\n" + DateTime.Now.ToString() + " " + "ConvertToFile Method in Utilities" + " Error : " + ex.Message);
                throw ex;
            }
        }
    }
}
