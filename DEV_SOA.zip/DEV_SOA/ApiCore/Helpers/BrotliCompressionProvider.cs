﻿using System.IO;
using System.IO.Compression;
using BrotliSharpLib;
using Microsoft.AspNetCore.ResponseCompression;

namespace APICore.Helpers
{
    public class BrotliCompressionProvider : ICompressionProvider
    {
        public string EncodingName => "br";
        public bool SupportsFlush => true;

        public Stream CreateStream(Stream outputStream)
        {
            return new BrotliSharpLib.BrotliStream(outputStream, CompressionMode.Compress);
        }
    }
}