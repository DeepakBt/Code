﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Helpers;
using ApiCore.Model;
using AutoMapper.Configuration;
using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;

namespace APICore.Helpers
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;

        private static readonly ILogger Logger = Log.ForContext<ErrorHandlingMiddleware>();

        private const string MessageTemplate =
            "HTTP,{RequestMethod},{RequestPath},{StatusCode}";

        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context /* other scoped dependencies */)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex) when (LogException(context, ex))
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var code = HttpStatusCode.InternalServerError; // 500 if unexpected

            /*if      (exception is MyNotFoundException)     code = HttpStatusCode.NotFound;
            else if (exception is MyUnauthorizedException) code = HttpStatusCode.Unauthorized;
            else if (exception is MyException)             code = HttpStatusCode.BadRequest;*/

            string result = null;
            if (exception is NoDataException)
            {
                var noDataException = (NoDataException)exception;
                if (noDataException.isList)
                {
                    code = HttpStatusCode.OK;
                    result = JsonConvert.SerializeObject(new ResponseDataArrayModel<string>(new List<string>(), noDataException.errorCode));
                }
                else
                {
                    code = HttpStatusCode.OK;
                    result = JsonConvert.SerializeObject(new ResponseDataModel<string>(null, noDataException.errorCode));
                }
            }
            else if (exception is LogDBException)
            {
                var _LogDataException = (LogDBException)exception;
                code = HttpStatusCode.OK;
                result = JsonConvert.SerializeObject(new ResponseDataModel<string>(null, Convert.ToString(_LogDataException.Message)));
            }
            else
            {
                result = JsonConvert.SerializeObject(new { error = exception.Message });
            }
            context.Response.Headers.Remove("Cache-Control");
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            return context.Response.WriteAsync(result == null ? code.ToString() : result);
        }

        private static bool LogException(HttpContext httpContext, Exception ex)
        {
            if (ex is NoDataException)
            {

            }
            else
            {
                string ErrorMessage = ex.Message;
                string StackTrace = ex.StackTrace;
                string ExceptionType = ex.GetType().FullName;
                string userid = string.Empty;

                string DisplayURL = Microsoft.AspNetCore.Http.Extensions.UriHelper.GetDisplayUrl(httpContext.Request);
                string ExceptionURL = DisplayURL; //Convert.ToString(httpContext.Request.Host.Value) + Convert.ToString(httpContext.Request.Path);

                LogForErrorContext(httpContext)
                .Error(ex, MessageTemplate, httpContext.Request.Method, httpContext.Request.Path,
                    HttpStatusCode.InternalServerError);
                string PANNo = httpContext.User.Identity.Name + '|' + HeaderAccessors.GetAppId(httpContext.Request.Headers);

                ErrorHandlingDB.LogExceptionDB(ErrorMessage, StackTrace, ExceptionType, ExceptionURL, PANNo);
            }
            return true;
        }

        private static ILogger LogForErrorContext(HttpContext httpContext)
        {
            var request = httpContext.Request;

            var result = Logger
                .ForContext("RequestHeaders", request.Headers.ToDictionary(h => h.Key, h => h.Value.ToString()),
                    true)
                .ForContext("RequestHost", request.Host)
                .ForContext("RequestProtocol", request.Protocol);

            if (request.HasFormContentType)
                result = result.ForContext("RequestForm",
                    request.Form.ToDictionary(v => v.Key, v => v.Value.ToString()));

            return result;
        }


    }
}