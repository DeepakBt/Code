﻿using ApiCore.Exceptions;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using ApiCore.Model;


namespace ApiCore.Helpers
{
   public class CVLPanKycData
    {
        private readonly IConfiguration _iconfiguration;
        public string ErrorLogFile;
        public CVLPanKycData(IConfiguration iconfiguration)
        {
            _iconfiguration = iconfiguration;
        }
        public string GetPanServiceKYC_Data(RequestPANKYC ObjPAN)
        {
            string ResponsePanXMLData = string.Empty;
            string PanDOB = string.Empty;
            string poscode = string.Empty;
            string username = string.Empty;
            string password = string.Empty;
            string passkey = string.Empty;
            string CVLAPI = string.Empty;
            string inputXML = string.Empty;
            string CVLParam = string.Empty;
            try
            {
                PanDOB = "01/01/1900";
                poscode = _iconfiguration["panEnquiry:poscode"];
                username = _iconfiguration["panEnquiry:username"];
                password = _iconfiguration["panEnquiry:password"];
                passkey = _iconfiguration["panEnquiry:passkey"];
                CVLAPI = _iconfiguration["panEnquiry:CVLAPI"];
                inputXML = "<APP_REQ_ROOT>" +
                                               "<APP_PAN_INQ> " +
                                                   "<APP_PAN_NO>" + ObjPAN.panNo + "</APP_PAN_NO> " +
                                                   "<APP_DOB_INCORP>" + PanDOB + "</APP_DOB_INCORP> " +
                                                   "<APP_POS_CODE >" + poscode + "</APP_POS_CODE> " +
                                                   "<APP_RTA_CODE>" + poscode + "</APP_RTA_CODE> " +
                                                   "<APP_KRA_CODE>CVLKRA</APP_KRA_CODE> " +
                                                   "<FETCH_TYPE>X</FETCH_TYPE> " +
                                               "</APP_PAN_INQ>" +
                                           "</APP_REQ_ROOT> ";

                CVLParam = "inputXML=" + inputXML + "&userName=" + username + "&PosCode=" + poscode + "&password=" + password + "&PassKey=" + passkey;
                using (WebClient wc = new WebClient())
                {
                    wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                    ResponsePanXMLData = wc.UploadString(CVLAPI, CVLParam);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "CVLErrorLog_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                System.IO.File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r\n URL" + CVLAPI + "\r\n REQUEST:" + CVLParam + "\r\n ERROR:" + ex.Message);
                throw new NoDataException(false);
            }
            return ResponsePanXMLData;
        }

        public string GetPanKycStatus(RequestPANKYCStatus ObjPAN)
        {
            string ResponsePanXMLData = string.Empty;
            string PanDOB = string.Empty;
            string poscode = string.Empty;
            string username = string.Empty;
            string password = string.Empty;
            string passkey = string.Empty;
            string CVLAPI = string.Empty;
            string inputXML = string.Empty;
            string CVLParam = string.Empty;
            try
            {

               

                
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "CVLErrorLog_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                System.IO.File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r\n URL" + CVLAPI + "\r\n REQUEST:" + CVLParam + "\r\n ERROR:" + ex.Message);
                throw new NoDataException(false);
            }
            return ResponsePanXMLData;
        }
    }
}
