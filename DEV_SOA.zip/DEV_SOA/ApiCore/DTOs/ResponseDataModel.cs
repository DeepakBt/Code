﻿namespace ApiCore.DTOs
{
    public class ResponseDataModel<T>
    {

        public bool success { get; set; }
        public T data { get; set; }
        public string message { get; set; }

        public ResponseDataModel(T data) : this(data, "No Data Available.", "Successful")
        {
        }

        public ResponseDataModel(T data, string message): this(data, message, message)
        {
        }

        public ResponseDataModel(T data, string errorMessage, string successMesssage = "Successful")
        {
            if (data != null)
            {
            
                success = successMesssage == "Successful" ? true :false;
                this.data = data;
                message = successMesssage;
            }
            else
            {
                success = false;
                message = errorMessage;
            }
        }
    }
}