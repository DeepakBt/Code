﻿using System.Text;
using APICore.Auth;

namespace APICore.Constants
{
    public class TokenConstants
    {
        public const string ClaimAppId = "appid";
        public const string ClaimTokenType = "ttyp";
        public const string ClaimUserSecret = "usec";
        public const string ClaimPanNo = "panNo";
        public const string ClaimUserId = "userid";
        public const string TokenTypeAccess = "access_token";
        public const string TokenTypeRefresh = "refresh_token";
    }
    public class RefreshTokenConstants
    {
        public const string ClaimAppId = "appid";
        public const string ClaimTokenType = "ttyp";
        public const string ClaimUserSecret = "usec";
        public const string ClaimPanNo = "panNo";
        public const string TokenTypeAccess = "access_token";
        public const string TokenTypeRefresh = "refresh_token";
    }
}