﻿namespace ApiCore.Constants
{
    public class HeaderConstants
    {
        public const string AppId = "appId";
        public const string LoginId = "loginId";
        public const string UserAgent = "UserAgent";
        public const string Authorization = "Authorization";
    }
}