﻿using System;
using System.Configuration;
using System.IO;
using System.Security.Cryptography;
using ApiCore.Auth;
using ApiCore.Model;
using APICore.Helpers;
using Microsoft.IdentityModel.Tokens;

namespace APICore.Auth
{
    public class RSAProvider
    {
        private static SecurityKey _accessTokenSigningKey;
        private static SecurityKey _refreshTokenSigningKey;
        public static SigningCredentials AccessTokenSigningCredentials { get; set; }
        public static SigningCredentials RefreshTokenSigningCredentials { get; set; }
        public static TokenValidationParameters AccessTokenValidationParameters { get; set; }
        public static TokenValidationParameters RefreshTokenValidationParameters { get; set; }
        static string _containerName = "AMCAPIkey";
        public static void InitializeTokens(JwtSettings settings)
        {
            InitializeAccessTokenRsa(settings);
            InitializeRefreshTokenRsa(settings);
        }
        public static void InitializeAccessTokenRsa(JwtSettings settings)
        {
            if (string.IsNullOrWhiteSpace(settings.AccessTokenPublicKey))
            {
                return;
            }
            var publicRsa = RSA.Create();

            var publicKeyXml = File.ReadAllText(settings.AccessTokenPublicKey);
            publicRsa.FromXmlFileString(publicKeyXml);
            _accessTokenSigningKey = new RsaSecurityKey(publicRsa);

            AccessTokenValidationParameters = new TokenValidationParameters()
            {
                IssuerSigningKey = _accessTokenSigningKey,
                ValidAudience = settings.Audience,
                ValidIssuer = settings.Issuer
            };
            if (string.IsNullOrWhiteSpace(settings.AccessTokenPrivateKey))
            {
                return;
            }
            var privateRsa = RSA.Create();

            var privateKeyXml = File.ReadAllText(settings.AccessTokenPrivateKey);
            privateRsa.FromXmlFileString(privateKeyXml);
            var privateKey = new RsaSecurityKey(privateRsa);
            AccessTokenSigningCredentials = new SigningCredentials(privateKey, SecurityAlgorithms.RsaSha256);
        }

        public static void InitializeRefreshTokenRsa(JwtSettings settings)
        {
            if (string.IsNullOrWhiteSpace(settings.RefreshTokenPublicKey))
            {
                return;
            }
            var publicRsa = RSA.Create();

            var publicKeyXml = File.ReadAllText(settings.RefreshTokenPublicKey);
            publicRsa.FromXmlFileString(publicKeyXml);
            _refreshTokenSigningKey = new RsaSecurityKey(publicRsa);

            RefreshTokenValidationParameters = new TokenValidationParameters()
            {
                IssuerSigningKey = _refreshTokenSigningKey,
                ValidAudience = settings.Audience,
                ValidIssuer = settings.Issuer
            };
            if (string.IsNullOrWhiteSpace(settings.RefreshTokenPrivateKey))
            {
                return;
            }
            var privateRsa = RSA.Create();

            var privateKeyXml = File.ReadAllText(settings.RefreshTokenPrivateKey);
            privateRsa.FromXmlFileString(privateKeyXml);
            var privateKey = new RsaSecurityKey(privateRsa);
            RefreshTokenSigningCredentials = new SigningCredentials(privateKey, SecurityAlgorithms.RsaSha256);
        }

        public static RSACryptoServiceProvider GetKey()
        {
            // Create the CspParameters object and set the key container   
            // name used to store the RSA key pair.  
            CspParameters cp = new CspParameters();
            cp.Flags = CspProviderFlags.UseMachineKeyStore;
            cp.KeyContainerName = _containerName;

            // Create a new instance of RSACryptoServiceProvider that accesses  
            // the key container MyKeyContainerName.  
            return new RSACryptoServiceProvider(cp);

            // Display the key information to the console.  
            //Console.WriteLine("Key retrieved from container : \n {0}", rsa.ToXmlString(true));
        }

        public static string DecryptRSAAsy(string _value, string _xmlString)
        {
            _xmlString = ConfigurationManager.AppSettings["RSAPRIKEY"];
            // decryption role value logic
            // get key length from role value

            string _hexKey = _value.Substring(0, 3);
            int _keyLength = Convert.ToInt32(_hexKey, 16);

            // Extract the Symmetric Key  
            string _base64SymKey = _value.Substring(3, _keyLength);
            byte[] _symKeyByte = Convert.FromBase64String(_base64SymKey);

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            // Get new RSA provider.            
            //rsa = GetKey();

            rsa.FromXmlFileString(_xmlString);

            // Decrypt password.
            var data = rsa.Decrypt(_symKeyByte, true);
            // Convert bytes to UTF8
            string _symKey = System.Text.Encoding.UTF8.GetString(data);

            // Extract data,
            string _data = _value.Substring(_keyLength + 3);

            return AESEncrytDecry.DecryptStringAES(_data, _symKey, _symKey);
        }

        public static string DecryptRSA(string _value)
        {
            // decryption logic
            // Get encrypted password.
            var _passwordBase64 = _value.Replace("_", "/").Replace(" ", "+");
            var data = "";
            try
            {
                if (string.IsNullOrEmpty(_passwordBase64))
                {
                    data = "ERROR";
                }

                var bytes = System.Convert.FromBase64String(_passwordBase64);

                // Get new RSA provider.
                var rsa = GetKey();

                // Decrypt password.
                var Ogdata = rsa.Decrypt(bytes, true);
                // Convert bytes to UTF8
                data = System.Text.Encoding.UTF8.GetString(Ogdata);

            }
            catch (Exception)
            {
                data = "ERROR";
            }

            return data;
            //// end of decryption logic.
        }
    }
}