﻿using ApiCore.Helpers;
namespace ApiCore.Model
{
    public class DbConnections
    {
        //public string ConAMCMobileDB { get; set; }
        //public string ConCMSDB { get; set; }
        //public string CorporateDB { get; set; }
        //public string ConAMCPORTAL { get; set; }
        //public string ConAMCWhatsappDB { get; set; }
        //public string ConMOSLGBIS { get; set; }
        //public string ConAMCPORTALREWAMP { get; set; }

        string _ConAMCMobileDB = string.Empty;
        string _ConCMSDB = string.Empty;
        string _CorporateDB = string.Empty;
        string _ConAMCPORTAL = string.Empty;
        string _ConAMCWhatsappDB = string.Empty;
        string _ConMOSLGBIS = string.Empty;
        string _ConMOSLAMC = string.Empty;
        string _ConMOSLCMS = string.Empty;
        string _ConErrorDB = string.Empty;
        string _ConAMCPORTALREWAMP = string.Empty;
        string _ConPMSTracker = string.Empty;
        string _ConCBOS = string.Empty;

        public string ConErrorDB
        {
            get { return _ConErrorDB; }
            set { _ConErrorDB = Utilities.StringDecrypt(value); }
        }
        public string ConMOSLCMS
        {
            get { return _ConMOSLCMS; }
            set { _ConMOSLCMS = Utilities.StringDecrypt(value); }
        }
        public string ConAMCMobileDB
        {
            get { return _ConAMCMobileDB; }
            set { _ConAMCMobileDB = Utilities.StringDecrypt(value); }
        }
        public string ConCMSDB
        {
            get { return _ConCMSDB; }
            set { _ConCMSDB = Utilities.StringDecrypt(value); }
        }
        public string CorporateDB
        {
            get { return _CorporateDB; }
            set { _CorporateDB = Utilities.StringDecrypt(value); }
        }
        public string ConAMCPORTAL
        {
            get { return _ConAMCPORTAL; }
            set { _ConAMCPORTAL = Utilities.StringDecrypt(value); }
        }
        public string ConAMCWhatsappDB
        {
            get { return _ConAMCWhatsappDB; }
            set { _ConAMCWhatsappDB = Utilities.StringDecrypt(value); }
        }
        public string ConMOSLGBIS
        {
            get { return _ConMOSLGBIS; }
            set { _ConMOSLGBIS = Utilities.StringDecrypt(value); }
        }

        public string ConMOSLAMC
        {
            get { return _ConMOSLAMC; }
            set { _ConMOSLAMC = Utilities.StringDecrypt(value); }
        }

        public string ConAMCPORTALREWAMP
        {
            get { return _ConAMCPORTALREWAMP; }
            set { _ConAMCPORTALREWAMP = Utilities.StringDecrypt(value); }
        }
        public string ConPMSTracker
        {
            get { return _ConPMSTracker; }
            set { _ConPMSTracker = Utilities.StringDecrypt(value); }
        }
        public string ConCBOS
        {
            get { return _ConCBOS; }
            set { _ConCBOS = Utilities.StringDecrypt(value); }
        }
        
        //public string ConAMCMobileDB { get; set; }
        //public string ConCMSDB { get; set; }
        //public string CorporateDB { get; set; }
        //public string ConAMCPORTAL { get; set; }
        //public string ConAMCWhatsappDB { get; set; }
        //public string ConMOSLGBIS { get; set; }
        //public string ConMOSLAMC { get; set; }
    }
}