﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiCore.Model
{
    public class DropDown
    {
        public int Id { get; set; }
        public string TextValue { get; set; }
    }
    public class DBResponseMessage
    {
        public bool Success { get; set; }
        public string Error_Code { get; set; }
        public string Message { get; set; }
    }
}
