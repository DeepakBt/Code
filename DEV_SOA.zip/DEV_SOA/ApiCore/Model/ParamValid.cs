﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ApiCore.Model
{
   public class ParamValid
    {
        public bool DateValidate(string inputDate, string DateFormat)
            {
                bool isValid = true;
                try
                {
                    DateTime dateTime = DateTime.ParseExact(Convert.ToString(inputDate), DateFormat, System.Globalization.CultureInfo.InvariantCulture);
                    return isValid;
                }
                catch
                {
                    isValid = false;
                    return isValid;
                }
            }

        public bool greaterThen(string fromDate, string toDate)
        {
            bool isValid = true;
            int FromDate = Convert.ToInt32(fromDate.Replace("-",""));
            int ToDate=Convert.ToInt32(toDate.Replace("-", ""));
            if (FromDate > ToDate)
            {
                return false;
            }
            else {
                return isValid;
            }
        }

        public  string RemoveHTMLTag(string input)
        {
            return Regex.Replace(Regex.Replace(Regex.Replace(Regex.Replace(input, "<.*?>", String.Empty), "\r", string.Empty), "\n", string.Empty), "&nbsp;", string.Empty);
        }

        public bool isNumeric(string input)
        {
            return Regex.IsMatch(input, @"^-?\d*[0-9]?(|.\d*[0-9]|,\d*[0-9])?$");
        }

        public int GetAge(string DateOfBirth)
        {
            DateTime birthDate = DateTime.Parse(DateOfBirth);
            int age = DateTime.Now.Year - birthDate.Year;
            if (DateTime.Now.Month < birthDate.Month || (DateTime.Now.Month == birthDate.Month && DateTime.Now.Day < birthDate.Day))
                age--;
            if (age < 0)
                return 0;
            else
                return age;
        }

        public bool IsValidEmail(string email)
        {
            try
            {
                return Regex.IsMatch(email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
               
            }
            catch
            {
                return false;
            }
        }
        public static bool IsValidPanno(string panno)
        {
            try
            {
                return Regex.IsMatch(panno, @"^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$");

            }
            catch
            {
                return false;
            }
        }
    }

    public static class stringExtension
    {
        public static bool IsValidJson(this string strInput)
        {
            strInput = strInput.Trim();
            if ((strInput.StartsWith("{") && strInput.EndsWith("}")) || //For object
                (strInput.StartsWith("[") && strInput.EndsWith("]"))) //For array
            {
                try
                {
                    var obj = JToken.Parse(strInput);
                    return true;
                }
                catch (JsonReaderException)
                {
                    //Exception in parsing json                   
                    return false;
                }
                catch (Exception) //some other exception
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }

}


