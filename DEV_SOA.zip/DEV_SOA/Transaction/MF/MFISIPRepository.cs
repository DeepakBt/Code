﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using karvyAPI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public class MFISIPRepository : IMFISIPDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";

        public MFISIPRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }

        public async Task<ResponseDataArrayModel<ISIPdetailRes>> fetchTransactions(ISIPdetailReq request)
        {
            string Folionumber = request.folioNo;
            string scheme = request.schemeCode.Substring(3, 2);
            string plan = request.schemeCode.Substring(5, 2);
            string option = request.schemeCode.Substring(7, 1);
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo = Folionumber,
                    scheme,
                    plan,
                    option
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLISIPFetchTransactions", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                List<ISIPdetailRes> oISIPdetailRes = new List<ISIPdetailRes>();
                if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    foreach (var p in s.ToList())
                    {
                        oISIPdetailRes.Add(new ISIPdetailRes
                        {
                            referenceNumber = Convert.ToString(p["Reference Number"]),
                            urnNumber = Convert.ToString(p["URN Number"]),
                            schemeCode = Convert.ToString(p["Scheme Code"]),
                            schemeDescription = Convert.ToString(p["Scheme Description"]),
                            accountType = Convert.ToString(p["AccountType"]),
                            urnStatus = Convert.ToString(p["URN Status"]),
                            registrationDate = Convert.ToString(p["Registration Date"]),
                            frequency = Convert.ToString(p["Frequency"]),
                            amount = Convert.ToDouble(Convert.ToString(p["Amount"])),
                            fromDate = Convert.ToString(p["From Date"]),
                            endDate = Convert.ToString(p["End Date"]),
                            withEffectDate = Convert.ToString(p["With Effect Date"])
                        });
                    }
                    return new ResponseDataArrayModel<ISIPdetailRes>(oISIPdetailRes);
                }

                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataArrayModel<ISIPdetailRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataArrayModel<ISIPdetailRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }
            }
            catch (Exception)
            {
                throw new NoDataException(false);
            }
        }


        public async Task<ResponseDataModel<ISIPTransRes>> transactionCancellation(string panNo,string UserAgent, ISIPTransReq request)
        {
            var branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            string folioNo = request.folioNo;
            string ihno = request.referenceNo;
            string entby = ""; //request.entby;
            string enddt = request.enddt;
            string userid = panNo;

            string Clientname = "";
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                    }
                }
            }

            entby = Clientname;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo,
                    ihno,
                    entby,
                    enddt,
                    branch=branchCode
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLISIPTransactionCancellation", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                ISIPTransRes oISIPTransRes = new ISIPTransRes();

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_ISIP_TRANSACTION", new
                    {
                        FOLIO_NO = folioNo,
                        PAN_NO = panNo,
                        INHO_NO = ihno,
                        ENTERED_BY = entby,
                        CANCELLED_DATE = enddt,
                        STATUS_CODE = Convert.ToString(s[0]["STATUS_CODE"]),
                        RES_IHNO_NO = Convert.ToString(s[0]["IHNO"]),
                        RES_TIME_STAMP = Convert.ToString(s[0]["TIME_STAMP"]),
                        RES_MESSAGE = Convert.ToString(s[0]["MESSAGE"]) == "" ? Convert.ToString(s[0]["Return_Message"]) : Convert.ToString(s[0]["MESSAGE"]),
                        BRANCH =branchCode
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }

                if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    oISIPTransRes.ihno = Convert.ToString(s[0]["IHNO"]);
                    oISIPTransRes.time_stamp = Convert.ToString(s[0]["TIME_STAMP"]);

                    return new ResponseDataModel<ISIPTransRes>(oISIPTransRes);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<ISIPTransRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<ISIPTransRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }

            }
            catch (Exception)
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_ISIP_TRANSACTION", new
                    {
                        FOLIO_NO = folioNo,
                        PAN_NO = panNo,
                        INHO_NO = ihno,
                        ENTERED_BY = entby,
                        CANCELLED_DATE = enddt,
                        STATUS_CODE = "",
                        RES_IHNO_NO = "",
                        RES_TIME_STAMP = "",
                        RES_MESSAGE = "API Exception. Please check with Karvy.",
                        BRANCH = branchCode
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                throw new NoDataException(false);
            }
          }

        public async Task<ResponseDataArrayModel<MFISIPFrequencyRes>> GetMFISIPFrequency(MFISIPFrequencyReq request,string PanNo)
        {
            try
            {
                List<MFISIPFrequencyRes> ObjList = new List<MFISIPFrequencyRes>();
                string inputJson = "";
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                input.Add("Pan", PanNo);
                inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSchemeFrequencyData", serviceUrl, inputJson);
                var Jresult = JArray.Parse(result);
                if (Convert.ToInt32(Jresult[0]["STATUS_CODE"]) == 200)
                {
                    if (Jresult.Count > 0)
                    {
                        for (int i = 0; i < Jresult.Count; i++)
                        {
                            MFISIPFrequencyRes objMFISIPFrequencyRes = new MFISIPFrequencyRes();
                            objMFISIPFrequencyRes.TrType = Convert.ToString(Jresult[i]["TrType"]);
                            objMFISIPFrequencyRes.Frequency = Convert.ToString(Jresult[i]["Frequency"]);
                            objMFISIPFrequencyRes.MinAmount = Decimal.TryParse(Convert.ToString(Jresult[i]["MinAmount"]), out decimal d) ? d : Convert.ToDecimal(0.0);
                            objMFISIPFrequencyRes.MinNoOfInstalments = Int32.TryParse(Convert.ToString(Jresult[i]["MinNoOfInstalments"]), out int mi) ? mi : Convert.ToInt32(0);
                            objMFISIPFrequencyRes.SchemeID = Convert.ToString(Jresult[i]["SchemeCode"]);
                            objMFISIPFrequencyRes.AmountMultiplier= Decimal.TryParse(Convert.ToString(Jresult[i]["AmountMultiplier"]), out decimal AM) ? AM : Convert.ToDecimal(0.0);
                            ObjList.Add(objMFISIPFrequencyRes);
                        }
                    }
                    return new ResponseDataArrayModel<MFISIPFrequencyRes>(ObjList);
                }
                else
                {
                    return new ResponseDataArrayModel<MFISIPFrequencyRes>(null, Convert.ToString(Jresult[0]["MESSAGE"]));
                }
            }
            catch (Exception ex)
            {
                throw new LogDBException(ex, ex.Message);
            }
        }
    }
}
