﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Transaction.Models;
using karvyAPI;
using Transaction.Utils;

namespace Transaction.Controllers
{
    public class MFPurchaseRepository : ITransactionDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";
        string pilotRazorpayFlag = string.Empty;
        

        public MFPurchaseRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
            pilotRazorpayFlag = _iconfiguration["pilotRazorpayFlag"];
            

        }

        public async Task<ResponseDataModel<BankRes>> bankDetails(BankReq request)
        {
            string s = GetBankdetailsByIFSC(request.IFSCCode);
            BankRes oBankRes = new BankRes();
            var result = JArray.Parse(s);
            //if (result != null && Convert.ToString(result[0]["STATUS_CODE"]) == "200")
            if (result != null && Convert.ToString(result[0]["STATUS_CODE"]) == "200")
            {
                using (var conn = MOAMCPORTAL)
                {
                    var multi = await conn.QueryAsync("AMCMOB_PROC_CHECKBANKAVAILABILITYWITHTRANSTYPE", new
                    {
                        TRANSACTIONTYPE = request.transactionType ?? "",
                        IFSCCODE = result[0]["IFSC"].ToString() ?? "",
                        MICR = result[0]["MICR"].ToString() ?? "",
                        BANKNAME = result[0]["BankName"].ToString() ?? "",
                        BRANCHNAME = result[0]["BranchName"].ToString() ?? "",
                        BRANCHCITY = result[0]["BranchCity"].ToString() ?? "",
                        BRANCHPINCODE = Convert.ToString(result[0]["branchpincode"]) ?? "",
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].STATUS_CODE == 200)
                        {
                            BankRes BankResponse = new BankRes();
                            BankResponse.micr = result[0]["MICR"].ToString() ?? "";
                            BankResponse.bankName = result[0]["BankName"].ToString() ?? "";
                            BankResponse.branchName = result[0]["BranchName"].ToString() ?? "";
                            BankResponse.branchState = result[0]["BranchCity"].ToString() ?? "";
                            BankResponse.branchCity = result[0]["BranchCity"].ToString() ?? "";
                            BankResponse.branchPincode = Convert.ToString(result[0]["branchpincode"]) ?? "";
                            BankResponse.bankAddress1 = result[0]["Bankaddress1"].ToString() ?? "";
                            BankResponse.bankAddress2 = result[0]["bankaddress2"].ToString() ?? "";
                            BankResponse.bankAddress3 = result[0]["bankaddress3"].ToString() ?? "";
                            return new ResponseDataModel<BankRes>(BankResponse);
                        }

                        else
                        {
                            return new ResponseDataModel<BankRes>(null, "ERUL024");
                        }
                    }
                }

            }
            else if (result != null && (Convert.ToString(result[0]["STATUS_CODE"]) != "200" && Convert.ToString(result[0]["STATUS_CODE"]) != ""))
            {
                return new ResponseDataModel<BankRes>(null, Convert.ToString(result[0]["MESSAGE"]));
            }
            else
            {
                return new ResponseDataModel<BankRes>(null, Convert.ToString(result[0]["Return_Message"]));
            }

            {
                throw new NoDataException(false);
            }

        }

        public async Task<ResponseDataModel<BrokerRes>> validateBrokerCode(BrokerReq request)
        {
            string SubBroker = request.subBroker;
            string SubBrokerCode = request.subBrokerCode;
            //if (!SubBrokerCode.Contains("ARN"))
            //{
            //    if (!string.IsNullOrEmpty(SubBrokerCode))
            //    {
            //        SubBrokerCode = "ARN-" + SubBrokerCode;
            //    }
            //}
            string res = validateBrokerCode(request.brokerCode, SubBroker, SubBrokerCode, request.euin,request.Riacode);
            //request.userId;
            BrokerRes oBrokerRes = new BrokerRes();
            var result = JArray.Parse(res);
            if (result != null && Convert.ToString(result[0]["STATUS_CODE"]) == "200")
            {

                oBrokerRes.euinFlag = result[0]["EUINFlag"].ToString();
                oBrokerRes.euinMsg = result[0]["MESSAGE"].ToString();
                return new ResponseDataModel<BrokerRes>(oBrokerRes);
            }
            else if (res != null && (Convert.ToString(result[0]["STATUS_CODE"]) != "200" && Convert.ToString(result[0]["STATUS_CODE"]) != ""))
            {
                return new ResponseDataModel<BrokerRes>(null, Convert.ToString(result[0]["MESSAGE"]));
            }
            else
            {
                return new ResponseDataModel<BrokerRes>(null, Convert.ToString(result[0]["Return_Message"]));
            }
        }

        public async Task<ResponseDataModel<KDMSRes>> GetKDMSUrl(KDMSReq request)
        {
            string res = GenerateKDMSUrl(request.aadharNo, request.panNo, request.name, request.mobile, request.email);
            KDMSRes oKDMSRes = new KDMSRes();
            var s = JObject.Parse(res);
            if (Convert.ToString(s["response1"]) != "")
            {
                oKDMSRes.response1 = Convert.ToString(s["response1"]);
                return new ResponseDataModel<KDMSRes>(oKDMSRes);
            }
            else
            {
                return new ResponseDataModel<KDMSRes>(null, Convert.ToString(s["status"]["Status_Message"]));
            }
        }

        public async Task<ResponseDataModel<SchemeValueRes>> minimumSchemeValue(SchemeValueReq request)
        {
            //switch(request.frequency.Trim().ToUpper())
            //{
            //    case "MONTHLY": frequency ="M" ;
            //        break;
            //    case "QUARTERLY":
            //        frequency = "Q";
            //        break;
            //    case "YEARLY":
            //        frequency = "Y";
            //        break;
            //    case "HALF YEARLY":
            //        frequency = "HY";
            //        break;
            //    case "DAILY":
            //        frequency = "D";
            //        break;
            //}

            string res = GetMinimumSchemeValue(request.schemeCode, request.planCode, request.optionCode, request.frequency, request.transactionType);
            if (res.ToString() != "")
            {
                var s = JArray.Parse(res);
                if (res != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    SchemeValueRes oSchemeValueRes = new SchemeValueRes();
                    //oSchemeValueRes.minAmount = Convert.ToDouble(Convert.ToString(s[0]["MinAmount"]));
                    oSchemeValueRes.minAmount= Convert.ToString(s[0]["MinAmount"]) != "" ? Convert.ToInt32(Convert.ToString(s[0]["MinAmount"])) : 0;
                    oSchemeValueRes.maxAmount = 0;
                    oSchemeValueRes.AmountMultiplier = Convert.ToString(s[0]["AmountMultiplier"]) != "" ? Convert.ToDouble(Convert.ToString(s[0]["AmountMultiplier"])) : 1;
                    oSchemeValueRes.NoOfInstallments = Convert.ToString(s[0]["NoOfInstallments"]) != "" ? Convert.ToInt32(Convert.ToString(s[0]["NoOfInstallments"])) : 0;
                    return new ResponseDataModel<SchemeValueRes>(oSchemeValueRes);
                }
                else if (res != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<SchemeValueRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<SchemeValueRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }
            }
            else
            {
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataArrayModel<RegisterBankRes>> registerBankList(RegisterBank request,string panNo)
        {
            string folioNo = request.folioNo;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo
                };
                string inputJson = JsonConvert.SerializeObject(input);
                string res = KarvyRequest.CreateHTTPRequest("MOSLInvestorRegisterBank", serviceUrl, inputJson);
                if (res.ToString() != "")
                {
                    var result = JArray.Parse(res);
                    List<RegisterBankRes> oRegisterBankListRes = new List<RegisterBankRes>();
                    if (result != null && Convert.ToString(result[0]["STATUS_CODE"]) == "200")
                    {
                        if (result.Count > 0)
                        {
                            foreach (var p in result.ToList())
                            {
                                // string debitBankDetails = Convert.ToString(p["AccountNumber"]);
                                //    string[] bankdetails = debitBankDetails.Split('~');
                                //     string accountNo = Convert.ToString(bankdetails[1]);
                                string bankName = string.Empty;
                                string ifscCode = string.Empty;
                                string PG = string.Empty;
                                string bankKeyRazorpay = string.Empty;
                                bool bankValue = false;
                                bankName = Convert.ToString(p["BankName"]);
                                ifscCode = Convert.ToString(p["BankIFSC"]);

                                Dictionary<string, string> RazrorPayTPVBanks = _iconfiguration.GetSection("RazorPayBankList").Get<Dictionary<string,string>>();
                                  
                                if (pilotRazorpayFlag.ToUpper() == "Y")
                                {
                                  var PilotPanNO = _iconfiguration.GetSection("PilotRazorPayPan").Get<string[]>();
                                    foreach (string b in PilotPanNO)
                                    {
                                        if (panNo.IndexOf(b) > -1)
                                        {

                                            string bankidfour = string.Empty;
                                            bankidfour = ifscCode.Substring(0, 4).TrimEnd();

                                            foreach (var T in RazrorPayTPVBanks)
                                            {
                                                var keyvalue = T.Key.ToUpper().Substring(0, 4).TrimEnd();
                                                if (bankidfour.Equals(keyvalue))
                                                {
                                                    PG = "Razorpay";
                                                    bankKeyRazorpay = T.Key;
                                                    break;
                                                }

                                            }
                                            bankValue = true;
                                            break;
                                        }
                                    }
                                    if (bankValue == false)
                                    {
                                        PG = "Billdesk";
                                    }

                                }
                                else
                                {
                                    string[] billdeskBank = _iconfiguration.GetSection("billdeskbanklist").Get<string[]>();

                                    foreach (string b in billdeskBank)
                                    {
                                        if (bankName.IndexOf(b) > -1)
                                        {
                                            PG = "Billdesk";
                                            bankValue = true;
                                            break;
                                        }
                                    }
                                    if (bankValue == false)
                                    {
                                         string bankidfour = string.Empty;
                                        bankidfour = ifscCode.Substring(0, 4).TrimEnd();
                                        //if (bankName.ToUpper().Contains("RETAIL"))
                                        //{
                                        //    bankidfour = bankidfour + "_R";
                                        //}
                                        //else if (bankName.ToUpper().Contains("CORPORATE"))
                                        //{
                                        //    bankidfour = bankidfour + "_C";
                                        //}

                                        foreach (var T in RazrorPayTPVBanks)
                                        {
                                            //if (bankidfour.Length == 4)
                                            //{
                                            //    if (bankidfour.Equals(T.Key.ToUpper().Substring(0, 4).TrimEnd()))
                                            //    {
                                            //        PG = "Razorpay";
                                            //        bankKeyRazorpay = T.Key;
                                            //        break;
                                            //    }

                                            //}
                                            //else
                                            //{
                                            var keyvalue = T.Key.ToUpper().Substring(0, 4).TrimEnd();
                                            if (bankidfour.Equals(keyvalue))
                                            {
                                                PG = "Razorpay";
                                                bankKeyRazorpay = T.Key;
                                                break;
                                            }
                                            // }
                                        }
                                    }
                                }
                                oRegisterBankListRes.Add(new RegisterBankRes
                                {
                                    bankName = Convert.ToString(p["BankName"]),
                                    accountNo = Convert.ToString(p["AccountNumber"]),
                                    ifscCode = Convert.ToString(p["BankIFSC"]),
                                    PG = string.IsNullOrEmpty(PG) ? "Billdesk" : PG,
                                    bankKeyRazorpay = PG == "Razorpay" ? bankKeyRazorpay : "",

                                });
                            }
                        }
                        return new ResponseDataArrayModel<RegisterBankRes>(oRegisterBankListRes);
                    }
                    else if (res != null && (Convert.ToString(result[0]["STATUS_CODE"]) != "200" && Convert.ToString(result[0]["STATUS_CODE"]) != ""))
                    {
                        return new ResponseDataArrayModel<RegisterBankRes>(null, Convert.ToString(result[0]["MESSAGE"]));
                    }
                    else
                    {
                        return new ResponseDataArrayModel<RegisterBankRes>(null, Convert.ToString(result[0]["Return_Message"]));
                    }
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "\r\n" + DateTime.Now.ToString() + " CheckvalidatePAN:" + ex.Message);
                throw new NoDataException(true);
            }
        }



        public string GetBankdetailsByIFSC(string IFSC)
        {
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    IFSC
                };
                string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                string result = KarvyRequest.CreateHTTPRequest("BankDetail", serviceUrl, inputJson);
                return result;
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "\r\n" + DateTime.Now.ToString() + " GetBankdetailsByIFSC:" + ex.Message);
                return null;
            }
        }

        public string validateBrokerCode(string BrokerCode, string SubBrokerCode, string SubBrokerARNCode, string Euin,string Riacode)
        {
            try
            {
                object input = new { Adminusername, Adminpassword, BrokerCode, SubBrokerCode, SubBrokerARNCode, Euin,Riacode };
                string inputJSON = JsonConvert.SerializeObject(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSL_EUINValidations", serviceUrl, inputJSON);
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public string GenerateKDMSUrl(string Aadhaarno, string Pan, string Name, string Mobile, string Email)
        {
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Aadhaarno,
                    Pan,
                    Name,
                    Mobile,
                    Email
                };
                string inputJson = JsonConvert.SerializeObject(input);
                //string result = KarvyRequest.CreateHTTPRequest("GetKDMSUrlNew", serviceUrl, inputJson);  new link
                string result = KarvyRequest.CreateHTTPRequest("GetKDMSUrl", serviceUrl, inputJson);
                return result;
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "\r\n" + DateTime.Now.ToString() + " CheckvalidatePAN:" + ex.Message);
                return null;
            }
        }

        public string GetMinimumSchemeValue(string scheme, string plan, string option, string frequency, string trnType)
        {
            option = option == null ? "" : option;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    scheme,
                    plan,
                    option,
                    frequency,
                    trnType
                };
                string inputJson = JsonConvert.SerializeObject(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLSwitchSchemePlanOption", serviceUrl, inputJson);

                return result;
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "\r\n" + DateTime.Now.ToString() + " GetMinimumSchemeValue:" + ex.Message);
                return null;
            }
        }

     
         public async Task<ResponseDataArrayModel<ResClientBankBroker>> clientBankBrokerlist(string PanNo)
         {
            using (var conn = MOAMCPORTAL)
            {
                var resData = await conn.QueryAsync("AMCMOB_GET_CLIENT_BANK_BROKER_LIST", new
                {
                    PanNo
                }, commandType: CommandType.StoredProcedure);
                {
                    List<ResClientBankBroker> ResClientBankBroker = new List<ResClientBankBroker>();
                    var VerifiedList2 = resData.ToList();
                    if (VerifiedList2.Count > 0)
                    {
                        foreach (var p in VerifiedList2.ToList())
                        {
                            ResClientBankBroker.Add(new ResClientBankBroker
                            {
                                accountType = Convert.ToString(p.ACCOUNTTYPE) ?? "",
                                bankName = Convert.ToString(p.BANK_NAME) ?? "",
                                bankAccNo = Convert.ToString(p.BANK_ACCNO) ?? "",
                                plan = Convert.ToString(p.PLAN) ?? "",
                                brokerCode = Convert.ToString(p.BROKER_CODE) ?? "",
                                brokerName= Convert.ToString(p.Broker_Name) ?? "",
                            });

                        }
                        return new ResponseDataArrayModel<ResClientBankBroker>(ResClientBankBroker);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }

                }

            }
        }
    }
}
