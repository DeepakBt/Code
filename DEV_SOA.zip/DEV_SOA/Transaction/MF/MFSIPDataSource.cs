﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Transaction.Models.MFSIP;

namespace Transaction.MF
{
    public interface IMFSIPDataSource
    {
        Task<ResponseDataModel<SIPPlanOptionsRes>> SIPPlanOptions(SIPPlanOptionsReq request);
        Task<ResponseDataModel<SchemeDetailsRes>> SIPSchemePurchaseDetail(SchemeDetailsReq request);
        Task<ResponseDataModel<SubSIPRes>> sipTransaction(string AppId,string panNo,SubSIPReq request,string UserAgent);
        Task<ResponseDataModel<SubSIPRes>> sipWebTransaction(string AppId, string panNo, SubSIPReq request);
        Task<ResponseDataModel<string>> sipConfirmation(string panNo, SIPBillDesk request);
        Task<ResponseDataModel<SubSIPRes>> sipMandateTransaction(string AppId, string panNo, SubSIPReq request, string UserAgent);
        
    }
}
