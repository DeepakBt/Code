﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
   public interface IAdditionalPurchaseDataSource
    {
        Task<ResponseDataModel<AddPurchaseRes>> saveAdditionalPurchase(string AppId,string panNo,AddPurchaseReq request,string UserAgent);
        Task<ResponseDataModel<AddPurchaseRes>> saveWebAdditionalPurchase(string AppId, string panNo, AddPurchaseReq request, string UserAgent);
        Task<ResponseDataModel<AddPurchaseRes>> additionalPurchaseShortCut(string AppId, string panNo, AddPurchaseShortCutReq request, string UserAgent);
        Task<ResponseDataModel<string>> additionalPurchaseConfirmation(string AppId, string panNo, AddPurchaseConfirmationReq request);
        Task<ResponseDataModel<AddBankRes>> addnewBank(string AppId, string panNo,AddBankReq request);
        Task<ResponseDataArrayModel<folioListRes>> folioList(string PANNo);
        Task<ResponseDataArrayModel<folioListRes>> folioListCapitalGain(string PANNo);
        Task<ResponseDataArrayModel<distributorListRes>> foliobrokerlist(string PANNo, distributorListReq request);
    }
}
