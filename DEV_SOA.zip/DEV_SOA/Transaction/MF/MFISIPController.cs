﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/MFISIP")]
    [ValidateModel]
    public class MFISIPController : ControllerBase
    {
        private string Day1 = "0";
        private readonly IMFISIPDataSource _MFISIPDataSource;
        private readonly IMasterDataSource _MasterDataSource;
        public MFISIPController(TokenHelper tokenHelper, IMFISIPDataSource MFISIPDataSource, IMasterDataSource MasterDataSource)
        {
            _MFISIPDataSource = MFISIPDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        [HttpPost("fetchTransactions")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ISIPdetailRes>), 200)]
        public async Task<IActionResult> fetchTransactions([FromBody]ISIPdetailReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFISIPDataSource.fetchTransactions(request);
            return Ok(response);
        }

        [HttpPost("transactionCancellation")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ISIPTransRes>), 200)]
        public async Task<IActionResult> transactionCancellation([FromBody]ISIPTransReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _MFISIPDataSource.transactionCancellation(panNo, UserAgent, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false);
            }
        }

        [HttpGet("GetMFISIPFrequency")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<MFISIPFrequencyRes>), 200)]
        public async Task<IActionResult> GetMFISIPFrequency(MFISIPFrequencyReq request)
        {
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                if (request.TrType.ToUpper() != "SIP")
                {
                    if (request.Frequency == null || request.Frequency.Trim().Length == 0)
                    {
                        request.Frequency = "";
                    }
                }
                var response = await _MFISIPDataSource.GetMFISIPFrequency(request,panNo);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false);
            }
            
        }
    }
}