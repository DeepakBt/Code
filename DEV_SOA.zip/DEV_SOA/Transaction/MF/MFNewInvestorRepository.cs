﻿using ApiCore.DTOs;
using ApiCore.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Controllers;
using Transaction.Models;
using ApiCore.Exceptions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using karvyAPI;
using Transaction.Utils;

namespace Transaction.MF
{
    public class MFNewInvestorRepository : IMFNewInvestorDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly TokenHelper _tokenHelper;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";


        public MFNewInvestorRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }
        public async Task<ResponseDataModel<SceenNewInvestorPanDetailsRes>> saveNewInvestorPanDetails(string AppID,string Role, SceenNewInvestorPanDetails request)
        {

            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_MOBILE_INSERT_NEWINVESTORS", new
                {
                    PANNO = Convert.ToString(request.panNo),
                    AADHARNO = Convert.ToString(request.aadharNo),
                    NAME = Convert.ToString(request.name),
                    APPID = Convert.ToString(AppID),
                    OTP = Convert.ToInt32(request.otp),
                    SAVEFORLATER = false,
                    BranchCode = "MB88"
                }, commandType: CommandType.StoredProcedure);
                SceenNewInvestorPanDetailsRes osceenOneRes = new SceenNewInvestorPanDetailsRes();
                var Data = multi.ToList();
                if (Data[0].successFlag == 1) 
                {
                    var userId = Convert.ToString(Data[0].userId);
                    var ScreenNo = Convert.ToString(Data[0].screenNo) ?? "2";
                    osceenOneRes.accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppID, userId);
                    osceenOneRes.expiresIn = _tokenHelper.GetAccessTokenValiditySeconds();
                    osceenOneRes.screenNo = ScreenNo;
                    return new ResponseDataModel<SceenNewInvestorPanDetailsRes>(osceenOneRes);
                }
                else if (Data[0].successFlag == 0)
                {
                    var msg = Convert.ToString(Data[0].MsgCode);
                    return new ResponseDataModel<SceenNewInvestorPanDetailsRes>(null, msg);
                }
                else
                {
                    throw new NoDataException(false);
                }

            }


            //using (var conn = MOAMCMOBILEDB)
            //{
            //    DynamicParameters param = new DynamicParameters();
            //    param.Add("@PANNO", request.panNo, DbType.String, ParameterDirection.Input);
            //    param.Add("@AADHARNO", request.aadharNo, DbType.String, ParameterDirection.Input);
            //    param.Add("@NAME", request.name, DbType.String, ParameterDirection.Input);
            //    param.Add("@APPID", AppID, DbType.String, ParameterDirection.Input);
            //    param.Add("@SAVEFORLATER",request.saveForlater, DbType.Boolean, ParameterDirection.Input);
            //    param.Add("@OTP", request.otp, DbType.Int32, ParameterDirection.Input);
            //    param.Add("@USERID", "0", DbType.String, ParameterDirection.Output);
            //    param.Add("@SCREENNO", "0", DbType.String, ParameterDirection.Output);
            //    conn.Execute("AMCMOB_MOBILE_INSERT_NEWINVESTORS", param, commandType: CommandType.StoredProcedure);
            //    SceenNewInvestorPanDetailsRes osceenOneRes = new SceenNewInvestorPanDetailsRes();
            //    var userId = param.Get<String>("@USERID");
            //    var ScreenNo = Convert.ToString(param.Get<String>("@SCREENNO")) ?? "2";
               
            //    if (request.saveForlater == false)
            //    {
            //        osceenOneRes.accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppID, userId);
            //        osceenOneRes.expiresIn = _tokenHelper.GetAccessTokenValiditySeconds();
            //        osceenOneRes.screenNo = ScreenNo;
            //    }
            //    else
            //    {
            //        osceenOneRes.accessToken = "";
            //        osceenOneRes.expiresIn = 0;
            //        osceenOneRes.screenNo = "";
            //    }
            //    return new ResponseDataModel<SceenNewInvestorPanDetailsRes>(osceenOneRes);
            //}
        }

        public async Task<ResponseDataModel<SceenNewInvestorPanDetailsRes>> saveWebNewInvestorPanDetails(string AppID, string Role, SceenNewInvestorPanDetails request)
        {

            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_MOBILE_INSERT_NEWINVESTORS", new
                {
                    PANNO = Convert.ToString(request.panNo),
                    AADHARNO = Convert.ToString(request.aadharNo),
                    NAME = Convert.ToString(request.name),
                    APPID = Convert.ToString(AppID),
                    OTP = Convert.ToInt32(request.otp),
                    SAVEFORLATER = false,
                    BranchCode = "WB99"
                }, commandType: CommandType.StoredProcedure);
                SceenNewInvestorPanDetailsRes osceenOneRes = new SceenNewInvestorPanDetailsRes();
                var Data = multi.ToList();
                if (Data[0].successFlag == 1)
                {
                    var userId = Convert.ToString(Data[0].userId);
                    var ScreenNo = Convert.ToString(Data[0].screenNo) ?? "2";
                    osceenOneRes.accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppID, userId);
                    osceenOneRes.expiresIn = _tokenHelper.GetAccessTokenValiditySeconds();
                    osceenOneRes.screenNo = ScreenNo;
                    return new ResponseDataModel<SceenNewInvestorPanDetailsRes>(osceenOneRes);
                }
                else if (Data[0].successFlag == 0)
                {
                    var msg = Convert.ToString(Data[0].MsgCode);
                    return new ResponseDataModel<SceenNewInvestorPanDetailsRes>(null, msg);
                }
                else
                {
                    throw new NoDataException(false);
                }

            }
        }


        public async Task<ResponseDataModel<string>> saveNewInvestorBasicDetails(string AppID,Int64 userid, ScreenNewInvestorBasicDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORSECONDSCREEN_BASICDETAILS", new
                {
                    USERID = userid,
                    MODEOFHOLDING = request.modeOfHolding,
                    CATEGORY = request.holderDetails[0].category,
                    FHIFNRI = request.holderDetails[0].ifNri,
                    INVESTORSTATUS = request.firstHolderTaxStatus,
                    FHOCCUPATION = request.holderDetails[0].occupation,
                    FHSALUTATION = request.holderDetails[0].title,
                    FHNAME = request.holderDetails[0].name,
                    FHDOB = request.holderDetails[0].dob,
                    FHPANNO = request.holderDetails[0].panNo,
                    FHAADHARNO = request.holderDetails[0].aadharNo,
                    FHEMAILID = request.holderDetails[0].email,
                    FHMOBILENO = request.holderDetails[0].mobileNo,
                    FHLANDLINENO = request.holderDetails[0].landlineNo,
                    FHKYCSTATUS = request.holderDetails[0].kycStatus,
           
                    SHCATEGORY = request.holderDetails.Count > 1 ? request.holderDetails[1].category : 0,
                    SHIFNRI = request.holderDetails.Count > 1 ? request.holderDetails[1].ifNri : 0,
                    SHOCCUPATION = request.holderDetails.Count > 1 ? request.holderDetails[1].occupation : 0,
                    SHSALUTATION = request.holderDetails.Count > 1 ? request.holderDetails[1].title : "",
                    SHNAME = request.holderDetails.Count > 1 ? request.holderDetails[1].name : "",
                    SHDOB = request.holderDetails.Count > 1 ? request.holderDetails[1].dob : "",
                    SHPANNO = request.holderDetails.Count > 1 ? request.holderDetails[1].panNo : "",
                    SHAADHARNO = request.holderDetails.Count > 1 ? request.holderDetails[1].aadharNo : "",
                    SHEMAILID = request.holderDetails.Count > 1 ? request.holderDetails[1].email : "",
                    SHMOBILENO = request.holderDetails.Count > 1 ? request.holderDetails[1].mobileNo : "",
                    SHLANDLINENO = request.holderDetails.Count > 1 ? request.holderDetails[1].landlineNo : "",
                    SHKYCSTATUS = request.holderDetails.Count > 1 ? request.holderDetails[1].kycStatus : true,

                    THCATEGORY = request.holderDetails.Count > 2 ? request.holderDetails[2].category : 0,
                    THIFNRI = request.holderDetails.Count > 2 ? request.holderDetails[2].ifNri : 0,
                    THOCCUPATION = request.holderDetails.Count > 2 ? request.holderDetails[2].occupation : 0,
                    THSALUTATION = request.holderDetails.Count > 2 ? request.holderDetails[2].title : "",
                    THNAME = request.holderDetails.Count > 2 ? request.holderDetails[2].name : "",
                    THDOB = request.holderDetails.Count > 2 ? request.holderDetails[2].dob : "",
                    THPANNO = request.holderDetails.Count > 2 ? request.holderDetails[2].panNo : "",
                    THAADHARNO = request.holderDetails.Count > 2 ? request.holderDetails[2].aadharNo : "",
                    THEMAILID = request.holderDetails.Count > 2 ? request.holderDetails[2].email : "",
                    THMOBILENO = request.holderDetails.Count > 2 ? request.holderDetails[2].mobileNo : "",
                    THLANDLINENO = request.holderDetails.Count > 2 ? request.holderDetails[2].landlineNo : "",
                    THKYCSTATUS = request.holderDetails.Count > 2 ? request.holderDetails[2].kycStatus : true,
                    
                    FHGAURDIANPAN = request.firstHolderGurdian == null ? "": request.firstHolderGurdian.panNo,
                    FHGAURDIANKYCSTATUS = request.firstHolderGurdian == null ? false : request.firstHolderGurdian.kycStatus,
                    FHGAURDIANNAME = request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.name,
                    FHGAURDIANAADHARNO = request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.aadhar,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null, "There is some technical issue, please try after some time");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                   
                }

            }

        }
        public async Task<ResponseDataModel<string>> saveNewInvestorFatcaDetails(string AppID, Int64 userid, ScreenNewInvestorFatchDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORTHIRDSCREEN_FATCADETAILS", new
                {

                    USERID = userid,
                    FHINCOMESLAB = request.fatcaDetails[0].incomeSlab,
                    FHBIRTHCOUNTRY = request.fatcaDetails[0].birthCountry,
                    FHNATIONALITY = request.fatcaDetails[0].nationality,
                    FHTAXRESIDENTOTHERTHANINDIA = request.fatcaDetails[0].taxResidentNonIndian,
                    FHTAXRESIDENT = request.fatcaDetails[0].taxResident,
                    FHFORIGNTAXID = request.fatcaDetails[0].foreignTaxId,
                    FHPEP = request.fatcaDetails[0].pep,
                    FHRPEP = request.fatcaDetails[0].relationalPep,

                    SHINCOMESLAB = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].incomeSlab : 0  ,
                    SHBIRTHCOUNTRY = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].birthCountry : "" ,
                    SHNATIONALITY = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].nationality : "" ,
                    SHTAXRESIDENTOTHERTHANINDIA = request.fatcaDetails.Count >1 ? request.fatcaDetails[1].taxResidentNonIndian : false ,
                    SHTAXRESIDENT = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].taxResident : "",
                    SHFORIGNTAXID = request.fatcaDetails.Count > 1? request.fatcaDetails[1].foreignTaxId : "" ,
                    SHPEP = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].pep : false ,
                    SHRPEP = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].relationalPep : false ,

                    THINCOMESLAB = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].incomeSlab :0 ,
                    THBIRTHCOUNTRY = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].birthCountry : "",
                    THNATIONALITY = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].nationality: "",
                    THTAXRESIDENTOTHERTHANINDIA = request.fatcaDetails.Count >2 ? request.fatcaDetails[2].taxResidentNonIndian: false  ,
                    THTAXRESIDENT = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].taxResident : "",
                    THFORIGNTAXID = request.fatcaDetails.Count > 2? request.fatcaDetails[2].foreignTaxId : "",
                    THPEP = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].pep :false,
                    THRPEP = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].relationalPep : false,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveNewInvestorContactDetails(string AppID, Int64 userid, ScreenNewInvestorContactDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORFOURTHSCREEN_CONTACTDETAILS", new
                {

                    USERID = userid,
                    FHWING = request.contactDetails[0].wing ,
                    FHAREA = request.contactDetails[0].area,
                    FHLANDMARK = request.contactDetails[0].landmark ,
                    FHSTATE = request.contactDetails[0].state ,
                    FHCITY = request.contactDetails[0].city ,
                    FHCOUNTRY = request.contactDetails[0].country ,
                    FHPINCODE = request.contactDetails[0].pincode ,

                    SHWING = request.contactDetails.Count > 1 ? request.contactDetails[1].wing : "",
                    SHAREA = request.contactDetails.Count > 1 ? request.contactDetails[1].area : "",
                    SHLANDMARK = request.contactDetails.Count > 1 ? request.contactDetails[1].landmark : "",
                    SHSTATE = request.contactDetails.Count > 1 ? request.contactDetails[1].state : "",
                    SHCITY = request.contactDetails.Count > 1 ? request.contactDetails[1].city : "",
                    SHCOUNTRY = request.contactDetails.Count > 1 ? request.contactDetails[1].country : "",
                    SHPINCODE = request.contactDetails.Count >1 ? request.contactDetails[1].pincode : 0,

                    THWING = request.contactDetails.Count > 2 ?  request.contactDetails[2].wing : "",
                    THAREA = request.contactDetails.Count > 2 ? request.contactDetails[2].area:"",
                    THLANDMARK = request.contactDetails.Count > 2 ? request.contactDetails[2].landmark : "",
                    THSTATE = request.contactDetails.Count > 2 ? request.contactDetails[2].state:"",
                    THCITY = request.contactDetails.Count > 2 ? request.contactDetails[2].city:"",
                    THCOUNTRY = request.contactDetails.Count > 2 ? request.contactDetails[2].country:"",
                    THPINCODE = request.contactDetails.Count > 2 ? request.contactDetails[2].pincode:0,

                    NRIADDRESS1 = request.nriContact  == null ? "" : request.nriContact.address1 ,
                    NRIADDRESS2 = request.nriContact == null ? "" : request.nriContact.address2,
                    NRIADDRESS3 = request.nriContact == null ? "" : request.nriContact.address3,
                    NRICITY = request.nriContact == null ? "" : request.nriContact.city,
                    NRICOUNTRY = request.nriContact == null ? "" : request.nriContact.country,
                    NRIZIPCODE = request.nriContact == null ? "" : request.nriContact.zipcode,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveNewInvestorNomineeDetails(string AppID, Int64 userid, ScreenNewInvestorNomineeDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                NomineeDetails NomineeDetails = new NomineeDetails();
                if (request.wishToNominate == true)
                {
                    if (request.nomineeDetails.Count == 1)
                    {
                        request.nomineeDetails.Add(NomineeDetails);
                        request.nomineeDetails.Add(NomineeDetails);
                    }
                    else if (request.nomineeDetails.Count == 2 )
                    {
                        request.nomineeDetails.Add(NomineeDetails);
                    }
                }
                else
                {
                    request.nomineeDetails.Add(NomineeDetails);
                    request.nomineeDetails.Add(NomineeDetails);
                    request.nomineeDetails.Add(NomineeDetails);
                }

                
                

                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORFIFTHSCREEN_NOMINEEDETAILS", new
                {
                    USERID = userid,
                    WISHTONOMINATE = request.wishToNominate,

                    FNOMINEESALUTATION =  request.nomineeDetails[0].title ,
                    FNOMINEENAME =request.nomineeDetails[0].name ,
                    FNOMINEEDOB =  request.nomineeDetails[0].dob ,
                    FNOMINEEPERCENTAGE =  request.nomineeDetails[0].percent,
                    FNOMADDRESSFLAG = request.nomineeDetails[0].addresFlag ,
                    FNOMADDRESS1 =  request.nomineeDetails[0].address1 ,
                    FNOMADDRESS2 =request.nomineeDetails[0].address2 ,
                    FNOMRELATIONSHIP =  request.nomineeDetails[0].relationship ,
                    FNOMGAURDIANSALUTATION = request.nomineeDetails[0].gurdianTitle ,
                    FNOMGAURDIANNAME =  request.nomineeDetails[0].gurdianName ,
                    FNOMGAURDIANPAN =  request.nomineeDetails[0].gurdianPanNo ,
                    FNOMGAURDIANKYCSTATUS =  request.nomineeDetails[0].gurdianKycStatus ,

                    SNOMINEESALUTATION = request.nomineeDetails[1].title,
                    SNOMINEENAME =  request.nomineeDetails[1].name ,
                    SNOMINEEDOB = request.nomineeDetails[1].dob ,
                    SNOMINEEPERCENTAGE = request.nomineeDetails[1].percent ,
                    SNOMADDRESSFLAG = request.nomineeDetails[1].addresFlag ,
                    SNOMADDRESS1 = request.nomineeDetails[1].address1,
                    SNOMADDRESS2 =  request.nomineeDetails[1].address2,
                    SNOMRELATIONSHIP =  request.nomineeDetails[1].relationship ,
                    SNOMGAURDIANSALUTATION = request.nomineeDetails[1].gurdianTitle ,
                    SNOMGAURDIANNAME =  request.nomineeDetails[1].gurdianName,
                    SNOMGAURDIANPAN = request.nomineeDetails[1].gurdianPanNo ,
                    SNOMGAURDIANKYCSTATUS =  request.nomineeDetails[1].gurdianKycStatus,

                    TNOMINEESALUTATION =request.nomineeDetails[2].title ,
                    TNOMINEENAME =  request.nomineeDetails[2].name ,
                    TNOMINEEDOB =  request.nomineeDetails[2].dob ,
                    TNOMINEEPERCENTAGE = request.nomineeDetails[2].percent ,
                    TNOMADDRESSFLAG =  request.nomineeDetails[2].addresFlag,
                    TNOMADDRESS1 =  request.nomineeDetails[2].address1 ,
                    TNOMADDRESS2 =   request.nomineeDetails[2].address2 ,
                    TNOMRELATIONSHIP =  request.nomineeDetails[2].relationship,
                    TNOMGAURDIANSALUTATION =  request.nomineeDetails[2].gurdianTitle,
                    TNOMGAURDIANNAME = request.nomineeDetails[2].gurdianName ,
                    TNOMGAURDIANPAN =  request.nomineeDetails[2].gurdianPanNo,
                    TNOMGAURDIANKYCSTATUS = request.nomineeDetails[2].gurdianKycStatus ,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveNewInvestorSchemeDetails(string AppID, Int64 userid, ScreenNewInvestorSchemeDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORSIXTHSCREEN_SCHEMEDETAILS", new
                {
                    USERID = userid,
                    TRANASCTIONTYPE = request.transactionType,
                    SCHEMECODE = request.schemeCode,
                    SCHEMENAME = request.schemeName,
                    PLANCODE = request.planCode,
                    OPTIONCODE = request.optionCode,
                    INVESTEDAMOUNT = Convert.ToString(request.investmentAmount),
                    SCHEMEMINIMUMAMOUNT = request.schemeMinAmount,
                    PLANMODE = request.planMode,
                    FREQUENCY = request.frequency,
                    DEDUCTIONDATE = request.deductionDate,
                    SIPFROMDATE = request.sipFromDate,
                    SIPTODATE = request.sipToDate,
                    PERPETUAL = request.perpetual,
                    NOOFINSTALLMENT = request.noOfInstalment,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveNewInvestorBrokerDetails(string AppID, Int64 userid, ScreenNewInvestorBrokerDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORSEVENTHSCREEN_BROKERDETAILS", new
                {
                    USERID = userid,
                    BROKERCODE = request.brokerCode,
                    SUBBROKER = request.subBroker,
                    SUBBROKERCODE = request.subBrokerCode,
                    EUINDECLARATION = request.declarationEUIN,
                    EUINCODE = request.codeEUIN,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveNewInvestorBankDetails(string AppID, Int64 userid, ScreenNewInvestorBankDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTOREIGHTHSCREEN_BANKDETAILS", new
                {
                    USERID = userid,
                    IFSCCODE = request.ifscCode ?? "",
                    MICRCODE = request.micrCode ?? "" ,
                    ACCOUNTTYPE = request.accountType ?? "",
                    BANKNAME = request.bankName ?? "" ,
                    ACCOUNTNO = request.accountNo ?? "" ,
                    BRANCHNAME = request.branchName ?? "" ,
                    BRANCHADDRESSLINE1 = request.branchAdd1 ?? "" ,
                    BRANCHADDRESSLINE2 = request.branchAdd2 ?? "",
                    BRANCHADDRESSLINE3 = request.branchAdd3 ?? "",
                    BRANCHCITY = request.branchCity ?? "",
                    BRANCHPINCODE = Convert.ToString(request.branchPincode) ?? "0" ,
                    PAYMENTMODE = request.paymentMode ?? "" ,
                    CHEQUEIMAGE = Convert.FromBase64String(request.chequeImage) ,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    UTRNO = request.UTRNo,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<FinalSubmitRes>> saveNewInvestorSubmit(string AppID, Int64 userid, FinalSubmit request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                FinalSubmitRes finalSubmitRes = new FinalSubmitRes();
                var dataSave = await conn.QueryAsync("AMCMOB_GETNEWINVESTORFINALDATA", new
                {
                    USERID = userid,
                    UNDERTAKING = request.undertaking
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2.Count >  0)
                    {
                        try
                        {
                            karvySubmit submit = new karvySubmit();
                            submit.Adminusername = Adminusername;
                            submit.Adminpassword = Adminpassword;
                            submit.Scheme = VerifiedList2[0].SCHEMECODE ?? ""; //M
                            submit.Plan = VerifiedList2[0].PLANCODE ?? "";       //M
                            submit.Option = VerifiedList2[0].OPTIONCODE ?? "";     //M
                            submit.NAVDate = Convert.ToString(VerifiedList2[0].NAVDATE) ?? "";
                            submit.Branch = "MB88";     //M
                            submit.DistributorID = VerifiedList2[0].BROKERCODE ?? "";
                            submit.SubBrokerCode = VerifiedList2[0]. SUBBROKERCODE ?? "";
                            submit.AccNo ="";      //M
                            submit.AppNo = ""    ;
                            submit.TrType = Convert.ToString(VerifiedList2[0].TRANASCTIONTYPE).Trim().ToUpper()  ?? "";     //M
                            submit.Amount = Convert.ToDouble(VerifiedList2[0].INVESTEDAMOUNT) ?? 0;  //M
                            submit.InvName = VerifiedList2[0].FHNAME ?? "";    //M
                            submit.FEMail = VerifiedList2[0].FHEMAILID ?? ""; //M
                            submit.FMobileNo = VerifiedList2[0].FHMOBILENO ?? "";  //M
                            submit.PaymentMode = VerifiedList2[0].PAYMENTMODE ?? "";  //M
                            submit.Category = VerifiedList2[0].CATEGORY ?? "";   //M
                            submit.ChqNo = ""     ;  //M
                            submit.ChqBank = VerifiedList2[0].BANKNAME ?? "";    //M
                            submit.ChqType = VerifiedList2[0].PAYMENTMODE ?? "";    //M
                            submit.purred = ""     ;
                            submit.ihno = 0;//M
                            submit.TransferFlag = VerifiedList2[0].TRANSFERFLAG;   //M
                            submit.Active = VerifiedList2[0].ACTIVE; //M
                            submit.CutOffTime = ""     ;
                            submit.PAN1 = VerifiedList2[0].FHPANNO ?? "";   //M
                            submit.BankAccNo = VerifiedList2[0].ACCOUNTNO ?? "";  //M
                            submit.PAN2 = VerifiedList2[0].SHPANNO ?? "";
                            submit.PAN3 = VerifiedList2[0].THPANNO ?? "";
                            submit.BankAccType = VerifiedList2[0].ACCOUNTTYPE ?? "";    //M
                            submit.BankAddress1 = VerifiedList2[0].BRANCHADDRESSLINE1 ?? "";   //M
                            submit.BankAddress2 = VerifiedList2[0].BRANCHADDRESSLINE2 ?? "";   //M
                            submit.BankAddress3 = VerifiedList2[0].BRANCHADDRESS3 ?? "";   //M
                            submit.BankCity = VerifiedList2[0].BRANCHCITY ?? "";   //M
                            submit.BankPIN = Convert.ToString(VerifiedList2[0].BRANCHPINCODE) ?? "";    //M
                            submit.MACID = ""     ;
                            submit.InvAdd1 = VerifiedList2[0].FHWING ?? "";    //M
                            submit.InvAdd2 = VerifiedList2[0].FHAREA ?? "";    //M
                            submit.InvAdd3 = VerifiedList2[0].FHLANDMARK ?? "";
                            submit.InvCity = VerifiedList2[0].FHCITY ?? "";    //M
                            submit.InvsState = VerifiedList2[0].FHSTATE ?? "";  //M
                            submit.InvPIN = Convert.ToString(VerifiedList2[0].FHPINCODE) ?? ""; //M
                            submit.SecondInvName = VerifiedList2[0].SHNAME ?? "";  //	
                            submit.ThirdInvName = VerifiedList2[0].THNAME ?? "";
                            submit.NomineeName = VerifiedList2[0].FNOMINEENAME ?? "";
                            submit.MOH = Convert.ToString(VerifiedList2[0].MODEOFHOLDING) ?? "";
                            submit.Occupation = VerifiedList2[0].FHOCCUPATION ?? ""; //M
                            submit.SecondInvOccupation = VerifiedList2[0].SHOCCUPATION ?? "";
                            submit.ThirdInvOccupation = VerifiedList2[0].THOCCUPATION ?? "";
                            submit.Status = Convert.ToString(VerifiedList2[0].INVESTORSTATUS); //M
                            submit.InvPhone1 = Convert.ToString(VerifiedList2[0].FHLANDLINENO) ?? "";  //M
                            submit.InvCountry = VerifiedList2[0].FHNATIONALITY ?? ""; //M
                            submit.Salutation = VerifiedList2[0].FHSALUTATION ?? "";
                            submit.InvDOB =  VerifiedList2[0].FHDOB ?? ""; //M
                            submit.InvPhone2 = VerifiedList2[0].SHLANDLINENO ?? "";
                            submit.SecondInvDOB = VerifiedList2[0].SHDOB ?? "";
                            submit.ThirdInvDOB = VerifiedList2[0].THDOB ?? "";
                            submit.GuardianDOB =""     ;
                            submit.NomRelation = VerifiedList2[0].FNOMRELATIONSHIP ?? "";
                            submit.NomDOB =  VerifiedList2[0].FNOMINEEDOB ?? "";
                            submit.NomAddress1 = VerifiedList2[0].FNOMADDRESS1 ?? "";
                            submit.NomAddress2 = VerifiedList2[0].FNOMADDRESS2 ?? "";
                            submit.NomAddress3 = ""    ;
                            submit.NomCity = ""    ;
                            submit.NomState = ""     ;
                            submit.NomPIN = ""    ;
                            submit.NRIAddress1 = VerifiedList2[0].NRIADDRESS1 ?? "";
                            submit.NRIAddress2 = VerifiedList2[0].NRIADDRESS2 ?? "";
                            submit.NRIAddress3 = VerifiedList2[0].NRIADDRESS3 ?? "";
                            submit.NRICity = VerifiedList2[0].NRICITY ?? "";
                            submit.NRIState = ""   ;
                            submit.NRICountry = VerifiedList2[0].NRICOUNTRY ?? "";
                            submit.NRIPIN = VerifiedList2[0].NRIZIPCODE ?? "";
                            submit.Options = ""    ;
                            submit.SecondInvEMail = VerifiedList2[0].SHEMAILID ?? "";
                            submit.ThirdInvEMail = VerifiedList2[0].THEMAILID ?? "";
                            submit.SecondInvMobile = VerifiedList2[0].SHMOBILENO ?? "";
                            submit.ThirdInvMobile = VerifiedList2[0].THMOBILENO ?? "";
                            submit.MICRCode = VerifiedList2[0].MICRCODE ?? "";
                            submit.IFSCCode = VerifiedList2[0].IFSCCODE ?? "";
                            submit.GuardianPAN = VerifiedList2[0].FHGAURDIANPAN ?? "";
                            submit.GuardianRelation = VerifiedList2[0].FNOMRELATIONSHIP ?? "";
                            submit.NomGuardianPAN = VerifiedList2[0].FNOMGAURDIANPAN ?? "";
                            submit.SecurityCode = ""    ;   //M
                            submit.NomGuardianName = VerifiedList2[0].FNOMGAURDIANNAME ?? "";
                            submit.SecondInvSalutation = VerifiedList2[0].SHSALUTATION ?? "";
                            submit.ThirdInvSalutation = VerifiedList2[0].THSALUTATION ?? "";
                            submit.Income = VerifiedList2[0].FHINCOMESLAB ?? ""; //M
                            submit.SourceInfo = ""    ;
                            submit.GuardianName = VerifiedList2[0].FHGAURDIANNAME ?? "";
                            submit.BankBranch = VerifiedList2[0].BRANCHNAME ?? ""; //M
                            submit.ChqDate = ""    ;
                            submit.ReqID = ""     ;
                            submit.DPID = ""    ;
                            submit.ClientID = ""    ;
                            submit.AllotmentMode = ""    ;
                            submit.EUINNo = ""     ;
                            submit.EUINFlag = Convert.ToString(VerifiedList2[0].EUINDECLARATION) == "True" ? "1" : "0";
                            submit.EUINOpt = ""     ;
                            submit.EUINSubARNCode = VerifiedList2[0].EUINCODE ?? "";
                            submit.MOCode = ""    ;
                            submit.FCountryOfBirth = VerifiedList2[0].FHBIRTHCOUNTRY ?? "";
                            submit.FNationality = VerifiedList2[0].FHNATIONALITY ?? "";
                            submit.FTaxResident = VerifiedList2[0].FHTAXRESIDENT ?? "";
                            submit.FForeignTaxID = VerifiedList2[0].FHFORIGNTAXID ?? "";
                            submit.SAnnualIncome = VerifiedList2[0].SHINCOMESLAB ?? "";
                            submit.SCountryOfBirth = VerifiedList2[0].SHBIRTHCOUNTRY ?? "";
                            submit.SNationality = VerifiedList2[0].SHNATIONALITY ?? "";
                            submit.STaxResident = VerifiedList2[0].SHTAXRESIDENT ?? "";
                            submit.SForeignTaxID = VerifiedList2[0].SHFORIGNTAXID ?? "";
                            submit.TAnnualIncome = VerifiedList2[0].THINCOMESLAB ?? "";
                            submit.TCountryOfBirth = VerifiedList2[0].THBIRTHCOUNTRY ?? "";
                            submit.TNationality = VerifiedList2[0].THNATIONALITY ?? "";
                            submit.TTaxResident = VerifiedList2[0].THTAXRESIDENT ?? "";
                            submit.TForeignTaxID = VerifiedList2[0].THFORIGNTAXID ?? "";
                            submit.GAnnualIncome = ""    ;
                            submit.GCountryOfBirth = ""     ;
                            submit.GNationality = ""     ;
                            submit.GTaxResident = ""    ;
                            submit.GForeignTaxID = ""    ;
                            submit.FPoliticallyExposed = Convert.ToString(VerifiedList2[0].FHPEP) == "True" ? "1" : "0";
                            submit.FRelatedToPoliticallyExposed = Convert.ToString(VerifiedList2[0].FHRPEP) == "True" ? "1" : "0";
                            submit.SPoliticallyExposed = Convert.ToString(VerifiedList2[0].SHPEP) == "True" ? "1" : "0";
                            submit.SRelatedToPoliticallyExposed = Convert.ToString(VerifiedList2[0].SHRPEP) == "True" ? "1" : "0";
                            submit.TPoliticallyExposed = Convert.ToString(VerifiedList2[0].THPEP) == "True" ? "1" : "0";
                            submit.TRelatedToPoliticallyExposed = Convert.ToString(VerifiedList2[0].THRPEP) == "True"? "1":"0";
                            submit.GPoliticallyExposed =""    ;
                            submit.GRelatedToPoliticallyExposed = ""   ;
                            submit.FGender = ""    ;
                            submit.SGender = ""     ;
                            submit.TGender = ""    ;
                            submit.GGender = ""     ;
                            submit.FFather = ""    ;
                            submit.SFather = "";
                            submit.TFather = ""     ;
                            submit.GFather = ""     ;
                            submit.FCOB = ""    ;
                            submit.SCOB = ""    ;
                            submit.TCOB = ""    ;
                            submit.GCOB = ""    ;
                            submit.FKRA = Convert.ToString(VerifiedList2[0].FHKYCSTATUS) == "1" ? "Y" : "";
                            submit.SKRA = Convert.ToString(VerifiedList2[0].SHKYCSTATUS) == "1" ? "Y" : "";
                            submit.TKRA = Convert.ToString(VerifiedList2[0].THKYCSTATUS) == "1" ? "Y" : "";
                            submit.GKRA = Convert.ToString(VerifiedList2[0].FHGAURDIANKYCSTATUS) == "1" ? "Y" : "";
                            submit.AADHAR = ""     ; //m
                            submit.Frequency = VerifiedList2[0].FREQUENCY ?? "";
                            submit.FromDate = VerifiedList2[0].SIPFROMDATE ?? "";
                            submit.ToDate = VerifiedList2[0].SIPTODATE ?? "";
                            submit.URNNo = ""     ;
                            submit.SIPRemarks =""     ;
                            submit.SweepScheme = ""     ;
                            submit.SweepPlan = ""     ;
                            submit.SweepOption = ""     ;
                            submit.jt1aadhaaruid = ""    ;
                            submit.jt2aadhaaruid = ""     ;
                            submit.ckycrefno1 = ""     ;
                            submit.ckycrefno2 =""     ;
                            submit.ckycrefno3 =""    ;
                            submit.ckycrefnog = ""    ;
                            submit.noofinst = Convert.ToString(VerifiedList2[0].NOOFINSTALLMENT) ?? "";
                            submit.RefNo = 0  ;
                            submit.BatchNo = 0;
                            submit.ErrNo = 0;
                            submit.CancelledCheque = VerifiedList2[0].CHEQUEIMAGE ?? "";
                            submit.UTRNo= VerifiedList2[0].UTRNo ?? "";
                            object input = submit;
                            string inputJson = JsonConvert.SerializeObject(input);

                            var result = KarvyRequest.CreateHTTPRequest("MOSLSaveNewPurchase", serviceUrl, inputJson);
                            var s = JArray.Parse(result);
                            if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                            {
                                finalSubmitRes.timeStamp = Convert.ToString(s[0]["TIME_STAMP"]);
                                finalSubmitRes.ihno = Convert.ToString(s[0]["IHNO"]);
                                finalSubmitRes.appRefNo = Convert.ToString(s[0]["APP_REF_NO"]);
                                finalSubmitRes.transactionRefNo = Convert.ToString(s[0]["Tran_Ref_No"]);
                                finalSubmitRes.batchNo = Convert.ToString(s[0]["BATCH_NO"]);
                                finalSubmitRes.errorNo = Convert.ToString(s[0]["ERROR_NO"]);
                                finalSubmitRes.scheme = Convert.ToString(s[0]["scheme"]);
                                finalSubmitRes.transactionAmount =Convert.ToDouble(Convert.ToString(s[0]["AMOUNT"]));
                                finalSubmitRes.urnNo = Convert.ToString(s[0]["URNNO"]);
                                finalSubmitRes.urnExpiryDate = Convert.ToString(s[0]["URNexpirydate"]);
                                finalSubmitRes.noOfInstallment = Convert.ToString(s[0]["No.of instalments"]);
                                finalSubmitRes.paymentURL = Convert.ToString(s[0]["BillDesk_URL"]);

                                return new ResponseDataModel<FinalSubmitRes>(finalSubmitRes);
                            }
                            else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                            }
                            else if (result != null && (Convert.ToString(s[0]["ErrorMessage"]) != ""))
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, Convert.ToString(s[0]["ErrorMessage"]));
                            }
                            else
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null,  Convert.ToString(s[0]["Return_Message"]));
                            }
                        }
                        catch (Exception ex)
                        {
                            //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                            using (var Conn = MOAMCMOBILEDB)
                            {
                                var multi = await conn.ExecuteAsync("AMCMOB_UPDATENEWINVESTORRESPONSE", new
                                {
                                    USERID = userid,
                                    TIMESTAMP = Convert.ToString(finalSubmitRes.timeStamp) ?? "",
                                    IHNO = Convert.ToString(finalSubmitRes.ihno) ?? "",
                                    TRANSACTIONREFERENCENO = Convert.ToString(finalSubmitRes.transactionRefNo) ?? "",
                                    BATCHNO = Convert.ToString(finalSubmitRes.batchNo) ?? "",
                                    ERRORNO = Convert.ToString(finalSubmitRes.errorNo +" API Exception.Please check with Karvy.") ?? "",
                                    URNNO = Convert.ToString(finalSubmitRes.urnNo) ?? "",
                                    PAYMENTURL = Convert.ToString(finalSubmitRes.paymentURL) ?? "",
                                }, commandType: CommandType.StoredProcedure);
                                
                            }
                            return new ResponseDataModel<FinalSubmitRes>(null,ex.Message);
                        }
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }

        public async Task<ResponseDataModel<FinalSubmitRes>> saveWEBNewInvestorSubmit(string AppID, Int64 userid, FinalSubmit request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                FinalSubmitRes finalSubmitRes = new FinalSubmitRes();
                var dataSave = await conn.QueryAsync("AMCMOB_GETNEWINVESTORFINALDATA", new
                {
                    USERID = userid,
                    UNDERTAKING = request.undertaking
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2.Count > 0)
                    {
                        try
                        {
                            karvySubmit submit = new karvySubmit();
                            submit.Adminusername = Adminusername;
                            submit.Adminpassword = Adminpassword;
                            submit.Scheme = VerifiedList2[0].SCHEMECODE ?? ""; //M
                            submit.Plan = VerifiedList2[0].PLANCODE ?? "";       //M
                            submit.Option = VerifiedList2[0].OPTIONCODE ?? "";     //M
                            submit.NAVDate = Convert.ToString(VerifiedList2[0].NAVDATE) ?? "";
                            submit.Branch = "WB99";     //M
                            submit.DistributorID = VerifiedList2[0].BROKERCODE ?? "";
                            submit.SubBrokerCode = VerifiedList2[0].SUBBROKERCODE ?? "";
                            submit.AccNo = "";      //M
                            submit.AppNo = "";
                            submit.TrType = Convert.ToString(VerifiedList2[0].TRANASCTIONTYPE).Trim().ToUpper() ?? "";     //M
                            submit.Amount = Convert.ToDouble(VerifiedList2[0].INVESTEDAMOUNT) ?? 0;  //M
                            submit.InvName = VerifiedList2[0].FHNAME ?? "";    //M
                            submit.FEMail = VerifiedList2[0].FHEMAILID ?? ""; //M
                            submit.FMobileNo = VerifiedList2[0].FHMOBILENO ?? "";  //M
                            submit.PaymentMode = VerifiedList2[0].PAYMENTMODE ?? "";  //M
                            submit.Category = VerifiedList2[0].CATEGORY ?? "";   //M
                            submit.ChqNo = "";  //M
                            submit.ChqBank = VerifiedList2[0].BANKNAME ?? "";    //M
                            submit.ChqType = VerifiedList2[0].PAYMENTMODE ?? "";    //M
                            submit.purred = "";
                            submit.ihno = 0;//M
                            submit.TransferFlag = VerifiedList2[0].TRANSFERFLAG;   //M
                            submit.Active = VerifiedList2[0].ACTIVE; //M
                            submit.CutOffTime = "";
                            submit.PAN1 = VerifiedList2[0].FHPANNO ?? "";   //M
                            submit.BankAccNo = VerifiedList2[0].ACCOUNTNO ?? "";  //M
                            submit.PAN2 = VerifiedList2[0].SHPANNO ?? "";
                            submit.PAN3 = VerifiedList2[0].THPANNO ?? "";
                            submit.BankAccType = VerifiedList2[0].ACCOUNTTYPE ?? "";    //M
                            submit.BankAddress1 = VerifiedList2[0].BRANCHADDRESSLINE1 ?? "";   //M
                            submit.BankAddress2 = VerifiedList2[0].BRANCHADDRESSLINE2 ?? "";   //M
                            submit.BankAddress3 = VerifiedList2[0].BRANCHADDRESS3 ?? "";   //M
                            submit.BankCity = VerifiedList2[0].BRANCHCITY ?? "";   //M
                            submit.BankPIN = Convert.ToString(VerifiedList2[0].BRANCHPINCODE) ?? "";    //M
                            submit.MACID = "";
                            submit.InvAdd1 = VerifiedList2[0].FHWING ?? "";    //M
                            submit.InvAdd2 = VerifiedList2[0].FHAREA ?? "";    //M
                            submit.InvAdd3 = VerifiedList2[0].FHLANDMARK ?? "";
                            submit.InvCity = VerifiedList2[0].FHCITY ?? "";    //M
                            submit.InvsState = VerifiedList2[0].FHSTATE ?? "";  //M
                            submit.InvPIN = Convert.ToString(VerifiedList2[0].FHPINCODE) ?? ""; //M
                            submit.SecondInvName = VerifiedList2[0].SHNAME ?? "";  //	
                            submit.ThirdInvName = VerifiedList2[0].THNAME ?? "";
                            submit.NomineeName = VerifiedList2[0].FNOMINEENAME ?? "";
                            submit.MOH = Convert.ToString(VerifiedList2[0].MODEOFHOLDING) ?? "";
                            submit.Occupation = VerifiedList2[0].FHOCCUPATION ?? ""; //M
                            submit.SecondInvOccupation = VerifiedList2[0].SHOCCUPATION ?? "";
                            submit.ThirdInvOccupation = VerifiedList2[0].THOCCUPATION ?? "";
                            submit.Status = Convert.ToString(VerifiedList2[0].INVESTORSTATUS); //M
                            submit.InvPhone1 = Convert.ToString(VerifiedList2[0].FHLANDLINENO) ?? "";  //M
                            submit.InvCountry = VerifiedList2[0].FHNATIONALITY ?? ""; //M
                            submit.Salutation = VerifiedList2[0].FHSALUTATION ?? "";
                            submit.InvDOB = VerifiedList2[0].FHDOB ?? ""; //M
                            submit.InvPhone2 = VerifiedList2[0].SHLANDLINENO ?? "";
                            submit.SecondInvDOB = VerifiedList2[0].SHDOB ?? "";
                            submit.ThirdInvDOB = VerifiedList2[0].THDOB ?? "";
                            submit.GuardianDOB = "";
                            submit.NomRelation = VerifiedList2[0].FNOMRELATIONSHIP ?? "";
                            submit.NomDOB = VerifiedList2[0].FNOMINEEDOB ?? "";
                            submit.NomAddress1 = VerifiedList2[0].FNOMADDRESS1 ?? "";
                            submit.NomAddress2 = VerifiedList2[0].FNOMADDRESS2 ?? "";
                            submit.NomAddress3 = "";
                            submit.NomCity = "";
                            submit.NomState = "";
                            submit.NomPIN = "";
                            submit.NRIAddress1 = VerifiedList2[0].NRIADDRESS1 ?? "";
                            submit.NRIAddress2 = VerifiedList2[0].NRIADDRESS2 ?? "";
                            submit.NRIAddress3 = VerifiedList2[0].NRIADDRESS3 ?? "";
                            submit.NRICity = VerifiedList2[0].NRICITY ?? "";
                            submit.NRIState = "";
                            submit.NRICountry = VerifiedList2[0].NRICOUNTRY ?? "";
                            submit.NRIPIN = VerifiedList2[0].NRIZIPCODE ?? "";
                            submit.Options = "";
                            submit.SecondInvEMail = VerifiedList2[0].SHEMAILID ?? "";
                            submit.ThirdInvEMail = VerifiedList2[0].THEMAILID ?? "";
                            submit.SecondInvMobile = VerifiedList2[0].SHMOBILENO ?? "";
                            submit.ThirdInvMobile = VerifiedList2[0].THMOBILENO ?? "";
                            submit.MICRCode = VerifiedList2[0].MICRCODE ?? "";
                            submit.IFSCCode = VerifiedList2[0].IFSCCODE ?? "";
                            submit.GuardianPAN = VerifiedList2[0].FHGAURDIANPAN ?? "";
                            submit.GuardianRelation = VerifiedList2[0].FNOMRELATIONSHIP ?? "";
                            submit.NomGuardianPAN = VerifiedList2[0].FNOMGAURDIANPAN ?? "";
                            submit.SecurityCode = "";   //M
                            submit.NomGuardianName = VerifiedList2[0].FNOMGAURDIANNAME ?? "";
                            submit.SecondInvSalutation = VerifiedList2[0].SHSALUTATION ?? "";
                            submit.ThirdInvSalutation = VerifiedList2[0].THSALUTATION ?? "";
                            submit.Income = VerifiedList2[0].FHINCOMESLAB ?? ""; //M
                            submit.SourceInfo = "";
                            submit.GuardianName = VerifiedList2[0].FHGAURDIANNAME ?? "";
                            submit.BankBranch = VerifiedList2[0].BRANCHNAME ?? ""; //M
                            submit.ChqDate = "";
                            submit.ReqID = "";
                            submit.DPID = "";
                            submit.ClientID = "";
                            submit.AllotmentMode = "";
                            submit.EUINNo = "";
                            submit.EUINFlag = Convert.ToString(VerifiedList2[0].EUINDECLARATION) == "True" ? "1" : "0";
                            submit.EUINOpt = "";
                            submit.EUINSubARNCode = VerifiedList2[0].EUINCODE ?? "";
                            submit.MOCode = "";
                            submit.FCountryOfBirth = VerifiedList2[0].FHBIRTHCOUNTRY ?? "";
                            submit.FNationality = VerifiedList2[0].FHNATIONALITY ?? "";
                            submit.FTaxResident = VerifiedList2[0].FHTAXRESIDENT ?? "";
                            submit.FForeignTaxID = VerifiedList2[0].FHFORIGNTAXID ?? "";
                            submit.SAnnualIncome = VerifiedList2[0].SHINCOMESLAB ?? "";
                            submit.SCountryOfBirth = VerifiedList2[0].SHBIRTHCOUNTRY ?? "";
                            submit.SNationality = VerifiedList2[0].SHNATIONALITY ?? "";
                            submit.STaxResident = VerifiedList2[0].SHTAXRESIDENT ?? "";
                            submit.SForeignTaxID = VerifiedList2[0].SHFORIGNTAXID ?? "";
                            submit.TAnnualIncome = VerifiedList2[0].THINCOMESLAB ?? "";
                            submit.TCountryOfBirth = VerifiedList2[0].THBIRTHCOUNTRY ?? "";
                            submit.TNationality = VerifiedList2[0].THNATIONALITY ?? "";
                            submit.TTaxResident = VerifiedList2[0].THTAXRESIDENT ?? "";
                            submit.TForeignTaxID = VerifiedList2[0].THFORIGNTAXID ?? "";
                            submit.GAnnualIncome = "";
                            submit.GCountryOfBirth = "";
                            submit.GNationality = "";
                            submit.GTaxResident = "";
                            submit.GForeignTaxID = "";
                            submit.FPoliticallyExposed = Convert.ToString(VerifiedList2[0].FHPEP) == "True" ? "1" : "0";
                            submit.FRelatedToPoliticallyExposed = Convert.ToString(VerifiedList2[0].FHRPEP) == "True" ? "1" : "0";
                            submit.SPoliticallyExposed = Convert.ToString(VerifiedList2[0].SHPEP) == "True" ? "1" : "0";
                            submit.SRelatedToPoliticallyExposed = Convert.ToString(VerifiedList2[0].SHRPEP) == "True" ? "1" : "0";
                            submit.TPoliticallyExposed = Convert.ToString(VerifiedList2[0].THPEP) == "True" ? "1" : "0";
                            submit.TRelatedToPoliticallyExposed = Convert.ToString(VerifiedList2[0].THRPEP) == "True" ? "1" : "0";
                            submit.GPoliticallyExposed = "";
                            submit.GRelatedToPoliticallyExposed = "";
                            submit.FGender = "";
                            submit.SGender = "";
                            submit.TGender = "";
                            submit.GGender = "";
                            submit.FFather = "";
                            submit.SFather = "";
                            submit.TFather = "";
                            submit.GFather = "";
                            submit.FCOB = "";
                            submit.SCOB = "";
                            submit.TCOB = "";
                            submit.GCOB = "";
                            submit.FKRA = Convert.ToString(VerifiedList2[0].FHKYCSTATUS) == "1" ? "Y" : "";
                            submit.SKRA = Convert.ToString(VerifiedList2[0].SHKYCSTATUS) == "1" ? "Y" : "";
                            submit.TKRA = Convert.ToString(VerifiedList2[0].THKYCSTATUS) == "1" ? "Y" : "";
                            submit.GKRA = Convert.ToString(VerifiedList2[0].FHGAURDIANKYCSTATUS) == "1" ? "Y" : "";
                            submit.AADHAR = ""; //m
                            submit.Frequency = VerifiedList2[0].FREQUENCY ?? "";
                            submit.FromDate = VerifiedList2[0].SIPFROMDATE ?? "";
                            submit.ToDate = VerifiedList2[0].SIPTODATE ?? "";
                            submit.URNNo = "";
                            submit.SIPRemarks = "";
                            submit.SweepScheme = "";
                            submit.SweepPlan = "";
                            submit.SweepOption = "";
                            submit.jt1aadhaaruid = "";
                            submit.jt2aadhaaruid = "";
                            submit.ckycrefno1 = "";
                            submit.ckycrefno2 = "";
                            submit.ckycrefno3 = "";
                            submit.ckycrefnog = "";
                            submit.noofinst = Convert.ToString(VerifiedList2[0].NOOFINSTALLMENT) ?? "";
                            submit.RefNo = 0;
                            submit.BatchNo = 0;
                            submit.ErrNo = 0;
                            submit.CancelledCheque = VerifiedList2[0].CHEQUEIMAGE ?? "";
                            submit.UTRNo = VerifiedList2[0].UTRNo ?? "";
                            object input = submit;
                            string inputJson = JsonConvert.SerializeObject(input);

                            var result = KarvyRequest.CreateHTTPRequest("MOSLSaveNewPurchase", serviceUrl, inputJson);
                            var s = JArray.Parse(result);
                            if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                            {
                                finalSubmitRes.timeStamp = Convert.ToString(s[0]["TIME_STAMP"]);
                                finalSubmitRes.ihno = Convert.ToString(s[0]["IHNO"]);
                                finalSubmitRes.appRefNo = Convert.ToString(s[0]["APP_REF_NO"]);
                                finalSubmitRes.transactionRefNo = Convert.ToString(s[0]["Tran_Ref_No"]);
                                finalSubmitRes.batchNo = Convert.ToString(s[0]["BATCH_NO"]);
                                finalSubmitRes.errorNo = Convert.ToString(s[0]["ERROR_NO"]);
                                finalSubmitRes.scheme = Convert.ToString(s[0]["scheme"]);
                                finalSubmitRes.transactionAmount = Convert.ToDouble(Convert.ToString(s[0]["AMOUNT"]));
                                finalSubmitRes.urnNo = Convert.ToString(s[0]["URNNO"]);
                                finalSubmitRes.urnExpiryDate = Convert.ToString(s[0]["URNexpirydate"]);
                                finalSubmitRes.noOfInstallment = Convert.ToString(s[0]["No.of instalments"]);
                                finalSubmitRes.paymentURL = Convert.ToString(s[0]["BillDesk_URL"]);

                                return new ResponseDataModel<FinalSubmitRes>(finalSubmitRes);
                            }
                            else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                            }
                            else if (result != null && (Convert.ToString(s[0]["ErrorMessage"]) != ""))
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, Convert.ToString(s[0]["ErrorMessage"]));
                            }
                            else
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, Convert.ToString(s[0]["Return_Message"]));
                            }
                        }
                        catch (Exception ex)
                        {
                            //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                            using (var Conn = MOAMCMOBILEDB)
                            {
                                var multi = await conn.ExecuteAsync("AMCMOB_UPDATENEWINVESTORRESPONSE", new
                                {
                                    USERID = userid,
                                    TIMESTAMP = Convert.ToString(finalSubmitRes.timeStamp) ?? "",
                                    IHNO = Convert.ToString(finalSubmitRes.ihno) ?? "",
                                    TRANSACTIONREFERENCENO = Convert.ToString(finalSubmitRes.transactionRefNo) ?? "",
                                    BATCHNO = Convert.ToString(finalSubmitRes.batchNo) ?? "",
                                    ERRORNO = Convert.ToString(finalSubmitRes.errorNo + " API Exception.Please check with Karvy.") ?? "",
                                    URNNO = Convert.ToString(finalSubmitRes.urnNo) ?? "",
                                    PAYMENTURL = Convert.ToString(finalSubmitRes.paymentURL) ?? "",
                                }, commandType: CommandType.StoredProcedure);

                            }
                            return new ResponseDataModel<FinalSubmitRes>(null, ex.Message);
                        }
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> PaymentConfirmation(string AppID, Int64 userid, PaymentConfirmation request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                DateTime timeStamp;
                timeStamp = Convert.ToDateTime(request.timeStamp);
                var dataSave = await conn.QueryAsync("AMCMOB_UPDATENEWINVESTORRESPONSE", new
                {
                    USERID = userid,
                    TIMESTAMP = timeStamp,
                    IHNO = request.IHNO,
                    TRANSACTIONREFERENCENO =request.transactionRefno,
                    BATCHNO =request.batchNo,
                    ERRORNO =request.errorNo,
                    URNNO = request.urnNo,
                    PAYMENTURL = request.paymentURL,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }

         
        //public async Task<ResponseDataModel<InvestorDetRes>> GetNewInvestorPanDetails(InvestorDetReq request,int screenNo)
        //{
        //    using (var conn = MOAMCMOBILEDB)
        //    {
        //        var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
        //        {
        //            request.userId,
        //            screenNo

        //        }, commandType: CommandType.StoredProcedure);

        //        var VerifiedList = multi.ToList();
        //        if (VerifiedList.Count > 0)
        //        {
        //           return new ResponseDataModel<InvestorDetRes>(null);
        //        }
        //        else
        //        {
        //            throw new NoDataException(true);
        //        }
        //    }
        //}

        public async Task<ResponseDataModel<ScreenNewInvestorBasicDetailsRes>> GetNewInvestorBasicDetails(Int64 userid,  long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo
                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorBasicDetailsRes obd = new ScreenNewInvestorBasicDetailsRes();
                    obd.userId = VerifiedList[0].USERID ?? 0;
                    obd.modeOfHolding = Int32.Parse(VerifiedList[0].MODEOFHOLDING) ?? 0;
                    obd.firstHolderTaxStatus = Int32.Parse(VerifiedList[0].INVESTORSTATUS) ?? 0;

                    List<BasicDetails> HolderData = new List<BasicDetails>();

                   
                    BasicDetails FirstHolder = new BasicDetails();
                    FirstHolder.category = Int32.Parse(VerifiedList[0].CATEGORY) ?? 0;
                    FirstHolder.ifNri = Int32.Parse(VerifiedList[0].FHIFNRI) ?? 0;
                    FirstHolder.occupation = Int32.Parse(VerifiedList[0].FHOCCUPATION) ?? 0;
                    FirstHolder.title = VerifiedList[0].FHSALUTATION ?? "";
                    FirstHolder.name = VerifiedList[0].FHNAME ?? "";
                    FirstHolder.panNo = VerifiedList[0].FHPANNO ?? "";
                    FirstHolder.dob = VerifiedList[0].FHDOB ?? "";
                    FirstHolder.aadharNo = VerifiedList[0].FHAADHARNO ?? "";
                    FirstHolder.email = VerifiedList[0].FHEMAILID ?? "";
                    FirstHolder.mobileNo = VerifiedList[0].FHMOBILENO ?? "";
                    FirstHolder.landlineNo = VerifiedList[0].FHLANDLINENO ?? "";
                    FirstHolder.kycStatus = VerifiedList[0].FHKYCSTATUS.Trim() == "1" ? true : false;
                    HolderData.Add(FirstHolder);
                    
                    if (VerifiedList[0].SHPANNO.Trim() != "")
                    {
                        BasicDetails SecondHolder = new BasicDetails();
                        SecondHolder.category = Int32.Parse(VerifiedList[0].SHCATEGORY) ?? 0;
                        SecondHolder.ifNri = Int32.Parse(VerifiedList[0].SHIFNRI) ?? 0;
                        SecondHolder.occupation = Int32.Parse(VerifiedList[0].SHOCCUPATION) ?? 0;
                        SecondHolder.title = VerifiedList[0].SHSALUTATION ?? "";
                        SecondHolder.name = VerifiedList[0].SHNAME ?? "";
                        SecondHolder.panNo = VerifiedList[0].SHPANNO ?? "";
                        SecondHolder.dob = VerifiedList[0].SHDOB ?? "";
                        SecondHolder.aadharNo = VerifiedList[0].SHAADHARNO ?? "";
                        SecondHolder.email = VerifiedList[0].SHEMAILID ?? "";
                        SecondHolder.mobileNo = VerifiedList[0].SHMOBILENO ?? "";
                        SecondHolder.landlineNo = VerifiedList[0].SHLANDLINENO ?? "";
                        SecondHolder.kycStatus = VerifiedList[0].SHKYCSTATUS.Trim() == "1" ? true : false;
                        HolderData.Add(SecondHolder);
                    }
                    if (VerifiedList[0].THPANNO.Trim() != "")
                    {
                        BasicDetails ThirdHolder = new BasicDetails();
                        ThirdHolder.category = Int32.Parse(VerifiedList[0].THCATEGORY) ?? 0;
                        ThirdHolder.ifNri = Int32.Parse(VerifiedList[0].THIFNRI) ?? 0;
                        ThirdHolder.occupation = Int32.Parse(VerifiedList[0].THOCCUPATION) ?? 0;
                        ThirdHolder.title = VerifiedList[0].THSALUTATION ?? "";
                        ThirdHolder.name = VerifiedList[0].THNAME ?? "";
                        ThirdHolder.panNo = VerifiedList[0].THPANNO ?? "";
                        ThirdHolder.dob = VerifiedList[0].THDOB ?? "";
                        ThirdHolder.aadharNo = VerifiedList[0].THAADHARNO ?? "";
                        ThirdHolder.email = VerifiedList[0].THEMAILID ?? "";
                        ThirdHolder.mobileNo = VerifiedList[0].THMOBILENO ?? "";
                        ThirdHolder.landlineNo = VerifiedList[0].THLANDLINENO ?? "";
                        ThirdHolder.kycStatus = VerifiedList[0].THKYCSTATUS.Trim() == "1" ? true : false;
                        HolderData.Add(ThirdHolder);
                    }
                    obd.HolderDetails = HolderData;
                    if (VerifiedList[0].FHGAURDIANPAN.Trim() != "")
                    {
                        FirstHolderGurdian FirstHolderGurdian = new FirstHolderGurdian();
                        FirstHolderGurdian.name = VerifiedList[0].FHGAURDIANNAME ?? "";
                        FirstHolderGurdian.panNo = VerifiedList[0].FHGAURDIANPAN ?? "";
                        FirstHolderGurdian.aadhar = VerifiedList[0].FHGAURDIANAADHARNO ?? "";
                        FirstHolderGurdian.kycStatus = VerifiedList[0].FHGAURDIANKYCSTATUS.Trim() == "1" ? true : false;
                        obd.firstHolderGurdian = FirstHolderGurdian;
                    }
                    else
                    {
                        obd.firstHolderGurdian = null;
                    }
                    return new ResponseDataModel<ScreenNewInvestorBasicDetailsRes>(obd);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataModel<ScreenNewInvestorFatchDetailsRes>> GetNewInvestorFatcaDetails(Int64 userid, long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo

                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorFatchDetailsRes oFD = new ScreenNewInvestorFatchDetailsRes();
                    //oFD.userId =VerifiedList[0].USERID ?? 0;

                    List<FatcaDetails> FatcaData = new List<FatcaDetails>();
                 
                    FatcaDetails firstHolder = new FatcaDetails();
                    firstHolder.incomeSlab = Int32.Parse(VerifiedList[0].FHINCOMESLAB) ?? 0;
                    firstHolder.birthCountry = VerifiedList[0].FHBIRTHCOUNTRY ?? "";
                    firstHolder.nationality = VerifiedList[0].FHNATIONALITY ?? "";
                    firstHolder.taxResidentNonIndian = VerifiedList[0].FHTAXRESIDENTOTHERTHANINDIA;
                    firstHolder.taxResident = VerifiedList[0].FHTAXRESIDENT ?? "";
                    firstHolder.foreignTaxId = VerifiedList[0].FHFORIGNTAXID ?? "";
                    firstHolder.pep = VerifiedList[0].FHPEP;
                    firstHolder.relationalPep = VerifiedList[0].FHRPEP;
                    FatcaData.Add(firstHolder);
                    
                    if (VerifiedList[0].SHBIRTHCOUNTRY.Trim() != "")
                    {
                        FatcaDetails secondHolder = new FatcaDetails();
                        secondHolder.incomeSlab = Int32.Parse(VerifiedList[0].SHINCOMESLAB) ?? 0;
                        secondHolder.birthCountry = VerifiedList[0].SHBIRTHCOUNTRY ?? "";
                        secondHolder.nationality = VerifiedList[0].SHNATIONALITY ?? "";
                        secondHolder.taxResidentNonIndian = VerifiedList[0].SHTAXRESIDENTOTHERTHANINDIA;
                        secondHolder.taxResident = VerifiedList[0].SHTAXRESIDENT ?? "";
                        secondHolder.foreignTaxId = VerifiedList[0].SHFORIGNTAXID ?? "";
                        secondHolder.pep = VerifiedList[0].SHPEP;
                        secondHolder.relationalPep = VerifiedList[0].SHRPEP;
                        FatcaData.Add(secondHolder);
                    }
                    if (VerifiedList[0].THBIRTHCOUNTRY.Trim() != "")
                    {
                        FatcaDetails thirdHolder = new FatcaDetails();
                        thirdHolder.incomeSlab = Int32.Parse(VerifiedList[0].THINCOMESLAB) ?? 0;
                        thirdHolder.birthCountry = VerifiedList[0].THBIRTHCOUNTRY ?? "";
                        thirdHolder.nationality = VerifiedList[0].THNATIONALITY ?? "";
                        thirdHolder.taxResidentNonIndian = VerifiedList[0].THTAXRESIDENTOTHERTHANINDIA;
                        thirdHolder.taxResident = VerifiedList[0].THTAXRESIDENT ?? "";
                        thirdHolder.foreignTaxId = VerifiedList[0].THFORIGNTAXID ?? "";
                        thirdHolder.pep = VerifiedList[0].THPEP;
                        thirdHolder.relationalPep = VerifiedList[0].THRPEP;
                        FatcaData.Add(thirdHolder);
                    }
                    oFD.FatcaDetails = FatcaData;
                    return new ResponseDataModel<ScreenNewInvestorFatchDetailsRes>(oFD);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataModel<ScreenNewInvestorContactDetailsRes>> GetNewInvestorContactDetails(Int64 userid, long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo

                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorContactDetailsRes oCD = new ScreenNewInvestorContactDetailsRes();
                   // oCD.userId = VerifiedList[0].USERID ?? 0;

                    List<ContactDetails> ContactData = new List<ContactDetails>();
                    if (VerifiedList[0].FHWING.Trim() != "")
                    {
                        ContactDetails FirstHolder = new ContactDetails();
                        FirstHolder.wing = VerifiedList[0].FHWING ?? "";
                        FirstHolder.area = VerifiedList[0].FHAREA ?? "";
                        FirstHolder.landmark = VerifiedList[0].FHLANDMARK ?? "";
                        FirstHolder.state = VerifiedList[0].FHSTATE ?? "";
                        FirstHolder.city = VerifiedList[0].FHCITY ?? "";
                        FirstHolder.country = VerifiedList[0].FHCOUNTRY ?? "";
                        FirstHolder.pincode = VerifiedList[0].FHPINCODE ?? 0;
                        ContactData.Add(FirstHolder);
                    }
                    if (VerifiedList[0].SHWING.Trim() != "")
                    {
                        ContactDetails SecondHolder = new ContactDetails();
                        SecondHolder.wing = VerifiedList[0].SHWING ?? "";
                        SecondHolder.area = VerifiedList[0].SHAREA ?? "";
                        SecondHolder.landmark = VerifiedList[0].SHLANDMARK ?? "";
                        SecondHolder.state = VerifiedList[0].SHSTATE ?? "";
                        SecondHolder.city = VerifiedList[0].SHCITY ?? "";
                        SecondHolder.country = VerifiedList[0].SHCOUNTRY ?? "";
                        SecondHolder.pincode = VerifiedList[0].SHPINCODE ?? 0 ;
                        ContactData.Add(SecondHolder);
                    }
                    if (VerifiedList[0].THWING.Trim() != "")
                    {
                        ContactDetails ThirdHolder = new ContactDetails();
                        ThirdHolder.wing = VerifiedList[0].THWING ?? "";
                        ThirdHolder.area = VerifiedList[0].THAREA ?? "";
                        ThirdHolder.landmark = VerifiedList[0].THLANDMARK ?? "";
                        ThirdHolder.state = VerifiedList[0].THSTATE ?? "";
                        ThirdHolder.city = VerifiedList[0].THCITY ?? "";
                        ThirdHolder.country = VerifiedList[0].THCOUNTRY ?? "";
                        ThirdHolder.pincode = VerifiedList[0].THPINCODE ?? 0 ;
                        ContactData.Add(ThirdHolder);
                    }
                    oCD.contactDetails = ContactData;
                    if (VerifiedList[0].NRIADDRESS1.Trim() != "")
                    {
                        NRIContactDetails NRIContact = new NRIContactDetails();
                        NRIContact.address1 = VerifiedList[0].NRIADDRESS1 ?? "";
                        NRIContact.address2 = VerifiedList[0].NRIADDRESS2 ?? "";
                        NRIContact.address3 = VerifiedList[0].NRIADDRESS3 ?? "";
                        NRIContact.city = VerifiedList[0].NRICITY ?? "";
                        NRIContact.country = VerifiedList[0].NRICOUNTRY ?? "";
                        NRIContact.zipcode = VerifiedList[0].NRIZIPCODE ?? "";
                        oCD.nriContact = NRIContact;
                    }
                    return new ResponseDataModel<ScreenNewInvestorContactDetailsRes>(oCD);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataModel<ScreenNewInvestorNomineeDetailsRes>> GetNewInvestorNomineeDetails(Int64 userid, long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo

                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorNomineeDetailsRes oND = new ScreenNewInvestorNomineeDetailsRes();
                   // oND.userId = VerifiedList[0].USERID ?? 0;
                    oND.wishToNominate = VerifiedList[0].WISHTONOMINATE ;
                    List<NomineeDetails> NomineeDetails = new List<NomineeDetails>();
                    if (oND.wishToNominate == true)
                    {
                       
                        NomineeDetails Firstholder = new NomineeDetails();
                        Firstholder.title = VerifiedList[0].FNOMINEESALUTATION ?? "";
                        Firstholder.name = VerifiedList[0].FNOMINEENAME ?? "";
                        Firstholder.dob = Convert.ToString(VerifiedList[0].FNOMINEEDOB);
                        Firstholder.percent = Convert.ToDecimal(VerifiedList[0].FNOMINEEPERCENTAGE) ?? 0;
                        Firstholder.addresFlag = VerifiedList[0].FNOMADDRESSFLAG;
                        Firstholder.address1 = VerifiedList[0].FNOMADDRESS1 ?? "";
                        Firstholder.address2 = VerifiedList[0].FNOMADDRESS2 ?? "";
                        Firstholder.relationship = VerifiedList[0].FNOMRELATIONSHIP ?? "";
                        Firstholder.gurdianTitle = VerifiedList[0].FNOMGAURDIANSALUTATION ?? "";
                        Firstholder.gurdianName = VerifiedList[0].FNOMGAURDIANNAME ?? "";
                        Firstholder.gurdianPanNo = VerifiedList[0].FNOMGAURDIANPAN ?? "";
                        Firstholder.gurdianKycStatus = VerifiedList[0].FNOMGAURDIANKYCSTATUS.Trim() == "1" ? true : false;
                        NomineeDetails.Add(Firstholder);
                        
                        if (!string.IsNullOrEmpty(VerifiedList[0].SNOMINEENAME ))
                        {
                            NomineeDetails Secondholder = new NomineeDetails();
                            Secondholder.title = VerifiedList[0].SNOMINEESALUTATION ?? "";
                            Secondholder.name = VerifiedList[0].SNOMINEENAME ?? "";
                            Secondholder.dob = Convert.ToString(VerifiedList[0].SNOMINEEDOB);
                            Secondholder.percent = Convert.ToDecimal(VerifiedList[0].SNOMINEEPERCENTAGE) ?? 0;
                            Secondholder.addresFlag = VerifiedList[0].SNOMADDRESSFLAG;
                            Secondholder.address1 = VerifiedList[0].SNOMADDRESS1 ?? "";
                            Secondholder.address2 = VerifiedList[0].SNOMADDRESS2 ?? "";
                            Secondholder.relationship = VerifiedList[0].SNOMRELATIONSHIP ?? "";
                            Secondholder.gurdianTitle = VerifiedList[0].SNOMGAURDIANSALUTATION ?? "";
                            Secondholder.gurdianName = VerifiedList[0].SNOMGAURDIANNAME ?? "";
                            Secondholder.gurdianPanNo = VerifiedList[0].SNOMGAURDIANPAN ?? "";
                            Secondholder.gurdianKycStatus = VerifiedList[0].SNOMGAURDIANKYCSTATUS.Trim() == "1" ? true : false;
                            NomineeDetails.Add(Secondholder);
                        }


                       if (!string.IsNullOrEmpty(VerifiedList[0].TNOMINEENAME))
                            {
                            NomineeDetails Thirdholder = new NomineeDetails();
                            Thirdholder.title = VerifiedList[0].TNOMINEESALUTATION ?? "";
                            Thirdholder.name = VerifiedList[0].TNOMINEENAME ?? "";
                            Thirdholder.dob = Convert.ToString(VerifiedList[0].TNOMINEEDOB) ?? "";
                            Thirdholder.percent = Convert.ToDecimal(VerifiedList[0].TNOMINEEPERCENTAGE) ?? 0;
                            Thirdholder.addresFlag = VerifiedList[0].TNOMADDRESSFLAG;
                            Thirdholder.address1 = VerifiedList[0].TNOMADDRESS1 ?? "";
                            Thirdholder.address2 = VerifiedList[0].TNOMADDRESS2 ?? "";
                            Thirdholder.relationship = VerifiedList[0].TNOMRELATIONSHIP ?? "";
                            Thirdholder.gurdianTitle = VerifiedList[0].TNOMGAURDIANSALUTATION ?? "";
                            Thirdholder.gurdianName = VerifiedList[0].TNOMGAURDIANNAME ?? "";
                            Thirdholder.gurdianPanNo = VerifiedList[0].TNOMGAURDIANPAN ?? "";
                            Thirdholder.gurdianKycStatus = VerifiedList[0].TNOMGAURDIANKYCSTATUS.Trim() == "1" ? true : false;
                            NomineeDetails.Add(Thirdholder);
                        }
                        oND.nomineeDetails = NomineeDetails;
                    }

                    return new ResponseDataModel<ScreenNewInvestorNomineeDetailsRes>(oND);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataModel<ScreenNewInvestorSchemeDetailsRes>> GetNewInvestorSchemeDetails(Int64 userid, long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo

                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorSchemeDetailsRes oSD = new ScreenNewInvestorSchemeDetailsRes();
                   // oSD.userId = VerifiedList[0].USERID ?? 0;
                    oSD.transactionType = VerifiedList[0].TRANASCTIONTYPE ?? "";
                    oSD.schemeCode = VerifiedList[0].SCHEMECODE ?? "";
                    oSD.schemeName = VerifiedList[0].SCHEMENAME ?? "";
                    oSD.planCode = VerifiedList[0].PLANCODE ?? "";
                    oSD.optionCode = VerifiedList[0].OPTIONCODE ?? "";
                    oSD.investmentAmount = Convert.ToDouble(VerifiedList[0].INVESTEDAMOUNT) ?? 0;
                    oSD.schemeMinAmount = Convert.ToDouble(VerifiedList[0].SCHEMEMINIMUMAMOUNT) ?? 0;
                    oSD.planMode = VerifiedList[0].PLANMODE ?? "";
                    oSD.frequency = VerifiedList[0].FREQUENCY ?? "";
                    oSD.deductionDate = VerifiedList[0].DEDUCTIONDATE ?? "";
                    oSD.sipFromDate = Convert.ToString(VerifiedList[0].SIPFROMDATE) ?? "";
                    oSD.sipToDate = Convert.ToString(VerifiedList[0].SIPTODATE) ?? "";
                    oSD.perpetual = VerifiedList[0].PERPETUAL;
                    oSD.noOfInstalment = Convert.ToInt32(VerifiedList[0].NOOFINSTALLMENT) ?? 0;

                    return new ResponseDataModel<ScreenNewInvestorSchemeDetailsRes>(oSD);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataModel<ScreenNewInvestorBrokerDetailsRes>> GetNewInvestorBrokerDetails(Int64 userid, long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo

                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorBrokerDetailsRes oBD = new ScreenNewInvestorBrokerDetailsRes();
                   // oBD.userId = VerifiedList[0].USERID ?? 0;
                    oBD.brokerCode = VerifiedList[0].BROKERCODE ?? "";
                    oBD.subBroker = VerifiedList[0].SUBBROKER ?? "";
                    oBD.declarationEUIN = Convert.ToString(VerifiedList[0].EUINDECLARATION) ?? "";
                    oBD.subBrokerCode = Convert.ToString(VerifiedList[0].SUBBROKERCODE) ?? "";
                    oBD.codeEUIN = VerifiedList[0].EUINCODE ?? "";
                    return new ResponseDataModel<ScreenNewInvestorBrokerDetailsRes>(oBD);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataModel<ScreenNewInvestorBankDetailsRes>> GetNewInvestorBankDetails(Int64 userid , long screenNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    userId = userid,
                    screenNo

                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    ScreenNewInvestorBankDetailsRes oBD = new ScreenNewInvestorBankDetailsRes();
                    //oBD.userId = VerifiedList[0].USERID ?? 0;
                    oBD.ifscCode = VerifiedList[0].IFSCCODE ?? "";
                    oBD.micrCode = VerifiedList[0].MICRCODE ?? "";
                    oBD.accountType = VerifiedList[0].ACCOUNTTYPE ?? "";
                    oBD.bankName = VerifiedList[0].BANKNAME ?? "";
                    oBD.accountNo = VerifiedList[0].ACCOUNTNO ?? 0;
                    oBD.branchName = VerifiedList[0].BRANCHNAME ?? "";
                    oBD.branchAdd1 = VerifiedList[0].BRANCHADDRESSLINE1 ?? "";
                    oBD.branchAdd2 = VerifiedList[0].BRANCHADDRESSLINE2 ?? "";
                    oBD.branchAdd3 = VerifiedList[0].BRANCHADDRESS3 ?? "";
                    oBD.branchCity = VerifiedList[0].BRANCHCITY ?? "";
                    oBD.branchPincode = Convert.ToString(VerifiedList[0].BRANCHPINCODE) ?? "";
                    oBD.paymentMode = VerifiedList[0].PAYMENTMODE ?? "";
                    oBD.chequeImage = VerifiedList[0].CHEQUEIMAGE ?? "";
                    oBD.UTRNo= VerifiedList[0].UTRNO ?? "";
                    return new ResponseDataModel<ScreenNewInvestorBankDetailsRes>(oBD);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }
    }
}
