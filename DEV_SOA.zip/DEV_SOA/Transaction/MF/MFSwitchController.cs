﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/Switch")]
    [ValidateModel]
    [Authorize]

    public class MFSwitchController : ControllerBase
    {
        private readonly ISwitchDataSource _SwitchDataSource;
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public MFSwitchController(TokenHelper tokenHelper, ISwitchDataSource SwitchDataSource, IMasterDataSource MasterDataSource)
        {
            _SwitchDataSource = SwitchDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        [HttpGet("folioDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<FolioDetail>), 200)]
        public async Task<IActionResult> folioDetailsSwitch(FolioDetailReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SwitchDataSource.folioDetailsSwitch(request);
            return Ok(response);
        }

        [HttpGet("switchNewSchemes")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AddpurchaseSchemeRes>), 200)]
        public async Task<IActionResult> switchNewSchemes()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SwitchDataSource.switchNewSchemes();
            return Ok(response);
        }

        //[HttpPost("newInvestmentSchemes")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataModel<NewInvestmentSchemeRes>), 200)]
        //public async Task<IActionResult> newInvestmentSchemes([FromBody]NewInvestmentSchemeReq request)
        //{
        //    var response = await _SwitchDataSource.newInvestmentSchemes(request);
        //    return Ok(response);
        //}

        [HttpPost("newInvestmentPlans")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<NewInvPlanRes>), 200)]
        public async Task<IActionResult> newInvestmentPlans([FromBody]NewInvPlanReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SwitchDataSource.newInvestmentPlans(request);
            return Ok(response);
        }

        [HttpGet("newInvestmentOptions")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<NewInvOptionsRes>), 200)]
        public async Task<IActionResult> newInvestmentOptions(NewInvOptionsReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SwitchDataSource.newInvestmentOptions(request);
            return Ok(response);
        }

         [HttpPost("switchTransaction")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SwitchTransactionRes>), 200)]
        public async Task<IActionResult> saveswitchTransaction([FromBody] SwitchTransactionReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _SwitchDataSource.saveswitchTransaction(AppId, panNo, UserAgent, request);
            return Ok(response);
        }

        [HttpPost("webSwitchTransaction")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SwitchTransactionRes>), 200)]
        public async Task<IActionResult> saveWebswitchTransaction([FromBody] SwitchTransactionReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _SwitchDataSource.saveWebswitchTransaction(AppId, panNo, UserAgent, request);
            return Ok(response);
        }
    }
}