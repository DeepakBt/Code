﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/AddtionalPurchase")]
    [ValidateModel]
    [Authorize]
    public class AdditionalPurchaseController : ControllerBase
    {
        private string Day1 = "0";
        private readonly IAdditionalPurchaseDataSource _AdditionalPurchaseDataSource;

        private readonly IMasterDataSource _MasterDataSource;
        public AdditionalPurchaseController(TokenHelper tokenHelper, IAdditionalPurchaseDataSource AdditionalPurchaseDataSource, IMasterDataSource MasterDataSource)
        {
            _AdditionalPurchaseDataSource = AdditionalPurchaseDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        [HttpPost("saveAdditionalPurchase")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AddPurchaseRes>), 200)]
        public async Task<IActionResult> saveAdditionalPurchase([FromBody] AddPurchaseReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
                var response = await _AdditionalPurchaseDataSource.saveAdditionalPurchase(AppId, panNo, request, UserAgent);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false,"Session expired");
            }
        }


        [HttpPost("webSaveAdditionalPurchase")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AddPurchaseRes>), 200)]
        public async Task<IActionResult> saveWebAdditionalPurchase([FromBody] AddPurchaseReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
                var response = await _AdditionalPurchaseDataSource.saveWebAdditionalPurchase(AppId, panNo, request, UserAgent);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }


        [HttpPost("additionalPurchaseShortCut")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AddPurchaseRes>), 200)]
        public async Task<IActionResult> additionalPurchaseShortCut([FromBody] AddPurchaseShortCutReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
                var response = await _AdditionalPurchaseDataSource.additionalPurchaseShortCut(AppId, panNo, request, UserAgent);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }


        [HttpPost("additionalPurchaseConfirmation")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> additionalPurchaseConfirmation([FromBody] AddPurchaseConfirmationReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var response = await _AdditionalPurchaseDataSource.additionalPurchaseConfirmation(AppId, panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }
        [HttpPost("newBank")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AddBankRes>), 200)]
        public async Task<IActionResult> addnewBank([FromBody] AddBankReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _AdditionalPurchaseDataSource.addnewBank(AppId, panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }

        [Produces("application/json")]
        [HttpGet("folioList")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<folioListRes>), 200)]
        public async Task<IActionResult> folioList()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _AdditionalPurchaseDataSource.folioList(panNo);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(true, "Session expired");
            }
        }

        [Produces("application/json")]
        [HttpGet("folioListCapitalGainLoss")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<folioListRes>), 200)]
        public async Task<IActionResult> folioListCapitalGainLoss()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _AdditionalPurchaseDataSource.folioListCapitalGain(panNo);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(true, "Session expired");
            }
        }

        [Produces("application/json")]
        [HttpGet("folioBrokerList")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<distributorListRes>), 200)]
        public async Task<IActionResult> foliobrokerlist(distributorListReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _AdditionalPurchaseDataSource.foliobrokerlist(panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(true, "Session expired");
            }
        }
    }


}