﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/MFNewInvestor")]
    [ValidateModel]

    public class MFNewInvestorController : ControllerBase
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly IMFNewInvestorDataSource _MFNewInvestorDataSource;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        public MFNewInvestorController(TokenHelper tokenHelper, IMFNewInvestorDataSource MFNewInvestorDataSource,IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _MFNewInvestorDataSource = MFNewInvestorDataSource;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
        }
        //public async Task<ResponseDataModel<dynamic>> DataValidation(Int64 UserId, int screenNo)
        //{

        //    using (var conn = MOAMCMOBILEDB)
        //    {
        //        var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
        //        {
        //            UserId,
        //            screenNo
        //        }, commandType: CommandType.StoredProcedure);

        //        dynamic Data = multi.ToList();

        //        return Data;
        //    }
        //}

        [HttpPost("panDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SceenNewInvestorPanDetailsRes>), 200)]
        public async Task<IActionResult> saveNewInvestorPanDetails([FromBody] SceenNewInvestorPanDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var Role = IdentityHelper.GetRole(User.Identity);
            var response = await _MFNewInvestorDataSource.saveNewInvestorPanDetails(AppId, string.IsNullOrEmpty(Role) ? "G" : Role,request);
            return Ok(response);
        }

        [HttpPost("WebpanDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SceenNewInvestorPanDetailsRes>), 200)]
        public async Task<IActionResult> saveWebNewInvestorPanDetails([FromBody] SceenNewInvestorPanDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var Role = IdentityHelper.GetRole(User.Identity);
            var response = await _MFNewInvestorDataSource.saveWebNewInvestorPanDetails(AppId, string.IsNullOrEmpty(Role) ? "G" : Role, request);
            return Ok(response);
        }

        [HttpPost("basicDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorBasicDetails([FromBody] ScreenNewInvestorBasicDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid =  Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.saveNewInvestorBasicDetails(AppId, userid, request);
            return Ok(response);
        }

        [HttpPost("fatcaDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorFatcaDetails([FromBody] ScreenNewInvestorFatchDetails request)
        {
            int modeOfHolding = 0;
            int firstHolderTaxStatus = 0;
            var secondHolderPanno = "";
            var thirdholderPanHolder = "";
            int category = 0;
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            long userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    USERID = userid,
                    SCREENNO = 2
                }, commandType: CommandType.StoredProcedure);
                var Data = multi.ToList();
                if (Data.Count > 0)
                {
                    modeOfHolding = Convert.ToInt32(Data[0].MODEOFHOLDING) ?? 0;
                    firstHolderTaxStatus = Convert.ToInt32(Data[0].INVESTORSTATUS) ?? 0;
                    category = Convert.ToInt32(Data[0].CATEGORY) ?? 0;
                    secondHolderPanno = Convert.ToString(Data[0].SHPANNO) ?? "";
                    thirdholderPanHolder = Convert.ToString(Data[0].THPANNO) ?? "";
                }
            }
            var results = new List<ValidationResult>();
            if (modeOfHolding == 2)
            {
                if (request.fatcaDetails.Count == 1)
                {
                    results.Add(new ValidationResult("SecondHolderFatcaDetails Required", new List<string> { "SecondHolderFatcaDetails" }));
                    return BadRequest(results);
                }
                else 
                {
                    if (request.fatcaDetails[1].incomeSlab == 0 || request.fatcaDetails[1].incomeSlab > 6)
                        {
                        results.Add(new ValidationResult("Invalid incomeSlab.", new List<string> { "SecondHolderFatcaDetails" } ));
                        }
                    if (request.fatcaDetails[1].birthCountry == null || request.fatcaDetails[1].birthCountry.Trim() == "")
                    {
                        results.Add(new ValidationResult("Birth Country cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[1].nationality == null || request.fatcaDetails[1].nationality.Trim() == "")
                    {
                        results.Add(new ValidationResult("Nationality cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    
                    if (request.fatcaDetails[1].taxResidentNonIndian == true)
                    {
                        if (request.fatcaDetails[1].taxResident == null || request.fatcaDetails[1].taxResident.Trim() == "")
                        {
                            results.Add(new ValidationResult("Tax Resident cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                        }
                        if (request.fatcaDetails[1].foreignTaxId == null || request.fatcaDetails[1].foreignTaxId.Trim() == "")
                        {
                            results.Add(new ValidationResult("ForignTaxId cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                        }
                    }
                    if (request.fatcaDetails[1].pep != true && request.fatcaDetails[1].pep != false)
                    {
                        results.Add(new ValidationResult("Invalid pep.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[1].relationalPep != true && request.fatcaDetails[1].relationalPep != false)
                    {
                        results.Add(new ValidationResult("Invalid Relation pep.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }
               
                }
            }
            if (modeOfHolding == 2 && thirdholderPanHolder.Trim() != "")
            {
                if (request.fatcaDetails.Count == 2)
                {
                    results.Add(new ValidationResult("ThirdHolderFatcaDetails Required", new List<string> { "ThirdHolderFatcaDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.fatcaDetails[2].incomeSlab == 0 || request.fatcaDetails[2].incomeSlab > 6)
                    {
                        results.Add(new ValidationResult("Invalid incomeSlab.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[2].birthCountry == null || request.fatcaDetails[2].birthCountry.Trim() == "")
                    {
                        results.Add(new ValidationResult("Birth Country cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[2].nationality == null || request.fatcaDetails[2].nationality.Trim() == "")
                    {
                        results.Add(new ValidationResult("Nationality cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                   
                    if (request.fatcaDetails[2].taxResidentNonIndian == true)
                    {
                        if (request.fatcaDetails[2].taxResident == null || request.fatcaDetails[2].taxResident.Trim() == "")
                        {
                            results.Add(new ValidationResult("Tax Resident cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                        }
                        if (request.fatcaDetails[2].foreignTaxId == null || request.fatcaDetails[2].foreignTaxId.Trim() == "")
                        {
                            results.Add(new ValidationResult("ForignTaxId cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                        }
                    }
                    if (request.fatcaDetails[2].pep != true && request.fatcaDetails[2].pep != false)
                    {
                        results.Add(new ValidationResult("Invalid pep.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[2].relationalPep != true && request.fatcaDetails[2].relationalPep != false)
                    {
                        results.Add(new ValidationResult("Invalid Relation pep.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }
                }

            }


                var response = await _MFNewInvestorDataSource.saveNewInvestorFatcaDetails(AppId,userid, request);
            return Ok(response);
        }

        [HttpPost("contactDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorContactDetails([FromBody] ScreenNewInvestorContactDetails request)
        {
            int modeOfHolding = 0;
            int firstHolderTaxStatus = 0;
            var secondHolderPanno = "";
            var thirdholderPanHolder = "";
            int category = 0;
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    USERID = userid,
                    SCREENNO = 2
                }, commandType: CommandType.StoredProcedure);
                var Data = multi.ToList();
                if (Data.Count > 0)
                {
                    modeOfHolding = Convert.ToInt32(Data[0].MODEOFHOLDING) ?? 0;
                    firstHolderTaxStatus = Convert.ToInt32(Data[0].INVESTORSTATUS) ?? 0;
                    category = Convert.ToInt32(Data[0].CATEGORY) ?? 0;
                    secondHolderPanno = Convert.ToString(Data[0].SHPANNO) ?? "";
                    thirdholderPanHolder = Convert.ToString(Data[0].THPANNO) ?? "";
                }
            }
            var results = new List<ValidationResult>();
            if (category == 21)
            {
                if (request.nriContact == null)
                {
                    results.Add(new ValidationResult("NRI Contact Details Required.", new List<string> { "FirstHolderNRIContactDetails" }));
                }
                else
                {
                    if (request.nriContact.address1 == null || request.nriContact.address1.Trim() == "")
                    {
                        results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                    if (request.nriContact.city == null || request.nriContact.city.Trim() == "")
                    {
                        results.Add(new ValidationResult("City cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                    if (request.nriContact.country == null || request.nriContact.country.Trim() == "")
                    {
                        results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                    if (request.nriContact.zipcode == null || request.nriContact.zipcode.Trim() == "")
                    {
                        results.Add(new ValidationResult("Zipcode cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                }
                if (results.Count > 0)
                {
                    return BadRequest(results);
                }
            }
            if (modeOfHolding == 2)
            {
                if (request.contactDetails.Count == 1)
                {
                    results.Add(new ValidationResult("SecondHolderContactDetails Required", new List<string> { "SecondHolderContactDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.contactDetails[1].wing == null || request.contactDetails[1].wing.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].area == null || request.contactDetails[1].area.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].state == null || request.contactDetails[1].state.Trim() == "")
                    {
                        results.Add(new ValidationResult("State cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].country == null || request.contactDetails[1].country.Trim() == "")
                    {
                        results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].pincode == 0)
                    {
                        results.Add(new ValidationResult("Invalid Pincode.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }

                }
            }
            if (modeOfHolding == 2 && thirdholderPanHolder.Trim() != "")
            {
                if (request.contactDetails.Count == 2)
                {
                    results.Add(new ValidationResult("ThirdHolderContactDetails Required", new List<string> { "ThirdHolderContactDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.contactDetails[2].wing == null || request.contactDetails[2].wing.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].area == null || request.contactDetails[2].area.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].state == null || request.contactDetails[2].state.Trim() == "")
                    {
                        results.Add(new ValidationResult("State cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].country == null || request.contactDetails[2].country.Trim() == "")
                    {
                        results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].pincode == 0)
                    {
                        results.Add(new ValidationResult("Invalid Pincode.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }
                }
            }
            var response = await _MFNewInvestorDataSource.saveNewInvestorContactDetails(AppId, userid, request);
            return Ok(response);
        }

        [HttpPost("nomineeDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorNomineeDetails([FromBody] ScreenNewInvestorNomineeDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.saveNewInvestorNomineeDetails(AppId, userid, request);
            return Ok(response);
        }

        [HttpPost("schemeDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorSchemeDetails([FromBody] ScreenNewInvestorSchemeDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.saveNewInvestorSchemeDetails(AppId, userid, request);
            return Ok(response);
        }


        [HttpPost("brokerDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorBrokerDetails([FromBody] ScreenNewInvestorBrokerDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.saveNewInvestorBrokerDetails(AppId, userid, request);
            return Ok(response);
        }

        [HttpPost("bankDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveNewInvestorBankDetails([FromBody] ScreenNewInvestorBankDetails request)
        {
            string transactionType = "";
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_DETAILS", new
                {
                    USERID = userid,
                    SCREENNO = 6
                }, commandType: CommandType.StoredProcedure);
                var Data = multi.ToList();
                if (Data.Count > 0)
                {
                    transactionType = Convert.ToString(Data[0].TRANASCTIONTYPE) ?? 0;
                }
            }
            var results = new List<ValidationResult>();
            if (transactionType.Trim() == "SIP")
            {
                if (string.IsNullOrEmpty(request.chequeImage))
                {
                    {
                        results.Add(new ValidationResult("Cancel Cheque image is required.", new List<string> { "BankDetails" }));
                    }
                }
            }
            else {
                if (string.IsNullOrEmpty(request.paymentMode))
                {
                    {
                        results.Add(new ValidationResult("PaymentMode is required.", new List<string> { "BankDetails" }));
                    }
                }
                else if (request.paymentMode.ToUpper() !="DCB" && request.paymentMode.ToUpper() != "DC" && request.paymentMode.ToUpper() != "UPI" && request.paymentMode.ToUpper() != "RTGS")
                {
                    results.Add(new ValidationResult("Invalid PaymentMode.", new List<string> { "BankDetails" }));
                }
            }
            if (results.Count > 0)
            {
                return BadRequest(results);
            }
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _MFNewInvestorDataSource.saveNewInvestorBankDetails(AppId, userid,request);
            return Ok(response);
        }

        [HttpPost("submit")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<FinalSubmitRes>), 200)]
        public async Task<IActionResult> saveNewInvestorSubmit([FromBody] FinalSubmit request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.saveNewInvestorSubmit(AppId, userid ,request);
            return Ok(response);
        }

        [HttpPost("webSubmit")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<FinalSubmitRes>), 200)]
        public async Task<IActionResult> saveWEBNewInvestorSubmit([FromBody] FinalSubmit request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.saveWEBNewInvestorSubmit(AppId, userid, request);
            return Ok(response);
        }

        [HttpPost("paymentConfirmation")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> PaymentConfirmation([FromBody] PaymentConfirmation request)
        {

            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.PaymentConfirmation(AppId, userid, request);
            return Ok(response);
        }

        //[HttpGet("GetNewInvestorPanDetails")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataModel<InvestorDetRes>), 200)]
        //public async Task<IActionResult> GetNewInvestorPanDetails(InvestorDetReq request)
        //{
        //    int screenNo = 1;
        //    var response = await _MFNewInvestorDataSource.GetNewInvestorPanDetails(request, screenNo);
        //    return Ok(response);
        //}

        [HttpGet("GetNewInvestorBasicDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorBasicDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorBasicDetails()
        {
            long screenNo = 2;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorBasicDetails(userid, screenNo);
            return Ok(response);
        }

        [HttpGet("GetNewInvestorFatcaDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorFatchDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorFatcaDetails()
        {
            long screenNo = 3;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorFatcaDetails(userid, screenNo);
            return Ok(response);
        }

        [HttpGet("GetNewInvestorContactDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorContactDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorContactDetails()
        {
            long screenNo = 4;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorContactDetails(userid, screenNo);
            return Ok(response);
        }

        [HttpGet("GetNewInvestorNomineeDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorNomineeDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorNomineeDetails()
        {
            long screenNo = 5;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorNomineeDetails(userid, screenNo);
            return Ok(response);
        }

        [HttpGet("GetNewInvestorSchemeDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorSchemeDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorSchemeDetails()
        {
            long screenNo = 6;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorSchemeDetails(userid, screenNo);
            return Ok(response);
        }

        [HttpGet("GetNewInvestorBrokerDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorBrokerDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorBrokerDetails()
        {
            long screenNo = 7;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorBrokerDetails(userid, screenNo);
            return Ok(response);
        }

        [HttpGet("GetNewInvestorBankDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ScreenNewInvestorBankDetailsRes>), 200)]
        public async Task<IActionResult> GetNewInvestorBankDetails()
        {
            long screenNo = 8;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _MFNewInvestorDataSource.GetNewInvestorBankDetails(userid, screenNo);
            return Ok(response);
        }
    }
}