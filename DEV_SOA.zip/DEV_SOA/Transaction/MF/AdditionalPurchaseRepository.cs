﻿using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Dapper;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using ApiCore.Exceptions;
using karvyAPI;

namespace Transaction.MF
{
    public class AdditionalPurchaseRepository : IAdditionalPurchaseDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";

        public AdditionalPurchaseRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }

        public async Task<ResponseDataModel<AddPurchaseRes>> saveAdditionalPurchase(string AppID, string panNo, AddPurchaseReq request, string UserAgent)
        {
            string folioNo = request.folioNo;
            string schemeName = request.schemeName;
            string plan = request.plan;
            string option = request.option;
            string amount = Convert.ToString(request.amount);
            string brokerCode = request.brokerCode.Contains("IN") ? "" : request.brokerCode;
            string ricode = request.brokerCode.Contains("IN") ? request.brokerCode : "";
            string subBrokerCode = request.subBroker;
            string subBrokerArnCode = request.subBrokerCode;
            string euinDeclarationFlag = request.euinDeclarationFlag == true ? "Y" : "N";
            string euinCode = request.euinCode;
            string PaymentMode = request.paymentMode;
            string statusCode = "";
            string statusmessage = "";
            string bankacctnumber = request.bankAccNo;
            string bankname = request.bankName;
            string branch = "MB88";
            string UTRNo = request.UTRNo;
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branch = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branch = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branch = "WB99";
                }
                else
                {
                    branch = "MB88";
                }
            }
            AddPurchaseRes oPurchase = new AddPurchaseRes();

            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo,
                    schemeName,
                    plan,
                    option,
                    PaymentMode,
                    bankname,
                    bankacctnumber,
                    amount,
                    brokerCode,
                    subBrokerCode,
                    subBrokerArnCode,
                    euinCode,
                    euinDeclarationFlag,
                    branch,
                    ricode,
                    UTRNo
                };

                string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLAdditionalPurchase", serviceUrl, inputJson);
                var res = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_ADDPURCHASE", new
                    {
                        PANNO = panNo,
                        FOLIONO = folioNo,
                        SCHEMECODE = schemeName,
                        PLANCODE = plan,
                        OPTIONCODE = option,
                        AMOUNT = amount,
                        BROKERCODE = request.brokerCode,
                        SUBBROKERCODE = subBrokerCode,
                        SUBBROKERARNCODE = subBrokerArnCode,
                        EUINCODE = euinCode,
                        EUINDECLARATIONFLAG = euinDeclarationFlag,
                        PAYMENTMODE = PaymentMode,
                        BANKNAME = bankname,
                        BANKACCNO = bankacctnumber,
                        APPREFNO = Convert.ToString(res[0]["APP_REF_NO"]),
                        AppID,
                        BILLDESKURL = Convert.ToString(res[0]["BillDesk_URL"]),
                        STATUSCODE = Convert.ToString(res[0]["STATUS_CODE"]),
                        MESSAGE = Convert.ToString(res[0]["MESSAGE"]),
                        Branch = branch,
                        UTRNo=UTRNo,
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].PURCHASEID != 0)
                        {
                            oPurchase.purchaseId = Convert.ToInt32(VerifiedList[0].PURCHASEID) ?? 0;
                        }
                    }
                }

                if (result != null && Convert.ToString(res[0]["STATUS_CODE"]) == "200")
                {
                    oPurchase.appRefNo = Convert.ToString(res[0]["APP_REF_NO"]);
                    oPurchase.timeStamp = Convert.ToString(res[0]["TIME_STAMP"]);
                    statusCode = Convert.ToString(res[0]["STATUS_CODE"]);
                    statusmessage = Convert.ToString(res[0]["MESSAGE"]);
                    oPurchase.billDeskUrl = Convert.ToString(res[0]["BillDesk_URL"]);
                    oPurchase.amount = Convert.ToDouble(Convert.ToString(res[0]["AMOUNT"]));
                    oPurchase.schemeName = Convert.ToString(res[0]["Scheme"]);
                    return new ResponseDataModel<AddPurchaseRes>(oPurchase);
                }
                else if (result != null && (Convert.ToString(res[0]["STATUS_CODE"]) != "200" && Convert.ToString(res[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<AddPurchaseRes>(null, Convert.ToString(res[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<AddPurchaseRes>(null, Convert.ToString(res[0]["Return_Message"]));
                }
            }
            catch (Exception)
            {
                //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_ADDPURCHASE", new
                    {
                        PANNO = panNo,
                        FOLIONO = folioNo,
                        SCHEMECODE = schemeName,
                        PLANCODE = plan,
                        OPTIONCODE = option,
                        AMOUNT = amount,
                        BROKERCODE = request.brokerCode,
                        SUBBROKERCODE = subBrokerCode,
                        SUBBROKERARNCODE = subBrokerArnCode,
                        EUINCODE = euinCode,
                        EUINDECLARATIONFLAG = euinDeclarationFlag,
                        PAYMENTMODE = PaymentMode,
                        BANKNAME = bankname,
                        BANKACCNO = bankacctnumber,
                        APPREFNO = "",
                        AppID,
                        BILLDESKURL = "",
                        STATUSCODE = "",
                        MESSAGE = "API Exception. Please check with Karvy.",
                        Branch = branch,
                        UTRNo = UTRNo,
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].PURCHASEID != 0)
                        {
                            //oPurchase.purchaseId = Convert.ToInt32(VerifiedList[0].PURCHASEID) ?? 0;
                        }
                    }
                }

                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<AddPurchaseRes>> saveWebAdditionalPurchase(string AppID, string panNo, AddPurchaseReq request,string UserAgent)
        {
            string folioNo = request.folioNo;
            string schemeName = request.schemeName;
            string plan = request.plan;
            string option = request.option;
            string amount = Convert.ToString(request.amount);
            string brokerCode = request.brokerCode.Contains("IN") ? "" : request.brokerCode;
            string ricode = request.brokerCode.Contains("IN") ? request.brokerCode : "";
            string subBrokerCode = request.subBroker;
            string subBrokerArnCode = request.subBrokerCode;
            string euinDeclarationFlag = request.euinDeclarationFlag == true ? "Y" : "N";
            string euinCode = request.euinCode;
            string PaymentMode = request.paymentMode;
            string statusCode = "";
            string statusmessage = "";
            string bankacctnumber = request.bankAccNo;
            string bankname = request.bankName;
            string branch = "MB88";
            string UTRNo = request.UTRNo;
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branch = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branch = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branch = "WB99";
                }
                else
                {
                    branch = "MB88";
                }
            }
            AddPurchaseRes oPurchase = new AddPurchaseRes();

            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo,
                    schemeName,
                    plan,
                    option,
                    PaymentMode,
                    bankname,
                    bankacctnumber,
                    amount,
                    brokerCode,
                    subBrokerCode,
                    subBrokerArnCode,
                    euinCode,
                    euinDeclarationFlag,
                    branch,
                    ricode,
                    UTRNo,
                };

                string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLAdditionalPurchase", serviceUrl, inputJson);
                var res = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_ADDPURCHASE", new
                    {
                        PANNO = panNo,
                        FOLIONO = folioNo,
                        SCHEMECODE = schemeName,
                        PLANCODE = plan,
                        OPTIONCODE = option,
                        AMOUNT = amount,
                        BROKERCODE = request.brokerCode,
                        SUBBROKERCODE = subBrokerCode,
                        SUBBROKERARNCODE = subBrokerArnCode,
                        EUINCODE = euinCode,
                        EUINDECLARATIONFLAG = euinDeclarationFlag,
                        PAYMENTMODE = PaymentMode,
                        BANKNAME = bankname,
                        BANKACCNO = bankacctnumber,
                        APPREFNO = Convert.ToString(res[0]["APP_REF_NO"]),
                        AppID,
                        BILLDESKURL = Convert.ToString(res[0]["BillDesk_URL"]),
                        STATUSCODE = Convert.ToString(res[0]["STATUS_CODE"]),
                        MESSAGE = Convert.ToString(res[0]["MESSAGE"]),
                        Branch = branch,
                        UTRNo=UTRNo,
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].PURCHASEID != 0)
                        {
                            oPurchase.purchaseId = Convert.ToInt32(VerifiedList[0].PURCHASEID) ?? 0;
                        }
                    }
                }

                if (result != null && Convert.ToString(res[0]["STATUS_CODE"]) == "200")
                {
                    oPurchase.appRefNo = Convert.ToString(res[0]["APP_REF_NO"]);
                    oPurchase.timeStamp = Convert.ToString(res[0]["TIME_STAMP"]);
                    statusCode = Convert.ToString(res[0]["STATUS_CODE"]);
                    statusmessage = Convert.ToString(res[0]["MESSAGE"]);
                    oPurchase.billDeskUrl = Convert.ToString(res[0]["BillDesk_URL"]);
                    oPurchase.amount = Convert.ToDouble(Convert.ToString(res[0]["AMOUNT"]));
                    oPurchase.schemeName = Convert.ToString(res[0]["Scheme"]);
                    return new ResponseDataModel<AddPurchaseRes>(oPurchase);
                }
                else if (result != null && (Convert.ToString(res[0]["STATUS_CODE"]) != "200" && Convert.ToString(res[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<AddPurchaseRes>(null, Convert.ToString(res[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<AddPurchaseRes>(null, Convert.ToString(res[0]["Return_Message"]));
                }
            }
            catch (Exception)
            {
                //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_ADDPURCHASE", new
                    {
                        PANNO = panNo,
                        FOLIONO = folioNo,
                        SCHEMECODE = schemeName,
                        PLANCODE = plan,
                        OPTIONCODE = option,
                        AMOUNT = amount,
                        BROKERCODE = request.brokerCode,
                        SUBBROKERCODE = subBrokerCode,
                        SUBBROKERARNCODE = subBrokerArnCode,
                        EUINCODE = euinCode,
                        EUINDECLARATIONFLAG = euinDeclarationFlag,
                        PAYMENTMODE = PaymentMode,
                        BANKNAME = bankname,
                        BANKACCNO = bankacctnumber,
                        APPREFNO = "",
                        AppID,
                        BILLDESKURL = "",
                        STATUSCODE = "",
                        MESSAGE = "API Exception. Please check with Karvy.",
                        Branch = branch,
                        UTRNo=UTRNo,
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].PURCHASEID != 0)
                        {
                            //oPurchase.purchaseId = Convert.ToInt32(VerifiedList[0].PURCHASEID) ?? 0;
                        }
                    }
                }

                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<AddBankRes>> addnewBank(string AppId, string panNo, AddBankReq request)
        {
            string userid = panNo;
            string IFSC = request.ifscCode;
            string MICR = request.micrCode;
            string BankName = request.bankName;
            string AccountType = request.accountType;
            string folioNo = request.folioNo;
            string BranchName = request.BranchName;
            string Address1 = request.Address1;
            string Address2 = request.Address2;
            string Address3 = request.Address3;
            string BranchCity = request.BranchCity;
            string PIN = request.PIN;
            string BranchState = request.BranchState;
            string CancelledCheque = request.CancelledCheque;
            string BankAccNo = request.BankAccNo;
            string status_code = "";
            string message = "";
            string refNo = "";

            AddBankRes oAddBankRes = new AddBankRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    IFSC,
                    MICR,
                    BankName,
                    AccountType,
                    folioNo,
                    BranchName,
                    Address1,
                    Address2,
                    Address3,
                    BranchCity,
                    PIN,
                    BranchState,
                    CancelledCheque,
                    BankAccNo
                };

                string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLAddNewBank", serviceUrl, inputJson);
                var res = JArray.Parse(result);

                status_code = Convert.ToString(res[0]["STATUS_CODE"]);
                message = Convert.ToString(res[0]["MESSAGE"]);
                refNo = Convert.ToString(res[0]["REF_NO"]);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMBMOB_INSERT_ADDTIONAL_BANK", new
                    {
                        USERID = userid,
                        IFSCCODE = IFSC,
                        MICRCODE = MICR,
                        BANKNAME = BankName,
                        ACCOUNTTYPE = AccountType,
                        FOLIONO = folioNo,
                        BRANCHNAME = BranchName,
                        ADDRESS1 = Address1,
                        ADDRESS2 = Address2,
                        ADDRESS3 = Address3,
                        BRANCHCITY = BranchCity,
                        PIN,
                        BRANCHSTATE = BranchState,
                        CANCELLEDCHEQUE = CancelledCheque,
                        BANKACCNO = BankAccNo,
                        REFNO = refNo,
                        APPID = AppId,
                        STATUS_CODE = status_code,
                        STATUSMESSAGE = message,
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                        else
                        {
                            return new ResponseDataModel<AddBankRes>(null, VerifiedList[0].Message);
                        }
                    }
                }

                if (result != null && Convert.ToString(res[0]["STATUS_CODE"]) == "200")
                {
                    oAddBankRes.message = message;
                    oAddBankRes.referenceNo = refNo;
                    return new ResponseDataModel<AddBankRes>(oAddBankRes);
                }
                else if (result != null && (Convert.ToString(res[0]["STATUS_CODE"]) != "200" && Convert.ToString(res[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<AddBankRes>(null, Convert.ToString(res[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<AddBankRes>(null, Convert.ToString(res[0]["Return_Message"]));
                }
            }
            catch (Exception )
            {
                //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMBMOB_INSERT_ADDTIONAL_BANK", new
                    {
                        USERID = userid,
                        IFSCCODE = IFSC,
                        MICRCODE = MICR,
                        BANKNAME = BankName,
                        ACCOUNTTYPE = AccountType,
                        FOLIONO = folioNo,
                        BRANCHNAME = BranchName,
                        ADDRESS1 = Address1,
                        ADDRESS2 = Address2,
                        ADDRESS3 = Address3,
                        BRANCHCITY = BranchCity,
                        PIN,
                        BRANCHSTATE = BranchState,
                        CANCELLEDCHEQUE = CancelledCheque,
                        BANKACCNO = BankAccNo,
                        REFNO = refNo,
                        APPID = AppId,
                        STATUS_CODE = status_code,
                        STATUSMESSAGE = "",
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataArrayModel<folioListRes>> folioList(string PanNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var folioDetails = await conn.QueryAsync("AMCMob_PROC_GETPANWISESCHEME", new
                {
                    PAN = PanNo,
                    TYPEOFCUSTOMER = "MF",
                }, commandType: CommandType.StoredProcedure);
                {
                    List<folioListRes> ofolioListRes = new List<folioListRes>();
                    var VerifiedList2 = folioDetails.ToList();
                    if (VerifiedList2.Count > 0)
                    {
                        foreach (var p in VerifiedList2.ToList())
                        {
                            ofolioListRes.Add(new folioListRes
                            {
                                foliono = Convert.ToString(p.FOLIONO),
                                schemecode = Convert.ToString(p.SCHEMECODE),
                                schemename = Convert.ToString(p.SCHEMENAME),
                                groupcode = Convert.ToString(p.GROUPCODE),
                                accounttype = Convert.ToString(p.ACCOUNTTYPE),
                                plancode = Convert.ToString(p.PLANCODE),
                                planname = Convert.ToString(p.PLANNAME),
                                optioncode = Convert.ToString(p.OPTIONCODE),
                                optionname = Convert.ToString(p.OPTIONNAME),
                                dematAccount = Convert.ToBoolean(p.DEMATFLAG)
                            });

                        }
                        return new ResponseDataArrayModel<folioListRes>(ofolioListRes);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }

                }

            }

        }

        public async Task<ResponseDataArrayModel<folioListRes>> folioListCapitalGain(string PanNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var folioDetails = await conn.QueryAsync("AMCMob_PROC_GETPANWISESCHEME_CAPTIALGAINLOSS", new
                {
                    PAN = PanNo,
                    TYPEOFCUSTOMER = "MF",
                }, commandType: CommandType.StoredProcedure);
                {
                    List<folioListRes> ofolioListRes = new List<folioListRes>();
                    var VerifiedList2 = folioDetails.ToList();
                    if (VerifiedList2.Count > 0)
                    {
                        foreach (var p in VerifiedList2.ToList())
                        {
                            ofolioListRes.Add(new folioListRes
                            {
                                foliono = Convert.ToString(p.FOLIONO),
                                schemecode = Convert.ToString(p.SCHEMECODE),
                                schemename = Convert.ToString(p.SCHEMENAME),
                                groupcode = Convert.ToString(p.GROUPCODE),
                                accounttype = Convert.ToString(p.ACCOUNTTYPE),
                                plancode = Convert.ToString(p.PLANCODE),
                                planname = Convert.ToString(p.PLANNAME),
                                optioncode = Convert.ToString(p.OPTIONCODE),
                                optionname = Convert.ToString(p.OPTIONNAME),
                                dematAccount = Convert.ToBoolean(p.DEMATFLAG)
                            });

                        }
                        return new ResponseDataArrayModel<folioListRes>(ofolioListRes);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }

                }

            }

        }

        public async Task<ResponseDataModel<AddPurchaseRes>> additionalPurchaseShortCut(string AppID, string panNo, AddPurchaseShortCutReq request, string UserAgent)
        {
            string folioNo = "";
            string schemeName = "";
            string plan = "";
            string option = "";
            string amount = Convert.ToString(request.amount);
            string brokerCode = "";
            string subBrokerCode = "";
            string subBrokerArnCode = "";
            string euinCode = "";
            string euinDeclarationFlag = "";
            string statusCode = "";
            string statusmessage = "";
            string PaymentMode = "DCB";
            string bankname = "";
            string bankacctnumber = "";
            string tranRefNo = request.tranRefNo;
            string ricode =  "";
            string branch = "MB88";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branch = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branch = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branch = "WB99";
                }
                else
                {
                    branch = "MB88";
                }
            }
            using (var conn = MOAMCMOBILEDB)
            {
                var folioDetails = await conn.QueryAsync("AMCMOB_PROC_ADDITIONALPURCHASEWITHSHORTCUT", new
                {
                    FOLIONO = request.folioNo,
                    PANNO = panNo,
                    AMOUNT = request.amount,
                    MOSLCODE = request.schemeCode,
                    tranRefNo

                }, commandType: CommandType.StoredProcedure);
                {
                    List<folioListRes> ofolioListRes = new List<folioListRes>();
                    var VerifiedList2 = folioDetails.ToList();

                    if (VerifiedList2.Count > 0)
                    {
                        folioNo = Convert.ToString(VerifiedList2[0].FOLIO);
                        schemeName = Convert.ToString(VerifiedList2[0].SCHEMECODE);
                        plan = Convert.ToString(VerifiedList2[0].PLANCODE);
                        option = Convert.ToString(VerifiedList2[0].OPTIONCODE);
                        brokerCode = Convert.ToString(VerifiedList2[0].BROKERCODE);
                        subBrokerCode = Convert.ToString(VerifiedList2[0].SUBBROKERCODE);
                        subBrokerArnCode = Convert.ToString(VerifiedList2[0].SUBBROKERARNCODE);
                        euinCode = Convert.ToString(VerifiedList2[0].EUINCODE);
                        euinDeclarationFlag = Convert.ToString(VerifiedList2[0].EUINDECLARATION);
                        bankname = Convert.ToString(VerifiedList2[0].BANK_NAME);
                        bankacctnumber = Convert.ToString(VerifiedList2[0].BANKACCNO);
                    }
                }

                AddPurchaseRes oPurchase = new AddPurchaseRes();
                try
                {
                    if (brokerCode.Substring(0, 4) == "ARN-")
                    {
                        brokerCode = brokerCode;
                        ricode = "";
                    }
                    else if (brokerCode.Substring(0, 2) == "IN")
                    {
                        brokerCode = "";
                        ricode = brokerCode;
                    }
                    else
                    {
                        brokerCode = "000000-0";
                        ricode = "";
                    }
                    object input = new
                    {
                        Adminusername,
                        Adminpassword,
                        folioNo,
                        schemeName,
                        plan,
                        option,
                        PaymentMode,
                        bankname,
                        bankacctnumber,
                        amount,
                        brokerCode,
                        subBrokerCode,
                        subBrokerArnCode,
                        euinCode,
                        euinDeclarationFlag,
                        ricode,
                        branch
                    };
                    string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                    string result = KarvyRequest.CreateHTTPRequest("MOSLAdditionalPurchase", serviceUrl, inputJson);
                    var res = JArray.Parse(result);
                    using (var conn2 = MOAMCMOBILEDB)
                    {
                        var multi = await conn.QueryAsync("AMCMOB_INSERT_ADDPURCHASE", new
                        {
                            PANNO = panNo,
                            FOLIONO = folioNo,
                            SCHEMECODE = schemeName,
                            PLANCODE = plan,
                            OPTIONCODE = option,
                            AMOUNT = amount,
                            BROKERCODE = brokerCode,
                            SUBBROKERCODE = subBrokerCode,
                            SUBBROKERARNCODE = subBrokerArnCode,
                            EUINCODE = euinCode,
                            EUINDECLARATIONFLAG = euinDeclarationFlag,
                            PAYMENTMODE = PaymentMode,
                            BANKNAME = bankname,
                            BANKACCNO = bankacctnumber,
                            APPREFNO = Convert.ToString(res[0]["APP_REF_NO"]),
                            AppID,
                            BILLDESKURL = Convert.ToString(res[0]["BillDesk_URL"]),
                            STATUSCODE = Convert.ToString(res[0]["STATUS_CODE"]),
                            MESSAGE = Convert.ToString(res[0]["MESSAGE"]),
                            Branch = branch

                        }, commandType: CommandType.StoredProcedure);
                        {
                            var VerifiedList = multi.ToList();
                            if (VerifiedList[0].PURCHASEID != 0)
                            {
                                oPurchase.purchaseId = Convert.ToInt32(VerifiedList[0].PURCHASEID) ?? 0;
                            }
                        }
                    }

                    if (result != null && Convert.ToString(res[0]["STATUS_CODE"]) == "200")
                    {
                        oPurchase.appRefNo = Convert.ToString(res[0]["APP_REF_NO"]);
                        oPurchase.timeStamp = Convert.ToString(res[0]["TIME_STAMP"]);
                        statusCode = Convert.ToString(res[0]["STATUS_CODE"]);
                        statusmessage = Convert.ToString(res[0]["MESSAGE"]);
                        oPurchase.billDeskUrl = Convert.ToString(res[0]["BillDesk_URL"]);
                        oPurchase.amount = Convert.ToDouble(Convert.ToString(res[0]["AMOUNT"]));
                        oPurchase.schemeName = Convert.ToString(res[0]["Scheme"]);
                        return new ResponseDataModel<AddPurchaseRes>(oPurchase);
                    }
                    else if (result != null && (Convert.ToString(res[0]["STATUS_CODE"]) != "200" && Convert.ToString(res[0]["STATUS_CODE"]) != ""))
                    {
                        return new ResponseDataModel<AddPurchaseRes>(null, Convert.ToString(res[0]["MESSAGE"]));
                    }
                    else
                    {
                        return new ResponseDataModel<AddPurchaseRes>(null, Convert.ToString(res[0]["Return_Message"]));
                    }
                }
                catch (Exception)
                {
                    using (var conn2 = MOAMCMOBILEDB)
                    {
                        var multi = await conn.QueryAsync("AMCMOB_INSERT_ADDPURCHASE", new
                        {
                            PANNO = panNo,
                            FOLIONO = folioNo,
                            SCHEMECODE = schemeName,
                            PLANCODE = plan,
                            OPTIONCODE = option,
                            AMOUNT = amount,
                            BROKERCODE = brokerCode,
                            SUBBROKERCODE = subBrokerCode,
                            SUBBROKERARNCODE = subBrokerArnCode,
                            EUINCODE = euinCode,
                            EUINDECLARATIONFLAG = euinDeclarationFlag,
                            PAYMENTMODE = PaymentMode,
                            BANKNAME = bankname,
                            BANKACCNO = bankacctnumber,
                            APPREFNO = "",
                            AppID,
                            BILLDESKURL = "",
                            STATUSCODE = "",
                            MESSAGE = "API Exception. Please check with Karvy.",
                            Branch = branch

                        }, commandType: CommandType.StoredProcedure);
                        {
                            var VerifiedList = multi.ToList();
                            if (VerifiedList[0].PURCHASEID != 0)
                            {
                                //oPurchase.purchaseId = Convert.ToInt32(VerifiedList[0].PURCHASEID) ?? 0;
                            }
                        }
                    }
                    return new ResponseDataModel<AddPurchaseRes>(null, "There is some technical issue, please try after some time.");
                }

            }
        }

        public async Task<ResponseDataModel<string>> additionalPurchaseConfirmation(string AppID, string panNo, AddPurchaseConfirmationReq request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var Details = await conn.QueryAsync("AMCMOB_Update_ADDPurchaseConfirmation", new
                {
                    PanNo = panNo,
                    PurchaseID = request.purchaseId,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = Details.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("", "There is some technical issue, please try after some time.");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }

        }

        public async Task<ResponseDataArrayModel<distributorListRes>> foliobrokerlist(string PanNo, distributorListReq request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var folio = Convert.ToString(request.folioNo) == "0" ? "" : Convert.ToString(request.folioNo);
                var folioDetails = await conn.QueryAsync("AMCMob_PROC_GETPANFOLIOSCHEMEWISE_BROKERCODE", new
                {
                    PAN = PanNo,
                    TYPEOFCUSTOMER = "MF",
                    FOLIONO = Convert.ToString(folio),
                    PLANTYPE = request.planType
                }, commandType: CommandType.StoredProcedure);
                {
                    List<distributorListRes> odistributorlistRes = new List<distributorListRes>();
                    var VerifiedList2 = folioDetails.ToList();
                    if (VerifiedList2.Count > 0)
                    {
                        foreach (var p in VerifiedList2.ToList())
                        {
                            odistributorlistRes.Add(new distributorListRes
                            {
                                folio = Convert.ToString(p.FOLIO) ?? "",
                                brokerCode = Convert.ToString(p.BROKERCODE) ?? "",
                                brokerName = Convert.ToString(p.BROKERNAME) ?? "",
                                subbrokerCode = Convert.ToString(p.SUBBROKERCODE) ?? "",
                                RIACode = Convert.ToString(p.RIACODE) ?? "",
                            });

                        }
                        return new ResponseDataArrayModel<distributorListRes>(odistributorlistRes);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }

                }

            }

        }

    }
}

