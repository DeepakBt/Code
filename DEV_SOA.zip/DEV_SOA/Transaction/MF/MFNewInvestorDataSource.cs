﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
   public interface IMFNewInvestorDataSource
    {
        Task<ResponseDataModel<SceenNewInvestorPanDetailsRes>> saveNewInvestorPanDetails(string AppID, string Role, SceenNewInvestorPanDetails request);
        Task<ResponseDataModel<SceenNewInvestorPanDetailsRes>> saveWebNewInvestorPanDetails(string AppID, string Role, SceenNewInvestorPanDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorBasicDetails(string AppID, Int64 userId, ScreenNewInvestorBasicDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorFatcaDetails(string AppID, Int64 userId, ScreenNewInvestorFatchDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorContactDetails(string AppID, Int64 userId, ScreenNewInvestorContactDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorNomineeDetails(string AppID, Int64 userId, ScreenNewInvestorNomineeDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorSchemeDetails(string AppID, Int64 userId, ScreenNewInvestorSchemeDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorBrokerDetails(string AppID, Int64 userId, ScreenNewInvestorBrokerDetails request);
        Task<ResponseDataModel<string>> saveNewInvestorBankDetails(string AppID, Int64 userId, ScreenNewInvestorBankDetails request);
        Task<ResponseDataModel<FinalSubmitRes>> saveNewInvestorSubmit(string AppID, Int64 userId, FinalSubmit request);
        Task<ResponseDataModel<FinalSubmitRes>> saveWEBNewInvestorSubmit(string AppID, Int64 userId, FinalSubmit request);
        Task<ResponseDataModel<string>> PaymentConfirmation(string AppID, Int64 userId, PaymentConfirmation request);


        //Task<ResponseDataModel<InvestorDetRes>> GetNewInvestorPanDetails(InvestorDetReq request, int screenNo);
        Task<ResponseDataModel<ScreenNewInvestorBasicDetailsRes>> GetNewInvestorBasicDetails(Int64 userId, long screenNo);
        Task<ResponseDataModel<ScreenNewInvestorFatchDetailsRes>> GetNewInvestorFatcaDetails(Int64 userId, long screenNo);
        Task<ResponseDataModel<ScreenNewInvestorContactDetailsRes>> GetNewInvestorContactDetails(Int64 userId, long screenNo);
        Task<ResponseDataModel<ScreenNewInvestorNomineeDetailsRes>> GetNewInvestorNomineeDetails(Int64 userId, long screenNo);
        Task<ResponseDataModel<ScreenNewInvestorSchemeDetailsRes>> GetNewInvestorSchemeDetails(Int64 userId, long screenNo);
        Task<ResponseDataModel<ScreenNewInvestorBrokerDetailsRes>> GetNewInvestorBrokerDetails(Int64 userId, long screenNo);
        Task<ResponseDataModel<ScreenNewInvestorBankDetailsRes>> GetNewInvestorBankDetails(Int64 userId, long screenNo);
    }
}
