﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using karvyAPI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public class MFSwitchRepository : ISwitchDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";

        public MFSwitchRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }

        public async Task<ResponseDataModel<FolioDetail>> folioDetailsSwitch(FolioDetailReq request)
        {
            string folioNo = request.folioNo;
            string scheme = request.schemeCode.Substring(3, 2);
            string plan = request.schemeCode.Substring(5, 2);
            string option = request.schemeCode.Substring(7, 1);
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo,
                    scheme,
                    plan,
                    option
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSwitchExistingSchemes", serviceUrl, inputJson);
                var p = JArray.Parse(result);
                FolioDetail oFolioDetail = new FolioDetail();
                List<FolioDetail> oFolioDetailRes = new List<FolioDetail>();
                if (p.Count > 0 && Convert.ToString(p[0]["STATUS_CODE"]) == "200")
                {
                    oFolioDetail.FundDescription = Convert.ToString(p[0]["FundDescription"]);
                    oFolioDetail.NAV = Convert.ToString(p[0]["NAV"]);
                    oFolioDetail.NAVDate = Convert.ToString(p[0]["NavDate"]);
                    oFolioDetail.mt_cuttime = Convert.ToString(p[0]["Cuttime"]);
                    oFolioDetail.MinAmount = Convert.ToDouble(Convert.ToString(p[0]["MinAmount"]));
                    oFolioDetail.mt_clrbalunit = Convert.ToString(p[0]["clrUnit"]);
                    oFolioDetail.MarketValue = Convert.ToString(p[0]["MarketValue"]);
                    oFolioDetail.investedAmount = Convert.ToString(p[0]["Invamount"]);
                    oFolioDetail.mt_redflag = Convert.ToString(p[0]["redflag"]);
                    oFolioDetail.Category = Convert.ToString(p[0]["Category"]);
                    oFolioDetail.SchemeGroup = Convert.ToString(p[0]["SchemeGroup"]);
                    oFolioDetail.mt_Addflag = Convert.ToString(p[0]["AddFlag"]);
                    oFolioDetail.mt_fund = Convert.ToString(p[0]["Fund"]);
                    oFolioDetail.Scheme = Convert.ToString(p[0]["Scheme"]);
                    oFolioDetail.Plan = Convert.ToString(p[0]["Plan"]);
                    oFolioDetail.Option = Convert.ToString(p[0]["Option"]);
                    oFolioDetail.schlink = Convert.ToString(p[0]["schlink"]);
                    oFolioDetail.BalanceUnit = Convert.ToDouble(Convert.ToString(p[0]["balUnit"]));
                    oFolioDetail.PlanMode = Convert.ToString(p[0]["PlanMode"]);
                    return new ResponseDataModel<FolioDetail>(oFolioDetail);
                }
                else if (result != null && (Convert.ToString(p[0]["STATUS_CODE"]) != "200" && Convert.ToString(p[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<FolioDetail>(null, Convert.ToString(p[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<FolioDetail>(null, Convert.ToString(p[0]["Return_Message"]));
                }

            }
            catch (Exception)
            {
                return new ResponseDataModel<FolioDetail>(null, "There is some technical issue, please try after some time.");
            }
        }

        public async Task<ResponseDataModel<AddpurchaseSchemeRes>> switchNewSchemes()
        {
            string category = "EQUITY FUND";
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    category
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSwitchNewSchemes", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                AddpurchaseSchemeRes oList = new AddpurchaseSchemeRes();
                Scheme oScheme = new Scheme();
                List<Scheme> oSchemeList = new List<Scheme>();
                foreach (var p in s.ToList())
                {
                    oSchemeList.Add(new Scheme
                    {
                        schemeId = Convert.ToString(p["Code"]),
                        schemeName = Convert.ToString(p["Description"]),
                    }
                 );
                }
                oList.Scheme = oSchemeList;
                return new ResponseDataModel<AddpurchaseSchemeRes>(oList);

            }
            catch (Exception)
            {
                return new ResponseDataModel<AddpurchaseSchemeRes>(null, "There is some technical issue, please try after some time.");
            }
        }

        //public async Task<ResponseDataModel<NewInvestmentSchemeRes>> newInvestmentSchemes(NewInvestmentSchemeReq request)
        //{
        //    string category = request.category;
        //    string folioNo = request.folioNo;
        //    string trnType = request.trnType;
        //    string scheme = request.scheme;
        //    string plan = request.plan;
        //    string option = request.option;
        //    try
        //    {
        //        object input = new
        //        {
        //            Adminusername,
        //            Adminpassword,
        //            folioNo,
        //            trnType,
        //            category,
        //            scheme,
        //            plan,
        //            option
        //        };
        //        string inputJson = JsonConvert.SerializeObject(input);
        //        var result = KarvyRequest.CreateHTTPRequest("MOSLSwitchNewInvestmentSchemeDetails", serviceUrl, inputJson);
        //        var s = JArray.Parse(result);
        //        SchemeDetails oSchemeDetails = new SchemeDetails();
        //        NewInvestmentSchemeRes oList = new NewInvestmentSchemeRes();
        //        Scheme oScheme = new Scheme();
        //        List<SchemeDetails> oSchemeList = new List<SchemeDetails>();
        //        foreach (var p in s.ToList())
        //        {
        //            oSchemeList.Add(new SchemeDetails
        //            {
        //                Fund = Convert.ToString(p["Fund"]),
        //                Scheme = Convert.ToString(p["Scheme"]),
        //                Plan = Convert.ToString(p["Plan"]),
        //                Description = Convert.ToString(p["Description"]),
        //                Cutofftime = Convert.ToString(p["Cutofftime"]),
        //                MinAmount = Convert.ToString(p["MinAmount"]),
        //                NAVDate = Convert.ToString(p["NAVDate"]),
        //                NAV = Convert.ToString(p["NAV"]),
        //                Option = Convert.ToString(p["Option"]),
        //                Option1 = Convert.ToString(p["Option1"]),
        //                Option2 = Convert.ToString(p["Option2"]),
        //                SCHlink = Convert.ToString(p["Option2"]),
        //                Category = Convert.ToString(p["Category"]),
        //                PlanMode = Convert.ToString(p["PlanMode"])
        //            }
        //         );
        //        }
        //        oList.SchemeDetails = oSchemeList;
        //        return new ResponseDataModel<NewInvestmentSchemeRes>(oList);

        //    }
        //    catch
        //    {
        //        return new ResponseDataModel<NewInvestmentSchemeRes>(null);
        //    }
        //}

        public async Task<ResponseDataModel<NewInvPlanRes>> newInvestmentPlans(NewInvPlanReq request)
        {
            string scheme = request.scheme;
            string mode = request.mode;
            string accno = request.folioNumber;
            string exscheme = request.moSchemeCode.Substring(3, 2); ;
            string explan = request.moSchemeCode.Substring(5, 2);
            string exoption = request.moSchemeCode.Substring(7, 1);
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    scheme,
                    mode,
                    accno,
                    exscheme,
                    explan,
                    exoption
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSwitchNewPlans", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                PlanRes oPlanRes = new PlanRes();
                NewInvPlanRes oList = new NewInvPlanRes();
                List<PlanRes> oPlanList = new List<PlanRes>();
                if (s != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    foreach (var p in s.ToList())
                    {
                        oPlanList.Add(new PlanRes
                        {
                            planCode = Convert.ToString(p["Code"]),
                            planName = Convert.ToString(p["Description"]),
                        }
                     );
                    }
                    oList.PlanList = oPlanList;
                    return new ResponseDataModel<NewInvPlanRes>(oList);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<NewInvPlanRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<NewInvPlanRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }
                {
                    throw new NoDataException(false);
                }
            }
            catch
            {
                return new ResponseDataModel<NewInvPlanRes>(null, "There is some technical issue, please try after some time.");
            }
        }

        public async Task<ResponseDataModel<NewInvOptionsRes>> newInvestmentOptions(NewInvOptionsReq request)
        {
            string Scheme = request.scheme;
            string Plan = request.plan;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Scheme,
                    Plan
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSwitchNewOptions", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                NewInvOptionsRes oOptionRes = new NewInvOptionsRes();
                OptionList oList = new OptionList();
                List<OptionList> oOptionList = new List<OptionList>();
                if (s != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    foreach (var p in s.ToList())
                    {
                        oOptionList.Add(new OptionList
                        {
                            Option = Convert.ToString(p["Option"]),
                            Description = Convert.ToString(p["Description"])
                        }
                     );
                    }
                    oOptionRes.OptionList = oOptionList;
                    return new ResponseDataModel<NewInvOptionsRes>(oOptionRes);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<NewInvOptionsRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<NewInvOptionsRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }
                {
                    throw new NoDataException(false);
                }
            }
            catch (Exception)
            {
                return new ResponseDataModel<NewInvOptionsRes>(null, "There is some technical issue, please try after some time.");
            }
        }

        public async Task<ResponseDataModel<SwitchTransactionRes>> saveswitchTransaction(string AppID, string PanNo,string UserAgent, SwitchTransactionReq request)
        {
            string branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            else
            {
                branchCode = "MB88";
            }
            string userid = PanNo;
            string Ffund = request.schemeCode.Substring(0, 3);
            string Fscheme = request.schemeCode.Substring(3, 2);
            string Fplan = request.schemeCode.Substring(5, 2);
            string Foption = request.schemeCode.Substring(7, 1);
            string Facno = request.folioNumber;
            string RedFlg = request.switchType;
            string UntAmtFlg = request.untamtflg;
            string UntAmtValue = Convert.ToString(request.untamtvalue);
            string Tfund = "127";
            string Tscheme = request.toScheme;
            string Tplan = request.toPlan;
            string Toption = request.toOption;
            string Tacno = request.toFoliNumber;
            string Agent = request.agent;
            string Userid = "";
            string Tpin = "1111";
            string Mstatus = "";
            string Fname = "";
            string Sname = "";
            string Tname = "";
            string Pangno = PanNo;
            string Mapinid = "43543";
            string entby = "";
            string oldihno = request.oldihno == "" ? "0" : request.oldihno;
            string entdt = DateTime.Now.ToString("yyyy-MM-dd");
            string EUINno = request.euinno;
            string EUINflag = request.euinflag == true ? "Y" : "N";
            string EUINopt = "";
            string EUINsubarncode = request.euinsubarncode;
            string ErrNo = "";
            string ErrMsg = "";
            string refno = "";
            string msg = "";
            string resurl = "";

            string Clientname = "";
            string Email = "";
            string status_code = "";
            string message = "";
            string Branch = branchCode;
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = PanNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                        Email = (from P in VerifiedList
                                 select P.Email).FirstOrDefault();
                    }
                }
            }

            Userid = Email == "" ? Clientname : Email;
            Fname = Clientname;
            SwitchTransactionRes oSWT = new SwitchTransactionRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Ffund,
                    Fscheme,
                    Fplan,
                    Foption,
                    Facno,
                    RedFlg,
                    UntAmtFlg,
                    UntAmtValue,
                    Tfund,
                    Tscheme,
                    Tplan,
                    Toption,
                    Tacno,
                    Agent,
                    Userid,
                    Tpin,
                    Mstatus,
                    Fname,
                    Sname,
                    Tname,
                    Pangno,
                    Mapinid,
                    entby,
                    oldihno,
                    entdt,
                    EUINno,
                    EUINflag,
                    EUINopt,
                    EUINsubarncode,
                    ErrNo,
                    ErrMsg,
                    Branch
                };
                string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLSwitchSaveTransaction", serviceUrl, inputJson);
                var res = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SWITCHTRANSACTION", new
                    {
                        userid,
                        Ffund,
                        Fscheme,
                        Fplan,
                        Foption,
                        Facno,
                        RedFlg,
                        UntAmtFlg,
                        UntAmtValue,
                        Tfund,
                        Tscheme,
                        Tplan,
                        Toption,
                        Tacno,
                        Agent,
                        TUSERID = Userid,
                        Tpin,
                        Mstatus,
                        Fname,
                        Sname,
                        Tname,
                        Pangno,
                        Mapinid,
                        entby,
                        oldihno,
                        entdt,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        ErrNo = Convert.ToString(res[0]["STATUS_CODE"]),
                        ErrMsg,
                        REFNO = Convert.ToString(res[0]["REFNO"]),
                        MSG = Convert.ToString(res[0]["MESSAGE"]),
                        RESURL = resurl,
                        AppID,
                        BRANCH=Branch
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }

                if (result != null && Convert.ToString(res[0]["STATUS_CODE"]) == "200")
                {
                    status_code = Convert.ToString(res[0]["STATUS_CODE"]);
                    message = Convert.ToString(res[0]["MESSAGE"]);
                    oSWT.refno = Convert.ToString(res[0]["REFNO"]);

                    return new ResponseDataModel<SwitchTransactionRes>(oSWT);
                }
                else if (result != null && (Convert.ToString(res[0]["STATUS_CODE"]) != "200" && Convert.ToString(res[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<SwitchTransactionRes>(null, Convert.ToString(res[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<SwitchTransactionRes>(null, Convert.ToString(res[0]["Return_Message"]));
                }
            }
            catch (Exception)
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SWITCHTRANSACTION", new
                    {
                        userid,
                        Ffund,
                        Fscheme,
                        Fplan,
                        Foption,
                        Facno,
                        RedFlg,
                        UntAmtFlg,
                        UntAmtValue,
                        Tfund,
                        Tscheme,
                        Tplan,
                        Toption,
                        Tacno,
                        Agent,
                        TUSERID = Userid,
                        Tpin,
                        Mstatus,
                        Fname,
                        Sname,
                        Tname,
                        Pangno,
                        Mapinid,
                        entby,
                        oldihno,
                        entdt,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        ErrNo = "",
                        ErrMsg,
                        REFNO = "",
                        MSG = "API Exception. Please check with Karvy.",
                        RESURL = resurl,
                        AppID,
                        BRANCH = Branch
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                return new ResponseDataModel<SwitchTransactionRes>(null, "There is some technical issue, please try after some time.");
            }
        }

        public async Task<ResponseDataModel<SwitchTransactionRes>> saveWebswitchTransaction(string AppID, string PanNo,string UserAgent, SwitchTransactionReq request)
        {
            var branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            else
            {
                branchCode = "WB99";
            }

            string userid = PanNo;
            string Ffund = request.schemeCode.Substring(0, 3);
            string Fscheme = request.schemeCode.Substring(3, 2);
            string Fplan = request.schemeCode.Substring(5, 2);
            string Foption = request.schemeCode.Substring(7, 1);
            string Facno = request.folioNumber;
            string RedFlg = request.switchType;
            string UntAmtFlg = request.untamtflg;
            string UntAmtValue = Convert.ToString(request.untamtvalue);
            string Tfund = "127";
            string Tscheme = request.toScheme;
            string Tplan = request.toPlan;
            string Toption = request.toOption;
            string Tacno = request.toFoliNumber;
            string Agent = request.agent;
            string Userid = "";
            string Tpin = "1111";
            string Mstatus = "";
            string Fname = "";
            string Sname = "";
            string Tname = "";
            string Pangno = PanNo;
            string Mapinid = "43543";
            string entby = "";
            string oldihno = request.oldihno == "" ? "0" : request.oldihno;
            string entdt = DateTime.Now.ToString("yyyy-MM-dd");
            string EUINno = request.euinno;
            string EUINflag = request.euinflag == true ? "Y" : "N";
            string EUINopt = "";
            string EUINsubarncode = request.euinsubarncode;
            string ErrNo = "";
            string ErrMsg = "";
            string refno = "";
            string msg = "";
            string resurl = "";

            string Clientname = "";
            string Email = "";
            string status_code = "";
            string message = "";
            string Branch = branchCode;
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = PanNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                        Email = (from P in VerifiedList
                                 select P.Email).FirstOrDefault();
                    }
                }
            }

            Userid = Email == "" ? Clientname : Email;
            Fname = Clientname;
            SwitchTransactionRes oSWT = new SwitchTransactionRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Ffund,
                    Fscheme,
                    Fplan,
                    Foption,
                    Facno,
                    RedFlg,
                    UntAmtFlg,
                    UntAmtValue,
                    Tfund,
                    Tscheme,
                    Tplan,
                    Toption,
                    Tacno,
                    Agent,
                    Userid,
                    Tpin,
                    Mstatus,
                    Fname,
                    Sname,
                    Tname,
                    Pangno,
                    Mapinid,
                    entby,
                    oldihno,
                    entdt,
                    EUINno,
                    EUINflag,
                    EUINopt,
                    EUINsubarncode,
                    ErrNo,
                    ErrMsg,
                    Branch
                };
                string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLSwitchSaveTransaction", serviceUrl, inputJson);
                var res = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SWITCHTRANSACTION", new
                    {
                        userid,
                        Ffund,
                        Fscheme,
                        Fplan,
                        Foption,
                        Facno,
                        RedFlg,
                        UntAmtFlg,
                        UntAmtValue,
                        Tfund,
                        Tscheme,
                        Tplan,
                        Toption,
                        Tacno,
                        Agent,
                        TUSERID = Userid,
                        Tpin,
                        Mstatus,
                        Fname,
                        Sname,
                        Tname,
                        Pangno,
                        Mapinid,
                        entby,
                        oldihno,
                        entdt,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        ErrNo = Convert.ToString(res[0]["STATUS_CODE"]),
                        ErrMsg,
                        REFNO = Convert.ToString(res[0]["REFNO"]),
                        MSG = Convert.ToString(res[0]["MESSAGE"]),
                        RESURL = resurl,
                        AppID,
                        BRANCH = Branch
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }

                if (result != null && Convert.ToString(res[0]["STATUS_CODE"]) == "200")
                {
                    status_code = Convert.ToString(res[0]["STATUS_CODE"]);
                    message = Convert.ToString(res[0]["MESSAGE"]);
                    oSWT.refno = Convert.ToString(res[0]["REFNO"]);

                    return new ResponseDataModel<SwitchTransactionRes>(oSWT);
                }
                else if (result != null && (Convert.ToString(res[0]["STATUS_CODE"]) != "200" && Convert.ToString(res[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<SwitchTransactionRes>(null, Convert.ToString(res[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<SwitchTransactionRes>(null, Convert.ToString(res[0]["Return_Message"]));
                }
            }
            catch (Exception)
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SWITCHTRANSACTION", new
                    {
                        userid,
                        Ffund,
                        Fscheme,
                        Fplan,
                        Foption,
                        Facno,
                        RedFlg,
                        UntAmtFlg,
                        UntAmtValue,
                        Tfund,
                        Tscheme,
                        Tplan,
                        Toption,
                        Tacno,
                        Agent,
                        TUSERID = Userid,
                        Tpin,
                        Mstatus,
                        Fname,
                        Sname,
                        Tname,
                        Pangno,
                        Mapinid,
                        entby,
                        oldihno,
                        entdt,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        ErrNo = "",
                        ErrMsg,
                        REFNO = "",
                        MSG = "API Exception. Please check with Karvy.",
                        RESURL = resurl,
                        AppID,
                        BRANCH = Branch
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                //System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "GetBankdetailsByIFSC:" + ex.Message);
                return new ResponseDataModel<SwitchTransactionRes>(null, "There is some technical issue, please try after some time.");
            }
        }

    }
}
