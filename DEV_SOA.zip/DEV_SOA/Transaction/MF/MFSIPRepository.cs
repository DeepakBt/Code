﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using karvyAPI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using static Transaction.Models.MFSIP;

namespace Transaction.MF
{
    public class MFSIPRepository : IMFSIPDataSource
    {

        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";

        public MFSIPRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }

        public async Task<ResponseDataModel<SIPPlanOptionsRes>> SIPPlanOptions(SIPPlanOptionsReq request)
        {
            string Scheme = request.scheme;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Scheme
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSIPPlanOptions", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                SIPPlanOptions oSIPPlanOptions = new SIPPlanOptions();
                SIPPlanOptionsRes oList = new SIPPlanOptionsRes();
                List<SIPPlanOptions> oPlanList = new List<SIPPlanOptions>();
                foreach (var p in s.ToList())
                {
                    oPlanList.Add(new SIPPlanOptions
                    {
                        code = Convert.ToString(p["Code"]),
                        description = Convert.ToString(p["Description"]),
                    }
                 );
                }
                oList.SIPPlanOptions = oPlanList;
                return new ResponseDataModel<SIPPlanOptionsRes>(oList);

            }
            catch
            {
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<SchemeDetailsRes>> SIPSchemePurchaseDetail(SchemeDetailsReq request)
        {
            string scheme = request.scheme;
            string plan = request.plan;
            string option = request.option;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    scheme,
                    plan,
                    option

                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSIPPurchaseDetails", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                SchemeDetail oSchemeDetail = new SchemeDetail();
                SchemeDetailsRes oList = new SchemeDetailsRes();
                List<SchemeDetail> oPlanList = new List<SchemeDetail>();
                foreach (var p in s.ToList())
                {
                    oPlanList.Add(new SchemeDetail
                    {
                        scheme = Convert.ToString(p["SCHEME"]),
                        plan = Convert.ToString(p["PLAN"]),
                        option = Convert.ToString(p["OPTION"]),
                        description = Convert.ToString(p["DESCRIPTION"]),
                        cutofftime = Convert.ToString(p["CUTOFFTIME"]),
                        minamount = Convert.ToDouble(Convert.ToString(p["MINAMOUNT"])),
                        schemedescription = Convert.ToString(p["SCHEMEDESCRIPTION"]),
                        plandescription = Convert.ToString(p["PLANDESCRIPTION"]),
                        optiondescription = Convert.ToString(p["OPTIONDESCRIPTION"]),
                        planoptiondescription = Convert.ToString(p["PLANOPTIONDESCRIPTION"]),
                    }
                 );
                }
                oList.SchemeDetail = oPlanList;
                return new ResponseDataModel<SchemeDetailsRes>(oList);

            }
            catch
            {
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<SubSIPRes>> sipTransaction(string AppId, string panNo, SubSIPReq request, string UserAgent)
        {
            string Siptype = "Online";
            string scheme = request.scheme;
            string plan = request.plan;
            string option = request.option;
            string acno = request.folioNo;
            string urno = "";
            string trtype = "ISIP";
            string trdate = "";
            string amount = Convert.ToString(request.Amount);
            string lname = "";
            string entby = "";
            string freq = request.frequency;
            string sipdate = request.sipDate;
            string stdt = request.startDate;
            string enddt = request.endDate;
            string distributor = request.brokerCode.Contains("ARN") ? request.brokerCode : "";
            string ricode = request.brokerCode.Contains("IN") ? request.brokerCode : "";
            string BnkActype = "";
            string Bnkname = request.bankName;
            string BnkAcno = request.bankAccNo;
            string BnkAdd = "";
            string Bnkcity = "";
            string Bnkpin = "0";
            string Bnkifsc = "";
            string Bnkmicr = "0";
            string SubBroker = request.SubBroker; ;
            string EUINno = request.euinCode;
            string EUINflag = request.euinDeclarationFlag == true ? "Y" : "N"; ;
            string EUINopt = "";
            string EUINsubarncode = request.subBrokerCode;
            string ResUrno = "";
            string TIME_STAMP = "";
            string ERRNO = "";
            string StatusCode = "";
            string StatusMsg = "";
            string ResposneRefNo = "";
            string ResponseURL = "";
            string status_code = "";
            string message = "";
            string errno = "";
            string branch = "MB88";
            string Urno = "";
            string ihno = "";
            string refno = "";
            string batchno = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branch = "WH99";
                }
                else
                {
                    branch = "MB88";
                }
            }
            string Clientname = "";
            string Email = "";
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                        Email = (from P in VerifiedList
                                 select P.Email).FirstOrDefault();
                    }
                }
            }
            lname = Clientname;
            entby = Email;

            SubSIPRes oSubSIPRes = new SubSIPRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Siptype,
                    scheme,
                    plan,
                    option,
                    acno,
                    branch,
                    trtype,
                    amount,
                    lname,
                    entby,
                    freq,
                    sipdate,
                    stdt,
                    enddt,
                    distributor,
                    ricode,
                    BnkActype,
                    Bnkname,
                    BnkAcno,
                    BnkAdd,
                    Bnkcity,
                    Bnkpin,
                    Bnkifsc,
                    Bnkmicr,
                    SubBroker,
                    EUINno,
                    EUINflag,
                    EUINopt,
                    EUINsubarncode

                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSIPInsert", serviceUrl, inputJson);
                var s = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SIPTRANSACTION", new
                    {
                        PANNO = panNo,
                        Siptype,
                        Scheme = scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        acno,
                        urno,
                        Branch = branch,
                        trtype,
                        trdate,
                        amount,
                        lname,
                        entby,
                        freq,
                        sipdate,
                        stdt,
                        enddt,
                        distributor = request.brokerCode,
                        ihno,
                        refno,
                        batchno,
                        BnkActype,
                        Bnkname,
                        BnkAcno,
                        BnkAdd,
                        Bnkcity,
                        Bnkpin,
                        Bnkifsc,
                        Bnkmicr,
                        SubBroker,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        URNNO = Convert.ToString(s[0]["URNNO"]),
                        URNexpirydate = Convert.ToString(s[0]["URNexpirydate"]),
                        TIME_STAMP = Convert.ToString(s[0]["TIME_STAMP"]),
                        ERRNO = Convert.ToString(s[0]["ERRNO"]),
                        ResposneRefNo = Convert.ToString(s[0]["REFNO"]),
                        ResponseURL = Convert.ToString(s[0]["MESSAGE"]),
                        AppId
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            oSubSIPRes.sipId = Convert.ToInt32(VerifiedList[0].SIPID);
                        }
                    }
                }

                if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                    message = Convert.ToString(s[0]["MESSAGE"]);
                    oSubSIPRes.ihno = Convert.ToString(s[0]["IHNO"]);
                    oSubSIPRes.refno = Convert.ToString(s[0]["REFNO"]);
                    oSubSIPRes.batchno = Convert.ToString(s[0]["BATCHNO"]);
                    oSubSIPRes.urnno = Convert.ToString(s[0]["URNNO"]);
                    oSubSIPRes.time_stamp = Convert.ToString(s[0]["TIME_STAMP"]);
                    oSubSIPRes.urnExpiryDate = Convert.ToString(s[0]["URNexpirydate"]);
                    errno = Convert.ToString(s[0]["ERRNO"]);


                    return new ResponseDataModel<SubSIPRes>(oSubSIPRes);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<SubSIPRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<SubSIPRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }

            }
            catch (Exception)
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SIPTRANSACTION", new
                    {
                        PANNO = panNo,
                        Siptype,
                        Scheme = scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        acno,
                        urno,
                        Branch = branch,
                        trtype,
                        trdate,
                        amount,
                        lname,
                        entby,
                        freq,
                        sipdate,
                        stdt,
                        enddt,
                        distributor = request.brokerCode,
                        ihno,
                        refno,
                        batchno,
                        BnkActype,
                        Bnkname,
                        BnkAcno,
                        BnkAdd,
                        Bnkcity,
                        Bnkpin,
                        Bnkifsc,
                        Bnkmicr,
                        SubBroker,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        URNNO = "",
                        URNexpirydate = "",
                        TIME_STAMP = "",
                        ERRNO = "",
                        ResposneRefNo = "",
                        ResponseURL = "API Exception. Please check with Karvy.",
                        AppId
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            oSubSIPRes.sipId = Convert.ToInt32(VerifiedList[0].SIPID);
                        }
                    }
                }
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<SubSIPRes>> sipWebTransaction(string AppId, string panNo, SubSIPReq request)
        {
            string Siptype = "Online";
            string scheme = request.scheme;
            string plan = request.plan;
            string option = request.option;
            string acno = request.folioNo;
            string urno = "";
            string trtype = "ISIP";
            string trdate = "";
            string amount = Convert.ToString(request.Amount);
            string lname = "";
            string entby = "";
            string freq = request.frequency;
            string sipdate = request.sipDate;
            string stdt = request.startDate;
            string enddt = request.endDate;
            string distributor = request.brokerCode.Contains("ARN") ? request.brokerCode : "";
            string ricode = request.brokerCode.Contains("IN") ? request.brokerCode : "";
            string BnkActype = "";
            string Bnkname = request.bankName;
            string BnkAcno = request.bankAccNo;
            string BnkAdd = "";
            string Bnkcity = "";
            string Bnkpin = "0";
            string Bnkifsc = "";
            string Bnkmicr = "0";
            string SubBroker = request.SubBroker; ;
            string EUINno = request.euinCode;
            string EUINflag = request.euinDeclarationFlag == true ? "Y" : "N"; ;
            string EUINopt = "";
            string EUINsubarncode = request.subBrokerCode;
            string ResUrno = "";
            string TIME_STAMP = "";
            string ERRNO = "";
            string StatusCode = "";
            string StatusMsg = "";
            string ResposneRefNo = "";
            string ResponseURL = "";
            string status_code = "";
            string message = "";
            string errno = "";
            string branch = "WB99";
            string Urno = "";
            string ihno = "";
            string refno = "";
            string batchno = "";

            string Clientname = "";
            string Email = "";
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                        Email = (from P in VerifiedList
                                 select P.Email).FirstOrDefault();
                    }
                }
            }
            lname = Clientname;
            entby = Email;

            SubSIPRes oSubSIPRes = new SubSIPRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Siptype,
                    scheme,
                    plan,
                    option,
                    acno,
                    branch,
                    trtype,
                    amount,
                    lname,
                    entby,
                    freq,
                    sipdate,
                    stdt,
                    enddt,
                    distributor,
                    ricode,
                    BnkActype,
                    Bnkname,
                    BnkAcno,
                    BnkAdd,
                    Bnkcity,
                    Bnkpin,
                    Bnkifsc,
                    Bnkmicr,
                    SubBroker,
                    EUINno,
                    EUINflag,
                    EUINopt,
                    EUINsubarncode

                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSIPInsert", serviceUrl, inputJson);
                var s = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SIPTRANSACTION", new
                    {
                        PANNO = panNo,
                        Siptype,
                        Scheme = scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        acno,
                        urno,
                        Branch = branch,
                        trtype,
                        trdate,
                        amount,
                        lname,
                        entby,
                        freq,
                        sipdate,
                        stdt,
                        enddt,
                        distributor = request.brokerCode,
                        ihno,
                        refno,
                        batchno,
                        BnkActype,
                        Bnkname,
                        BnkAcno,
                        BnkAdd,
                        Bnkcity,
                        Bnkpin,
                        Bnkifsc,
                        Bnkmicr,
                        SubBroker,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        URNNO = Convert.ToString(s[0]["URNNO"]),
                        URNexpirydate = Convert.ToString(s[0]["URNexpirydate"]),
                        TIME_STAMP = Convert.ToString(s[0]["TIME_STAMP"]),
                        ERRNO = Convert.ToString(s[0]["ERRNO"]),
                        ResposneRefNo = Convert.ToString(s[0]["REFNO"]),
                        ResponseURL = Convert.ToString(s[0]["MESSAGE"]),
                        AppId
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            oSubSIPRes.sipId = Convert.ToInt32(VerifiedList[0].SIPID);
                        }
                    }
                }

                if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                    message = Convert.ToString(s[0]["MESSAGE"]);
                    oSubSIPRes.ihno = Convert.ToString(s[0]["IHNO"]);
                    oSubSIPRes.refno = Convert.ToString(s[0]["REFNO"]);
                    oSubSIPRes.batchno = Convert.ToString(s[0]["BATCHNO"]);
                    oSubSIPRes.urnno = Convert.ToString(s[0]["URNNO"]);
                    oSubSIPRes.time_stamp = Convert.ToString(s[0]["TIME_STAMP"]);
                    oSubSIPRes.urnExpiryDate = Convert.ToString(s[0]["URNexpirydate"]);
                    errno = Convert.ToString(s[0]["ERRNO"]);


                    return new ResponseDataModel<SubSIPRes>(oSubSIPRes);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<SubSIPRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<SubSIPRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }

            }
            catch (Exception)
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SIPTRANSACTION", new
                    {
                        PANNO = panNo,
                        Siptype,
                        Scheme = scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        acno,
                        urno,
                        Branch = branch,
                        trtype,
                        trdate,
                        amount,
                        lname,
                        entby,
                        freq,
                        sipdate,
                        stdt,
                        enddt,
                        distributor = request.brokerCode,
                        ihno,
                        refno,
                        batchno,
                        BnkActype,
                        Bnkname,
                        BnkAcno,
                        BnkAdd,
                        Bnkcity,
                        Bnkpin,
                        Bnkifsc,
                        Bnkmicr,
                        SubBroker,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        URNNO = "",
                        URNexpirydate = "",
                        TIME_STAMP = "",
                        ERRNO = "",
                        ResposneRefNo = "",
                        ResponseURL = "API Exception. Please check with Karvy.",
                        AppId
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            oSubSIPRes.sipId = Convert.ToInt32(VerifiedList[0].SIPID);
                        }
                    }
                }
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<string>> sipConfirmation(string panNo, SIPBillDesk request)
        {
            Boolean billdeskflag = request.billdeskflag;
            int SIPID = request.SIPID;
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_UPDATE_SIP_BILLDESKSTATUS", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    billdeskflag,
                    SIPID

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>("There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        public async Task<ResponseDataModel<SubSIPRes>> sipMandateTransaction(string AppId, string panNo, SubSIPReq request, string UserAgent)
        {
            string Siptype = "Online";
            string scheme = request.scheme;
            string plan = request.plan;
            string option = request.option;
            string acno = request.folioNo;
            string urno = "";
            string trtype = "ISIP";
            string trdate = "";
            string amount = Convert.ToString(request.Amount);
            string lname = "";
            string entby = "";
            string freq = request.frequency;
            string sipdate = request.sipDate;
            string stdt = request.startDate;
            string enddt = request.endDate;
            string distributor = request.brokerCode.Contains("ARN") ? request.brokerCode : "";
            string ricode = request.brokerCode.Contains("IN") ? request.brokerCode : "";
            string BnkActype = "";
            string Bnkname = request.bankName;
            string BnkAcno = request.bankAccNo;
            string BnkAdd = "";
            string Bnkcity = "";
            string Bnkpin = "0";
            string Bnkifsc = "";
            string Bnkmicr = "0";
            string SubBroker = request.SubBroker; ;
            string EUINno = request.euinCode;
            string EUINflag = request.euinDeclarationFlag == true ? "Y" : "N"; ;
            string EUINopt = "";
            string EUINsubarncode = request.subBrokerCode;

            // Newly added parameters added in API
            string SIPinstalno = "";
            string Siprefno = "";
            string SIPinstdate = "";
            string SIPmonth = "";
            string Paymode = "";
            string PG = "";
            string PGtxnrefno = "";
            string URNNO = "";
            string UMRNno = "";
            string DebitCardno = "";
            string UPIadd = "";
            string ExpiryDate = "";
            string MandateLimit = "";

            string ResUrno = "";
            string TIME_STAMP = "";
            string ERRNO = "";
            string StatusCode = "";
            string StatusMsg = "";
            string ResposneRefNo = "";
            string ResponseURL = "";
            string status_code = "";
            string message = "";
            string errno = "";
            string branch = "MB88";
            string Urno = "";
            string ihno = "";
            string refno = "";
            string batchno = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branch = "WH99";
                }
                else
                {
                    branch = "MB88";
                }
            }
            string Clientname = "";
            string Email = "";
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                        Email = (from P in VerifiedList
                                 select P.Email).FirstOrDefault();
                    }
                }
            }
            lname = Clientname;
            entby = Email;

            SubSIPRes oSubSIPRes = new SubSIPRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Siptype,
                    scheme,
                    plan,
                    option,
                    acno,
                    branch,
                    trtype,
                    amount,
                    lname,
                    entby,
                    freq,
                    sipdate,
                    stdt,
                    enddt,
                    distributor,
                    ricode,
                    BnkActype,
                    Bnkname,
                    BnkAcno,
                    BnkAdd,
                    Bnkcity,
                    Bnkpin,
                    Bnkifsc,
                    Bnkmicr,
                    SubBroker,
                    EUINno,
                    EUINflag,
                    EUINopt,
                    EUINsubarncode

                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSIPInsert", serviceUrl, inputJson);
                var s = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SIPTRANSACTION", new
                    {
                        PANNO = panNo,
                        Siptype,
                        Scheme = scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        acno,
                        urno,
                        Branch = branch,
                        trtype,
                        trdate,
                        amount,
                        lname,
                        entby,
                        freq,
                        sipdate,
                        stdt,
                        enddt,
                        distributor = request.brokerCode,
                        ihno,
                        refno,
                        batchno,
                        BnkActype,
                        Bnkname,
                        BnkAcno,
                        BnkAdd,
                        Bnkcity,
                        Bnkpin,
                        Bnkifsc,
                        Bnkmicr,
                        SubBroker,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        URNNO = Convert.ToString(s[0]["URNNO"]),
                        URNexpirydate = Convert.ToString(s[0]["URNexpirydate"]),
                        TIME_STAMP = Convert.ToString(s[0]["TIME_STAMP"]),
                        ERRNO = Convert.ToString(s[0]["ERRNO"]),
                        ResposneRefNo = Convert.ToString(s[0]["REFNO"]),
                        ResponseURL = Convert.ToString(s[0]["MESSAGE"]),
                        AppId
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            oSubSIPRes.sipId = Convert.ToInt32(VerifiedList[0].SIPID);
                        }
                    }
                }

                if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                    message = Convert.ToString(s[0]["MESSAGE"]);
                    oSubSIPRes.ihno = Convert.ToString(s[0]["IHNO"]);
                    oSubSIPRes.refno = Convert.ToString(s[0]["REFNO"]);
                    oSubSIPRes.batchno = Convert.ToString(s[0]["BATCHNO"]);
                    oSubSIPRes.urnno = Convert.ToString(s[0]["URNNO"]);
                    oSubSIPRes.time_stamp = Convert.ToString(s[0]["TIME_STAMP"]);
                    oSubSIPRes.urnExpiryDate = Convert.ToString(s[0]["URNexpirydate"]);
                    errno = Convert.ToString(s[0]["ERRNO"]);


                    return new ResponseDataModel<SubSIPRes>(oSubSIPRes);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<SubSIPRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<SubSIPRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }

            }
            catch (Exception)
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_SIPTRANSACTION", new
                    {
                        PANNO = panNo,
                        Siptype,
                        Scheme = scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        acno,
                        urno,
                        Branch = branch,
                        trtype,
                        trdate,
                        amount,
                        lname,
                        entby,
                        freq,
                        sipdate,
                        stdt,
                        enddt,
                        distributor = request.brokerCode,
                        ihno,
                        refno,
                        batchno,
                        BnkActype,
                        Bnkname,
                        BnkAcno,
                        BnkAdd,
                        Bnkcity,
                        Bnkpin,
                        Bnkifsc,
                        Bnkmicr,
                        SubBroker,
                        EUINno,
                        EUINflag,
                        EUINopt,
                        EUINsubarncode,
                        URNNO = "",
                        URNexpirydate = "",
                        TIME_STAMP = "",
                        ERRNO = "",
                        ResposneRefNo = "",
                        ResponseURL = "API Exception. Please check with Karvy.",
                        AppId
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            oSubSIPRes.sipId = Convert.ToInt32(VerifiedList[0].SIPID);
                        }
                    }
                }
                throw new NoDataException(false);
            }
        }

    }

}

