﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/MFRedemption")]
    [ValidateModel]
    [Authorize]
    public class MFRedemptionController : ControllerBase
    {
        private readonly IMFRedemptionDataSource _MFRedemptionDataSource;
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public MFRedemptionController(TokenHelper tokenHelper, IMFRedemptionDataSource MFRedemptionDataSource, IMasterDataSource MasterDataSource)
        {
            _MFRedemptionDataSource = MFRedemptionDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        [HttpPost("RedemptionTransaction")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<RedemptionTraRes>), 200)]
        public async Task<IActionResult> RedemptionTransaction([FromBody]RedemptionTraReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var panNo = User.Identity.Name;
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _MFRedemptionDataSource.RedemptionTransaction(AppId, panNo,UserAgent, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }

        [HttpGet("redemptionContent")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ReduceRedemptionRes>), 200)]
        public async Task<IActionResult> redemptionContent( ReduceRedemptionrequest request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _MFRedemptionDataSource.ReduceRedepmtionTransaction(AppId, panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }
    }
}