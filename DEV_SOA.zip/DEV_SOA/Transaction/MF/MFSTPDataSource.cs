﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public interface IMFSTPDataSource
    {
        Task<ResponseDataModel<STPContentRes>> STPContent();
        //Task<ResponseDataModel<ExistingSchemeRes>> STPexistingSchemes(ExistingSchemeReq request);
        Task<ResponseDataArrayModel<Scheme>> STPSchemes();
        Task<ResponseDataArrayModel<PlanRes>> STPPlans(STPPlanReq request);
        Task<ResponseDataArrayModel<OptionRes>> STPOptions(STPOptionReq request);
        Task<ResponseDataModel<STPTransRes>> stpTransaction(string AppId,string panNo,string UserAgent, STPTransReq request);
        Task<ResponseDataModel<STPTransRes>> WebstpTransaction(string AppId, string panNo,string UserAgent, STPTransReq request);
        Task<ResponseDataArrayModel<frequency>> stpFrequency();
        
    }
}
