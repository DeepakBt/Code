﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public interface IMFRedemptionDataSource
    {
       // Task<ResponseDataModel<RedemptionValidRes>> RedemptionValidation(RedemptionValidReq request);
        Task<ResponseDataModel<RedemptionTraRes>> RedemptionTransaction(string AppId,string panNo,string UserAgent,RedemptionTraReq request);
        Task<ResponseDataModel<ReduceRedemptionRes>> ReduceRedepmtionTransaction(string AppId, string panNo, ReduceRedemptionrequest request);

    }
}
