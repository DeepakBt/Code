﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
   public interface ISwitchDataSource
    {
        Task<ResponseDataModel<FolioDetail>> folioDetailsSwitch(FolioDetailReq request);

        Task<ResponseDataModel<AddpurchaseSchemeRes>> switchNewSchemes();
        //Task<ResponseDataModel<NewInvestmentSchemeRes>> newInvestmentSchemes(NewInvestmentSchemeReq request);
        Task<ResponseDataModel<NewInvPlanRes>> newInvestmentPlans(NewInvPlanReq request);
        Task<ResponseDataModel<NewInvOptionsRes>> newInvestmentOptions(NewInvOptionsReq request);
        Task<ResponseDataModel<SwitchTransactionRes>> saveswitchTransaction(string AppId, string PANNo, string UserAgent, SwitchTransactionReq request);
        Task<ResponseDataModel<SwitchTransactionRes>> saveWebswitchTransaction(string AppId, string PANNo,string UserAgent, SwitchTransactionReq request);

    }
}
