﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using karvyAPI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public class MFSTPRepository : IMFSTPDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";

        public MFSTPRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }



        public async Task<ResponseDataModel<STPContentRes>> STPContent()
        {
            try
            {
                Scheme oSTP = new Scheme();
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_PROC_GETSTPTEXT", commandType: CommandType.StoredProcedure);
                    STPContentRes sTPContentRes = new STPContentRes();
                    List<FrequencyOption> FrequencyOption = new List<FrequencyOption>();
                    List<string> header = new List<string>();
                    List<string> footer = new List<string>();
                    var SPTContent = multi.ToList();
                    if (SPTContent.Count > 0)
                    {
                        for (int i = 0; i < 1; i++)
                        {

                            header.Add(Convert.ToString(SPTContent[0].HEADERTEXT) ?? "");
                            sTPContentRes.header = header;
                            footer.Add(Convert.ToString(SPTContent[0].FOOTER1) ?? "");
                            footer.Add(Convert.ToString(SPTContent[0].FOOTER2) ?? "");
                            sTPContentRes.footer = footer;
                        }
                        sTPContentRes.stpDateLag = Convert.ToInt32(SPTContent[0].STPDATELAG) ?? 0;
                        foreach (var s in SPTContent)
                        {
                            FrequencyOption.Add(new FrequencyOption
                            {
                                frequency = Convert.ToString(s.STPFREQUENCY) ?? "",
                                cycleDate = Convert.ToString(s.CYCLEDATE) ?? "",
                                minAmount = Convert.ToDouble(Convert.ToString(s.MINAMOUNT)) ?? 0,
                                minInstallment = Convert.ToInt32(s.MININSTALLMENT) ?? 0,
                                amounttMultiplier= Convert.ToInt32(s.AMOUNTMULTIPLIER) ?? 0
                            });

                        }
                        sTPContentRes.frequencyOption = FrequencyOption;
                        return new ResponseDataModel<STPContentRes>(sTPContentRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }
            }
            catch (Exception)
            {
                throw new NoDataException(false);
            }
        }

        //public async Task<ResponseDataModel<ExistingSchemeRes>> STPexistingSchemes(ExistingSchemeReq request)
        //{
        //    string Folionumber = request.folioNo;
        //    try
        //    {
        //        object input = new
        //        {
        //            Adminusername,
        //            Adminpassword,
        //            Folionumber
        //        };
        //        string inputJson = JsonConvert.SerializeObject(input);
        //        var result = KarvyRequest.CreateHTTPRequest("MOSLSTPExistingSchemes", serviceUrl, inputJson);
        //        var s = JArray.Parse(result);
        //        STPExistingSchemes oSTP = new STPExistingSchemes();
        //        ExistingSchemeRes oScheme = new ExistingSchemeRes();
        //        List<STPExistingSchemes> oSTPList = new List<STPExistingSchemes>();
        //        foreach (var p in s.ToList())
        //        {
        //            oSTPList.Add(new STPExistingSchemes
        //            {
        //                schemecode = Convert.ToString(p["Schemecode"]),
        //                plancode = Convert.ToString(p["Plancode"]),
        //                optioncode = Convert.ToString(p["Optioncode"]),
        //                investorname = Convert.ToString(p["InvestorName"]),
        //                schemedescription = Convert.ToString(p["SchemeDescription"]),
        //                totalunits = Convert.ToString(p["TotalUnits"]),
        //                remainingunits = Convert.ToString(p["RemainingUnits"]),
        //                nav = Convert.ToString(p["NAV"]),
        //                navdate = Convert.ToString(p["NAVDate"]),
        //                marketvalue = Convert.ToString(p["MarketValue"]),
        //                fundtype = Convert.ToString(p["FundType"]),
        //                planmode = Convert.ToString(p["Planmode"]),
        //                marketlockunits = Convert.ToString(p["MarketLockUnits"])
        //            }
        //         );
        //        }
        //        oScheme.STPExistingSchemes = oSTPList;
        //        return new ResponseDataModel<ExistingSchemeRes>(oScheme);

        //    }
        //    catch (Exception ex)
        //    {
        //        return new ResponseDataModel<ExistingSchemeRes>(null);
        //    }
        //}

        public async Task<ResponseDataArrayModel<Scheme>> STPSchemes()
        {
            try
            {
                Scheme oSTP = new Scheme();
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_GET_STP_SCHEME_MASTER", commandType: CommandType.StoredProcedure);

                    List<Scheme> oScheme = new List<Scheme>();
                    var schememaster = multi.ToList();
                    if (schememaster.Count > 0)
                    {
                        foreach (var s in schememaster)
                        {
                            oScheme.Add(new Scheme
                            {
                                schemeId = Convert.ToString(s.SCHEMECODE),
                                schemeName = Convert.ToString(s.SCHEMENAME)
                            });
                        }
                        return new ResponseDataArrayModel<Scheme>(oScheme);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }

                }
            }
            catch (Exception)
            {
                throw new NoDataException(true);
            }
        }

        public async Task<ResponseDataArrayModel<PlanRes>> STPPlans(STPPlanReq request)
        {
            string stpType = "Fixed";
            string schemecode = request.schemecode;
            string planmode = request.planmode;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    stpType,
                    schemecode,
                    planmode
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSTPPlans", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                List<PlanRes> oPlanRes = new List<PlanRes>();
                if (s.Count > 0)
                {
                    foreach (var p in s)
                    {
                        oPlanRes.Add(new PlanRes
                        {
                            planCode = Convert.ToString(p["Code"]),
                            planName = Convert.ToString(p["Description"])
                        });
                    }
                }
                return new ResponseDataArrayModel<PlanRes>(oPlanRes);
            }
            catch
            {
                throw new NoDataException(true);
            }
        }

        public async Task<ResponseDataArrayModel<OptionRes>> STPOptions(STPOptionReq request)
        {
            string schemecode = request.schemecode;
            string plancode = request.plancode;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    schemecode,
                    plancode
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSTPOptions", serviceUrl, inputJson);
                var s = JArray.Parse(result);
                List<OptionRes> oOptionRes = new List<OptionRes>();
                if (s.Count > 0)
                {
                    foreach (var p in s)
                    {
                        oOptionRes.Add(new OptionRes
                        {
                            optionCode = Convert.ToString(p["Code"]),
                            optionName = Convert.ToString(p["Description"])
                        });
                    }
                }
                return new ResponseDataArrayModel<OptionRes>(oOptionRes);
            }
            catch
            {
                throw new NoDataException(true);
            }
        }

        public async Task<ResponseDataArrayModel<frequency>> stpFrequency()
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_STP_FREQUENCY", new
                {
                }, commandType: CommandType.StoredProcedure);

                List<frequency> ofrequency = new List<frequency>();
                var FrequencyList = multi.Read().ToList();
                if (FrequencyList.Count > 0)
                {
                    foreach (var p in FrequencyList.ToList())
                    {
                        ofrequency.Add(new frequency
                        {
                            frequencyName = Convert.ToString(p.STPFREQUENCY),
                        });
                    }

                    return new ResponseDataArrayModel<frequency>(ofrequency);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }


        public async Task<ResponseDataModel<STPTransRes>> stpTransaction(string AppId, string panNo,string UserAgent, STPTransReq request)
        {
            string branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            else
            {
                branchCode = "MB88";
            }

            string scheme = request.moSchemeCode.Substring(3, 2);
            string plan = request.moSchemeCode.Substring(5, 2);
            string option = request.moSchemeCode.Substring(7, 1);
            string acno = request.acno;
            //string trdate = DateTime.Now.ToString("yyyy-MM-dd");
            string amount = Convert.ToString(request.amount);
            string lname = "";
            string entby = "";
            string freq = request.freq;
            string stdt = request.stdt;
            string enddt = request.enddt;
            string toscheme = request.toscheme;
            string toplan = request.toplan;
            string tooption = request.tooption;
            string stptype = "Fixed";
            string distributor = request.brokerCode;
            string stpswptype = "Y";
            string EUINNo = request.EUINNo;
            string EUINFlag = request.EUINFlag == true ? "Y" : "";
            string EUINoption = "";
            string SubBrokerARNCode = request.SubBrokerARNCode;
            string EUINsubarncode = request.EUINsubarncode;
            string rcpno = "1";

            string Clientname = "";
            string status_code = "";
            string message = "";
            //string branch = "";
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                    }
                }
            }
            lname = Clientname;
            entby = Clientname;
            STPTransRes oSTPTransRes = new STPTransRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    scheme,
                    plan,
                    option,
                    acno,
                    amount,
                    lname,
                    entby,
                    freq,
                    branch=branchCode,
                    stdt,
                    enddt,
                    toscheme,
                    toplan,
                    tooption,
                    stptype,
                    distributor,
                    rcpno,
                    stpswptype,
                    EUINNo,
                    EUINFlag,
                    EUINoption,
                    SubBrokerARNCode,
                    EUINsubarncode

                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSTPInsert", serviceUrl, inputJson);
                var s = JArray.Parse(result);

                using (var conn2 = MOAMCMOBILEDB)
                {
                    string userid = panNo;
                    var multi2 = await conn2.QueryAsync("AMCMOB_INSERT_STPTRANSACTIONS", new
                    {
                        userid,
                        scheme,
                        PLANCODE = plan,
                        option,
                        acno,
                        amount,
                        lname,
                        entby,
                        freq,
                        stdt,
                        enddt,
                        toscheme,
                        toplan,
                        tooption,
                        stptype,
                        distributor,
                        rcpno,
                        stpswptype,
                        EUINNo,
                        EUINFlag,
                        EUINoption,
                        SubBrokerARNCode,
                        EUINsubarncode,
                        AppId,
                        referenceno = Convert.ToString(s[0]["ReferenceNo"]),
                        time_stamp = Convert.ToString(s[0]["TIME_STAMP"]),
                        RESBATCHNO = Convert.ToString(s[0]["BatchNo"]),
                        RESIHNO = Convert.ToString(s[0]["IHNO"]),
                        status_code = Convert.ToString(s[0]["STATUS_CODE"]),
                        message = Convert.ToString(s[0]["MESSAGE"]),
                        BRANCH= branchCode

                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList2 = multi2.ToList();
                        if (VerifiedList2[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }

                    if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                    {
                        status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                        message = Convert.ToString(s[0]["MESSAGE"]);
                        oSTPTransRes.ihno = Convert.ToString(s[0]["IHNO"]);
                        oSTPTransRes.referenceno = Convert.ToString(s[0]["ReferenceNo"]);
                        oSTPTransRes.time_stamp = Convert.ToString(s[0]["TIME_STAMP"]);
                        oSTPTransRes.batchno = Convert.ToString(s[0]["BatchNo"]);

                        return new ResponseDataModel<STPTransRes>(oSTPTransRes);
                    }
                    else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                    {
                        return new ResponseDataModel<STPTransRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                    }
                    else
                    {
                        return new ResponseDataModel<STPTransRes>(null, Convert.ToString(s[0]["Return_Message"]));
                    }
            }
            catch (Exception)
            {
                using (var conn2 = MOAMCMOBILEDB)
                {
                    string userid = panNo;
                    var multi2 = await conn2.QueryAsync("AMCMOB_INSERT_STPTRANSACTIONS", new
                    {
                        userid,
                        scheme,
                        PLANCODE = plan,
                        option,
                        acno,
                        amount,
                        lname,
                        entby,
                        freq,
                        stdt,
                        enddt,
                        toscheme,
                        toplan,
                        tooption,
                        stptype,
                        distributor,
                        rcpno,
                        stpswptype,
                        EUINNo,
                        EUINFlag,
                        EUINoption,
                        SubBrokerARNCode,
                        EUINsubarncode,
                        AppId,
                        referenceno = "",
                        time_stamp = "",
                        RESBATCHNO = "",
                        RESIHNO = "",
                        status_code = "",
                        message = "API Exception. Please check with Karvy.",
                        BRANCH = branchCode

                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList2 = multi2.ToList();
                        if (VerifiedList2[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                throw new NoDataException(true);
            }
        }

        public async Task<ResponseDataModel<STPTransRes>> WebstpTransaction(string AppId, string panNo,string UserAgent, STPTransReq request)
        {
            string branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            else
            {
                branchCode = "WB99";
            }

            string scheme = request.moSchemeCode.Substring(3, 2);
            string plan = request.moSchemeCode.Substring(5, 2);
            string option = request.moSchemeCode.Substring(7, 1);
            string acno = request.acno;
            //string trdate = DateTime.Now.ToString("yyyy-MM-dd");
            string amount = Convert.ToString(request.amount);
            string lname = "";
            string entby = "";
            string freq = request.freq;
            string stdt = request.stdt;
            string enddt = request.enddt;
            string toscheme = request.toscheme;
            string toplan = request.toplan;
            string tooption = request.tooption;
            string stptype = "Fixed";
            string distributor = request.brokerCode;
            string stpswptype = "Y";
            string EUINNo = request.EUINNo;
            string EUINFlag = request.EUINFlag == true ? "Y" : "";
            string EUINoption = "";
            string SubBrokerARNCode = request.SubBrokerARNCode;
            string EUINsubarncode = request.EUINsubarncode;
            string rcpno = "1";

            string Clientname = "";
            string status_code = "";
            string message = "";
            //string branch = "WB99";
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = panNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                    }
                }
            }
            lname = Clientname;
            entby = Clientname;
            STPTransRes oSTPTransRes = new STPTransRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    scheme,
                    plan,
                    option,
                    acno,
                    amount,
                    lname,
                    entby,
                    freq,
                    branch=branchCode,
                    stdt,
                    enddt,
                    toscheme,
                    toplan,
                    tooption,
                    stptype,
                    distributor,
                    rcpno,
                    stpswptype,
                    EUINNo,
                    EUINFlag,
                    EUINoption,
                    SubBrokerARNCode,
                    EUINsubarncode

                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSTPInsert", serviceUrl, inputJson);
                var s = JArray.Parse(result);

                using (var conn2 = MOAMCMOBILEDB)
                {
                    string userid = panNo;
                    var multi2 = await conn2.QueryAsync("AMCMOB_INSERT_STPTRANSACTIONS", new
                    {
                        userid,
                        scheme,
                        PLANCODE = plan,
                        option,
                        acno,
                        amount,
                        lname,
                        entby,
                        freq,
                        stdt,
                        enddt,
                        toscheme,
                        toplan,
                        tooption,
                        stptype,
                        distributor,
                        rcpno,
                        stpswptype,
                        EUINNo,
                        EUINFlag,
                        EUINoption,
                        SubBrokerARNCode,
                        EUINsubarncode,
                        AppId,
                        referenceno = Convert.ToString(s[0]["ReferenceNo"]),
                        time_stamp = Convert.ToString(s[0]["TIME_STAMP"]),
                        RESBATCHNO = Convert.ToString(s[0]["BatchNo"]),
                        RESIHNO = Convert.ToString(s[0]["IHNO"]),
                        status_code = Convert.ToString(s[0]["STATUS_CODE"]),
                        message = Convert.ToString(s[0]["MESSAGE"]),
                        BRANCH = branchCode
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList2 = multi2.ToList();
                        if (VerifiedList2[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }

                if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                {
                    status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                    message = Convert.ToString(s[0]["MESSAGE"]);
                    oSTPTransRes.ihno = Convert.ToString(s[0]["IHNO"]);
                    oSTPTransRes.referenceno = Convert.ToString(s[0]["ReferenceNo"]);
                    oSTPTransRes.time_stamp = Convert.ToString(s[0]["TIME_STAMP"]);
                    oSTPTransRes.batchno = Convert.ToString(s[0]["BatchNo"]);

                    return new ResponseDataModel<STPTransRes>(oSTPTransRes);
                }
                else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                {
                    return new ResponseDataModel<STPTransRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                }
                else
                {
                    return new ResponseDataModel<STPTransRes>(null, Convert.ToString(s[0]["Return_Message"]));
                }
            }
            catch (Exception)
            {
                using (var conn2 = MOAMCMOBILEDB)
                {
                    string userid = panNo;
                    var multi2 = await conn2.QueryAsync("AMCMOB_INSERT_STPTRANSACTIONS", new
                    {
                        userid,
                        scheme,
                        PLANCODE = plan,
                        option,
                        acno,
                        amount,
                        lname,
                        entby,
                        freq,
                        stdt,
                        enddt,
                        toscheme,
                        toplan,
                        tooption,
                        stptype,
                        distributor,
                        rcpno,
                        stpswptype,
                        EUINNo,
                        EUINFlag,
                        EUINoption,
                        SubBrokerARNCode,
                        EUINsubarncode,
                        AppId,
                        referenceno = "",
                        time_stamp = "",
                        RESBATCHNO = "",
                        RESIHNO = "",
                        status_code = "",
                        message = "API Exception. Please check with Karvy.",
                        BRANCH = branchCode

                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList2 = multi2.ToList();
                        if (VerifiedList2[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                throw new NoDataException(true);
            }
        }


    }
}
