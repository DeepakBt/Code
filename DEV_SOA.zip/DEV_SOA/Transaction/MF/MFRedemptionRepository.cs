﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using karvyAPI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public class MFRedemptionRepository : IMFRedemptionDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";

        public MFRedemptionRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
        }

        public async Task<ResponseDataModel<ReduceRedemptionRes>> ReduceRedepmtionTransaction(string AppId, string Panno, ReduceRedemptionrequest request)
        {
            try
            {

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryMultipleAsync("AMCMOB_PORTFOLIO_FUTURE_PROFIT_CALCULATION", new
                    {
                        Panno = Panno,
                        FOLIONO = request.folioNo,
                        MoslCode = request.moslCode,
                    }, commandType: CommandType.StoredProcedure);

                    var data = multi.Read().ToList();
                    ReduceRedemptionRes content = new ReduceRedemptionRes();
                    if (data.Count > 0)
                    {
                        var Table = multi.Read().ToList();

                        content.header = data[0].Header;
                        content.footer = data[0].Footer;

                        List<ReduceRedemTable> TableList = new List<ReduceRedemTable>();
                        foreach (var p in Table.ToList())
                        {
                            TableList.Add(new ReduceRedemTable
                            {
                                date = Convert.ToString(p.DATE) ?? "",
                                year = Convert.ToString(p.Year) ?? "",
                                amount = Convert.ToDouble(p.Amount) ?? 0,
                            }
                         );
                        }
                        content.table = TableList;
                        return new ResponseDataModel<ReduceRedemptionRes>(content);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }
            }
            catch (Exception)
            {
                throw new NoDataException(false);
            }
        }

        /*   public async Task<ResponseDataModel<RedemptionValidRes>> RedemptionValidation(RedemptionValidReq request)
           {
               string scheme = request.scheme;
               string plan = request.plan;
               string trType = request.trType;
               string timeStamp = request.timeStamp;
               try
               {
                   object input = new
                   {
                       Adminusername,
                       Adminpassword,
                       scheme,
                       plan,
                       trType,
                       timeStamp
                   };
                   string inputJson = JsonConvert.SerializeObject(input);
                   var result = KarvyRequest.CreateHTTPRequest("MOSLRedemptionValidation", serviceUrl, inputJson);
                   var s = JArray.Parse(result);
                   RedemptionValidRes oValid = new RedemptionValidRes();
                   oValid.status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                   oValid.message = Convert.ToString(s[0]["Message"]);
                   oValid.category = Convert.ToString(s[0]["category"]);
                   oValid.cuttime = Convert.ToString(s[0]["cuttime"]);
                   return new ResponseDataModel<RedemptionValidRes>(oValid);
               }
               catch (Exception ex)
               {
                   return new ResponseDataModel<RedemptionValidRes>(null);
               }

           } */

        public async Task<ResponseDataModel<RedemptionTraRes>> RedemptionTransaction(string AppId, string PANNo,string UserAgent, RedemptionTraReq request)
        {
            var branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            string Userid = PANNo; //request.userid;
            string folioNo = request.folio;
            string scheme = request.moSchemeCode.Substring(3, 2);
            string plan = request.moSchemeCode.Substring(5, 2);
            string option = request.moSchemeCode.Substring(7, 1);
            string Amount = Convert.ToString(request.amount);
            string Tpin = "0";
            string pangno = PANNo;
            string ihno = "0";
            string AmountorUnitsFlag = request.untamtflg;
            string Clientname = "";
            string status_code = "";
            string message = "";
            string category = "";
            string bankname = request.bankName;
            string bankacctnumber = request.bankAccNo;
            string RedFlag = request.redeemType;

            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                {
                    panno = PANNo.Trim(),    //From TOKEN 
                    PMSCODE = "",
                    MOSLCODE = "X",

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        Clientname = (from P in VerifiedList
                                      select P.ClientName).FirstOrDefault();
                    }
                }
            }

            string firstholdername = Clientname;
            string secondholdername = "";
            string thirdholdername = "";
            string tuserid = "0";
            string cuttime = "";
            string status = "";
            string ip = AppId;
            string userid = Clientname;
            RedemptionTraRes oTrans = new RedemptionTraRes();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    folioNo,
                    scheme,
                    plan,
                    option,
                    bankname,
                    bankacctnumber,
                    Amount,
                    RedFlag,
                    pangno,
                    ihno,
                    firstholdername,
                    secondholdername,
                    thirdholdername,
                    userid = "0",
                    cuttime,
                    status,
                    AmountorUnitsFlag,
                    ip,
                    branch=branchCode
                };
                string inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSaveRedemptionTransaction", serviceUrl, inputJson);
                var s = JArray.Parse(result);

                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_REDEMPTIONTRANS", new
                    {
                        userid = Userid,
                        folio = folioNo,
                        scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        Amount,
                        Tpin = "",
                        pangno,
                        ihno,
                        firstholdername,
                        secondholdername,
                        thirdholdername,
                        tuserid,
                        cuttime,
                        status,
                        IP_ADDRESS = ip,
                        AppId,
                        REFNO = Convert.ToString(s[0]["REFNO"]),
                        UNITS = Convert.ToString(s[0]["UNITS"]),
                        STATUS_CODE = Convert.ToString(s[0]["STATUS_CODE"]) == "" ? Convert.ToString(s[0]["Return_Message"]) : Convert.ToString(s[0]["STATUS_CODE"]),
                        MESSAGE = Convert.ToString(s[0]["MESSAGE"]) == "" ? Convert.ToString(s[0]["Return_Message"]) : Convert.ToString(s[0]["MESSAGE"]),
                        BRANCH=branchCode
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }

                    if (result != null && Convert.ToString(s[0]["STATUS_CODE"]) == "200")
                    {
                        status_code = Convert.ToString(s[0]["STATUS_CODE"]);
                        message = Convert.ToString(s[0]["MESSAGE"]);
                        category = Convert.ToString(s[0]["category"]);
                        cuttime = Convert.ToString(s[0]["cuttime"]);
                        oTrans.units = Convert.ToString(s[0]["UNITS"]);
                        oTrans.refno = Convert.ToString(s[0]["REFNO"]);
                        oTrans.amount = Convert.ToDouble(Convert.ToString(s[0]["AMOUNT"]));
                        return new ResponseDataModel<RedemptionTraRes>(oTrans);
                    }
                    else if (result != null && (Convert.ToString(s[0]["STATUS_CODE"]) != "200" && Convert.ToString(s[0]["STATUS_CODE"]) != ""))
                    {
                        return new ResponseDataModel<RedemptionTraRes>(null, Convert.ToString(s[0]["MESSAGE"]));
                    }
                    else
                    {
                        return new ResponseDataModel<RedemptionTraRes>(null, Convert.ToString(s[0]["Return_Message"]));
                    }
                }
            }
            catch
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_INSERT_REDEMPTIONTRANS", new
                    {
                        userid = Userid,
                        folio = folioNo,
                        scheme,
                        PlanCode = plan,
                        OptionCode = option,
                        Amount,
                        Tpin = "",
                        pangno,
                        ihno,
                        firstholdername,
                        secondholdername,
                        thirdholdername,
                        tuserid,
                        cuttime,
                        status,
                        IP_ADDRESS = "",
                        AppId,
                        REFNO = "",
                        UNITS = "",
                        STATUS_CODE = "",
                        MESSAGE = "API Exception. Please check with Karvy.",
                        BRANCH = branchCode
                    }, commandType: CommandType.StoredProcedure);
                    {

                        var VerifiedList = multi.ToList();
                        if (VerifiedList[0].successFlag == 1)
                        {
                            //return new ResponseDataModel<string>("Data Saved Successfully.");
                        }
                    }
                }
                throw new NoDataException(false);
            }
        }
    }
}
