﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Auth;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ValidateModel]
    [Authorize]
    public class MFPurchaseController : ControllerBase
    {
        private readonly ITransactionDataSource _TransactionDataSource;
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public MFPurchaseController(TokenHelper tokenHelper, ITransactionDataSource TransactionDataSource, IMasterDataSource MasterDataSource)
        {
            _TransactionDataSource = TransactionDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        [HttpGet("registerbanklist")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<RegisterBankRes>), 200)]
        public async Task<IActionResult> registerBankList(RegisterBank request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            string panNo= User.Identity.Name;
            var response = await _TransactionDataSource.registerBankList(request, panNo);
            return Ok(response);
        }



        [HttpGet("bankDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<BankRes>), 200)]
        public async Task<IActionResult> bankDetails(BankReq request)
        {
            var response = await _TransactionDataSource.bankDetails(request);
            return Ok(response);
        }

        [HttpPost("validateBrokerCode")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<BrokerRes>), 200)]
        public async Task<IActionResult> validateBrokerCode([FromBody]BrokerReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _TransactionDataSource.validateBrokerCode(request);
            return Ok(response);
         }

        [HttpPost("GetKDMSUrl")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<KDMSRes>), 200)]
        public async Task<IActionResult> GetKDMSUrl([FromBody]KDMSReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _TransactionDataSource.GetKDMSUrl(request);
            return Ok(response);
        }

        [HttpGet("minimumSchemeInvestment")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SchemeValueRes>), 200)]
        public async Task<IActionResult> minimumSchemeValue(SchemeValueReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _TransactionDataSource.minimumSchemeValue(request);
            return Ok(response);
        }

        [HttpPost("GetClientBankBrokerList")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ResClientBankBroker>), 200)]
        public async Task<IActionResult> clientBankBrokerlist()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            var response = await _TransactionDataSource.clientBankBrokerlist(panNo);
            return Ok(response);
        }

    }
}