﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/MFSTP")]
    public class MFSTPController : Controller
    {
        private readonly IMFSTPDataSource _MFSTPDataSource;
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public MFSTPController(TokenHelper tokenHelper, IMFSTPDataSource MFSTPDataSource, IMasterDataSource MasterDataSource)
        {
            _MFSTPDataSource = MFSTPDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }
        [HttpGet("stpContent")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<STPContentRes>), 200)]
        public async Task<IActionResult> STPContent()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSTPDataSource.STPContent();
            return Ok(response);
        }

        //[HttpGet("existingSchemes")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataModel<ExistingSchemeRes>), 200)]
        //public async Task<IActionResult> STPexistingSchemes(ExistingSchemeReq request)
        //{
        //    var response = await _MFSTPDataSource.STPexistingSchemes(request);
        //    return Ok(response);
        //}

        [HttpGet("STPSchemes")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<Scheme>), 200)]
        public async Task<IActionResult> STPSchemes()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSTPDataSource.STPSchemes();
            return Ok(response);
        }


        [HttpPost("STPPlan")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<PlanRes>), 200)]
        public async Task<IActionResult> STPPlans([FromBody]STPPlanReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSTPDataSource.STPPlans(request);
            return Ok(response);
        }

        [HttpPost("STPOptions")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<OptionRes>), 200)]
        public async Task<IActionResult> STPOptions([FromBody]STPOptionReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSTPDataSource.STPOptions(request);
            return Ok(response);
        }

        [HttpPost("stpTransaction")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<STPTransRes>), 200)]
        public async Task<IActionResult> stpTransaction([FromBody]STPTransReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
                var response = await _MFSTPDataSource.stpTransaction(AppId, panNo, UserAgent, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false);
            }
        }
        [HttpPost("webStpTransaction")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<STPTransRes>), 200)]
        public async Task<IActionResult> WebstpTransaction([FromBody]STPTransReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var response = await _MFSTPDataSource.WebstpTransaction(AppId, panNo, UserAgent, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false);
            }
        }
        [HttpGet("stpFrequency")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<frequency>), 200)]
        public async Task<IActionResult> stpFrequency()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSTPDataSource.stpFrequency();
            return Ok(response);
        }
    }
}