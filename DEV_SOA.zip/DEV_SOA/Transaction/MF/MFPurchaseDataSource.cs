﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.Controllers
{
    public interface ITransactionDataSource
    {
        Task<ResponseDataArrayModel<RegisterBankRes>> registerBankList(RegisterBank request, string panNo);
        Task<ResponseDataModel<BankRes>> bankDetails(BankReq request);
        Task<ResponseDataModel<BrokerRes>> validateBrokerCode(BrokerReq request);
        Task<ResponseDataModel<KDMSRes>> GetKDMSUrl(KDMSReq request);
        Task<ResponseDataModel<SchemeValueRes>> minimumSchemeValue(SchemeValueReq request);
        Task<ResponseDataArrayModel<ResClientBankBroker>> clientBankBrokerlist(string PanNo);
    }
}
