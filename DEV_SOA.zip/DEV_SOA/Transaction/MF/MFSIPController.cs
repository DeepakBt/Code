﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Utils;
using static Transaction.Models.MFSIP;

namespace Transaction.MF
{
    [Produces("application/json")]
    [Route("api/MFSIP")]
    [ValidateModel]
    //[Authorize]

    public class MFSIPController : Controller
    {
        private readonly IMFSIPDataSource _MFSIPDataSource;
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public MFSIPController(TokenHelper tokenHelper, IMFSIPDataSource MFSIPDataSource, IMasterDataSource MasterDataSource)
        {
            _MFSIPDataSource = MFSIPDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        [HttpPost("SIPPlanOptions")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<SIPPlanOptionsRes>), 200)]
        public async Task<IActionResult> newInvestmentPlans([FromBody]SIPPlanOptionsReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSIPDataSource.SIPPlanOptions(request);
            return Ok(response);
        }

        [HttpPost("SIPSchemePurchaseDetail")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<SchemeDetailsRes>), 200)]
        public async Task<IActionResult> SIPSchemePurchaseDetail([FromBody]SchemeDetailsReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MFSIPDataSource.SIPSchemePurchaseDetail(request);
            return Ok(response);
        }

        [HttpPost("sipTransaction")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<SubSIPRes>), 200)]
        public async Task<IActionResult> sipTransaction([FromBody]SubSIPReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _MFSIPDataSource.sipTransaction(AppId, panNo, request, UserAgent);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }

        [HttpPost("webSipTransaction")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<SubSIPRes>), 200)]
        public async Task<IActionResult> sipWebTransaction([FromBody]SubSIPReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _MFSIPDataSource.sipWebTransaction(AppId, panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }
        
        [HttpPost("sipConfirmation")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> sipConfirmation([FromBody]SIPBillDesk request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            var response = await _MFSIPDataSource.sipConfirmation(panNo,request);
            return Ok(response);
        }

        
        [HttpPost("sipMandateTransaction")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<SubSIPRes>), 200)]
        public async Task<IActionResult> sipMandateTransaction([FromBody]SubSIPReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _MFSIPDataSource.sipMandateTransaction(AppId, panNo, request, UserAgent);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }
    }
}