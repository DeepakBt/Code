﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.MF
{
    public interface IMFISIPDataSource
    {
        Task<ResponseDataArrayModel<ISIPdetailRes>> fetchTransactions(ISIPdetailReq request);
        Task<ResponseDataModel<ISIPTransRes>> transactionCancellation(string panNo,string UserAgent,ISIPTransReq request);
        Task<ResponseDataArrayModel<MFISIPFrequencyRes>> GetMFISIPFrequency(MFISIPFrequencyReq request,string Pan);
    }
}
