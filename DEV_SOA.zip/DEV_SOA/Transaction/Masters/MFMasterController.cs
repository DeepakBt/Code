﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.Masters
{
    
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ValidateModel]
    public class MFMasterController : ControllerBase
    {
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public MFMasterController(TokenHelper tokenHelper, IMasterDataSource MasterDataSource)
        {
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }

        //[HttpGet("Master")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataModel<MasterRes>), 200)]
        //public async Task<IActionResult> GetMasterList()
        //{
        //    var response = await _MasterDataSource.GetMasterList();
        //    return Ok(response);
        //}

        [HttpGet("holderBasicDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<HolderBasicRes>), 200)]
        public async Task<IActionResult> holderBasicDetails()
        {
            var response = await _MasterDataSource.holderBasicDetails();
            return Ok(response);
        }

        [HttpGet("fatcaBasicDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<FatcaBasicRes>), 200)]
        public async Task<IActionResult> fatcaBasicDetails()
        {
            var response = await _MasterDataSource.fatcaBasicDetails();
            return Ok(response);
        }

        [HttpGet("stateList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<StateMaster>), 200)]
        public async Task<IActionResult> GetstateList()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.GetstateList();
            return Ok(response);
        }

        [HttpGet("cityList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<CityRes>), 200)]
        public async Task<IActionResult> GetcityList(CityReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.GetcityList(request);
            return Ok(response);
        }

        [HttpGet("relationshipLists")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<Relation>), 200)]
        public async Task<IActionResult> getRelationshipLists()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.relationshipLists();
            return Ok(response);
        }

        [HttpGet("accountTypeDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<AccountType>), 200)]
        public async Task<IActionResult> GetaccountTypeDetails(AccountTypeReq request)
        {
            var response = await _MasterDataSource.GetaccountTypeDetails(request);
            return Ok(response);
        }

        [HttpGet("availableBankList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<BankTypeRes>), 200)]
        public async Task<IActionResult> availableBankList(BankTypeReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.availableBankList(request);
            return Ok(response);
        }

        //[HttpGet("optionList")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataArrayModel<>),200)]
        //public async Task<IActionResult> optionList()
        //{

        //}

        //[HttpGet("schemeList")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataArrayModel<Scheme>), 200)]
        //public async Task<IActionResult> schemeList()
        //{
        //    var response = await _MasterDataSource.schemeList();
        //    return Ok(response);
        //}

        //[HttpGet("planModeList")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataArrayModel<PlanMode>), 200)]
        //public async Task<IActionResult> planList()
        //{
        //    var response = await _MasterDataSource.planModeList();
        //    return Ok(response);
        //}

        [HttpGet("schemeList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SchemePlanModeRes>), 200)]
        public async Task<IActionResult> planModeLists()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.schemeList();
            return Ok(response);
        }

        [HttpGet("planList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<PlanRes>), 200)]
        public async Task<IActionResult> planList(PlanReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.planList(request);
            return Ok(response);
        }

        [HttpGet("optionList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<OptionRes>), 200)]
        public async Task<IActionResult> optionList(OptionReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.optionList(request);
            return Ok(response);
        }

        [HttpGet("countryList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<CountryRes>), 200)]
        public async Task<IActionResult> countryList()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.countryList();
            return Ok(response);
        }

        [HttpPost("validatePAN")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<PANCheck>), 200)]
        public async Task<IActionResult> validatePAN([FromBody] PanKYCReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.validatePAN(request);
                return Ok(response);
        }

        [HttpGet("validateAadhar")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<aadharcheckReq>), 200)]
        public async Task<IActionResult> validateAadhar(aadharcheckReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.validateAadhar(request);
            return Ok(response);
        }

        [HttpGet("calculateInstalment")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> calculateInstalment(calculateInstalment request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.calculateInstalment(request);
            return Ok(response);
        }


        [HttpPost("validateUser")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<validateUserRes>), 200)]
        public async Task<IActionResult> validateUser([FromBody] PanKYCReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _MasterDataSource.validateUser(AppId, request);
            return Ok(response);
        }

        [HttpGet("getStateCity")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResPinCode>), 200)]
        public async Task<IActionResult> getStateCity(ReqPinCode request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _MasterDataSource.getStateCity(request);
            return Ok(response);
        }
    }


}