﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using karvyAPI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.Masters
{
    public class MFMasterRepository : IMasterDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";
        double cachetilltommorrowhours = 0;
        public MFMasterRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
            cachetilltommorrowhours = Convert.ToDouble(_iconfiguration["cachetilltommorrowhours"]);
        }

        public async Task<ResponseDataModel<HolderBasicRes>> holderBasicDetails()
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_NEWINVESTOR_HOLDER_MASTER", new
                { }, commandType: CommandType.StoredProcedure);


                HolderBasicRes oMasterRes = new HolderBasicRes();

                List<ModeOfHolding> oModeOfHolding = new List<ModeOfHolding>();
                var ModeOfHoldingList = multi.Read().ToList();
                if (ModeOfHoldingList.Count > 0)
                {
                    foreach (var p in ModeOfHoldingList.ToList())
                    {
                        oModeOfHolding.Add(new ModeOfHolding
                        {
                            holdingmodeId = Convert.ToString(p.MOH_ID),
                            holdingmode = Convert.ToString(p.MODEOFHOLDING)
                        });
                    }
                }

                List<Category> oCategoryRes = new List<Category>();

                var CategoryList = multi.Read().ToList();
                if (CategoryList.Count > 0)
                {
                    foreach (var p in CategoryList.ToList())
                    {
                        oCategoryRes.Add(new Category
                        {
                            categoryId = Convert.ToString(p.CATEGORY_ID),
                            categoryName = p.CATEGORY
                        });
                    }


                    List<NRI> oNRI = new List<NRI>();
                    var NRIList = multi.Read().ToList();
                    if (NRIList.Count > 0)
                    {
                        foreach (var p in NRIList.ToList())
                        {
                            oNRI.Add(new NRI
                            {
                                nriId = Convert.ToString(p.NRIID),
                                nriCategory = Convert.ToString(p.NRICATEGORY)
                            });
                        }
                    }

                    List<Status> oStatus = new List<Status>();
                    var StatusList = multi.Read().ToList();
                    if (StatusList.Count > 0)
                    {
                        foreach (var p in StatusList.ToList())
                        {
                            oStatus.Add(new Status
                            {
                                statusId = Convert.ToString(p.INVESTORSTATUS),
                                status = Convert.ToString(p.INVESTORSTATUSDESCRIPTION)
                            });
                        }
                    }

                    List<Occupation> oOccupation = new List<Occupation>();
                    var OccupationList = multi.Read().ToList();
                    if (OccupationList.Count > 0)
                    {
                        foreach (var p in OccupationList.ToList())
                        {
                            oOccupation.Add(new Occupation
                            {
                                occupationId = Convert.ToString(p.OCCUPATIONID),
                                occupation = Convert.ToString(p.OCCUPATIONNAME)
                            });
                        }
                    }

                    oMasterRes.ModeOfHolding = oModeOfHolding;
                    oMasterRes.category = oCategoryRes;
                    oMasterRes.NRI = oNRI;
                    oMasterRes.Status = oStatus;
                    oMasterRes.Occupation = oOccupation;

                    return new ResponseDataModel<HolderBasicRes>(oMasterRes);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }

        }

        public async Task<ResponseDataModel<FatcaBasicRes>> fatcaBasicDetails()
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_NEWINVESTOR_FATCA_MASTER", new
                { }, commandType: CommandType.StoredProcedure);

                FatcaBasicRes oMasterRes = new FatcaBasicRes();
                List<IncomeSlab> oIncomeSlab = new List<IncomeSlab>();
                var IncomeSlabList = multi.Read().ToList();
                if (IncomeSlabList.Count > 0)
                {
                    foreach (var p in IncomeSlabList.ToList())
                    {
                        oIncomeSlab.Add(new IncomeSlab
                        {
                            incomeCode = Convert.ToString(p.INCOMECODE),
                            incomeSlab = Convert.ToString(p.INCOMESLAB)
                        });
                    }
                }
                else
                {
                    throw new NoDataException(true);
                }

                List<CountryRes> oCountry = new List<CountryRes>();
                var countryMaster = multi.Read().ToList();
                if (countryMaster.Count > 0)
                {
                    foreach (var c in countryMaster)
                    {
                        oCountry.Add(new CountryRes
                        {
                            country = c.Country
                        });
                    }
                }
                else
                {
                    throw new NoDataException(true);
                }
                oMasterRes.IncomeSlab = oIncomeSlab;
                oMasterRes.countryList = oCountry;

                return new ResponseDataModel<FatcaBasicRes>(oMasterRes);
            }
        }

        public async Task<ResponseDataArrayModel<StateMaster>> GetstateList()
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_NEWINVESTOR_STATE_MASTER", new
                {
                }, commandType: CommandType.StoredProcedure);

                List<StateMaster> oStateMaster = new List<StateMaster>();
                var StateList = multi.Read().ToList();
                if (StateList.Count > 0)
                {
                    foreach (var p in StateList.ToList())
                    {
                        oStateMaster.Add(new StateMaster
                        {
                            stateName = Convert.ToString(p.STATENAME),
                        });
                    }

                    return new ResponseDataArrayModel<StateMaster>(oStateMaster);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }

        public async Task<ResponseDataArrayModel<CityRes>> GetcityList(CityReq request)
        {

            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_City_MASTER_BY_STATE", new
                {
                    StateName = request.stateName
                }, commandType: CommandType.StoredProcedure);

                List<CityRes> oCityMaster = new List<CityRes>();
                var CityMaster = multi.ToList();
                if (CityMaster.Count > 0)
                {
                    foreach (var p in CityMaster.ToList())
                    {
                        oCityMaster.Add(new CityRes
                        {
                            city = Convert.ToString(p.City)
                        });
                    }

                    return new ResponseDataArrayModel<CityRes>(oCityMaster);
                }
                else
                {
                    throw new NoDataException(true);
                }

            }
        }

        public async Task<ResponseDataArrayModel<BankTypeRes>> availableBankList(BankTypeReq request)
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMCMOB_GETBANKLIST", new { TYPEOFTRASNACTION = request.investmentType },
                    commandType: CommandType.StoredProcedure);
                List<BankTypeRes> oBankTypeRes = new List<BankTypeRes>();
                var BankList = multi.ToList();
                if (BankList.Count > 0)
                {
                    foreach (var p in BankList.ToList())
                    {
                        oBankTypeRes.Add(new BankTypeRes
                        {
                            bankCode = Convert.ToString(p.BANKCODE),
                            bankName = Convert.ToString(p.BANKNAME)
                        });
                    }
                    return new ResponseDataArrayModel<BankTypeRes>(oBankTypeRes);
                }
                else
                {
                    throw new NoDataException(true);
                }

            }
        }

        public async Task<ResponseDataArrayModel<Relation>> relationshipLists()
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_NEWINVESTOR_RELATION_MASTER", new
                {
                }, commandType: CommandType.StoredProcedure);


                List<Relation> oRelation = new List<Relation>();
                var RelationList = multi.Read().ToList();
                if (RelationList.Count > 0)
                {
                    foreach (var p in RelationList.ToList())
                    {
                        oRelation.Add(new Relation
                        {
                            relationName = Convert.ToString(p.relationName)
                        });
                    }
                    return new ResponseDataArrayModel<Relation>(oRelation);
                }
                else
                {
                    throw new NoDataException(true);
                }

            }
        }

        public async Task<ResponseDataArrayModel<AccountType>> GetaccountTypeDetails(AccountTypeReq request)
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_NEWINVESTOR_ACCOUNTTYPE_MASTER", new
                {
                    request.category
                }, commandType: CommandType.StoredProcedure);
                List<AccountType> oAccountType = new List<AccountType>();
                var AccountTypeList = multi.Read().ToList();
                if (AccountTypeList.Count > 0)
                {
                    foreach (var p in AccountTypeList.ToList())
                    {
                        oAccountType.Add(new AccountType
                        {
                            accountType = Convert.ToString(p.AccountType),
                            Code = Convert.ToString(p.AccTypecode)
                        });
                    }
                    return new ResponseDataArrayModel<AccountType>(oAccountType);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }

        public async Task<ResponseDataModel<SchemePlanModeRes>> schemeList()
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryMultipleAsync("AMCMOB_GET_NEWINVESTOR_SCHEME_MASTER", commandType: CommandType.StoredProcedure);
                SchemePlanModeRes SchemePlanList = new SchemePlanModeRes();
                List<Scheme> oScheme = new List<Scheme>();
                List<PlanMode> oPlanModeRes = new List<PlanMode>();
                var schememaster = multi.Read().ToList();
                var PlanMode = multi.Read().ToList();

                if (schememaster.Count > 0)
                {
                    foreach (var s in schememaster)
                    {
                        oScheme.Add(new Scheme
                        {
                            schemeId = Convert.ToString(s.SCHEMECODE),
                            schemeName = Convert.ToString(s.SCHEMENAME),
                            schemeType = Convert.ToString(s.SCHEMETYPE)

                        });
                    }
                    SchemePlanList.schemeList = oScheme;

                    if (PlanMode.Count > 0)
                    {
                        foreach (var s in PlanMode)
                        {
                            oPlanModeRes.Add(new PlanMode
                            {
                                planModeName = Convert.ToString(s.planname),
                            });
                        }
                        SchemePlanList.planModeList = oPlanModeRes;
                    }
                    return new ResponseDataModel<SchemePlanModeRes>(SchemePlanList);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        public async Task<ResponseDataArrayModel<PlanRes>> planList(PlanReq request)
        {
            string planMode = request.planMode;
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_PLAN_MASTER", new { schemecode = request.schemeCode, planMode }, commandType: CommandType.StoredProcedure);

                List<PlanRes> oPlanRes = new List<PlanRes>();
                var schememaster = multi.ToList();
                if (schememaster.Count > 0)
                {
                    foreach (var s in schememaster)
                    {
                        oPlanRes.Add(new PlanRes
                        {
                            planCode = Convert.ToString(s.PLANCODE),
                            planName = Convert.ToString(s.PLANNAME)
                        });
                    }
                    return new ResponseDataArrayModel<PlanRes>(oPlanRes);
                }
                else
                {
                    throw new NoDataException(true);
                }

            }
        }

        public async Task<ResponseDataArrayModel<OptionRes>> optionList(OptionReq request)
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_OPTION_MASTER", new { PLANCODE = request.planCode , SCHEMECODE = request.schemeCode }, commandType: CommandType.StoredProcedure);

                List<OptionRes> oOption = new List<OptionRes>();
                var schememaster = multi.ToList();
                if (schememaster.Count > 0)
                {
                    foreach (var s in schememaster)
                    {
                        oOption.Add(new OptionRes
                        {
                            optionCode = Convert.ToString(s.OPTIONCODE),
                            optionName = Convert.ToString(s.OPTIONNAME)
                        });
                    }
                    return new ResponseDataArrayModel<OptionRes>(oOption);
                }
                else
                {
                    throw new NoDataException(true);
                }

            }
        }

        public async Task<ResponseDataArrayModel<CountryRes>> countryList()
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_NEWINVESTOR_COUNTRY_MASTER", commandType: CommandType.StoredProcedure);
                List<CountryRes> oCountry = new List<CountryRes>();
                var countryList = multi.ToList();
                if (countryList.Count > 0)
                {
                    foreach (var c in countryList)
                    {
                        oCountry.Add(new CountryRes
                        {
                            country = c.Country
                        });
                    }
                    return new ResponseDataArrayModel<CountryRes>(oCountry);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }

        public async Task<ResponseDataModel<PANCheck>> validatePAN(PanKYCReq request)
        {
            PANCheck oPANCheck = new PANCheck();
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("PROC_CHECKPANEXISTING ", new { PAN_NO = request.panNo }, commandType: CommandType.StoredProcedure);
                var ClientData = multi.ToList();
                if (ClientData[0].KYCDONE == "YES")
                {
                    oPANCheck.kycStatus = true;
                    oPANCheck.userName = Convert.ToString(ClientData[0].FHNAME);
                }
                else
                {
                    string res = CheckvalidatePAN(request.panNo) ?? "";
                    if (res.IsValidJson())
                    {
                        if (!string.IsNullOrEmpty(res))
                        {
                            var s = JsonConvert.DeserializeObject<List<PANRes>>(Convert.ToString(res));
                            if (s != null && s.Count > 0 && Convert.ToString(s[0].ReturnCode) == "200")
                            {
                                List<PANRes> oPANRes = new List<PANRes>();
                                var pandetail = new string[2];
                                if (s[0].ReturnMessage.Contains("~"))
                                {
                                    pandetail = s[0].ReturnMessage.Split("~");
                                    oPANCheck.kycStatus = Convert.ToBoolean(pandetail[0]);
                                    oPANCheck.userName = Convert.ToString(pandetail[1]);
                                }
                            }
                            else
                            {
                                oPANCheck.kycStatus = false;
                                oPANCheck.userName = "";
                            }
                        }
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
            return new ResponseDataModel<PANCheck>(oPANCheck);
        }

        public async Task<ResponseDataModel<aadharcheckRes>> validateAadhar(aadharcheckReq request)
        {
            string res = ValidateKYCByAadhar(request.aadharNumber);
            if (res != null)
            {
                aadharcheckRes oaadharcheckReq = new aadharcheckRes();
                oaadharcheckReq.returnMessage = res;
                return new ResponseDataModel<aadharcheckRes>(oaadharcheckReq);
            }
            else
            {
                throw new NoDataException(false);
            }
            //if (res.ToUpper() != "FALSE")
            //{
            //    return new ResponseDataModel<aadharcheckRes>(oaadharcheckReq);
            //}
            //else
            //{
            //    throw new NoDataException(true);
            //}
        }

        public async Task<ResponseDataModel<validateUserRes>> validateUser(string Appid,PanKYCReq request)
        {
            validateUserRes oPANCheck = new validateUserRes();
            var message = "";
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMCMOB_VALIDATE_GENERATEOTP_NEWINVESTOR ", new { PANNO = request.panNo, APPID  = Appid }, commandType: CommandType.StoredProcedure);
                var ClientData = multi.ToList();
                if (ClientData.Count > 0)
                {
                    oPANCheck.authorizeUser = Convert.ToBoolean(ClientData[0].authorizeUser);
                    message = ClientData[0].MsgMessage;
                    if (ClientData[0].AllowOTP == 0)
                    {
                        return new ResponseDataModel<validateUserRes>(null, ClientData[0].MsgMessage);
                    }
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
            return new ResponseDataModel<validateUserRes>(oPANCheck);
        }

        public string CheckvalidatePAN(string PanNumber)
        {
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    PanNumber
                };
                string inputJson = JsonConvert.SerializeObject(input);
                string result = KarvyRequest.CreateHTTPRequest("KYCCheck", serviceUrl, inputJson);
                return result;
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt","\r\n" + DateTime.Now.ToString() + " CheckvalidatePAN:" + ex.Message);
                return null;
            }
        }

        public string ValidateKYCByAadhar(string Aadharnumber)
        {
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Aadharnumber
                };
                string inputJson = JsonConvert.SerializeObject(input);
                string result = KarvyRequest.CreateHTTPRequest("MOSLAadharvalidation", serviceUrl, inputJson);
                return result;
            }
            catch (Exception ex)
            {

                System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "\r\n" + DateTime.Now.ToString() + "CheckvalidatePAN:" + ex.Message);
                return null;
            }
        }

        public async Task<ResponseDataModel<string>> calculateInstalment(calculateInstalment request)
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("CalculateNoOfInstallment", new
                {
                    request.fromDate,
                    request.toDate,
                    request.frequency,
                }, commandType: CommandType.StoredProcedure);

                var noOfinstallment = multi.ToList();
                if (noOfinstallment.Count > 0)
                {
                    return new ResponseDataModel<string>(noOfinstallment[0].Noofinstalments.ToString());
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }


        public async Task<ResponseDataModel<ResPinCode>> getStateCity(ReqPinCode request)
        {
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("AMC_GET_STATECITY", new
                {
                    request.pinCode,
                }, commandType: CommandType.StoredProcedure);

                var data = multi.ToList();
                ResPinCode objStateCity = new ResPinCode();
                if (data.Count > 0)
                {
                    objStateCity.state = data[0].State;
                    objStateCity.city = data[0].City;
                    return new ResponseDataModel<ResPinCode>(objStateCity);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }

        //public List<CityRes> GetCitydetailsByState(string stateName)
        //{
        //    string state = "city";
        //    try
        //    {
        //        object input = new
        //        {
        //            Adminusername,
        //            Adminpassword,
        //            state
        //        };
        //        string inputJson = JsonConvert.SerializeObject(input); //(new JavaScriptSerializer()).Serialize(input);
        //        HttpWebRequest httpRequest = KarvyRequest.CreateHTTPRequest("MOSLStates", serviceUrl, inputJson);

        //        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //        string result = "";
        //        List<CityRes> ocity = new List<CityRes>();

        //        using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
        //        {
        //            using (Stream stream = httpResponse.GetResponseStream())
        //            {
        //                string s = (new StreamReader(stream)).ReadToEnd();
        //                result = JsonConvert.DeserializeObject(s).ToString();

        //                JArray json = JArray.Parse(result);


        //                var query = from c in json
        //                            where c["state"].ToString() == stateName
        //                            select new CityRes
        //                            {
        //                                city = (string)c["city"],
        //                            };

        //                ocity = query.ToList<CityRes>();

        //            }
        //        }
        //        return ocity;
        //    }
        //    catch (Exception ex)
        //    {
        //        System.IO.File.AppendAllText("D:\\KarvyMasterLog.txt", "City Master:" + ex.Message);
        //        return null;
        //    }
        //}
        public string CheckBODFlag()
        {
            string flag = string.Empty;
            string Duration = "0";
            using (var conn = MOAMCPORTAL)
            {
                using (var ObjRes = conn.QueryMultiple("USP_BOD_STATUS", new
                {
                }, commandType: CommandType.StoredProcedure))
                {
                    var Returnvalue = ObjRes.Read<string>().FirstOrDefault();
                    flag = Convert.ToString(Returnvalue);
                    var now = DateTime.Now;
                    var tomorrowAM = now.AddDays(1).Date.AddHours(cachetilltommorrowhours);
                    if (flag.ToString() == "False")
                    {
                        int cacheTimeSeconds = Convert.ToInt32((tomorrowAM - now).TotalSeconds);
                        Duration = Convert.ToString(cacheTimeSeconds);
                    }
                }
                return Duration.ToString();
            }

        }

    }
}
