﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.Masters
{
    public interface IMasterDataSource
    {
        Task<ResponseDataModel<HolderBasicRes>> holderBasicDetails();
        Task<ResponseDataModel<FatcaBasicRes>> fatcaBasicDetails();
        Task<ResponseDataArrayModel<StateMaster>> GetstateList();
        Task<ResponseDataArrayModel<CityRes>> GetcityList(CityReq request);
        Task<ResponseDataArrayModel<Relation>> relationshipLists();
        Task<ResponseDataArrayModel<AccountType>> GetaccountTypeDetails(AccountTypeReq request);
        Task<ResponseDataArrayModel<BankTypeRes>> availableBankList(BankTypeReq request);
        Task<ResponseDataModel<SchemePlanModeRes>> schemeList();
        Task<ResponseDataArrayModel<CountryRes>> countryList();
        Task<ResponseDataArrayModel<PlanRes>> planList(PlanReq request);
        Task<ResponseDataArrayModel<OptionRes>> optionList(OptionReq request);
        Task<ResponseDataModel<PANCheck>> validatePAN(PanKYCReq request);
        Task<ResponseDataModel<aadharcheckRes>> validateAadhar(aadharcheckReq request);
        Task<ResponseDataModel<string>> calculateInstalment(calculateInstalment request);
        Task<ResponseDataModel<validateUserRes>> validateUser(string Appid,PanKYCReq request);
        Task<ResponseDataModel<ResPinCode>> getStateCity(ReqPinCode request);
        string CheckBODFlag();
    }
}
