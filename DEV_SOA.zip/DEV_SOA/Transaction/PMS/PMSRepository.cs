﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Helpers;
using ApiCore.Model;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.PMS
{
    public class PMSRepository : IPMSDataSource
    {
        private readonly DbConnections _connections;
        
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCPORTAL);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string serviceUrl = "";
        string Adminusername = "";
        string Adminpassword = "";
        string orderGenratonURL = "";
        string paymentReuestURL = "";
        string ReqLog = string.Empty;
        private string ErrorLogFile = string.Empty;
        public PMSRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            serviceUrl = _iconfiguration["URL:serviceUrl"];
            Adminusername = _iconfiguration["URL:Adminusername"];
            Adminpassword = _iconfiguration["URL:Adminpassword"];
            orderGenratonURL= _iconfiguration["URL:orderGenratonURL"];
            paymentReuestURL = _iconfiguration["URL:paymentReuestURL"];
        }
        //strategyList
        public async Task<ResponseDataArrayModel<StrategylistRes>> PMSStrategylist(string panno, Strategylist request)
        {
            using (var conn = MOAMCMOBILEDB)
            {


                if (request.typeofTrans.Trim().ToUpper() == "EXISTING")
                {
                    var multi = await conn.QueryAsync("AMCMob_USP_AMC_GET_PMS_DEATILS_TopUp", new
                    {
                        PAN_NO = panno,
                    }, commandType: CommandType.StoredProcedure);
                    var StrategyList = multi.ToList();
                    List<StrategylistRes> oStrategylist = new List<StrategylistRes>();
                    if (StrategyList.Count > 0)
                    {
                        foreach (var p in StrategyList.ToList())
                        {
                            oStrategylist.Add(new StrategylistRes
                            {
                                pmsCode = Convert.ToString(p.PMS_CODE),
                                strategyName = Convert.ToString(p.INSTRUMENT_NAME),
                                minTopupAmt = Convert.ToDouble(Convert.ToString(p.minTopupAmount)),
                                minSipAmt = Convert.ToDouble(Convert.ToString(p.minSipAmount)),
                            });
                        }
                        return new ResponseDataArrayModel<StrategylistRes>(oStrategylist);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
                else if (request.typeofTrans.Trim().ToUpper() == "NEW")
                {
                    var multi = await conn.QueryAsync("AMCMob_USP_PMS_STAG_DETAILS", new
                    {
                        PAN_NO = panno,
                    }, commandType: CommandType.StoredProcedure);
                    var StrategyList = multi.ToList();
                    List<StrategylistRes> oStrategylist = new List<StrategylistRes>();
                    if (StrategyList.Count > 0)
                    {
                        foreach (var p in StrategyList.ToList())
                        {
                            oStrategylist.Add(new StrategylistRes
                            {
                                pmsCode = Convert.ToString(p.PMS_CODE),
                                strategyName = Convert.ToString(p.INSTRUMENT_NAME),
                                minTopupAmt = Convert.ToDouble(Convert.ToString(p.minTopupAmount)),
                                minSipAmt = Convert.ToDouble(Convert.ToString(p.minSipAmount)),
                            });
                        }
                        return new ResponseDataArrayModel<StrategylistRes>(oStrategylist);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
                else
                {
                    throw new NoDataException(true);
                }
               
            }

        }
        //bankAndDistributor
        public async Task<ResponseDataModel<BankAndDistriRes>> PMSBankAndDistributorList(string panno,BankAndDistri request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_Proc_Getdistributordetails", new
                {
                    Panno = panno,
                    PMSCODE = request.strategyCode ,
                    TransType = request.transactionType ,
                }, commandType: CommandType.StoredProcedure))
                {
                    BankAndDistriRes BankAndDistri = new BankAndDistriRes();
                    var Distributor = multi.Read().ToList();
                    var BankDetail = multi.Read().ToList();
                    if (Distributor.Count > 0)
                    {
                        BankAndDistri.distributorName = Distributor[0].DISNAME ?? "";
                        BankAndDistri.currentValue = Convert.ToDouble(Convert.ToString(Distributor[0].CurrentValue)) ?? 0.00;
                        BankAndDistri.netInvestment = Convert.ToDouble(Convert.ToString(Distributor[0].NetInvestment)) ?? 0.00;
                        List<BankDetails> bankData = new List<BankDetails>();
                        for (int i = 0; i < BankDetail.Count; i++)
                        {

                            BankDetails cls = new BankDetails();
                            cls.bankname = BankDetail[i].Bank_Name ?? "";
                            cls.bankShortname =  BankDetail[i].BankShortName ?? "";
                            cls.bankAccNumber = BankDetail[i].BANKACCOUNT ?? "";
                            cls.bankEligibilityStatus = Convert.ToBoolean(BankDetail[i].Flagforbank) ?? false;
                            bankData.Add(cls);
                        }
                        BankAndDistri.bankDetails = bankData;

                        return new ResponseDataModel<BankAndDistriRes>(BankAndDistri);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }
                
            }

        }
        //feeStructureUrl
        public async Task<ResponseDataModel<FeeStructureRes>> FeeStructure(string panno)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_Proc_GetFeesStructure", new
                {
                    Panno = panno
                }, commandType: CommandType.StoredProcedure);

                FeeStructureRes FeeStructure = new FeeStructureRes();
                var FeeStructureData = multi.ToList();
                if (FeeStructureData.Count > 0)
                {
                    FeeStructure.url = FeeStructureData[0].FEEPATH ?? "";
                    return new ResponseDataModel<FeeStructureRes>(FeeStructure);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }

        }
        //savePMSTopUp
        public async Task<ResponseDataModel<SavePMSTopupRes>> SavePmsTransaction(string panno,string AppId, SavePMSTopup request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_PROC_INSERTPMSTOPUPTRANSACTIONDETAILS", new
                {
                    PANNO = panno,
                    PMSCODE = request.pmsCode,
                    StrategyName = request.strategyName,
                    BankAccNo = request.bankAccNumber,
                    TransactionAmount = request.transactionAmount,
                    TypeofTrans = request.typeOfTransaction,
                    IpAddress = AppId,
                    InvestorRegBank = request.bankFullName + "[" + request.bankAccNumber +"]",
                }, commandType: CommandType.StoredProcedure);
                    {
                        var Returnvalue = multi.ToList();
                        if (Returnvalue.Count > 0)
                        {
                            SavePMSTopupRes SavePMSTopupRes = new SavePMSTopupRes();
                            SavePMSTopupRes.pmsCode = Returnvalue[0].PMSCODE;
                            SavePMSTopupRes.transactionRefrenceNumber = Convert.ToString(Returnvalue[0].TransactionReferenceNo);
                            SavePMSTopupRes.requestRaiseDate = Convert.ToDateTime(Returnvalue[0].RequestRaiseDate);
                            SavePMSTopupRes.transactionAmount = Convert.ToDouble(string.Format("{0:0.00}", Returnvalue[0].TransactionAmount).Trim());
                            SavePMSTopupRes.typeOfTransaction = Returnvalue[0].TYPE_OF_TRANS;
                            SavePMSTopupRes.orderNo = Returnvalue[0].OrderNo;
                            SavePMSTopupRes.strategyName = Returnvalue[0].StrategyName;
                            SavePMSTopupRes.strategyCode = Returnvalue[0].StrategyCode;
                            SavePMSTopupRes.emailId = Returnvalue[0].email;
                            SavePMSTopupRes.phoneNo = Returnvalue[0].MobileNo;
                        string TimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                        //var str = "MOTILALOAM|" + Convert.ToString(Returnvalue[0].TransactionReferenceNo) + "|" + request.bankAccNumber + "|" + 1 + "|" + request.bankShortName + "|NA|NA|INR|DIRECT|R|motilaloam|NA|NA|F|" + Returnvalue[0].PMSCODE + "|" + Returnvalue[0].OrderNo + "|NA|NA|NONLIQUID|RESIDENT-" + Returnvalue[0].StrategyCode + "-NA-L-NA-NA|" + DateTime.Now.ToString("yyyyMMddHHmmss") + "|" + Returnvalue[0].URL;
                        var str = "MOTILALOAM|" + Convert.ToString(Returnvalue[0].TransactionReferenceNo).Trim() + "|" + Convert.ToString(request.bankAccNumber).Trim() + "|" + string.Format("{0:0.00}", Returnvalue[0].TransactionAmount).Trim() + "|" + request.bankShortName.Trim() + "|NA|NA|INR|DIRECT|R|motilaloam|NA|NA|F|" + Returnvalue[0].PMSCODE.Trim() + "|" + Returnvalue[0].OrderNo.Trim() + "|NA|NA|NONLIQUID|RESIDENT-" + Returnvalue[0].StrategyCode.Trim() + "-NA-L-NA-NA|" + TimeStamp + "|" + Returnvalue[0].URL.Trim();

                            UTF8Encoding encoder = new UTF8Encoding();
                            string key = "GaEIbouJtdPj";
                            byte[] hashValue;
                            byte[] keybyt = encoder.GetBytes(key);
                            byte[] message = encoder.GetBytes(str);

                            HMACSHA256 hashString = new HMACSHA256(keybyt);
                            string hex = "";
                            hashValue = hashString.ComputeHash(message);
                            foreach (byte x in hashValue)
                            {
                                hex += String.Format("{0:x2}", x);
                            }
                            hex =   hex.ToUpper();
                        SavePMSTopupRes.referelURL = Returnvalue[0].URL;
                        SavePMSTopupRes.checksum = hex;
                        SavePMSTopupRes.timeStamp = TimeStamp;
                        return new ResponseDataModel<SavePMSTopupRes>(SavePMSTopupRes);
                        }
                    else
                    {
                        throw new NoDataException(false);
                    }

                    }
            }
        }
        //paymentConfirmation
        public async Task<ResponseDataModel<PaymentConfirmationRes>> PaymentConfirmation(string panno, string AppId, PaymentConfirm request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_Proc_UpdateBilldeskResponse", new
                {
                    transactionNo = request.transactionNo,
                    merchantId = request.merchantId,
                    transactionReferenceNo = request.transactionReferenceNo,
                    bankRef = request.bankRef,
                    transactionAmount = request.transactionAmount,
                    bankId = request.bankId,
                    bankMerchantId = request.bankMerchantId,
                    transactionType = request.transactionType,
                    currency = request.currency,
                    itemCode = request.itemCode,
                    securityType = request.securityType,
                    securityPassword = request.securityPassword,
                    transactionDate = request.transactionDate,
                    authStatus = request.authStatus,
                    settlementType = request.settlementType,
                    additional_Info1 = request.additional_Info1,
                    additional_Info2 = request.additional_Info2,
                    additional_Info3 = request.additional_Info3,
                    additional_Info4 = request.additional_Info4,
                    additional_Info5 = request.additional_Info5,
                    additional_Info6 = request.additional_Info6,
                    additional_Info7 = request.additional_Info7,
                    erroStatus = request.erroStatus,
                    errorDescription = request.errorDescription,
                    checkSum = request.checkSum,
                }, commandType: CommandType.StoredProcedure);
                {
                    var Returnvalue = multi.ToList();
                    if (Returnvalue.Count > 0)
                    {
                        PaymentConfirmationRes PaymentConfirmationRes = new PaymentConfirmationRes();
                        PaymentConfirmationRes.pmsCode = Convert.ToString(Returnvalue[0].PMSCODE) ?? "";
                        PaymentConfirmationRes.strategyName = Convert.ToString(Returnvalue[0].strategyName) ?? "";
                        PaymentConfirmationRes.transactionRefrenceNumber = Convert.ToString(Returnvalue[0].TransactionNo) ?? "" ;
                        PaymentConfirmationRes.transactionAmount = Convert.ToDouble(Returnvalue[0].TransactionAmount) ?? 0;
                        return new ResponseDataModel<PaymentConfirmationRes>(PaymentConfirmationRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }
            }
        }
        //savePMSTopUp
        public async Task<ResponseDataModel<SavePMSSIPRes>> SavePMSSIP(string panno, string AppId, SavePMSSIP request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryMultipleAsync("AMCMob_Insert_PMS_SIP_Trans_Details", new
                {
                    PANNO = panno,
                    PMSCode = request.pmsCode,
                    TypeofTrans = request.typeofTrans,
                    SIPAmt = request.sipAmount,
                    Date_of_Deduction = request.deductionDate,
                    Frequency = request.frequency,
                    FromDate = request.fromDate,
                    ToDate = request.toDate,
                    NoOfInstament = request.noOfInstament,
                    Perpetual = request.perpetual,
                    BankAccNo = request.bankAccNo,
                    InvestorRegBank = request.investorRegBank,
                    StrategyName = request.strategyName,
                    IFSCCode = "",
                    MICRCCode = "",
                    Appid =AppId,
                }, commandType: CommandType.StoredProcedure);
                {
                  
                    var TransactionDetails = multi.Read().ToList();
                    if (TransactionDetails.Count > 0)
                    {
                        SavePMSSIPRes SavePMSSIP= new SavePMSSIPRes();
                        SavePMSSIP.pmsCode = TransactionDetails[0].PMS_Code;
                        SavePMSSIP.transactionRefrenceNumber = Convert.ToString(TransactionDetails[0].TransID);
                        SavePMSSIP.urnNumber = TransactionDetails[0].URN_No;
                        SavePMSSIP.urnExpiryDate = TransactionDetails[0].URN_EXPIRY_DATE;
                        return new ResponseDataModel<SavePMSSIPRes>(SavePMSSIP);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }


            }
        }
        public async Task<ResponseDataModel<SavePMSTopupResBillDesk>> SavePmsTransactionNew(string panno, string AppId, TransactionRequestConsolidate request)
        {

            TransactionReqResponse transaction = new TransactionReqResponse();
            string ReqResponseXML = string.Empty;
            try
            {
                transaction._TransactionRequest = request;
                ReqResponseXML = Utilities.ObjectToXMLString(transaction);
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMOB_PROC_INSERTPMSTOPUPTRANSACTIONDETAILS_New", new
                    {
                        ReqTrans = ReqResponseXML,
                        PANNO = panno,
                        IpAddress = AppId

                    }, commandType: CommandType.StoredProcedure);
                    {
                        var Returnvalue = multi.ToList();
                        SavePMSTopupResBillDesk SavePMSTopupRes = new SavePMSTopupResBillDesk();
                        if (Returnvalue.Count > 0 && Convert.ToString(Returnvalue[0].successflag) == "1")
                        {
                            string TimeStamp = DateTime.Now.ToString();
                            OrderRequest ObjOrderRequest = new OrderRequest();
                            List<OrderRecord> itemDetails = new List<OrderRecord>();
                            List<PMSInevestment> pmsInvestmentDetails = new List<PMSInevestment>();
                            var count = _iconfiguration["PaymentGateway:UATAmount"] == "Y" && Returnvalue.Count>1 ? 2 : Returnvalue.Count;
                            for (int i = 0; i < count; i++)
                            {
                                OrderRecord ObjOrderRecord = new OrderRecord();
                                PMSInevestment investment = new PMSInevestment();
                                investment.DistributorName = Convert.ToString(Returnvalue[i].DistributorName).Trim();
                                investment.PMSCode = Convert.ToString(Returnvalue[0].PMSCODE);
                                investment.childOrderID = Convert.ToString(Returnvalue[i].TransactionReferenceNo).Trim();
                                investment.Amount= Convert.ToString(Returnvalue[i].TransactionAmount).Trim();
                                ObjOrderRecord.Amount = _iconfiguration["PaymentGateway:UATAmount"]== "Y"? "1": Convert.ToString(Returnvalue[i].TransactionAmount).Trim();
                                ObjOrderRecord.ChildOrderId = Convert.ToString(Returnvalue[i].TransactionReferenceNo).Trim();
                                pmsInvestmentDetails.Add(investment);
                                itemDetails.Add(ObjOrderRecord);
                            }
                            ObjOrderRequest.MainOrderId = Convert.ToString(Returnvalue[0].ParentID).Trim();
                            ObjOrderRequest.Amount = _iconfiguration["PaymentGateway:UATAmount"] == "Y" && Returnvalue.Count > 1 ? "2" : _iconfiguration["PaymentGateway:UATAmount"] == "Y" && Returnvalue.Count == 1? "1":string.Format("{0:0.00}", Returnvalue[0].TotalAmount).Trim();
                            var data = Returnvalue[0].CreatedDate;
                            ObjOrderRequest.TimeStamp = Convert.ToDateTime(Returnvalue[0].CreatedDate).ToString("yyyy'-'MM'-'dd HH':'mm").Trim();
                            ObjOrderRequest.itemDetails = itemDetails;
                            ObjOrderRequest.TnxType = "PMS";
                            //ObjOrderRequest.PG_PGMERCID = _iconfiguration["PaymentGateway:PGMERCID"];
                            string JsonReq = JsonConvert.SerializeObject(ObjOrderRequest);
                            if (_iconfiguration["PMSTnxLog"] == "On")
                            {
                                ReqLog = _iconfiguration["RequestLog"];
                                ReqLog = ReqLog + "_PMSTnx_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                                File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppId + "\r ParentId :" + Convert.ToString(ObjOrderRequest.MainOrderId) + "\r PanNo :" + Convert.ToString(panno) + "\r Request :" + JsonReq);
                            }
                            SavePMSTopupRes.pmsInvestmentDetails = pmsInvestmentDetails;
                            SavePMSTopupRes.parentID = Convert.ToString(Returnvalue[0].ParentID).Trim();
                            SavePMSTopupRes.totalAmount= string.Format("{0:0.00}", Returnvalue[0].TotalAmount).Trim();
                            //txt log update in table parent id
                            var resOrder = await Utility.HttpPostRequestwithHeaders(AppId, JsonReq, orderGenratonURL);
                            var ResOrderGeneration = JsonConvert.DeserializeObject<orderGenerateResponse>(resOrder.ToString());
                            if (ResOrderGeneration.success == true)
                            {
                                if (ResOrderGeneration.data != null && ResOrderGeneration.data.StatusCode == "0")
                                {
                                    PaymentRequest ObjPaymentRequest = new PaymentRequest();
                                    ObjPaymentRequest.PG_MerchantID = _iconfiguration["PaymentGateway:PGMERCID"];
                                    ObjPaymentRequest.MainOrderId = Convert.ToString(Returnvalue[0].ParentID).Trim();
                                    ObjPaymentRequest.BankAccNo = request.BankAccountNo;
                                    ObjPaymentRequest.TxnAmount = _iconfiguration["PaymentGateway:UATAmount"] == "Y" && Returnvalue.Count > 1 ? "2" : _iconfiguration["PaymentGateway:UATAmount"] == "Y" && Returnvalue.Count == 1 ? "1" : Convert.ToString(request.TotalInvestAMount).Trim();
                                    ObjPaymentRequest.BankID = request.BankId;
                                    ObjPaymentRequest.PG_CurrencyType = _iconfiguration["PaymentGateway:CurrencyType"];
                                    ObjPaymentRequest.PG_ProductID = _iconfiguration["PaymentGateway:ProductID"];
                                    ObjPaymentRequest.PG_TypeField1 = _iconfiguration["PaymentGateway:TypeField1"];
                                    ObjPaymentRequest.PG_SecurityID = _iconfiguration["PaymentGateway:SecurityID"];
                                    ObjPaymentRequest.PG_TypeField2 = _iconfiguration["PaymentGateway:TypeField2"];
                                    ObjPaymentRequest.PG_AdditionalInfo1 = Returnvalue[0].PMSCODE;
                                    ObjPaymentRequest.PG_AdditionalInfo2 = Convert.ToString(Returnvalue[0].OrderNo).Trim();
                                    ObjPaymentRequest.PG_AdditionalInfo5 = _iconfiguration["PaymentGateway:AdditionalInfo5"];
                                    ObjPaymentRequest.PG_AdditionalInfo6 = _iconfiguration["PaymentGateway:RESIDENT"] + Returnvalue[0].StrategyCode + _iconfiguration["PaymentGateway:AdditionalInfo6"];
                                    ObjPaymentRequest.PG_AdditionalInfo7 = DateTime.Now.ToString("yyyyMMddHHmmss");
                                    ObjPaymentRequest.Mode = "NETBANKING";
                                    ObjPaymentRequest.TnxType = "PMS";
                                    ObjPaymentRequest.PG_ReturnURL = _iconfiguration["PaymentGateway:PG_ReturnURL"];
                                    ObjPaymentRequest.PG_ChecksumKey = _iconfiguration["PaymentGateway:CHECKSUMKEY"];
                                    string JsonReqConfirmation = JsonConvert.SerializeObject(ObjPaymentRequest);
                                    //log=>txt/parentid update into log table resconf
                                    if (_iconfiguration["PMSTnxReqURLLog"] == "On")
                                    {
                                        ReqLog = _iconfiguration["RequestLog"];
                                        ReqLog = ReqLog + "_PMSTnx_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                                        File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppId + "\r ParentId :" + Convert.ToString(ObjOrderRequest.MainOrderId) + "\r PanNo :" + Convert.ToString(panno) + "\r Request :" + JsonReq);
                                    }
                                    var resConfirmation = await Utility.HttpPostRequestwithHeaders(AppId, JsonReqConfirmation, paymentReuestURL);
                                    var FinalRsponse = JsonConvert.DeserializeObject<PaymentRequestResponse>(resConfirmation.ToString());
                                    SavePMSTopupRes.referelURL = FinalRsponse.data.PaymentURL;
                                    return new ResponseDataModel<SavePMSTopupResBillDesk>(SavePMSTopupRes);
                                }
                                else
                                {
                                    SavePMSTopupRes.ExceptionMsg = ResOrderGeneration.data.StatusDesc;
                                    return new ResponseDataModel<SavePMSTopupResBillDesk>(SavePMSTopupRes);
                                }
                            }
                            else
                            {
                                SavePMSTopupRes.ExceptionMsg = ResOrderGeneration.message;
                                return new ResponseDataModel<SavePMSTopupResBillDesk>(SavePMSTopupRes);
                            }
                        }
                        else
                        {
                            SavePMSTopupRes.ExceptionMsg = Convert.ToString(Returnvalue[0].message);
                            return new ResponseDataModel<SavePMSTopupResBillDesk>(SavePMSTopupRes);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw new NoDataException(false);
            }

        }

        //paymentConfirmation
        public async Task<ResponseDataModel<List<PaymentConfirmationResponse>>> PaymentConfirmationNew(string panno, string AppId, PaymentConfirmReq request)
        {
            List<PaymentConfirmationResponse> paymentConfirmations = new List<PaymentConfirmationResponse>();
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMobProc_UpdateBilldeskResponse_New", new
                    {
                        transactionNo = request.ParentId,
                        merchantId = request.merchantId,
                        transactionReferenceNo = request.transactionReferenceNo,
                        bankRef = request.bankRef,
                        transactionAmount = request.transactionAmount,
                        bankId = request.bankId,
                        bankMerchantId = request.bankMerchantId,
                        transactionType = request.transactionType,
                        currency = request.currency,
                        itemCode = request.itemCode,
                        securityType = request.securityType,
                        securityPassword = request.securityPassword,
                        transactionDate = request.transactionDate,
                        authStatus = request.authStatus,
                        settlementType = request.settlementType,
                        additional_Info1 = request.additional_Info1,
                        additional_Info2 = request.additional_Info2,
                        additional_Info3 = request.additional_Info3,
                        additional_Info4 = request.additional_Info4,
                        additional_Info5 = request.additional_Info5,
                        additional_Info6 = request.additional_Info6,
                        additional_Info7 = request.additional_Info7,
                        erroStatus = request.erroStatus,
                        errorDescription = request.errorDescription,
                        checkSum = request.checkSum,
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var Returnvalue = multi.ToList();
                        if (Returnvalue.Count > 0)
                        {
                            for (int i = 0; i < Returnvalue.Count; i++)
                            {
                                PaymentConfirmationResponse PaymentConfirmationRes = new PaymentConfirmationResponse();
                                PaymentConfirmationRes.ParentId = Convert.ToString(Returnvalue[i].ParentID) ?? "";
                                PaymentConfirmationRes.pmsCode = Convert.ToString(Returnvalue[i].PMSCODE) ?? "";
                                PaymentConfirmationRes.strategyName = Convert.ToString(Returnvalue[i].StrategyName) ?? "";
                                PaymentConfirmationRes.transactionRefrenceNumber = Convert.ToString(Returnvalue[i].TransactionNo) ?? "";
                                PaymentConfirmationRes.transactionAmount = Convert.ToDouble(Returnvalue[i].TransactionAmount) ?? 0;
                                PaymentConfirmationRes.ErrorMessage = Convert.ToString(Returnvalue[i].Error) ?? "";
                                paymentConfirmations.Add(PaymentConfirmationRes);
                            }
                            return new ResponseDataModel<List<PaymentConfirmationResponse>>(paymentConfirmations);
                        }
                        else
                        {
                            return new ResponseDataModel<List<PaymentConfirmationResponse>>(null, "No Data Found");
                        }

                    }
                }
             }
            catch(Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "PaymentCOnfirmationPMS \r ERROR:" + ex.Message);
                return new ResponseDataModel<List<PaymentConfirmationResponse>>(null, ex.Message);
            }
        }
   }

}

