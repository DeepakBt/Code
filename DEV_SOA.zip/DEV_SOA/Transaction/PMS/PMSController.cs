﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Auth;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Transaction.Masters;
using Transaction.Models;
using Transaction.Utils;

namespace Transaction.PMS
{
    [Produces("application/json")]
    [Route("api/PMS")]
    [ValidateModel]
    [Authorize]
    public class PMSController : ControllerBase
    {
        private readonly IPMSDataSource _TransactionDataSource;
        private string Day1 = "0";
        private readonly IMasterDataSource _MasterDataSource;
        public PMSController(TokenHelper tokenHelper, IPMSDataSource TransactionDataSource, IMasterDataSource MasterDataSource)
        {
            _TransactionDataSource = TransactionDataSource;
            _MasterDataSource = MasterDataSource;
            Day1 = _MasterDataSource.CheckBODFlag();
        }
        [HttpGet("strategyList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<StrategylistRes>), 200)]
        public async Task<IActionResult> PMSStrategylist( Strategylist request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.PMSStrategylist(panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }

        [HttpGet("bankAndDistributor")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<BankAndDistriRes>), 200)]
        public async Task<IActionResult> PMSBankAndDistributorList(BankAndDistri request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.PMSBankAndDistributorList(panNo, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }

        [HttpGet("feeStructureUrl")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<FeeStructureRes>), 200)]
        public async Task<IActionResult> FeeStructure()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.FeeStructure(panNo);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }


        // GET api/values
        [HttpPost("savePMSTopUp")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SavePMSTopupRes>), 200)]
        public async Task<IActionResult> SavePmsTransaction([FromBody] SavePMSTopup request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.SavePmsTransaction(panNo, AppId, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }



        [HttpPost("paymentConfirmation")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<PaymentConfirmationRes>), 200)]
        public async Task<IActionResult> PaymentConfirmation([FromBody] PaymentConfirm request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.PaymentConfirmation(panNo, AppId, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }




        [HttpPost("savePMSSIPDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SavePMSSIPRes>), 200)]
        public async Task<IActionResult> SavePMSSIP([FromBody] SavePMSSIP request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.SavePMSSIP(panNo, AppId, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }
        [HttpPost("savePMS")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SavePMSTopupResBillDesk>), 200)]
        public async Task<IActionResult> SavePmsTransactionNew([FromBody] TransactionRequestConsolidate request)
        {
           // Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            Request.HttpContext.Response.Headers.Remove("Cache-Control");
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                var response = await _TransactionDataSource.SavePmsTransactionNew(panNo, AppId, request);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }
        [HttpPost("paymentConfirmationNew")] [Produces("application/json")] 
        [ProducesResponseType(typeof(ResponseDataModel<List<PaymentConfirmationResponse>>), 200)]
        public async Task<IActionResult> PaymentConfirmationNew([FromBody] PaymentConfirmReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1); 
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.PaymentConfirmationNew(panNo, AppId, request); return Ok(response);
            }
            else
            {
                throw new NoDataException(false, "Session expired");
            }
        }


    }
}