﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Transaction.Models;

namespace Transaction.PMS
{
   public interface IPMSDataSource
    {
        Task<ResponseDataArrayModel<StrategylistRes>> PMSStrategylist(string panno, Strategylist request);
        Task<ResponseDataModel<BankAndDistriRes>> PMSBankAndDistributorList(string panno, BankAndDistri request);
        Task<ResponseDataModel<FeeStructureRes>> FeeStructure(string panno);
        Task<ResponseDataModel<SavePMSTopupRes>> SavePmsTransaction(string panno, string AppId, SavePMSTopup request);
        Task<ResponseDataModel<PaymentConfirmationRes>> PaymentConfirmation(string panno, string AppId, PaymentConfirm request);
        Task<ResponseDataModel<SavePMSSIPRes>> SavePMSSIP(string panno, string AppId, SavePMSSIP request);
        Task<ResponseDataModel<SavePMSTopupResBillDesk>> SavePmsTransactionNew(string panno, string AppId, TransactionRequestConsolidate request);
        Task<ResponseDataModel<List<PaymentConfirmationResponse>>> PaymentConfirmationNew(string panno, string AppId, PaymentConfirmReq request);
    }
}
