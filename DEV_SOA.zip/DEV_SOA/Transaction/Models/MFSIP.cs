﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class MFSIP
    {
        public class SIPPlanOptionsReq
        {
            /// <summary> Ex. CP </summary>
            [DefaultValue("CP")]
            public string scheme { get; set; }
        }
        public class SIPPlanOptionsRes
        {
            public List<SIPPlanOptions> SIPPlanOptions { get; set; }
        }
       public class SIPPlanOptions
        {
            public string code { get; set; }
            public string description { get; set; }
        }

        public class SchemeDetailsReq
        {
            /// <summary> Ex. CP </summary>
            [DefaultValue("CP")]
            public string scheme { get; set; }

            /// <summary> Ex. GD </summary>
            [DefaultValue("GD")]
            public string plan { get; set; }

            /// <summary> Ex. G </summary>
            [DefaultValue("G")]
            public string option { get; set; }
        }

        public class SchemeDetailsRes
        {
            public List<SchemeDetail> SchemeDetail { get; set; }
        }
        public class SchemeDetail
        {
            public string scheme { get; set; }
            public string plan { get; set; }
            public string option { get; set; }
            public string description { get; set; }
            public string cutofftime { get; set; }
            public double minamount { get; set; }
            public string schemedescription { get; set; }
            public string plandescription { get; set; }
            public string optiondescription { get; set; }
            public string planoptiondescription { get; set; }
        }

        public class SubSIPReq
        {
            /// <summary> Ex. CP</summary>
            [Required]
            public string scheme { get; set; }

            /// <summary> Ex. GD</summary>
            [Required]
            public string plan { get; set; }

            /// <summary> Ex. G</summary>
            [Required]
            public string option { get; set; }

            /// <summary> Ex. 91011673385 </summary>
            [Required]
            [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
            public string folioNo { get; set; }

            /// <summary> Ex. 500 </summary>
            [Required]
            public double Amount { get; set; }

            /// <summary> Ex. 12 </summary>
            [Required]
            public string frequency { get; set; }

            /// <summary> Ex. 2019-01-01 </summary>
            [Required]
            public string sipDate { get; set; }

            /// <summary> Ex. 2019-01-01 </summary>
            [Required]
            public string startDate { get; set; }

            /// <summary> Ex. 2020-01-01 </summary>
            [Required]
            public string endDate { get; set; }

            /// <summary> Ex. ARN-0018</summary>
            public string brokerCode { get; set; }

            /// <summary> Ex. HDFC BANK </summary>
            public string bankName { get; set; }

            /// <summary> Ex. 1234567890 </summary>
            [Required]
            [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed in bankAccNo field.")]
            public string bankAccNo { get; set; }

            /// <summary> Ex. "" </summary>
            public string SubBroker { get; set; }

            /// <summary> Ex. "" </summary>
            public string euinCode { get; set; }

            /// <summary> Ex. false | true  //pass true in case of declaration checked else false only</summary>
            public Boolean euinDeclarationFlag { get; set; }

            /// <summary> Ex. "" </summary>
            public string subBrokerCode { get; set; }
 
        }

        public class SubSIPRes
        {
            public string ihno { get; set; }
            public string refno { get; set; }
            public string batchno { get; set; }
            public string urnno { get; set; }
            public string time_stamp { get; set; }
            public string urnExpiryDate { get; set; }
            public int sipId { get; set; }
        }

        public class SIPBillDesk
        {
            /// <summary> Ex. true | false </summary>
            public Boolean billdeskflag { get; set; }

            /// <summary> Ex. 5 </summary>
            public int SIPID { get; set; }
        }
    }
}
