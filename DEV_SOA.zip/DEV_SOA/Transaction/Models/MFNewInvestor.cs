﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using ApiCore.Validation;
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace Transaction.Models
{

    public  class MFNewInvestor 
    {
    }
    //PanDetails
    public class SceenNewInvestorPanDetailsRes
    {
        public string accessToken { get; set; }
        public int expiresIn { get; set; }
        public string screenNo { get; set; }
    }
    public class SceenNewInvestorPanDetails
    {
        /// <summary> Ex. XXXXX1234X </summary>
        [Required]
        public string panNo { get; set; }

        /// <summary> Ex. 12345678XXXX </summary>
        public string aadharNo { get; set; }

        /// <summary> Ex. Suryakant katariya  </summary>
        [Required]
        public string name { get; set; }

        /// <summary> Ex. 9999 </summary>
        [DefaultValue(0)]
        public int otp { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        public bool saveForlater { get; set; }
    }

    //BasicDetails
    public class ScreenNewInvestorBasicDetailsRes
    {
        public Int64 userId { get; set; }
        public int modeOfHolding { get; set; }
        public int firstHolderTaxStatus { get; set; }
        public List<BasicDetails> HolderDetails { get; set; }
        public FirstHolderGurdian firstHolderGurdian { get; set; }
    }

    public class ScreenNewInvestorBasicDetails : IValidatableObject
    {
        //[Required]
        ///// <summary> "Refer saveNewInvestorPanDetails API  "userId" Key " </summary>
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }

        /// <summary> Ex. 1 | 2 | 3 </summary>
        [Required]
        [DefaultValue(0)]
        public int modeOfHolding { get; set; }

        /// <summary> Ex. 1  </summary>
        [DefaultValue(0)]
        public int firstHolderTaxStatus { get; set; }
        public List<BasicDetails> holderDetails { get; set; }
        public FirstHolderGurdian firstHolderGurdian { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        [DefaultValue(false)]
        public bool saveForlater {get; set;}

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();

            var results = new List<ValidationResult>();

            if (this.modeOfHolding != 1 && this.modeOfHolding != 2 && this.modeOfHolding != 3 && this.modeOfHolding != 4)
            {
                results.Add(new ValidationResult("Invalid mode of holding", new List<string> { nameof(modeOfHolding) }));
            }
            if (this.firstHolderTaxStatus != 1 && this.firstHolderTaxStatus != 2)
            {
                results.Add(new ValidationResult("Invalid Tax status selected.", new List<string> { nameof(firstHolderTaxStatus) }));
            }
            if (this.holderDetails[0].category != 11 && this.holderDetails[0].category != 21)
            {
                results.Add(new ValidationResult("Invalid category selected.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].ifNri != 1 && this.holderDetails[0].ifNri != 2)
            {
                results.Add(new ValidationResult("Invalid IfNRI selected.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].occupation <= 0)
            {
                results.Add(new ValidationResult("Invalid Occupation selected.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].name == null || this.holderDetails[0].name.Trim() == "")
            {
                results.Add(new ValidationResult("First Holder Name cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].dob == null || this.holderDetails[0].dob.Trim() == "")
            {
                results.Add(new ValidationResult("Date of birth cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            else
            {
                if (ParamValid.DateValidate(this.holderDetails[0].dob.Trim(), "yyyy-MM-dd") == false)
                {
                    results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "firstHolderDetails" }));
                }
                else
                {
                    if (this.firstHolderTaxStatus == 1 && ParamValid.GetAge(this.holderDetails[0].dob) < 18)
                    {
                        results.Add(new ValidationResult("Date of birth should be greater then 18 year incase of Tax status is Individual.", new List<string> { "firstHolderDetails" }));
                    }
                    else if (this.firstHolderTaxStatus == 2 && ParamValid.GetAge(this.holderDetails[0].dob) > 18)
                    {
                        results.Add(new ValidationResult("Date of birth should be less then 18 year  incase of Tax status is Minor.", new List<string> { "firstHolderDetails" }));
                    }
                    if (this.firstHolderTaxStatus == 2)
                    {
                        if (this.firstHolderGurdian != null)
                        {
                            if (this.firstHolderGurdian.name == null || this.firstHolderGurdian.name.Trim() == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian name cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            if (this.firstHolderGurdian.panNo == null || this.firstHolderGurdian.panNo.Trim() == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian Pan No cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            else
                            {
                                if (ParamValid.IsValidPanno(this.firstHolderGurdian.panNo) == false)
                                {
                                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { "gurdaianDetails" }));
                                }
                            }
                            if (this.firstHolderGurdian.kycStatus != true && this.firstHolderGurdian.kycStatus != false)
                            {
                                results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "gurdaianDetails" }));
                            }
                        }
                        else
                        {
                            results.Add(new ValidationResult("FirstHolder gurdian details Compulsory incase of Minor Holder.", new List<string> { "firstHolderDetails" }));
                        }
                        
                    }
                }
      
            }
            if (this.holderDetails[0].panNo == null || this.holderDetails[0].panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan no cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.holderDetails[0].panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { "firstHolderDetails" }));
                }
            }
            if (this.holderDetails[0].email == null || this.holderDetails[0].email.Trim() == "")
            {
                results.Add(new ValidationResult("Email cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            else if (ParamValid.IsValidEmail(this.holderDetails[0].email) == false)
            {
                results.Add(new ValidationResult("Invalid Email id", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].mobileNo == null || this.holderDetails[0].mobileNo.Trim() == "")
            {
                results.Add(new ValidationResult("Mobile no cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].kycStatus != true && this.holderDetails[0].kycStatus != false)
            {
                results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "firstHolderDetails" }));
            }


            if (this.modeOfHolding == 2)
            {
                if (this.holderDetails.Count > 1)
                {
                    if (this.holderDetails[1].category != 11 && this.holderDetails[1].category != 21)
                    {
                        results.Add(new ValidationResult("Invalid category selected.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].ifNri != 1 && this.holderDetails[1].ifNri != 2)
                    {
                        results.Add(new ValidationResult("Invalid IfNRI selected.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].occupation <= 0)
                    {
                        results.Add(new ValidationResult("Invalid Occupation selected.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].name == null || this.holderDetails[1].name.Trim() == "")
                    {
                        results.Add(new ValidationResult("First Holder Name cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].dob == null || this.holderDetails[1].dob.Trim() == "")
                    {
                        results.Add(new ValidationResult("Date of birth cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    else
                    {
                        if (ParamValid.DateValidate(this.holderDetails[1].dob.Trim(), "yyyy-MM-dd") == false)
                        {
                            results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "SecondHolderDetails" }));
                        }
                        else if (ParamValid.GetAge(this.holderDetails[1].dob) < 18)
                        {
                            results.Add(new ValidationResult("Date of birth should be greater then 18 year.", new List<string> { "SecondHolderDetails" }));
                        }
                    }
                    if (this.holderDetails[1].panNo == null || this.holderDetails[1].panNo.Trim() == "")
                    {
                        results.Add(new ValidationResult("Pan no cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    else
                    {
                        if (ParamValid.IsValidPanno(this.holderDetails[1].panNo) == false)
                        {
                            results.Add(new ValidationResult("Invalid Panno.", new List<string> { "SecondHolderDetails" }));
                        }
                    }
                    if (this.holderDetails[1].email == null || this.holderDetails[1].email.Trim() == "")
                    {
                        results.Add(new ValidationResult("Email cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    else if (ParamValid.IsValidEmail(this.holderDetails[1].email) == false)
                    {
                        results.Add(new ValidationResult("Invalid Email id", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].mobileNo == null || this.holderDetails[1].mobileNo.Trim() == "")
                    {
                        results.Add(new ValidationResult("Mobile no cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].kycStatus != true && this.holderDetails[1].kycStatus != false)
                    {
                        results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "SecondHolderDetails" }));
                    }
                }
                else
                {
                    results.Add(new ValidationResult("Second holder Details Compulsory incase of mode of holding is Joint.", new List<string> { "SecondHolderDetails" }));
                }
               
            }

            if (this.modeOfHolding == 2)
            {
                if (this.holderDetails.Count > 2)
                {
                    if (this.holderDetails[2].panNo != null && this.holderDetails[2].panNo.Trim() != "")
                    {

                        if (this.holderDetails[2].category != 11 && this.holderDetails[2].category != 21)
                        {
                            results.Add(new ValidationResult("Invalid category selected.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].ifNri != 1 && this.holderDetails[2].ifNri != 2)
                        {
                            results.Add(new ValidationResult("Invalid IfNRI selected.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].occupation <= 0)
                        {
                            results.Add(new ValidationResult("Invalid Occupation selected.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].name == null || this.holderDetails[2].name.Trim() == "")
                        {
                            results.Add(new ValidationResult("First Holder Name cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].dob == null || this.holderDetails[2].dob.Trim() == "")
                        {
                            results.Add(new ValidationResult("Date of birth cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        else
                        {
                            if (ParamValid.DateValidate(this.holderDetails[2].dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "ThirdHolderDetails" }));
                            }
                            else if (ParamValid.GetAge(this.holderDetails[2].dob) < 18)
                            {
                                results.Add(new ValidationResult("Date of birth should be greater then 18 year.", new List<string> { "ThirdHolderDetails" }));
                            }
                        }
                        if (this.holderDetails[2].panNo == null || this.holderDetails[2].panNo.Trim() == "")
                        {
                            results.Add(new ValidationResult("Pan no cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        else
                        {
                            if (ParamValid.IsValidPanno(this.holderDetails[2].panNo) == false)
                            {
                                results.Add(new ValidationResult("Invalid Panno.", new List<string> { "ThirdHolderDetails" }));
                            }
                        }
                        if (this.holderDetails[2].email == null || this.holderDetails[2].email.Trim() == "")
                        {
                            results.Add(new ValidationResult("Email cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        else if (ParamValid.IsValidEmail(this.holderDetails[2].email) == false)
                        {
                            results.Add(new ValidationResult("Invalid Email id", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].mobileNo == null || this.holderDetails[2].mobileNo.Trim() == "")
                        {
                            results.Add(new ValidationResult("Mobile no cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].kycStatus != true && this.holderDetails[2].kycStatus != false)
                        {
                            results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "ThirdHolderDetails" }));
                        }

                    }
                }
            }


        
            if (this.holderDetails.Count > 2)
            {
                if ((this.holderDetails[0].panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[0].panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("First and Second Holders Pan no cannot be Same."));
                    }
                }
                if ((this.holderDetails[0].panNo.Trim() != "" && this.holderDetails[2].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[0].panNo.Trim() == this.holderDetails[2].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("First and Third Holders Pan no cannot be Same."));
                    }
                }
                if ((this.holderDetails[1].panNo.Trim() != "" && this.holderDetails[2].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[1].panNo.Trim() == this.holderDetails[2].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("Second and Third Holders Pan no cannot be Same."));
                    }
                }
            }
            else if (this.holderDetails.Count > 1 )
            {
                if ((this.holderDetails[0].panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[0].panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("First and Second Holders Pan no cannot be Same."));
                    }
                }
            }

            if (this.firstHolderTaxStatus == 2)
            {
                if (this.holderDetails.Count > 2)
                {
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[0].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[0].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and First Holders Pan no cannot be Same."));
                        }
                    }
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and Second Holders Pan no cannot be Same."));
                        }
                    }
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[2].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[2].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and Third Holders Pan no cannot be Same."));
                        }
                    }
                }
                else if (this.holderDetails.Count > 1)
                {
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[0].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[0].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and First Holders Pan no cannot be Same."));
                        }
                    }
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and Second Holders Pan no cannot be Same."));
                        }
                    }
                }
            }
            return results;
        }
    }
    public class BasicDetails
    {
        /// <summary> Ex. 11 | 21   //Refer holderBasicDetails API  "category:categoryId" Key </summary>
        [DefaultValue(0)]
        public int category { get; set; }

        /// <summary> Ex. 1 | 2    //"Refer holderBasicDetails API  "nri:nriId" Key" </summary>
        [DefaultValue(0)]
        public int ifNri { get; set; }

        /// <summary> Ex. 1 | 2    //"Refer holderBasicDetails API  "occupation:occupationId" </summary>
        [DefaultValue(0)]
        public int occupation { get; set; }

        /// <summary> Ex. Mr. | Master | Miss | Mrs </summary>
        [DefaultValue("")]
        public string title { get; set; }

        /// <summary> Ex. John XXXX </summary>
        [DefaultValue("")]
        public string name { get; set; }

        /// <summary> Ex. 1990-01-01 </summary>
        [DefaultValue("")]
        public string dob { get; set; }

        /// <summary> Ex. XXXXX1234X </summary>
        [DefaultValue("")]
        public string panNo { get; set; }

        /// <summary> Ex. 12345678XXXX </summary>
        [DefaultValue("")]
        public string aadharNo { get; set; }

        /// <summary> Ex. abc@gmail.com </summary>
        [DefaultValue("")]
        public string email { get; set; }

        /// <summary> Ex. 1234567890 </summary>
        [DefaultValue("")]
        public string mobileNo { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string landlineNo { get; set; }

        /// <summary> false | true </summary>
        [DefaultValue(true)]
        public bool kycStatus { get; set; }

    }
    public class FirstHolderGurdian
    {
        /// <summary> Ex. John XXXX </summary>
        [DefaultValue("")]
        public string name { get; set; }

        /// <summary> Ex. XXXXX1234X </summary>
        [DefaultValue("")]
        public string panNo { get; set; }

        /// <summary> Ex. 12345678XXXX </summary>
        [DefaultValue("")]
        public string aadhar { get; set; }

        /// <summary> false | true </summary>
        [DefaultValue(true)]
        public bool kycStatus { get; set; }
    }

    //FatcaDetails
    public class ScreenNewInvestorFatchDetailsRes
    {
        //public Int64 userId { get; set; }
        public List<FatcaDetails> FatcaDetails { get; set; }
    }
    public class ScreenNewInvestorFatchDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        public List<FatcaDetails> fatcaDetails { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            //if (this.userId == 0)
            //{
            //    results.Add(new ValidationResult("Invalid userId.", new List<string> { nameof(userId) }));
            //}
            if (this.fatcaDetails[0].incomeSlab == 0 || this.fatcaDetails[0].incomeSlab > 6)
            {
                results.Add(new ValidationResult("Invalid incomeSlab.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].birthCountry == null || this.fatcaDetails[0].birthCountry.Trim() == "")
            {
                results.Add(new ValidationResult("Birth Country cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].nationality == null || this.fatcaDetails[0].nationality.Trim() == "")
            {
                results.Add(new ValidationResult("Nationality cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].taxResident == null || this.fatcaDetails[0].taxResident.Trim() == "")
            {
                results.Add(new ValidationResult("Tax Resident cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].taxResidentNonIndian == true)
            {
                if (this.fatcaDetails[0].foreignTaxId == null || this.fatcaDetails[0].foreignTaxId.Trim() == "")
                {
                    results.Add(new ValidationResult("ForignTaxId cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
                }
            }
            if (this.fatcaDetails[0].pep != true && this.fatcaDetails[0].pep != false)
            {
                results.Add(new ValidationResult("Invalid pep.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].relationalPep != true && this.fatcaDetails[0].relationalPep != false)
            {
                results.Add(new ValidationResult("Invalid Relation pep.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            return results;
        }

     }
    public class FatcaDetails 
    {
        /// <summary> Ex. 0 | 1 </summary>
        [DefaultValue(0)]
        public int incomeSlab { get; set; }

        /// <summary> Ex. INDIA </summary>
        [DefaultValue("")]
        public string birthCountry { get; set; }

        /// <summary> Ex. INDIA </summary>
        [DefaultValue("")]
        public string nationality { get; set; }

        /// <summary> Ex. false | true </summary>
        [DefaultValue(true)]
        public bool taxResidentNonIndian { get; set; }

        /// <summary> Ex. INDIA </summary>
        [DefaultValue("")]
        public string taxResident { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string foreignTaxId { get; set; }

        /// <summary> Ex. false </summary>
        [DefaultValue(false)]
        public bool pep { get; set; }  // Pep: Politcal exposed person

        /// <summary> Ex. false </summary>
        [DefaultValue(false)]
        public bool relationalPep { get; set; }
    }

    //ContactDetails
    public class ScreenNewInvestorContactDetailsRes
    {
        //public Int64 userId { get; set; }
        public List<ContactDetails> contactDetails { get; set; }
        public NRIContactDetails nriContact { get; set; }
    }
    public class ScreenNewInvestorContactDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        public List<ContactDetails> contactDetails { get; set; }
        public NRIContactDetails nriContact { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            //if (this.userId == 0)
            //{
            //    results.Add(new ValidationResult("Invalid userId.", new List<string> { nameof(userId) }));
            //}
            if (this.contactDetails[0].wing == null || this.contactDetails[0].wing.Trim() == "")
            {
                results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].area == null || this.contactDetails[0].area.Trim() == "")
            {
                results.Add(new ValidationResult("Area cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].state == null || this.contactDetails[0].state.Trim() == "")
            {
                results.Add(new ValidationResult("State cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].country == null || this.contactDetails[0].country.Trim() == "")
            {
                results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].pincode == 0)
            {
                results.Add(new ValidationResult("Invalid Pincode.", new List<string> { "FirstHolderContactDetails" }));
            }
            return results;
        }
    }
    public class ContactDetails
    {
        [DefaultValue("")]
        public string wing { get; set; }
        [DefaultValue("")]
        public string area { get; set; }
        [DefaultValue("")]
        public string landmark { get; set; }
        [DefaultValue("")]
        public string state { get; set; }
        [DefaultValue("")]
        public string city { get; set; }
        [DefaultValue("")]
        public string country { get; set; }
        [DefaultValue(0)]
        public int pincode { get; set; }
    }
    public class NRIContactDetails
    {
        /// <summary> Ex. "Bhandup" </summary>
        [DefaultValue("")]
        public string address1 { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string address2 { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string address3 { get; set; }

        /// <summary> Ex. "MUMBAI" </summary>
        [DefaultValue("")]
        public string city { get; set; }

        /// <summary> Ex. "INDIA" </summary>
        [DefaultValue("")]
        public string country { get; set; }

        /// <summary> Ex. "400014" </summary>
        [DefaultValue("")]
        public string zipcode { get; set; }
    }

    //NomineeDetails
    public class ScreenNewInvestorNomineeDetailsRes
    {
        //public Int64 userId { get; set; }
        public bool wishToNominate { get; set; }
        public List<NomineeDetails> nomineeDetails { get; set; }
      
    }
    public class ScreenNewInvestorNomineeDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }

        /// <summary> Ex. true | false </summary>
        [Required]
        [DefaultValue(false)]
        public bool wishToNominate { get; set; }
        public List<NomineeDetails> nomineeDetails { get; set; }

        /// <summary> Ex. true | false </summary>
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.wishToNominate == true)
            {
                if (this.nomineeDetails[0].name == null || this.nomineeDetails[0].name.Trim() == "" )
                {
                    results.Add(new ValidationResult("Name cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                }
                if (this.nomineeDetails[0].dob == null || this.nomineeDetails[0].dob.Trim() == "" )
                {
                    results.Add(new ValidationResult("Date of Birth cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                }
                else
                {
                    if (ParamValid.DateValidate(this.nomineeDetails[0].dob.Trim(), "yyyy-MM-dd") == false)
                    {
                        results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd.", new List<string> { "FirstNomineeDetails" }));
                    }
                    else if (ParamValid.GetAge(this.nomineeDetails[0].dob) < 18)
                    {
                        if (this.nomineeDetails[0].gurdianName == null || this.nomineeDetails[0].gurdianName.Trim() == "")
                        {
                            results.Add(new ValidationResult("First Nominee Gurdian name cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                        }
                        if (this.nomineeDetails[0].gurdianPanNo == null || this.nomineeDetails[0].gurdianPanNo.Trim() == "")
                        {
                            results.Add(new ValidationResult("First Nominee Gurdian Pan No cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                        }
                        else
                        {
                            if (ParamValid.IsValidPanno(this.nomineeDetails[0].gurdianPanNo) == false)
                            {
                                results.Add(new ValidationResult("Invalid Panno.", new List<string> { "FirstNomineeDetails" }));
                            }
                        }
                    }
                }
                if (this.nomineeDetails[0].percent == 0)
                {
                    results.Add(new ValidationResult("Percent should be greater then Zero.", new List<string> { "FirstNomineeDetails" }));
                }
                if (this.nomineeDetails[0].addresFlag != true && this.nomineeDetails[0].addresFlag != false)
                {
                    results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "SecondHolderDetails" }));
                }
                else
                {
                    if (this.nomineeDetails[0].addresFlag == false)
                    {
                        if (this.nomineeDetails[0].address1.Trim() == "" || this.nomineeDetails[0].address1 == null)
                        {
                            results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                        }
                    }
                }
                if (this.nomineeDetails[0].relationship == null || this.nomineeDetails[0].relationship.Trim() == "" )
                {
                    results.Add(new ValidationResult("Relationship cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                }

                if (this.nomineeDetails.Count == 2)
                {
                    if (this.nomineeDetails[1].percent > 0)
                    {
                        if (this.nomineeDetails[1].name == null || this.nomineeDetails[1].name.Trim() == "")
                        {
                            results.Add(new ValidationResult("Name cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                        }
                        if (this.nomineeDetails[1].dob == null || this.nomineeDetails[1].dob.Trim() == "")
                        {
                            results.Add(new ValidationResult("Date of Birth cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                        }
                        else
                        {
                            if (ParamValid.DateValidate(this.nomineeDetails[1].dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd.", new List<string> { "SecondNomineeDetails" }));
                            }
                            else if (ParamValid.GetAge(this.nomineeDetails[1].dob) < 18)
                            {
                                if (this.nomineeDetails[1].gurdianName == null || this.nomineeDetails[1].gurdianName.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Second Nominee Gurdian name cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                                }
                                if (this.nomineeDetails[1].gurdianPanNo == null || this.nomineeDetails[1].gurdianPanNo.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Second Nominee Gurdian Pan No cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                                }
                                else
                                {
                                    if (ParamValid.IsValidPanno(this.nomineeDetails[1].gurdianPanNo) == false)
                                    {
                                        results.Add(new ValidationResult("Invalid Panno.", new List<string> { "SecondNomineeDetails" }));
                                    }
                                }
                            }
                        }
                        if (this.nomineeDetails[1].percent == 0)
                        {
                            results.Add(new ValidationResult("Percent should be greater then Zero.", new List<string> { "SecondNomineeDetails" }));
                        }
                        if (this.nomineeDetails[1].addresFlag != true && this.nomineeDetails[1].addresFlag != false)
                        {
                            results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "SecondNomineeDetails" }));
                        }
                        else
                        {
                            if (this.nomineeDetails[1].addresFlag == false)
                            {
                                if (this.nomineeDetails[1].address1.Trim() == "" || this.nomineeDetails[1].address1 == null)
                                {
                                    results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                                }
                            }
                        }
                        if (this.nomineeDetails[1].relationship == null || this.nomineeDetails[1].relationship.Trim() == "")
                        {
                            results.Add(new ValidationResult("Relationship cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                        }
                    }
                }


                if (this.nomineeDetails.Count == 3)
                {
                    if (this.nomineeDetails[2].percent > 0)
                    {
                        if (this.nomineeDetails[2].name == null || this.nomineeDetails[2].name.Trim() == "")
                        {
                            results.Add(new ValidationResult("Name cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        if (this.nomineeDetails[2].dob == null || this.nomineeDetails[2].dob.Trim() == "")
                        {
                            results.Add(new ValidationResult("Date of Birth cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        else
                        {
                            if (ParamValid.DateValidate(this.nomineeDetails[2].dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd.", new List<string> { "ThirdNomineeDetails" }));
                            }
                            else if (ParamValid.GetAge(this.nomineeDetails[2].dob) < 18)
                            {
                                if (this.nomineeDetails[2].gurdianName == null || this.nomineeDetails[2].gurdianName.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Third Nominee Gurdian name cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                                }
                                if (this.nomineeDetails[1].gurdianPanNo == null || this.nomineeDetails[1].gurdianPanNo.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Third Nominee Gurdian Pan No cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                                }
                                else
                                {
                                    if (ParamValid.IsValidPanno(this.nomineeDetails[2].gurdianPanNo) == false)
                                    {
                                        results.Add(new ValidationResult("Invalid Panno.", new List<string> { "ThirdNomineeDetails" }));
                                    }
                                }
                            }
                        }
                        if (this.nomineeDetails[2].percent == 0)
                        {
                            results.Add(new ValidationResult("Percent should be greater then Zero.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        if (this.nomineeDetails[2].addresFlag != true && this.nomineeDetails[2].addresFlag != false)
                        {
                            results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        else
                        {
                            if (this.nomineeDetails[2].addresFlag == false)
                            {
                                if (this.nomineeDetails[2].address1.Trim() == "" || this.nomineeDetails[2].address1 == null)
                                {
                                    results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                                }
                            }
                        }
                        if (this.nomineeDetails[2].relationship == null || this.nomineeDetails[2].relationship.Trim() == "")
                        {
                            results.Add(new ValidationResult("Relationship cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                        }
                    }
                }





                if (this.nomineeDetails.Count > 2)
                {
                    if (this.nomineeDetails[0].percent + this.nomineeDetails[1].percent + this.nomineeDetails[2].percent != 100)
                    {
                        results.Add(new ValidationResult("Total  Percent should be 100%."));
                    }
                       
                }
                else if (this.nomineeDetails.Count > 1)
                {
                    if (this.nomineeDetails[0].percent + this.nomineeDetails[1].percent != 100)
                    {
                        results.Add(new ValidationResult("Total  Percent should be 100%."));
                    }
                }
                else if (this.nomineeDetails.Count == 1)
                {
                    if (this.nomineeDetails[0].percent  != 100)
                    {
                        results.Add(new ValidationResult("Total  Percent should be 100%."));
                    }
                }



            }
            return results;
        }
        }
    public class NomineeDetails
    {
        /// <summary> Ex. Mr. | Mrs. | Master | Miss </summary>
        [DefaultValue("")]
        public string title { get; set; }

        /// <summary> Ex. John XXXX </summary>
        [DefaultValue("")]
        public string name { get; set; }

        /// <summary> Ex. 1950-01-01 </summary>
        [DefaultValue("")]
        public string dob { get; set; }

        /// <summary> Ex. 100 </summary>
        [DefaultValue(0)]
        public decimal percent { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue(1)]
        public bool addresFlag { get; set; }

        /// <summary> Ex. "Bhandup" </summary>
        [DefaultValue("")]
        public string address1 { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string address2 { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string relationship { get; set; }

        /// <summary> Ex. Mr. | Mrs. | Master | Miss</summary>
        [DefaultValue("")]
        public string gurdianTitle { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string gurdianName { get; set; }

        /// <summary> Ex. XXXXX1234X </summary>
        [DefaultValue("")]
        public string gurdianPanNo { get; set; }

        /// <summary> Ex. true | false </summary>
        [DefaultValue(false)]
        public bool gurdianKycStatus { get; set; }
    }

    //SchemeDetails
    public class ScreenNewInvestorSchemeDetailsRes
    {
        //public Int64 userId { get; set; }
        public string transactionType { get; set; }
        public string schemeCode { get; set; }
        public string schemeName { get; set; }
        public string planCode { get; set; }
        public string optionCode { get; set; }
        public double investmentAmount { get; set; }
        public double schemeMinAmount { get; set; }
        public string planMode { get; set; }
        public string frequency { get; set; }
        public string deductionDate { get; set; }
        public string sipFromDate { get; set; }
        public string sipToDate { get; set; }
        public bool perpetual { get; set; }
        public int noOfInstalment { get; set; }
    }
    public class ScreenNewInvestorSchemeDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }

        /// <summary> Ex. Lumpsum | SIP </summary>
        [Required]
        [DefaultValue("")]
        public string transactionType { get; set; }

        /// <summary> Ex. DE | LT | HE </summary>
        [Required]
        [DefaultValue("")]
        public string schemeCode { get; set; }

        /// <summary> Ex. MOTILAL OSWAL DYNAMIC FUND | MOTILAL OSWAL LONG TERM EQUITY FUND </summary>
        [Required]
        [DefaultValue("")]
        public string schemeName { get; set; }

        /// <summary> Ex. DA | GD </summary>
        [Required]
        [DefaultValue("")]
        public string planCode { get; set; }

        /// <summary> Ex. G | D </summary>
        [Required]
        [DefaultValue("")]
        public string optionCode { get; set; }

        /// <summary> Ex. 500 </summary>
        [Required]
        [DefaultValue(0)]
        public double investmentAmount { get; set; }

        /// <summary> Ex. 500 </summary>
        [Required]
        [DefaultValue(0)]
        public double schemeMinAmount { get; set; }

        /// <summary> Ex. Direct </summary>
        [Required]
        [DefaultValue("")]
        public string planMode { get; set; }

        /// <summary> Ex. Weekly | Monthly </summary>
        [DefaultValue("")]
        public string frequency { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string deductionDate { get; set; }

        /// <summary> Ex. 2019-10-01 </summary>
        [DefaultValue("")]
        public string sipFromDate { get; set; }

        /// <summary> Ex. 2020-10-01 </summary>
        [DefaultValue("")]
        public string sipToDate { get; set; }

        /// <summary> Ex. false | true </summary>
        [DefaultValue(false)]
        public bool perpetual { get; set; }

        /// <summary> Ex. 12 </summary>
        [DefaultValue(0)]
        public int noOfInstalment { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.transactionType.ToUpper().Trim() != "LUMPSUM" && this.transactionType.ToUpper().Trim() != "SIP")
            {
                results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { "SchemeDetails" }));
            }
            if (this.schemeCode.ToUpper() == null && this.schemeCode.ToUpper().Trim() == "")
            {
                results.Add(new ValidationResult("Invalid scheme code", new List<string> { "SchemeDetails" }));
            }
            if (this.schemeName.ToUpper() == null && this.schemeName.ToUpper().Trim() == "")
            {
                results.Add(new ValidationResult("Invalid scheme Name", new List<string> { "SchemeDetails" }));
            }
            if (this.planCode.ToUpper() == null && this.planCode.ToUpper().Trim() == "")
            {
                results.Add(new ValidationResult("Invalid planCode", new List<string> { "SchemeDetails" }));
            }
            //if (this.investmentAmount < 500)
            //{
            //    results.Add(new ValidationResult("Investment amount should be greater min Amount", new List<string> { "SchemeDetails" }));
            //}
            if (this.planMode.ToUpper().Trim() != "DIRECT" && this.planMode.ToUpper().Trim() != "REGULAR")
            {
                results.Add(new ValidationResult("Invalid Plan mode", new List<string> { "SchemeDetails" }));
            }
            if (this.optionCode.ToUpper().Trim() != "G" && this.optionCode.ToUpper().Trim() != "D" && this.optionCode.ToUpper().Trim() != "R")
            {
                results.Add(new ValidationResult("Invalid Option code ", new List<string> { "SchemeDetails" }));
            }
            if (this.transactionType.ToUpper().Trim() == "SIP")
            {
                if (!string.IsNullOrEmpty(this.deductionDate))
                {
                    if (ParamValid.isNumeric(this.deductionDate) == false)
                    {
                        results.Add(new ValidationResult("Deduction Date should be numeric value", new List<string> { "SchemeDetails" }));
                    }
                    else if (Convert.ToInt32(this.deductionDate) < 1 && Convert.ToInt32(this.deductionDate) > 31)
                    {
                        results.Add(new ValidationResult("Deduction Date should be numeric value Range 1  to  28", new List<string> { "SchemeDetails" }));
                    }
                }
                else
                {
                    results.Add(new ValidationResult("Deduction Date Required", new List<string> { "SchemeDetails" }));
                }


                if (this.frequency.ToUpper().Trim() != "MONTHLY" && this.frequency.ToUpper().Trim() != "QUARTERLY" && this.frequency.ToUpper().Trim() != "YEARLY" && this.frequency.ToUpper().Trim() != "FORTNIGHTLY" && this.frequency.ToUpper().Trim() != "WEEKLY")
                {
                    results.Add(new ValidationResult("Invalid frequency", new List<string> { "SchemeDetails" }));
                }
                bool fromdate = true;
                bool toDate = true;
                // some other random test
                if (!string.IsNullOrEmpty(this.sipFromDate))
                {
                    if (ParamValid.DateValidate(this.sipFromDate.Trim(), "yyyy-MM-dd") == false)
                    {
                        results.Add(new ValidationResult("Fromdate must be in format : yyyy-MM-dd", new List<string> { "SchemeDetails" }));
                        fromdate = false;
                    }
                }
                else {
                    results.Add(new ValidationResult("Fromdate Required", new List<string> { "SchemeDetails" }));
                    fromdate = false;
                }

                if (!string.IsNullOrEmpty(this.sipToDate))
                {
                    if (ParamValid.DateValidate(this.sipToDate.Trim(), "yyyy-MM-dd") == false)
                    {
                        results.Add(new ValidationResult("Todate must be in format : yyyy-MM-dd", new List<string> { "SchemeDetails" }));
                        toDate = false;
                    }
                }
                else {
                    results.Add(new ValidationResult("ToDate Required", new List<string> { "SchemeDetails" }));
                    toDate = false;
                }

                if (fromdate == true && toDate == true)
                {
                    if (Convert.ToDateTime(this.sipFromDate) > Convert.ToDateTime(this.sipToDate))
                    {
                        results.Add(new ValidationResult("toDate must be larger than fromDate"));
                    }
                }
                if (this.perpetual != true && this.perpetual != false)
                {
                    results.Add(new ValidationResult("Invalid prepetual flag.", new List<string> { "SchemeDetails" }));
                }
                if (this.noOfInstalment == 0)
                {
                    results.Add(new ValidationResult("No of intallment should not be Zero.", new List<string> { "SchemeDetails" }));
                }
            }
           /* if(this.investmentAmount%100!=0)
            {
                results.Add(new ValidationResult("investmentAmount should be the multiple of 100.", new List<string> { "investmentAmount" }));
            }
            */

            return results;
        }
    }
    //BrokerDetails
    public class ScreenNewInvestorBrokerDetailsRes
    {
        //public Int64 userId { get; set; }
        public string brokerCode { get; set; }
        public string subBroker { get; set; }
        public string subBrokerCode { get; set; }
        public string declarationEUIN { get; set; }
        public string codeEUIN { get; set; }
    }
    public class ScreenNewInvestorBrokerDetails :  IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }

        /// <summary> Ex. ARN-00XX </summary>
        [Required]
        [DefaultValue("")]
        public string brokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string subBroker { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string subBrokerCode { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        [DefaultValue(false)]
        public bool declarationEUIN { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string codeEUIN { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.brokerCode.Trim() == "" && this.brokerCode == null)
            {
                results.Add(new ValidationResult("Broker Code cannot be blank.", new List<string> { "BrokerDetails" }));
            }
            if (this.declarationEUIN != true && this.declarationEUIN != false)
            {
                results.Add(new ValidationResult("Invalid EUIN Declaration flag.", new List<string> { "BrokerDetails" }));
            }
            if (this.declarationEUIN == false)
            {
                if (this.codeEUIN.Trim() == "" || this.codeEUIN == null)
                {
                    results.Add(new ValidationResult("Invalid EUIN code.", new List<string> { "BrokerDetails" }));
                }
            }
            return results;
        }

    }

    //BankDetails
    public class ScreenNewInvestorBankDetailsRes
    {
        //public Int64 userId { get; set; }
        public string ifscCode { get; set; }
        public string micrCode { get; set; }
        public string accountType { get; set; }
        public string bankName { get; set; }
        public string accountNo { get; set; }
        public string branchName { get; set; }
        public string branchAdd1 { get; set; }
        public string branchAdd2 { get; set; }
        public string branchAdd3 { get; set; }
        public string branchCity { get; set; }
        public string branchPincode { get; set; }
        public string paymentMode { get; set; }
        public byte[] chequeImage { get; set; }
        public string UTRNo { get; set; }
    }
    public class ScreenNewInvestorBankDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }

        /// <summary> Ex. hdfc0000001 </summary>
        [Required]
        [DefaultValue("")]
        public string ifscCode { get; set; }

        /// <summary> Ex. 400240003 </summary>
        [Required]
        [DefaultValue("")]
        public string micrCode { get; set; }

        /// <summary> Ex. SAV </summary>
        [Required]
        [DefaultValue("")]
        public string accountType { get; set; }

        /// <summary> Ex. HDFC BANK </summary>
        [Required]
        [DefaultValue("")]
        public string bankName { get; set; }

        /// <summary> Ex. 012345678902 </summary>
        [Required]
        [DefaultValue("")]
        public string accountNo { get; set; }

        /// <summary> Ex. Bhandup Branch </summary>
        [Required]
        [DefaultValue("")]
        public string branchName { get; set; }

        /// <summary> Ex. Bhandup </summary>
        [Required]
        [DefaultValue("")]
        public string branchAdd1 { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string branchAdd2 { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string branchAdd3 { get; set; }

        /// <summary> Ex. MUMBAI </summary>
        [Required]
        [DefaultValue("")]
        public string branchCity { get; set; }

        /// <summary> Ex. 400014 </summary>
        [Required]
        [DefaultValue(0)]
        public int branchPincode { get; set; }

        ///<summary> Ex. DCB | DC | UPI </summary>
        public string paymentMode { get; set; }

        /// <summary> Ex. "" </summary>
        public string chequeImage { get; set; }

        /// <summary> Ex. false | true </summary>
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string UTRNo { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.ifscCode.Trim() == "" && this.ifscCode == null)
            {
                results.Add(new ValidationResult("IFSC Code cannot be blank.", new List<string> { "BankDetails" }));
            }
            //if (this.micrCode.Trim() == "" && this.micrCode == null)
            //{
            //    results.Add(new ValidationResult("MICR Code cannot be blank.", new List<string> { "BankDetails" }));
            //}
            if (this.accountType.ToUpper().Trim() != "CUR" && this.accountType.ToUpper().Trim() != "SAV" && this.accountType.ToUpper().Trim() != "FCN" && this.accountType.ToUpper().Trim() != "NRE" && this.accountType.ToUpper().Trim() != "NRO")
            {
                results.Add(new ValidationResult("Invalid Account Type", new List<string> { "BankDetails" }));
            }
            if (this.bankName.Trim() == "" && this.bankName == null)
            {
                results.Add(new ValidationResult("Bank Name cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.accountNo.Trim() == "" && this.accountNo == null)
            {
                results.Add(new ValidationResult("Account No cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.branchName.Trim() == "" && this.branchName == null)
            {
                results.Add(new ValidationResult("Branch Name cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.branchAdd1.Trim() == "" && this.branchAdd1 == null)
            {
                results.Add(new ValidationResult("Branch Address cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.branchCity.Trim() == "" && this.branchCity == null)
            {
                results.Add(new ValidationResult("Branch City cannot be blank.", new List<string> { "BankDetails" }));
            }
            //if (this.branchPincode == 0 && this.branchPincode == null)
            //{
            //    results.Add(new ValidationResult("Branch City cannot be blank.", new List<string> { "BankDetails" })); 
            //}
            return results;
        }
        }
     

    public class FinalSubmit : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }

        /// <summary> Ex. true | false </summary>
        [Required]
        [DefaultValue(false)]
        public bool undertaking { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.undertaking != true)
            {
                results.Add(new ValidationResult("UnderTaking is mandatory.", new List<string> { "FinalSubmit" }));
            }
            return results;
        }
    }
    public class FinalSubmitRes
    {
        public string timeStamp { get; set; }
        public string ihno { get; set; }
        public string appRefNo { get; set; }
        public string transactionRefNo { get; set; }
        public string batchNo {get;set;}
        public string errorNo { get; set; }
        public string scheme { get; set; }
        public double transactionAmount { get; set; }
        public string urnNo { get; set; }
        public string urnExpiryDate { get; set; }
        public string noOfInstallment { get; set; }
        public string paymentURL { get; set; }
    }


    public class PaymentConfirmation
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        [Required]
        public string timeStamp { get; set; }
        [Required]
        public string IHNO { get; set; }
        [Required]
        public string transactionRefno { get; set; }
        [Required]
        public string batchNo { get; set; }
        public string errorNo { get; set; }
        public string urnNo { get; set; }
        public string paymentURL { get; set; }
    }
    public class InvestorDetReq
    {
        public int userId { get; set; }
    }

    public class InvestorDetRes
    {

    }
    public class karvySubmit
    {
        public string Adminusername { get; set; }      //M
        public string Adminpassword { get; set; }        //M
        public string Scheme { get; set; }      //M
        public string Plan { get; set; }        //M
        public string Option { get; set; }      //M
        public string NAVDate { get; set; }
        public string Branch { get; set; }      //M
        public string DistributorID { get; set; }
        public string SubBrokerCode { get; set; }
        public string AccNo { get; set; }       //M
        public string AppNo { get; set; }
        public string TrType { get; set; }      //M
        public double Amount  { get; set; }   //M
        public string InvName { get; set; } //M
        public string FEMail { get; set; }  //M
        public string FMobileNo { get; set; }   //M
        public string PaymentMode { get; set; }
        public string Category { get; set; }    //M
        public string ChqNo { get; set; }   //M
        public string ChqBank { get; set; } //M
        public string ChqType { get; set; } //M
        public string purred { get; set; }
        public long ihno { get; set; }//M
        public string TransferFlag { get; set; }    //M
        public string Active { get; set; }  //M
        public string CutOffTime { get; set; }
        public string PAN1 { get; set; }    //M
        public string BankAccNo { get; set; }   //M
        public string PAN2 { get; set; }
        public string PAN3 { get; set; }
        public string BankAccType { get; set; } //M
        public string BankAddress1 { get; set; }    //M
        public string BankAddress2 { get; set; }    //M
        public string BankAddress3 { get; set; }    //M
        public string BankCity { get; set; }    //M
        public string BankPIN { get; set; } //M
        public string MACID { get; set; }
        public string InvAdd1 { get; set; } //M
        public string InvAdd2 { get; set; } //M
        public string InvAdd3 { get; set; }
        public string InvCity { get; set; } //M
        public string InvsState { get; set; }   //M
        public string InvPIN { get; set; }  //M
        public string SecondInvName { get; set; }   //	
        public string ThirdInvName { get; set; }
        public string NomineeName { get; set; }
        public string MOH { get; set; } //M
        public string Occupation { get; set; }  //M
        public string SecondInvOccupation { get; set; }
        public string ThirdInvOccupation { get; set; }
        public string Status { get; set; }  //M
        public string InvPhone1 { get; set; }   //M
        public string InvCountry { get; set; }  //M
        public string Salutation { get; set; }
        public string InvDOB { get; set; } // M
        public string InvPhone2 { get; set; }
        public string SecondInvDOB { get; set; }
        public string ThirdInvDOB { get; set; }
        public string GuardianDOB { get; set; }
        public string NomRelation { get; set; }
        public string NomDOB { get; set; }
        public string NomAddress1 { get; set; }
        public string NomAddress2 { get; set; }
        public string NomAddress3 { get; set; }
        public string NomCity { get; set; }
        public string NomState { get; set; }
        public string NomPIN { get; set; }
        public string NRIAddress1 { get; set; }
        public string NRIAddress2 { get; set; }
        public string NRIAddress3 { get; set; }
        public string NRICity { get; set; }
        public string NRIState { get; set; }
        public string NRICountry { get; set; }
        public string NRIPIN { get; set; }
        public string Options { get; set; }
        public string SecondInvEMail { get; set; }
        public string ThirdInvEMail { get; set; }
        public string SecondInvMobile { get; set; }
        public string ThirdInvMobile { get; set; }
        public string MICRCode { get; set; }
        public string IFSCCode { get; set; }
        public string GuardianPAN { get; set; }
        public string GuardianRelation { get; set; }
        public string NomGuardianPAN { get; set; }
        public string SecurityCode { get; set; }    //M
        public string NomGuardianName { get; set; }
        public string SecondInvSalutation { get; set; }
        public string ThirdInvSalutation { get; set; }
        public string Income { get; set; }  //M
        public string SourceInfo { get; set; }
        public string GuardianName { get; set; }
        public string BankBranch { get; set; }  //M
        public string ChqDate { get; set; }
        public string ReqID { get; set; }
        public string DPID { get; set; }
        public string ClientID { get; set; }
        public string AllotmentMode { get; set; }
        public string EUINNo { get; set; }
        public string EUINFlag { get; set; }
        public string EUINOpt { get; set; }
        public string EUINSubARNCode { get; set; }
        public string MOCode { get; set; }
        public string FCountryOfBirth { get; set; }
        public string FNationality { get; set; }
        public string FTaxResident { get; set; }
        public string FForeignTaxID { get; set; }
        public string SAnnualIncome { get; set; }
        public string SCountryOfBirth { get; set; }
        public string SNationality { get; set; }
        public string STaxResident { get; set; }
        public string SForeignTaxID { get; set; }
        public string TAnnualIncome { get; set; }
        public string TCountryOfBirth { get; set; }
        public string TNationality { get; set; }
        public string TTaxResident { get; set; }
        public string TForeignTaxID { get; set; }
        public string GAnnualIncome { get; set; }
        public string GCountryOfBirth { get; set; }
        public string GNationality { get; set; }
        public string GTaxResident { get; set; }
        public string GForeignTaxID { get; set; }
        public string FPoliticallyExposed { get; set; }
        public string FRelatedToPoliticallyExposed { get; set; }
        public string SPoliticallyExposed { get; set; }
        public string SRelatedToPoliticallyExposed { get; set; }
        public string TPoliticallyExposed { get; set; }
        public string TRelatedToPoliticallyExposed { get; set; }
        public string GPoliticallyExposed { get; set; }
        public string GRelatedToPoliticallyExposed { get; set; }
        public string FGender { get; set; }
        public string SGender { get; set; }
        public string TGender { get; set; }
        public string GGender { get; set; }
        public string FFather { get; set; }
        public string SFather { get; set; }
        public string TFather { get; set; }
        public string GFather { get; set; }
        public string FCOB { get; set; }
        public string SCOB { get; set; }
        public string TCOB { get; set; }
        public string GCOB { get; set; }
        public string FKRA { get; set; }
        public string SKRA { get; set; }
        public string TKRA { get; set; }
        public string GKRA { get; set; }
        public string AADHAR { get; set; } //m
        public string Frequency { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string URNNo { get; set; }
        public string SIPRemarks { get; set; }
        public string SweepScheme { get; set; }
        public string SweepPlan { get; set; }
        public string SweepOption { get; set; }
        public string jt1aadhaaruid { get; set; }
        public string jt2aadhaaruid { get; set; }
        public string ckycrefno1 { get; set; }
        public string ckycrefno2 { get; set; }
        public string ckycrefno3 { get; set; }
        public string ckycrefnog { get; set; }
        public string noofinst { get; set; }
        public int RefNo { get; set; }
        public int BatchNo { get; set; }
        public int ErrNo { get; set; }
        public byte[] CancelledCheque { get; set; }
        public string UTRNo { get; set; }
    }
}
