﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class Redemption
    {

    }

    public class RedemptionValidReq
    {
        ///<summary>DE</summary>
        [DefaultValue("")]
        public string scheme { get; set; }
        ///<summary>DA</summary>
        [DefaultValue("")]
        public string plan { get; set; }
        ///<summary>PUR</summary>
        [DefaultValue("")]
        public string trType { get; set; }
        [DefaultValue("")]
        public string timeStamp { get; set; }
    }

    public class RedemptionValidRes
    {
        public string category { get; set; }
        public string cuttime { get; set; }
    }

    public class RedemptionTraReq
    {
        /// <summary> Ex. 91011673385 </summary>
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
        public string folio { get; set; }

        /// <summary> Ex. 127CPGDG</summary>
        [Required]
        public string moSchemeCode { get; set; }


        /// <summary> Ex. U | A (U - units/ A- Amounts)</summary>
        [Required(ErrorMessage ="Please provide unit/amount flag")]
        public string untamtflg { get;set; }

        /// <summary> Ex. 5000 </summary>
        [Required]
        public double amount { get; set; }

        /// <summary> Ex. P | F (P - Partial/ F- Full)</summary>
        public string redeemType { get; set; }

        /// <summary> Ex. HDFC BANK</summary>
        [Required]
        public string bankName { get; set; }

        /// <summary> Ex. 12345678891 </summary>
        [Required]
        public string bankAccNo { get; set; }
    }


    public class RedemptionTraRes
    {
        public string units { get; set; }
        public string refno { get; set; }
        public double amount { get; set; }
    }
    public class ReduceRedemptionrequest
    {
        ///<summary> Ex. 91011673385 </summary>
        public string folioNo { get; set; }

        ///<summary> Ex. 127HEGDG </summary>
        public string moslCode { get; set; }
    }
    public class ReduceRedemptionRes
    {
        public string header { get; set; }
        public string footer { get; set; }
        public List<ReduceRedemTable> table { get; set; }
    }
    public class ReduceRedemTable
    {
        public string date { get; set; }
        public string year { get; set; }
        public double amount { get; set; }
    }
}

