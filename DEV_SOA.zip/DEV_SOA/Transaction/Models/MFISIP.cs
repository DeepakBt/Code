﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Model;

namespace Transaction.Models
{
    public class MFISIP
    {

    }
    public class ISIPdetailReq : IValidatableObject
    {
        ///  <summary> Ex. 91011673385  </summary> 
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
        public string folioNo { get; set; }

        /// <summary> Ex. "127CPGDG"  //Refer Postlogin:panwiseScheme:schemeCode  API  "schemeCode" Key" </summary>
        [Required]
        public string schemeCode { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.schemeCode.Length < 8)
            {
                results.Add(new ValidationResult("Invalid Scheme Code", new List<string> { nameof(schemeCode) }));
            }
            return results;
        }
    }

    public class ISIPdetailRes
    {
        public string referenceNumber { get; set; }
        public string urnNumber { get; set; }
        public string schemeCode { get; set; }
        public string schemeDescription { get; set; }
        public string accountType { get; set; }
        public string urnStatus { get; set; }
        public string registrationDate { get; set; }
        public string frequency { get; set; }
        public double amount { get; set; }
        public string fromDate { get; set; }
        public string endDate { get; set; }
        public string withEffectDate { get; set; }
    }

    public class ISIPTransReq
    {
        [Required(ErrorMessage = "Please input folio number.")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only.")]
        public string folioNo { get; set; }
        public string referenceNo { get; set; }
        public string enddt { get; set; }
        
    }

    public class ISIPTransRes
    {
        public string ihno { get; set; }
        public string time_stamp { get; set; }
    }

    public class MFISIPFrequencyReq
    {
        [Required(ErrorMessage = "Please input SchemeID.")]
        public string SchemeID { get; set; }
        public string Frequency { get; set; }
        [Required(ErrorMessage = "Please TrType")]
        public string TrType { get; set; }
    }


    public class MFISIPFrequencyRes
    {
        public string TrType { get; set; }
        public string Frequency { get; set; }
        public decimal MinAmount { get; set; }
        public int MinNoOfInstalments { get; set; }
        public string SchemeID { get; set; }
        public decimal AmountMultiplier { get; set; }
    }

}
