﻿using ApiCore.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Model;
namespace Transaction.Models
{
    public class StrategylistRes
    {
        public string pmsCode { get; set; }
        public string strategyName { get; set; }
        public double minTopupAmt { get; set; }
        public double minSipAmt { get; set; }
    }

    public class Strategylist
    {
        /// <summary> Ex. NEW | EXISTING </summary>
        [Required]
        [DefaultValue("New|Existing")]
        public string typeofTrans { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (this.typeofTrans.ToUpper().Trim() != "NEW" && this.typeofTrans.ToUpper().Trim() != "EXISTING")
            {
                results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { nameof(typeofTrans) }));
            }
            return results;
        }
    }

    public class BankAndDistri :IValidatableObject
    {
        /// <summary> Incase of  NEW investment "" else Refer strategyList API  "pmsCode" Key </summary>
        public string strategyCode { get; set; }

        /// <summary> Incase of  NEW investment "" else TOPUP | SIP  </summary>
        public string transactionType { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            if (!string.IsNullOrEmpty(this.transactionType))
            {
                if (this.transactionType.ToUpper().Trim() != "TOPUP" && this.transactionType.ToUpper().Trim() != "SIP")
                {
                    results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { nameof(transactionType) }));
                }
            }
            return results;
        }
    }

    public class BankAndDistriRes
    {
        public string distributorName { get; set; }
        public double currentValue { get; set; }
        public double netInvestment { get; set; }
        public List<BankDetails> bankDetails { get; set; }
    }

    public class BankDetails
    {
        public string bankShortname { get; set; }
        public string bankname { get; set; }
        public string bankAccNumber { get; set; }
        public bool bankEligibilityStatus { get; set; }
    }

    public class SavePMSSIPRes
    {
        public string pmsCode { get; set; }
        public string transactionRefrenceNumber { get; set; }
        public string urnNumber { get; set; }
        public string urnExpiryDate { get; set; }
    }

    public class SavePMSSIP : IValidatableObject
    {
        /// <summary> "PMSCode Required in case of typeOfTransaction is Existing else blank" </summary>
        [DefaultValue("PMSCode Required in case of typeOfTransaction is Existing else blank")]
        public string pmsCode { get; set; }
        /// <summary> "New|Existing"" </summary>
        [Required]
        [DefaultValue("New|Existing")]
        public string typeofTrans { get; set; }
        [Required]
        public double sipAmount { get; set; }
        [Required]
        public int deductionDate { get; set; }
        /// <summary> "Monthly|Quarterly|Yearly" </summary>
        [Required]
        [DefaultValue("Monthly|Quarterly|Yearly|Fortnightly")]
        public string frequency { get; set; }
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string fromDate { get; set; }
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string toDate { get; set; }
        [Required]
        public int noOfInstament { get; set; }
        [Required]
        public int perpetual { get; set; }
        [Required]
        public string bankAccNo { get; set; }
        [Required]
        public string investorRegBank { get; set; }
        [Required]
        public string strategyName { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
            {
                results.Add(new ValidationResult("toDate must be greater than fromDate"));
            }

            if (this.typeofTrans.ToUpper().Trim() != "NEW" && this.typeofTrans.ToUpper().Trim() != "EXISTING")
            {
                results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { nameof(typeofTrans) }));
            }
            else
            {
                if (this.typeofTrans.ToUpper().Trim() == "EXISTING" && (this.pmsCode.Trim() == "" || this.pmsCode == null))
                {
                    results.Add(new ValidationResult("PMSCode Required in case of Existing", new List<string> { nameof(pmsCode) }));
                }
            }
            return results;
        }
    }

    public class SavePMSTopupRes
    {
        public string pmsCode { get; set; }
        public string transactionRefrenceNumber { get; set; }
        public DateTime requestRaiseDate { get; set; }
        public double transactionAmount { get; set; }
        public string typeOfTransaction { get; set; }
        public string orderNo { get; set; }
        public string strategyName { get; set; }
        public string strategyCode { get; set; }
        public string emailId { get; set; }
        public string phoneNo { get; set; }
        public string referelURL { get; set; }
        public string checksum { get; set; }
        public string timeStamp { get; set; }
    }
    public class SavePMSTopupResBillDesk
    {
        public string parentID { get; set; }
        public string totalAmount { get; set; }
        public string referelURL { get; set; }
        public string ExceptionMsg { get; set; }
        public List<PMSInevestment> pmsInvestmentDetails{ get; set; }

    }
    public class PMSInevestment
    {
        public string DistributorName { get; set; }
        public string PMSCode { get; set; }
        public string childOrderID { get; set; }
       
        public string Amount { get; set; }
    }

        public class SavePMSTopup : IValidatableObject
    {
        /// <summary> "PMSCode Required in case of typeOfTransaction is Existing else blank" </summary>
        [DefaultValue("PMSCode Required in case of typeOfTransaction is Existing else blank")]
        public string pmsCode { get; set; }
        [Required]
        public string strategyName { get; set; }
        [Required]
        public string bankShortName { get; set; }
        [Required]
        public double transactionAmount { get; set; }
        /// <summary> "New|Existing"" </summary>
        [Required]
        [DefaultValue("New|Existing")]
        public string typeOfTransaction { get; set; }
        [Required]
        public string bankFullName { get; set; }
        [Required]
        public string bankAccNumber { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            ParamValid ParamValid = new ParamValid();
            if (this.typeOfTransaction.ToUpper().Trim() != "NEW" && this.typeOfTransaction.ToUpper().Trim() != "EXISTING")
            {
                results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { nameof(typeOfTransaction) }));
            }
            else
            {
                if (this.typeOfTransaction.ToUpper().Trim() == "EXISTING" && (this.pmsCode.Trim() == "" || this.pmsCode == null))
                {
                    results.Add(new ValidationResult("PMSCode Required in case of Existing", new List<string> { nameof(pmsCode) }));
                }
               
            }
            if ( ParamValid.isNumeric(Convert.ToString(this.transactionAmount)) == false )
            {
                results.Add(new ValidationResult("Invalid Transaction Amount", new List<string> { nameof(typeOfTransaction) }));
            }
            //else if (Convert.ToDouble(this.transactionAmount) < 100000)
            //{
            //    results.Add(new ValidationResult("Minimum Transaction amount is  lakh ", new List<string> { nameof(transactionAmount) }));
            //}
            else if (this.typeOfTransaction.ToUpper().Trim() == "EXISTING" && (this.transactionAmount < 200000))
            {
                results.Add(new ValidationResult("Minimum Transaction amount is  2 lakh in case of Existing client", new List<string> { nameof(transactionAmount) }));
            }
            else if (this.typeOfTransaction.ToUpper().Trim() == "NEW" && (this.transactionAmount < 500000))
            {
                results.Add(new ValidationResult("Minimum Transaction amount is  5 lakh in case of New client", new List<string> { nameof(transactionAmount) }));
            }
            return results;
        }
    }
    public class TransactionRequestConsolidate:IValidatableObject
    {
        [Required]
        public string PurchaseDate { get; set; }
        [Required]
        public string PaymentMode { get; set; }
        [Required]
        public string TotalInvestAMount { get; set; }
        
        public string PG { get; set; }
        [Required]
        public string BankAccountNo { get; set; }
        /// <summary> "New|Existing"" </summary>
        [Required]
        [DefaultValue("New|Existing")]
        public string TrType { get; set; }
        [Required]
        public string InvestorRegBank { get; set; }
        [Required]
        public string BankId { get; set; }
        public List<PMSInvestmentDetail> PMSInvestmentDetails { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            ParamValid ParamValid = new ParamValid();
            var TotalAmount = 0.00;
            for (int i = 0; i < this.PMSInvestmentDetails.Count(); i++)
            {
                if (this.TrType.ToUpper().Trim() != "NEW" && this.TrType.ToUpper().Trim() != "EXISTING")
                {
                    results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { nameof(TrType) }));
                }
                else
                {
                    if (this.TrType.ToUpper().Trim() == "EXISTING" && (this.PMSInvestmentDetails[i].PMSCode == "" || this.PMSInvestmentDetails[i].PMSCode == null))
                    {
                        results.Add(new ValidationResult("PMSCode:PMSCode Required in case of Existing", new List<string> { nameof(PMSInvestmentDetails) }));
                    }
                    else if(this.TrType.ToUpper().Trim() == "NEW" && (this.PMSInvestmentDetails[i].PMSCode != "" && this.PMSInvestmentDetails[i].PMSCode != null))
                    {
                        results.Add(new ValidationResult("PMSCode:PMSCode Not Required in case of New", new List<string> { nameof(PMSInvestmentDetails) }));
                    }

                }
                if (ParamValid.isNumeric(Convert.ToString(this.PMSInvestmentDetails[i].Amount)) == false)
                {
                    results.Add(new ValidationResult("Amount:Invalid Transaction Amount", new List<string> { nameof(PMSInvestmentDetails) }));
                }
                //else if (Convert.ToDouble(this.transactionAmount) < 100000)
                //{
                //    results.Add(new ValidationResult("Minimum Transaction amount is  lakh ", new List<string> { nameof(transactionAmount) }));
                //}
                else if (this.TrType.ToUpper().Trim() == "EXISTING" && (this.PMSInvestmentDetails[i].Amount < 200000))
                {
                    results.Add(new ValidationResult("Amount:Minimum Transaction amount is  2 lakh in case of Existing client", new List<string> { nameof(PMSInvestmentDetails) }));
                }
                else if (this.TrType.ToUpper().Trim() == "NEW" && (this.PMSInvestmentDetails[i].Amount < 500000))
                {
                    results.Add(new ValidationResult("Amount:Minimum Transaction amount is  5 lakh in case of New client", new List<string> { nameof(PMSInvestmentDetails) }));
                }
                TotalAmount = TotalAmount + this.PMSInvestmentDetails[i].Amount;
                if (i == this.PMSInvestmentDetails.Count() - 1 && TotalAmount<Convert.ToDouble(this.TotalInvestAMount))
                {
                    results.Add(new ValidationResult("Total Investment Amount Should be Equal to the sum of particular Amount", new List<string> { nameof(TotalInvestAMount) }));
                }

            }
            return results;
        }



    }
    public class PMSInvestmentDetail
    {
        [Required]
        public string DistributorName { get; set; }
        [DefaultValue("PMSCode Required in case of typeOfTransaction is Existing else blank")]
        public string PMSCode { get; set; }
        [Required]
        public string StrategyName { get; set; }
       [Required]
        public double Amount { get; set; }
    }
    public class TransactionReqResponse
    {
        public TransactionRequestConsolidate _TransactionRequest { get; set; }

    }

        public class FeeStructureRes
    {
        public string url { get; set; }
    }

    public class PaymentConfirmationRes
    {
        public string pmsCode { get; set; }
        public string strategyName { get; set; }
        public string transactionRefrenceNumber { get; set; }
        public double transactionAmount { get; set; }
    }


    public class PaymentConfirm
    {
        [Required]
        public Int64 transactionNo { get; set; }
        /// <summary> "MOTILALOAM" </summary>
        [Required]
        [DefaultValue("")]
        public string merchantId { get; set; }
        /// <summary> "GHDF4558070213" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionReferenceNo { get; set; }
        [Required]
        [DefaultValue("")]
        public string bankRef { get; set; }
        /// <summary> "Minimum Amount 1 lakh" </summary>
        [Required]
        [DefaultValue(0)]
        public double transactionAmount { get; set; }
        /// <summary> "Bank Short name" </summary>
        [Required]
        [DefaultValue("")]
        public string bankId { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string bankMerchantId { get; set; }
        /// <summary> "01" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionType { get; set; }
        /// <summary> "INR" </summary>
        [Required]
        [DefaultValue("")]
        public string currency { get; set; }
        [Required]
        [DefaultValue("")]
        public string itemCode { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityType { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityPassword { get; set; }
        [Required]
        [DefaultValue("")]
        public string transactionDate { get; set; }
        /// <summary> "0300: success" </summary>
        [DefaultValue("")]
        public string authStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string settlementType { get; set; }
        /// <summary> "PMSCODE" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info1 { get; set; }
        [Required]
        [DefaultValue("")]
        public string additional_Info2 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info3 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info4 { get; set; }
        /// <summary> "NONLIQUID" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info5 { get; set; }
        /// <summary> "logic for generating Code-(RESIDENT-VAL-NA-L-NA-NA)" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info6 { get; set; }
        /// <summary> "Date Time in String " </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info7 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string erroStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string errorDescription { get; set; }
        [Required]
        [DefaultValue("")]
        public string checkSum { get; set; }
    }
    public class PaymentConfirmReq
    {
        [Required]
        public Int64 ParentId { get; set; }
        /// <summary> "MOTILALOAM" </summary>
        [Required]
        [DefaultValue("")]
        public string merchantId { get; set; }
        /// <summary> "GHDF4558070213" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionReferenceNo { get; set; }
        [Required]
        [DefaultValue("")]
        public string bankRef { get; set; }
        /// <summary> "Minimum Amount 1 lakh" </summary>
        [Required]
        [DefaultValue(0)]
        public double transactionAmount { get; set; }
        /// <summary> "Bank Short name" </summary>
        [Required]
        [DefaultValue("")]
        public string bankId { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string bankMerchantId { get; set; }
        /// <summary> "01" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionType { get; set; }
        /// <summary> "INR" </summary>
        [Required]
        [DefaultValue("")]
        public string currency { get; set; }
        [Required]
        [DefaultValue("")]
        public string itemCode { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityType { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityPassword { get; set; }
        [Required]
        [DefaultValue("")]
        public string transactionDate { get; set; }
        /// <summary> "0300: success" </summary>
        [DefaultValue("")]
        public string authStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string settlementType { get; set; }
        /// <summary> "PMSCODE" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info1 { get; set; }
        [Required]
        [DefaultValue("")]
        public string additional_Info2 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info3 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info4 { get; set; }
        /// <summary> "NONLIQUID" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info5 { get; set; }
        /// <summary> "logic for generating Code-(RESIDENT-VAL-NA-L-NA-NA)" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info6 { get; set; }
        /// <summary> "Date Time in String " </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info7 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string erroStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string errorDescription { get; set; }
        [Required]
        [DefaultValue("")]
        public string checkSum { get; set; }
    }
    public class PaymentConfirmationResponse
    { 
        public string ParentId { get; set; }
        public string pmsCode { get; set; } 
        public string strategyName { get; set; } 
        public string transactionRefrenceNumber { get; set; } 
        public double transactionAmount { get; set; }
        public string ErrorMessage { get; set; }

    }

}
