﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class PinCode
    {
       
    }

    public class ReqPinCode
    {
        /// <summary> Ex. 400014 </summary>
        public int pinCode { get; set; }
    }
    public class ResPinCode
    {
        public string state { get; set; }
        public string city { get; set; }
    }
}
