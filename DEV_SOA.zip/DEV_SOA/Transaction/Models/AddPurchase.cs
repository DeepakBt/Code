﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ApiCore.Model;

namespace Transaction.Models
{
    public class AddPurchaseReq : IValidatableObject
    {
        /// <summary> Ex. 91011673385  </summary>///
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
        public string folioNo { get; set; }

        /// <summary> Ex. HE</summary>
        [Required]
        [StringLength(2)]
        public string schemeName { get; set; }

        /// <summary> Ex. GD </summary>
        [Required]
        [StringLength(2)]
        public string plan { get; set; }

        /// <summary> Ex. G </summary>
        [Required]
        [StringLength(1)]
        public string option { get; set; }

        /// <summary> Ex. 500 </summary>
        [Required]
        public double amount { get; set; }

        //[RegularExpression("^ARN-.*", ErrorMessage = "Please input valid broker code")]
        /// <summary> Ex. ARN-0018 </summary>
        public string brokerCode { get; set; }

        /// <summary> Ex. ""</summary>
        public string subBroker { get; set; }

        /// <summary> Ex. "" </summary>
        public string subBrokerCode { get; set; }

        /// <summary> Ex. false </summary>
        [DefaultValue(false)]
        public Boolean euinDeclarationFlag { get; set; }

        /// <summary> Ex. E123456 </summary>
        public string euinCode { get; set; }

        ///<summary> Ex. DCB | DC | UPI </summary>
        [Required]
        public string paymentMode { get; set; }

        /// <summary> Ex. HDFC BANK </summary>
        [Required]
        public string bankName { get; set; }
        /// <summary> Ex. 50100080084XXX </summary>
        [Required]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed in bankAccNo field.")]
        public string bankAccNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string UTRNo { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();     
            if (this.paymentMode.ToUpper() != "DCB" && this.paymentMode.ToUpper() != "DC" && this.paymentMode.ToUpper() != "UPI" && this.paymentMode.ToUpper() != "RTGS")
            {
                results.Add(new ValidationResult("Invalid PaymentMode.", new List<string> { "AddPurchaseRes" }));
            }
            if (!string.IsNullOrEmpty(brokerCode))
            {
                if (!Regex.IsMatch(brokerCode, "^ARN-.*") && !Regex.IsMatch(brokerCode, "^IN.*") && !Regex.IsMatch(brokerCode, "^000000.*"))
                {
                    results.Add(new ValidationResult("Please input valid broker code", new List<string> { "AddPurchaseRes" }));

                }
                if (this.euinDeclarationFlag == false)
                {
                    if (this.euinCode.Trim() == "" || this.euinCode == null)
                    {
                        results.Add(new ValidationResult("Invalid EUIN code.", new List<string> { "AddPurchaseRes" }));
                    }
                }
            }
            /*if(this.amount % 100!=0)
            {
                results.Add(new ValidationResult("Amount should be the multiple of 100.", new List<string> { "Amount" }));
            }*/
            return results;
        }
    }


    public class AddPurchaseRes
    {
        public string timeStamp { get; set; }
        public string appRefNo { get; set; }
        public string billDeskUrl { get; set; }
        public double amount { get; set; }
        public string schemeName { get; set; }
        public int purchaseId { get; set; }
    }
    public class distributorListReq : IValidatableObject
    {
        /// <summary> Ex. 91011673385 </summary>
        public Int64? folioNo { get; set; }

        ///<summary> Ex. D | R </summary>
        [DefaultValue("")]
        public string planType { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.planType != null && Convert.ToString(this.planType) != "")
            {
                if (this.planType.ToUpper().Trim() != "R" && this.planType.ToUpper().Trim() != "D")
                {
                    results.Add(new ValidationResult("Invalid Plan Type", new List<string> { "planType" }));
                }
            }
            return results;
        }
    }
    public class distributorListRes
    {
        public string folio { get; set; }
        public string brokerCode { get; set; }
        public string brokerName { get; set; }
        public string subbrokerCode { get; set; }
        public string RIACode { get; set; }
    }
    public class AddBankReq : IValidatableObject
    {
        /// <summary> Ex. HDFC0000967</summary>
        [Required]
        public string ifscCode { get; set; }

        /// <summary> Ex. 4002401XX </summary>
        public string micrCode { get; set; }

        /// <summary> Ex. HDFC BANK </summary>
        public string bankName { get; set; }

        /// <summary> Ex. SAV </summary>
        public string accountType { get; set; }

        /// <summary> Ex. 91011673385 </summary>
        [RegularExpression("([0-9]+)", ErrorMessage = "folio number should be numeric only")]
        public string folioNo { get; set; }

        /// <summary> Ex. BHANDUP BRANCH </summary>
        public string BranchName { get; set; }

        /// <summary> Ex. "Bhandup" </summary>
        public string Address1 { get; set; }

        /// <summary> Ex. "" </summary>
        public string Address2 { get; set; }

        /// <summary> Ex. "" </summary>
        public string Address3 { get; set; }

        /// <summary> Ex. MUMBAI </summary>
        public string BranchCity { get; set; }

        /// <summary> Ex. 400014 </summary>
        public string PIN { get; set; }

        /// <summary> Ex. MAHARASHTRA </summary>
        public string BranchState { get; set; }

        /// <summary> Ex. ""</summary>
        public string CancelledCheque { get; set; }

        /// <summary> Ex. 012345678XXX </summary>
        [Required]
        [RegularExpression("^[a-zA-Z0-9_]*$", ErrorMessage = "Account number should be alphanumeric only")]
        public string BankAccNo { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.accountType.ToUpper().Trim() != "CUR" && this.accountType.ToUpper().Trim() != "SAV" && this.accountType.ToUpper().Trim() != "FCN" && this.accountType.ToUpper().Trim() != "NRE" && this.accountType.ToUpper().Trim() != "NRO")
            {
                results.Add(new ValidationResult("Invalid Account Type", new List<string> { "newBank" }));
            }
            return results;
        }
    }

   

    public class AddBankRes
    {
        public string message { get; set; }
        public string referenceNo { get; set; }
    }
    public class AddPurchaseConfirmationReq
    {
        /// <summary> Ex. 41203F44M9E21A450CM9F97C5799B6471XXX </summary>
        [Required]
        public int purchaseId { get; set; }

        /// <summary> Ex. "" </summary>
        [Required]
        [DefaultValue(false)]
        public bool billdeskflag { get; set; }
    }
    public class folioListRes
    {
        public string foliono { get; set; }
        public string groupcode { get; set; }
        public string accounttype { get; set; }
        public string schemecode { get; set; }
        public string schemename { get; set; }
        public string plancode { get; set; }
        public string planname { get; set; }
        public string optioncode { get; set; }
        public string optionname { get; set; }
        public bool dematAccount { get; set; }
    }   

    public class AddPurchaseShortCutReq : IValidatableObject
    {
        ///<summary> Ex. 91011673385 </summary>
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
        public string folioNo { get; set; }

        ///<summary> Ex. 127LTGDG</summary>
        [Required]
        [StringLength(8)]
        public string schemeCode { get; set; }

        ///<summary> Ex. 5000</summary>
        [Required]
        public double amount { get; set; }

        /// <summary> Ex. 127CPGDBB074860499074060XXX </summary>
        [Required]
        public string tranRefNo { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
           /* if (this.amount % 100 != 0)
            {
                results.Add(new ValidationResult("amount should be multiple of 100", new List<string> { "amount" }));
            }
            */
            return results;

        }

    }

    //public class folioListReq
    //{
    //    [Required]
    //    public string typeOfCustomer { get; set; }
    //    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    //    {
    //        var results = new List<ValidationResult>();
    //        if (this.typeOfCustomer.ToUpper().Trim() != "MF" && this.typeOfCustomer.ToUpper().Trim() != "PMS" && this.typeOfCustomer.ToUpper().Trim() != "BOTH")
    //        {
    //            results.Add(new ValidationResult("Invalid Customer Type", new List<string> { nameof(typeOfCustomer) }));
    //        }
    //        return results;
    //    }
    //}

}
