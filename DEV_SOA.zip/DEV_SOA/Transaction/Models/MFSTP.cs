﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class MFSTP
    {

    }

    public class ExistingSchemeReq
    {
        [DefaultValue("9042210255")]
        public string folioNo { get; set; }
    }

    public class ExistingSchemeRes
    {
        public List<STPExistingSchemes> STPExistingSchemes { get; set; }
    }

    public class STPExistingSchemes
    {
        public string schemecode { get; set; }
        public string plancode { get; set; }
        public string optioncode { get; set; }
        public string investorname { get; set; }
        public string schemedescription { get; set; }
        public string totalunits { get; set; }
        public string remainingunits { get; set; }
        public string nav { get; set; }
        public string navdate { get; set; }
        public string marketvalue { get; set; }
        public string fundtype { get; set; }
        public string planmode { get; set; }
        public string marketlockunits { get; set; }
    }

    public class STPPlanReq
    {
        //[DefaultValue("Fixed")]
        //public string stpType { get; set; }

        /// <summary> Ex. CP | GD </summary>
        [DefaultValue("CP")]
        public string schemecode { get; set; }

        /// <summary> Ex. DIRECT | REGULAR </summary>
        [DefaultValue("REGULAR")]
        public string planmode { get; set; }
    }

    public class STPOptionReq
    {
        /// <summary> Ex. CP </summary>
        [DefaultValue("CP")]
        public string schemecode { get; set; }

        /// <summary> Ex. DP </summary>
        [DefaultValue("DP")]
        public string plancode { get; set; }
    }

    public class STPTransReq
    {
        /// <summary> Ex. 127CPGPG </summary>
        [Required]
        public string moSchemeCode { get; set; }

        /// <summary> Ex. 91011673385 </summary>
        [Required(ErrorMessage ="Please input folio number.")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only.")]
        public string acno { get; set; }

        /// <summary> Ex. 1000 </summary>
        [Required]
        public double amount { get; set; }

        /// <summary> Ex. 3 </summary>
        [Required]
        public string freq { get; set; }

        /// <summary> Ex. 2018-07-04 </summary>
        [Required]
        public string stdt { get; set; }

        /// <summary> Ex. 2018-09-04 </summary>
        [Required]
        public string enddt { get; set; }

        /// <summary> Ex. CP </summary>
        [Required]
        public string toscheme { get; set; }
        /// <summary> Ex. GP </summary>
        [Required]
        public string toplan { get; set; }
        /// <summary> Ex. G </summary>
        [Required]
        public string tooption { get; set; }

        /// <summary> Ex. Regular </summary>
        public string planMode { get; set; }

        /// <summary> Ex. ARN-0018 </summary> 
        public string brokerCode { get; set; }

        /// <summary> Ex. "" </summary> 
        public string EUINNo { get; set; }

        /// <summary> Ex. false </summary> 
        public Boolean EUINFlag { get; set; }

        /// <summary> Ex. "" </summary>
        public string SubBrokerARNCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINsubarncode { get; set; }
    }

    public class STPTransRes
    {
        public string ihno { get; set; }
        public string referenceno { get; set; }
        public string time_stamp { get; set; }
        public string batchno { get; set; }
    }

    public class STPContentRes
    {
        public List<string> header { get; set; }
        public List<string> footer { get; set; }
        public int stpDateLag { get; set; }
        public List<FrequencyOption> frequencyOption { get;set; }
    }
    public class FrequencyOption
    {
        public string frequency { get; set; }
        public string cycleDate { get; set; }
        public double minAmount { get; set; }
        public int minInstallment { get; set; }
        public int amounttMultiplier { get; set; }
    }
    public class frequency
    {
        public string frequencyName { get; set; }
    }
}
