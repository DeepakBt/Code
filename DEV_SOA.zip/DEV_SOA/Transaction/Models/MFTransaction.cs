﻿using ApiCore.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class MFTransaction
    {
       
    }
    public class BankRes
    {
        public string micr { get; set; }
        public string bankName { get; set; }
        public string branchName { get; set; }
        public string branchState { get; set; }
        public string branchCity { get; set; }
        public string branchPincode { get; set; }
        public string bankAddress1 { get; set; }
        public string bankAddress2 { get; set; }
        public string bankAddress3 { get; set; }

    }
    public class RegisterBankRes
    {
        public string bankName { get; set; }
        public string accountNo { get; set; }
        public string ifscCode { get; set; }
        public string PG { get; set; }
        public string bankKeyRazorpay { get; set; }
    }
    public class RegisterBank
    {
        /// <summary> Ex. 91011673385</summary>
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
        public string folioNo { get; set; }
    }
    public class PANCheck
    {
        public Boolean kycStatus  { get; set; }
        public string userName { get; set; }

    }
    public class PANRes
    {
        public string ReturnMessage { get; set; }
        public string ReturnCode { get; set; }
    }

    public class aadharcheckReq
    {
        /// <summary> Ex. 12345678XXXX </summary>
        [Required]
        public string aadharNumber { get; set; }
    }
    public class calculateInstalment : IValidatableObject
    {
        /// <summary> Ex. WEEKLY | FORTNIGHTLY | MONTHLY | QUARTERLY | YEARLY </summary>
        [Required]
        public string frequency { get; set; }
        [Required]
        /// <summary> Ex. 2018-01-01 </summary>
        public string fromDate { get;set; }
        [Required]
        /// <summary> Ex. 2020-01-01 </summary>
        public string toDate { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            ParamValid paramValid = new ParamValid();
            if (this.frequency.ToUpper().Trim() != "MONTHLY" && this.frequency.ToUpper().Trim() != "QUARTERLY" && this.frequency.ToUpper().Trim() != "YEARLY" && this.frequency.ToUpper().Trim() != "FORTNIGHTLY" && this.frequency.ToUpper().Trim() != "WEEKLY")
            {
                results.Add(new ValidationResult("Invalid frequency", new List<string> { "SchemeDetails" }));
            }

            bool fromdate = true;
            bool toDate = true;
            // some other random test
            if (!string.IsNullOrEmpty(this.fromDate))
            {
                if (paramValid.DateValidate(this.fromDate.Trim(), "yyyy-MM-dd") == false)
                {
                    results.Add(new ValidationResult("Fromdate must be in format : yyyy-MM-dd", new List<string> { "CalulateInstalment" }));
                    fromdate = false;
                }
            }
            else
            {
                results.Add(new ValidationResult("Fromdate Required", new List<string> { "CalulateInstalment" }));
                fromdate = false;
            }

            if (!string.IsNullOrEmpty(this.toDate))
            {
                if (paramValid.DateValidate(this.toDate.Trim(), "yyyy-MM-dd") == false)
                {
                    results.Add(new ValidationResult("Todate must be in format : yyyy-MM-dd", new List<string> { "CalulateInstalment" }));
                    toDate = false;
                }
            }
            else
            {
                results.Add(new ValidationResult("ToDate Required", new List<string> { "CalulateInstalment" }));
                toDate = false;
            }

            if (fromdate == true && toDate == true)
            {
                if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
                {
                    results.Add(new ValidationResult("toDate must be ghreater than fromDate"));
                }
            }
            return results;
        }
    }
    public class aadharcheckRes
    {
        public string returnMessage { get; set; }
    }

    public class BrokerReq
    {
        /// <summary> Ex. ARN-0018 </summary>
        public string brokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string subBroker { get; set; }

        /// <summary> Ex. "" </summary>
        public string subBrokerCode { get; set; }

        /// <summary> Ex. E123456 </summary>
        public string euin { get; set; }

        /// <summary> Ex. "" </summary>
        public string Riacode { get; set; }
    }

    public class BrokerRes 
    {
        public string euinFlag { get; set; }
        public string euinMsg { get; set; }
    }
    public class PanKYCReq : IValidatableObject
    {
        /// <summary> Ex. "XXXXX1234X" </summary>
        [Required]
        public string panNo { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            Regex regex = new System.Text.RegularExpressions.Regex("^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$");
            Match match = regex.Match(panNo);
            if(!match.Success)
            {
                results.Add(new ValidationResult("PanNo must be in valid format", new List<string> { nameof(panNo) }));
            }
            return results;
        }
    }
    public class validateUserRes
    {
        [DefaultValue(false)]
        public bool authorizeUser { get; set; }
    }
    public class KDMSReq
    {
        /// <summary> Ex. 12345678XXXX </summary>
        public string aadharNo { get; set; }

        /// <summary> Ex. XXXXX1234X </summary>
        public string panNo { get; set; }

        /// <summary> Ex. John XXXX </summary>
        public string name { get; set; }

        /// <summary> Ex. 1234567890 </summary>
        public string mobile { get; set; }

        /// <summary> Ex. abcXXX@gmail.com </summary>
        public string email { get; set; }
    }

    public class KDMSRes
    {
        public string response1 { get; set; }
    }

    public class SchemeValueReq : IValidatableObject
    {
        /// <summary> Ex. LT </summary>
        [Required]
        public string schemeCode { get; set; }

        /// <summary> Ex. GP </summary>
        [Required]
        public string planCode { get; set; }

        /// <summary> Ex. G </summary>
        [Required]
        public string optionCode { get; set; }

        /// <summary> Ex. MONTHLY | QUARTERLY | YEARLY | WEEKLY | FORTNIGHTLY </summary>
        public string frequency { get; set; }

        /// <summary> NewSIp | AddSIP | NewP | AddP | Switch | STP | Redeem </summary>
        [Required]
        public string transactionType { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            ParamValid paramValid = new ParamValid();
            if(this.frequency ==null)
            {
                this.frequency = "";
            }
            if (this.frequency.ToUpper().Trim() != "MONTHLY" && this.frequency.ToUpper().Trim() != "QUARTERLY" && this.frequency.ToUpper().Trim() != "YEARLY" && this.frequency.ToUpper().Trim() != "" && this.frequency.ToUpper().Trim() != "FORTNIGHTLY" && this.frequency.ToUpper().Trim() != "WEEKLY" && this.frequency.ToUpper().Trim() != "DAILY")
            {
                results.Add(new ValidationResult("Invalid frequency", new List<string> { "MinimumSchemeAmount" }));
            }
            return results;
        }
    }

    public class SchemeValueRes
    {
        public double minAmount { get; set; }
        public double maxAmount { get; set; }
        public int NoOfInstallments { get; set; }
        public double AmountMultiplier { get; set; }
    }

    public class FailedRes
    {
        public string STATUS_CODE { get; set; }
        public string MESSAGE { get; set; }
    }


    public class ResClientBankBroker
    {
        public string accountType { get; set; }
        public string bankName { get; set; }
        public string bankAccNo { get; set; }
        public string plan { get; set; }
        public string brokerCode { get; set; }
        public string brokerName { get; set; }
    }

}
