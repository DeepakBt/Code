﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class Switch
    {

    }

    public class FolioDetailReq : IValidatableObject
    {
        /// <summary> Ex. 91011673385  </summary>
        [Required]
        public string folioNo { get; set; }

        /// <summary> Ex. 127CPGDG  </summary>
        [Required]
        public string schemeCode { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
     
            var results = new List<ValidationResult>();
            if (this.schemeCode == "" || this.schemeCode.Length < 8)
            {
                results.Add(new ValidationResult("Invalid schemeCode", new List<string> { nameof(schemeCode) }));
            }

            return results;
        }
    }

    public class FolioDetailRes
    {
        public List<FolioDetail> FolioDetail { get; set; }
     }

    public class FolioDetail
    {
        public string FundDescription { get; set; }
        public string NAV { get; set; }
        public string NAVDate { get; set; }
        public string mt_cuttime { get; set; }
        public double MinAmount { get; set; }
        public string mt_clrbalunit { get; set; }
        public string MarketValue { get; set; }
        public string mt_redflag { get; set; }
        public string Category { get; set; }
        public string SchemeGroup { get; set; }
        public string mt_Addflag { get; set; }
        public string mt_fund { get; set; }
        public string Scheme { get; set; }
        public string Plan { get; set; }
        public string Option { get; set; }
        public string schlink { get; set; }
        public double BalanceUnit { get; set; }
        public string PlanMode { get; set; }
        public string investedAmount { get; set; }
    }

    //public class AddpurchaseSchemeReq
    //{
    //    /// <summary>Enter categoty e.g. EQUITY FUND </summary>
    //    public string category { get; set; }
    //}

    public class AddpurchaseSchemeRes
    {
        public List<Scheme> Scheme { get; set; }
    }

    public class NewInvestmentSchemeReq
    {
        /// <summary>e.g. 9042012422</summary>
        [DefaultValue("9042012422")]
        public string folioNo { get; set; }
        /// <summary>e.g. P</summary>
          [DefaultValue("P")]
        public string trnType { get; set; }
        /// <summary>e.g. 11</summary>
        [DefaultValue("11")]
        public string category { get; set; }
        /// <summary>e.g. CP</summary>
        [DefaultValue("CP")]
        public string scheme { get; set; }
        /// <summary>e.g. GP</summary>
        [DefaultValue("GP")]
        public string plan { get; set; }
        /// <summary>e.g. G</summary>
        [DefaultValue("G")]
        public string option { get; set; }
    }

    public class NewInvestmentSchemeRes
    {
        public List<SchemeDetails> SchemeDetails { get; set; }
    }

    public class SchemeDetails
    {
        public string Fund { get; set; }
        public string Scheme { get; set; }
        public string Plan { get; set; }
        public string Description { get; set; }
        public string Cutofftime { get; set; }
        public double MinAmount { get; set; }
        public string NAVDate { get; set; }
        public string NAV { get; set; }
        public string Option { get; set; }
        public string Option1 { get; set; }
        public string Option2 { get; set; }
        public string SCHlink { get; set; }
        public string Category { get; set; }
        public string PlanMode { get; set; }
    }

    public class NewInvPlanReq
    {
        /// <summary> Ex. US </summary>
        [DefaultValue("US")]
        public string scheme { get; set; }

        /// <summary> Ex. Direct </summary>
        [DefaultValue("Direct")]
        public string mode { get; set; }

        /// <summary> Ex. 91011673385 </summary>
        [DefaultValue("9102339311")]
        public string folioNumber { get; set; }

        /// <summary> Ex. 127CPGDG </summary>
        [DefaultValue("127GRGPG")]
        public string moSchemeCode { get; set; }
    }

    public class NewInvPlanRes
    {
        public List<PlanRes> PlanList { get; set; }
    }

    public class NewInvOptionsReq
    {
        /// <summary> Ex. CP </summary>
        public string scheme { get; set; }

        /// <summary> Ex. GP </summary>
        public string plan { get; set; }
    }

    public class NewInvOptionsRes
    {
        public List<OptionList> OptionList { get; set; }
    }

    public class OptionList
    {
        public string Option { get; set; }
        public string Description { get; set; }
    }

    public class SwitchTransactionReq
    {
        ///  <summary> Ex. 91011673385 </summary> 
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Folio number should be numeric only")]
        public string folioNumber { get; set; }

        ///  <summary> Ex. HE </summary> 
        [Required]
        public string schemeCode { get; set; }

        /// <summary> Ex. A </summary>
        public string untamtflg { get; set; }

        /// <summary> Ex. 10385</summary>
        public double untamtvalue { get; set; }

        /// <summary> Ex. CP</summary>
        public string toScheme { get; set; }

        /// <summary> Ex. GD</summary>
        public string toPlan { get; set; }

        /// <summary> Ex. G</summary>
        public string toOption { get; set; }

        /// <summary> Ex. ""</summary>
        public string switchType { get; set; }

        ///  <summary> Ex. 91011673385 </summary> 
        [RegularExpression("([0-9]+)", ErrorMessage = "To Folio number should be numeric only")]
        public string toFoliNumber { get; set; }

        /// <summary> Ex. ""</summary>
        public string agent { get; set; }

        /// <summary> Ex. ""</summary>
        public string oldihno { get; set; }

        /// <summary> Ex. ""</summary>
        public string euinno { get; set; }

        /// <summary> Ex. true | false </summary>
        public Boolean euinflag { get; set; }

        /// <summary> Ex. ""</summary>
        public string euinsubarncode { get; set; }
    }

    public class SwitchTransactionRes
    {
        public string refno { get; set; }
    }
}
