﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.Models
{
    public class Master
    {

    }
    public class Category
    {
        public string categoryId { get; set; }
        public string categoryName { get; set; }
    }

    public class IncomeSlab
    {
        public string incomeCode { get; set; }
        public string incomeSlab { get; set; }
    }

    public class Status
    {
        public string statusId { get; set; }
        public string status { get; set; }
    }

    public class Occupation
    {
        public string occupationId { get; set; }
        public string occupation { get; set; }
    }

    public class ModeOfHolding
    {
        public string holdingmodeId { get; set; }
        public string holdingmode { get; set; }
    }

    public class Scheme
    {
        public string schemeId { get; set; }
        public string schemeName { get; set; }
        public string schemeType { get; set; }
    }

    public class StateMaster
    {
        public string stateName { get; set; }
    }

    public class Relation
    {
        public string relationName { get; set; }
    }

    public class NRI
    {
        public string nriId { get; set; }
        public string nriCategory { get; set; }
    }
    public class MasterRes
    {

        public List<ModeOfHolding> ModeOfHolding { get; set; }
        public List<Category> category { get; set; }
        public List<NRI> NRI { get; set; }
        public List<Status> Status { get; set; }
        public List<Occupation> Occupation { get; set; }
        public List<IncomeSlab> IncomeSlab { get; internal set; }
    }

    public class HolderBasicRes
    {

        public List<ModeOfHolding> ModeOfHolding { get; set; }
        public List<Category> category { get; set; }
        public List<NRI> NRI { get; set; }
        public List<Status> Status { get; set; }
        public List<Occupation> Occupation { get; set; }
    }

    public class FatcaBasicRes
    {
        public List<IncomeSlab> IncomeSlab { get; set; }
        public List<CountryRes> countryList { get; set; }
    }

    public class CityReq
    {
        /// <summary>  Ex. MAHARASHTRA </summary>
        [Required]
        public string stateName { get; set; }
    }

    public class BankReq
    {
        /// <summary> Ex. HDFC0000001 </summary>
        [Required]
        public string IFSCCode { get; set; }

        /// <summary> Ex. SIP | ADDBANK </summary>
        [Required]
        public string transactionType { get; set; }
    }

    public class CityRes
    {
        public string city { get; set; }
    }

    public class AccountType
    {
        public string accountType { get; set; }
        public string Code { get; set; }
    }

    public class AccountTypeReq
    {
        /// <summary> Ex. RI | NRI </summary>
        [Required]
        public string category { get; set; }
 }

    public class BankTypeReq
    {
        /// <summary> Ex. LUMPSUM | SIP </summary>
        [Required]
        public string investmentType { get; set; }
    }

    public class BankTypeRes
    {
        public string bankCode { get; set; }
        public string bankName { get; set; }
    }

    public class PlanReq
    {
        /// <summary> Ex. CP | DE | BI</summary>
        [Required]
        public string schemeCode { get; set; }

        /// <summary> Ex. Direct | Regular </summary>
        [Required]
        public string planMode { get; set; }
    }

    public class OptionReq
    {
        /// <summary> Ex. BI | CP | DE </summary>
        [Required]
        public string schemeCode { get; set; }

        /// <summary> Ex. GP | GP | PD | AD </summary>
        [Required]
        public string planCode { get; set; }
    }

    public class PlanRes
    {
        public string planName { get; set; }
        public string planCode { get; set; }
    }

    public class PlanMode 
    {
        public string planModeName { get; set; }
    }

    public class OptionRes
    {
        public string optionCode { get; set; }
        public string optionName { get; set; }
    }

    public class CountryRes
    {
        public string country { get; set; }
    }
    public class SchemePlanModeRes
    {
        public List<Scheme> schemeList { get; set; }
        public List<PlanMode> planModeList { get; set; }
    }
   
}
