﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ApiCore.Constants;
using ApiCore.Helpers;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Swagger;
using Transaction.Controllers;
using Transaction.Masters;
using Transaction.MF;
using Transaction.PMS;
using Transaction.Utils;

namespace Transaction
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var jwtSettings = new JwtSettings();
            Configuration.GetSection("jwt").Bind(jwtSettings);
            RSAProvider.InitializeTokens(jwtSettings);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = RSAProvider.AccessTokenValidationParameters;
                });

            services.AddResponseCompression(options =>
            {
                options.Providers.Add<APICore.Helpers.BrotliCompressionProvider>();
                options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "image/svg+xml" });
                options.EnableForHttps = true;
            });
            services.AddControllers(options =>
            {
                options.CacheProfiles.Add("Default",
                    new CacheProfile()
                    {
                        Duration = 7600
                    });
                options.CacheProfiles.Add("Never",
                    new CacheProfile()
                    {
                        Location = ResponseCacheLocation.None,
                        NoStore = true
                    });
            });

            services.AddMvcCore()
                .AddApiExplorer()
                .AddAuthorization()
                .AddFormatterMappings()
                .AddDataAnnotations();
                //.AddJsonFormatters();
            //services.ConfigureSwaggerGen(options =>
            //{
            //    //Determine base path for the application.
            //    var basePath = PlatformServices.Default.Application.ApplicationBasePath;
            //    //Set the comments path for the swagger json and ui.
            //    options.IncludeXmlComments(basePath + "\\Transaction.xml");
            //});

            services.AddSingleton<IConfiguration>(Configuration.GetSection("StaticPath"));
            services.Configure<JwtSettings>(Configuration.GetSection("jwt"));
            services.Configure<DbConnections>(Configuration.GetSection("connections"));
            services.AddScoped<ITransactionDataSource,MFPurchaseRepository>();
            services.AddScoped<IMasterDataSource, MFMasterRepository>();
            services.AddScoped<IMFNewInvestorDataSource, MFNewInvestorRepository>();
            services.AddScoped<IPMSDataSource, PMSRepository>();
            services.AddScoped<IAdditionalPurchaseDataSource, AdditionalPurchaseRepository>();
            services.AddScoped<ISwitchDataSource, MFSwitchRepository>();
            services.AddScoped<IMFSIPDataSource, MFSIPRepository>();
            services.AddScoped<IMFRedemptionDataSource, MFRedemptionRepository>();
            services.AddScoped<IMFSTPDataSource, MFSTPRepository>();
            services.AddScoped<IMFISIPDataSource, MFISIPRepository>();
            services.AddScoped<TokenHelper>();
            // Register the Swagger generator, defining one or more Swagger documents
            services.ConfigureSwaggerGen(options =>
            {
                var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                options.IncludeXmlComments(basePath + "\\Transaction.xml");
            });
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Transaction API", Version = "v1" });

                c.AddSecurityDefinition(HeaderConstants.AppId, new OpenApiSecurityScheme
                {
                    Description = "AppId",
                    In = ParameterLocation.Header,
                    Name = HeaderConstants.AppId,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = HeaderConstants.AppId,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = HeaderConstants.AppId
                            },
                         },
                         new List<string>()
                     }
                });

                c.AddSecurityDefinition(HeaderConstants.Authorization, new OpenApiSecurityScheme
                {
                    Description = "JWT Token",
                    In = ParameterLocation.Header,
                    Name = HeaderConstants.Authorization,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = HeaderConstants.Authorization,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = HeaderConstants.Authorization
                            },
                         },
                         new List<string>()
                     }
                });

                c.AddSecurityDefinition(HeaderConstants.UserAgent, new OpenApiSecurityScheme
                {
                    Description = "UserAgent",
                    In = ParameterLocation.Header,
                    Name = HeaderConstants.UserAgent,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = HeaderConstants.UserAgent,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = HeaderConstants.UserAgent
                            },
                         },
                         new List<string>()
                     }
                });
            });
            //services.AddNodeServices(); //use to work with node js 
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory, IConfiguration iconfiguration)
        {
            app.UseMiddleware<AppIdValidatorMiddleware>();
            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseMiddleware<ApiLoggingMiddleware>();
            app.UseAuthentication();
            string strHostName = "";
            string myIP = "";
            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            myIP = addr[addr.Length - 1].ToString();

            //app.UseHttpsRedirection();
            app.UseSwagger();
            var swagger = iconfiguration["swagger"];

            if (myIP != swagger)
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => {
                    c.SwaggerEndpoint("../swagger/v1/swagger.json", "Transaction API v1");
                });
            }
            app.UseRouting();
            app.UseCors("MOSLPolicy");
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
