﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;

namespace Transaction.Utils
{
    public class Utility
    {
        public async static Task<string> HttpPostRequestwithHeaders(string AppId, string jsonInput, string serviceUrl)
        {
            try
            {

                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("AppId", AppId);
                var jsonData = new StringContent(jsonInput, Encoding.UTF8, "application/json");
                var result = await client.PostAsync(serviceUrl, jsonData);
                var content = await result.Content.ReadAsStringAsync();
                return  content;

            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\HttpPostRequestwithHeadersBillDesk.txt", "\r\n" + DateTime.Now.ToString() + " " + serviceUrl + " Error : " + ex.Message);
                return  "";
            }

        }
        public async static Task<HttpResponseMessage> HttpGetRequest(string serviceUrl)
        {
            try
            {

                HttpClient client = new HttpClient();
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                var result = await client.GetAsync(serviceUrl);
                var content = await result.Content.ReadAsStringAsync();
                return result;

            }
            catch (Exception ex)
            {
                HttpClient client = new HttpClient();
                File.AppendAllText("D:\\HttpPostRequestwithHeadersBillDesk.txt", "\r\n" + DateTime.Now.ToString() + " " + serviceUrl + " Error : " + ex.Message);
                return await client.GetAsync(serviceUrl); ;
            }

        }

    }
}
