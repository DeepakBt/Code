﻿
namespace LoginModule.Models
{
    public class LoginResponseDto
    {
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
    }
}
