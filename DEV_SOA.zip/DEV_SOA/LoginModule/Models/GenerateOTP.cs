﻿using ApiCore.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using ApiCore.Models;

namespace LoginModule.Models
{
    public class GenerateOtp : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.panNo == null || this.panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(panNo) }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.",new List<string> { nameof(panNo) }));
                   
                }
            }
            return results;
        }
    }

    public class GenerateOtpWeb : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        [Required]
        public string clientType { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.panNo == null || this.panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(panNo) }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(panNo) }));

                }
            }
            if (this.clientType == null || this.clientType.Trim() == "")
            {
                results.Add(new ValidationResult("clientType cannot be left blank.", new List<string> { nameof(clientType) }));
            }
            return results;
        }
    }

    public class GenerateOtpWhatsappReq : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();

            string DecryptedPANNo = RSACSP.Decrypt(this.panNo);
            this.panNo = DecryptedPANNo;

            if (this.panNo == null || this.panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(panNo) }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(panNo) }));

                }
            }
            return results;
        }
    }

}
