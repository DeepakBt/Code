﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using ApiCore.Model;
using ApiCore.Exceptions;

namespace LoginModule.Models
{
    public class LoginMode : IValidatableObject
    {
        [Required]
        public string UserId { get; set; }
        [Required]
        public int LoginModeId { get; set; }
        [Required]
        public int CredentialModeId { get; set; }
        public string IPV4 { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            try
            {
                ParamValid ParamValid = new ParamValid();
                var results = new List<ValidationResult>();
                if (LoginModeId == 1)
                {
                    if (this.UserId == null || this.UserId.Trim() == "")
                    {
                        results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(UserId) }));
                    }
                    else
                    {
                        if (ParamValid.IsValidPanno(this.UserId) == false)
                        {
                            results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(UserId) }));

                        }
                    }
                }
                else if(LoginModeId == 4)
                {
                    if (this.UserId == null || this.UserId.Trim() == "")
                    {
                        results.Add(new ValidationResult("Email Id cannot be left blank.", new List<string> { nameof(UserId) }));
                    }
                    else
                    {
                        if (ParamValid.IsValidEmail(this.UserId) == false)
                        {
                            results.Add(new ValidationResult("Invalid Email Id.", new List<string> { nameof(UserId) }));
                        }
                    }
                }
                else if(LoginModeId==5)
                {
                    if (this.UserId == null || this.UserId.Trim() == "")
                    {
                        results.Add(new ValidationResult("Folio No cannot be left blank.", new List<string> { nameof(UserId) }));
                    }
                    else
                    {
                        if (ParamValid.isNumeric(this.UserId) == false)
                        {
                            results.Add(new ValidationResult("Invalid Folio No.", new List<string> { nameof(UserId) }));
                        }
                    }
                }
                return results;
            }
            catch (Exception)
            {
                throw new NoDataException(false);
            }
        }
    }
    public class LoginModeAuth : LoginMode, IValidatableObject
    {
        [Required]
        public string Password { get; set; }
        public new IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            try
            {
                ParamValid ParamValid = new ParamValid();
                var results = new List<ValidationResult>();
                if (this.Password == null || this.Password.Trim() == "")
                {
                    results.Add(new ValidationResult("Password cannot be left blank.", new List<string> { nameof(Password) }));
                }
                return results;
            }
            catch (Exception)
            {
                throw new NoDataException(false);
            }
            
        }
    }

    public class UserInfo
    {
        public long Client_UCID { get; set; }
        public string PAN_NO { get; set; }
        public string ClientName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string MaskedContact { get; set; }
        public string MaskedEmail { get; set; }
        public bool Success { get; set; }
        public string Message { get; set; }
        public string ClientType { get; set; }
    }
    public class LoginAuthResponse
    {
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
        public int expiresIn { get; set; }
        public int reLoginAfter { get; set; }
        public long serverTime { get; set; }
        public UserInfo userInfo { get; set; }
    }
}
