﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginModule.Models
{
    public class Credentials
    {
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
        public int expiresIn { get; set; }
        public int reLoginAfter { get; set; }
        public long serverTime { get; set; }
        public VerifiedClientData UserInfo { get; set; }

    }
}
