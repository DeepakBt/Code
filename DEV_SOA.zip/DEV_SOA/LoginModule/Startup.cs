﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using ApiCore.Constants;
using ApiCore.Helpers;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using LoginModule.Controllers;
using LoginModule.Utils;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;


namespace LoginModule
{
    public class Startup
    {
        
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var jwtSettings = new JwtSettings();
            Configuration.GetSection("jwt").Bind(jwtSettings);
            RSAProvider.InitializeTokens(jwtSettings);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = RSAProvider.AccessTokenValidationParameters;
                });

            services.AddResponseCompression(options =>
            {
                options.Providers.Add<APICore.Helpers.BrotliCompressionProvider>();
                options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "image/svg+xml" });
                options.EnableForHttps = true;
            });
            services.AddControllers(options =>
            {
                options.CacheProfiles.Add("Default",
                    new CacheProfile()
                    {
                        Duration = 7600
                    });
                options.CacheProfiles.Add("Never",
                    new CacheProfile()
                    {
                        Location = ResponseCacheLocation.None,
                        NoStore = true
                    });
            });
            services.AddMvcCore()
                .AddApiExplorer()
                .AddAuthorization()
                .AddFormatterMappings()
                .AddDataAnnotations();
            //.AddJsonFormatters();
            //services.AddControllers().AddNewtonsoftJson();

            services.Configure<JwtSettings>(Configuration.GetSection("jwt"));
            services.Configure<DbConnections>(Configuration.GetSection("connections"));
            services.AddSingleton<IConfiguration>(Configuration.GetSection("settings"));
            
            services.AddScoped<ILoginDataSource, LoginRepository>();
            services.AddScoped<TokenHelper>();
            services.AddCors(options =>
            {
                options.AddPolicy("MOSLPolicy", builder =>
                {
                    builder.WithOrigins(
                                            "http://www.moamc.com",
                                            "http://localhost:4200",
                                            "http://www.moamc.com:93",
                                            "http://www.moamc.com:92",
                                            "https://www.motilaloswalmf.com"
                                        ).WithHeaders(HeaderNames.ContentType, "application/json")
                                        .WithHeaders(HeaderNames.Vary, "Origin")
                                        .WithHeaders()
                                        .AllowAnyMethod()
                                        .AllowCredentials();
                });
            });
            services.ConfigureSwaggerGen(options =>
            {
                var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                options.IncludeXmlComments(basePath + "\\LoginModule.xml");
            });
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Login API", Version = "v1" });

                c.AddSecurityDefinition(HeaderConstants.AppId, new OpenApiSecurityScheme
                {
                    Description = "AppId",
                    In = ParameterLocation.Header,
                    Name = HeaderConstants.AppId,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = HeaderConstants.AppId,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = HeaderConstants.AppId
                            },
                         },
                         new List<string>()
                     }
                });
                c.AddSecurityDefinition(HeaderConstants.UserAgent, new OpenApiSecurityScheme
                {
                    Description = "UserAgent",
                    In = ParameterLocation.Header,
                    Name = HeaderConstants.UserAgent,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = HeaderConstants.UserAgent,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = HeaderConstants.UserAgent
                            },
                         },
                         new List<string>()
                     }
                });
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory, IConfiguration iconfiguration)
        {
            app.UseMiddleware<AppIdValidatorMiddleware>();
            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseMiddleware<ApiLoggingMiddleware>();
            app.UseAuthentication();
            string strHostName = "";
            string myIP = "";
            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            myIP = addr[addr.Length - 1].ToString();

            //app.UseHttpsRedirection();
            app.UseSwagger();
            var swagger = iconfiguration["swagger"];

            if (myIP != swagger)
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => {
                    c.SwaggerEndpoint("../swagger/v1/swagger.json", "Login API v1");
                });
                //app.Run(async (context) =>
                //{
                //    var logger = loggerFactory.CreateLogger("InitModule.Startup");
                //    logger.LogInformation("No endpoint found for request {path}", context.Request.Path);
                //    await context.Response.WriteAsync("No endpoint found.");
                //});
            }
            app.UseRouting();
            app.UseCors("MOSLPolicy");
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
