﻿using ApiCore.DTOs;
using ApiCore.Model;
using LoginModule.Models;
using System.Threading.Tasks;

namespace LoginModule.Controllers
{
   public interface ILoginDataSource
    {
        Task<ResponseDataModel<string>> OtpGenerate(string AppId, GenerateOtp request);
        Task<ResponseDataModel<string>> OtpGenerateWeb(string AppId, GenerateOtpWeb request);
        Task<ResponseDataModel<string>> OtpGenerateNew(string AppId,string UserAgent, LoginMode request);
        Task<ResponseDataModel<Credentials>> AuthenticateUser(string AppId, AuthenticateUser request);
        Task<ResponseDataModel<LoginAuthResponse>> AuthenticateUserCred(string AppId, string UserAgent, LoginModeAuth request);
        Task<ResponseDataModel<Credentials>>  AuthorizeUser(string AppId, AuthorizeUser request);
        Task<ResponseDataModel<VerifiedToken>> Token(string AppId, Token request);        
        Task<ResponseDataModel<string>> Logout(Token request);
        Task<ResponseDataModel<KYC_DETAILS>> saveNewInvestorKYC_Details(RequestPANKYC ObjPAN);
        Task<ResponseDataModel<KYC_DETAILS>> GetNewInvestorKYC_Details(RequestPANKYC ObjPAN);
    }
}
