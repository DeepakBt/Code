﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using APICore.Constants;
using APICore.Helpers;
using Dapper;
using LoginModule.Controllers;
using LoginModule.Models;
using LoginModule.Utils;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Login.Controllers
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class LoginController : ControllerBase
    {
        private readonly ILoginDataSource _LoginDataSource;
        private readonly TokenHelper _tokenHelper;
        private readonly JwtSettings _jwtSettings;
        private readonly DbConnections _connections;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        public  LoginController(IOptionsSnapshot<DbConnections> connectionsSnapshot, ILoginDataSource LoginDataSource, IOptionsSnapshot<JwtSettings> jwtSnapshot, TokenHelper tokenHelper)
        {
            _LoginDataSource = LoginDataSource;
            _jwtSettings = jwtSnapshot.Value;
            _tokenHelper = tokenHelper;
            _connections = connectionsSnapshot.Value;
        }

        // GET api/values
        [EnableCors("MOSLPolicy")]
        [HttpPost("GenerateOtp")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> Post([FromBody] GenerateOtp request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _LoginDataSource.OtpGenerate(AppId, request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("GenerateOtpWeb")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> GenerateOtpWeb([FromBody] GenerateOtpWeb request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _LoginDataSource.OtpGenerateWeb(AppId, request);
            return Ok(response);
        }

        // GET api/values
        [EnableCors("MOSLPolicy")]
        [HttpPost("VerifyOtp")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<Credentials>), 200)]
        public async Task<IActionResult> Post([FromBody] AuthenticateUser request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _LoginDataSource.AuthenticateUser(AppId, request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("GenerateOtpNew")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> GenerateOtpNew([FromBody] LoginMode request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            string UserAgent = Convert.ToString(HeaderAccessors.GetUserAgent(Request.Headers));
            var response = await _LoginDataSource.OtpGenerateNew(AppId, UserAgent, request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("AuthenticateUserCred")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<LoginAuthResponse>), 200)]
        public async Task<IActionResult> Post([FromBody] LoginModeAuth request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            string UserAgent = Convert.ToString(HeaderAccessors.GetUserAgent(Request.Headers));
            var response = await _LoginDataSource.AuthenticateUserCred(AppId, UserAgent, request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("authorizeUser")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<Credentials>), 200)]
        public async Task<IActionResult> Post([FromBody] AuthorizeUser request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            //using (StreamWriter writer = System.IO.File.AppendText("Authuser1.txt"))
            //{
            //    writer.WriteLine("\r\n\r\n " + DateTime.Now.ToString() + "  Apiname: authorizeUser \r\n Mode: " + AppId + "\r\n Mode: " + request.mode + "\r\n PanNo: " + request.panNo + "\r\n OTP: " + request.otp + " \r\n accessToken: " + request.accessToken  + "\r\n refreshToken: " + request.refreshToken);
            //}
            if (request.mode.ToUpper().Trim() == "SILENT")
            {
                var isRefreshTokenValid = _tokenHelper.IsValidButMaybeExpired(request.refreshToken, RefreshTokenConstants.TokenTypeRefresh, Request.Headers);
                var isAccessTokenValid = _tokenHelper.IsValidAccessToken(request.accessToken, TokenConstants.TokenTypeAccess, Request.Headers);
                JwtSecurityToken refreshtokenData = _tokenHelper.ReadToken(request.refreshToken);
                JwtSecurityToken accesstokenData = _tokenHelper.ReadToken(request.accessToken);
                var refreshPan = "";
                var accessPan = "";
                if (!isRefreshTokenValid)
                {
                    //using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                    //{
                    //    writer.WriteLine("\r\n Checking JwtSecurityToken tokenData = _tokenHelper.ReadToken(request.refreshToken);");
                    //}
                    JwtSecurityToken tokenData = _tokenHelper.ReadToken(request.refreshToken);
                    //using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                    //{
                    //    writer.WriteLine("\r\n Checking JwtSecurityToken RefreshtokenData = Done");
                    //}
                    if ((DateTime.Now - tokenData.ValidTo).Days >= 30)
                    {
                        return Unauthorized(); 
                    }
                }
                else
                {
                     refreshPan = refreshtokenData.Claims.First(claim => claim.Type == "unique_name").Value;
                }
                if (!isAccessTokenValid)
                {
                    //using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                    //{
                    //    writer.WriteLine("\r\n Checking JwtSecurityToken tokenData = _tokenHelper.ReadToken(request.accessToken);");
                    //}
                    JwtSecurityToken tokenData = _tokenHelper.ReadToken(request.accessToken);
                    //using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                    //{
                    //    writer.WriteLine("\r\n Checking JwtSecurityToken AccesstokenData = Done");
                    //}
                    if ((DateTime.Now - tokenData.ValidTo).Days >= 30)
                    {
                        return Unauthorized();
                    }
                }
                else 
                {
                     accessPan = accesstokenData.Claims.First(claim => claim.Type == "unique_name").Value;
                }
                if ((request.panNo.ToUpper() != refreshPan.ToUpper()) || (request.panNo.ToUpper() != accessPan.ToUpper()) || (refreshPan.ToUpper() != accessPan.ToUpper()))
                {
                    return Unauthorized();
                }
                //using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                //{
                //    writer.WriteLine("\r\n Checking for Refresh token in DB");
                //}
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("AMCMob_Token_Check", new
                    {
                        RefreshToken = request.refreshToken
                    }, commandType: CommandType.StoredProcedure);
                    {
                        bool expired = false;
                        var VerifiedList = multi.ToList();
                        expired = Convert.ToBoolean(VerifiedList[0].loggedIn);
                        if (!expired)
                        {
                            return Unauthorized();
                        }
                        else
                        {
                            //using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                            //{
                            //    writer.WriteLine("\r\n Checking Controller Done");
                            //}
                            var response = await _LoginDataSource.AuthorizeUser(AppId, request);
                            return Ok(response);
                        }
                    }
                }
            }
            else
            {
                var response = await _LoginDataSource.AuthorizeUser(AppId, request);
                return Ok(response);
            }  
        }
        
        [Produces("application/json")]
        [HttpPost("Token")]
        [ProducesResponseType(typeof(ResponseDataModel<VerifiedToken>), 200)]
        public async Task<IActionResult> Token([FromBody] Token request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var isRefreshTokenValid = _tokenHelper.IsValidButMaybeExpired(request.refreshToken, RefreshTokenConstants.TokenTypeRefresh, Request.Headers);
            var isAccessTokenValid = _tokenHelper.IsValidAccessToken(request.accessToken, TokenConstants.TokenTypeAccess, Request.Headers);
            JwtSecurityToken refreshtokenData = _tokenHelper.ReadToken(request.refreshToken);
            JwtSecurityToken accesstokenData = _tokenHelper.ReadToken(request.accessToken);
            var refreshPan = refreshtokenData.Claims.First(claim => claim.Type == "unique_name").Value;
            var accessPan = accesstokenData.Claims.First(claim => claim.Type == "unique_name").Value;
            if (!isRefreshTokenValid )
            {
                JwtSecurityToken tokenData = _tokenHelper.ReadToken(request.refreshToken);
                if ((DateTime.Now - tokenData.ValidTo).Days >= 30)
                {
                    return Unauthorized();
                }
            }
            if (!isAccessTokenValid)
            {
                JwtSecurityToken tokenData = _tokenHelper.ReadToken(request.accessToken);
                if ((DateTime.Now - tokenData.ValidTo).Days >= 30)
                {
                    return Unauthorized();
                }
            }
            if ((refreshPan.ToUpper() != accessPan.ToUpper()))
            {
                return Unauthorized();
            }
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMob_Token_Check", new
                {
                    RefreshToken = request.refreshToken
                }, commandType: CommandType.StoredProcedure);
                {
                    bool expired = false;
                    var VerifiedList = multi.ToList();
                    expired = Convert.ToBoolean(VerifiedList[0].loggedIn);
                    if (!expired)
                    {
                        return Unauthorized();
                    }
                    else
                    {
                        var response = await _LoginDataSource.Token(AppId, request);
                        return Ok(response);
                    }
                }
            }
        }

        [Produces("application/json")]
        [HttpPost("Logout")]
        public async Task<IActionResult> logout([FromBody] Token request)
        {
            var response = await _LoginDataSource.Logout( request);
            return Ok(response);
        }

        [HttpPost("GetKYCDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<KYC_DETAILS>), 200)]
        public async Task<IActionResult> GetKYCDetails([FromBody] RequestPANKYC objPAN)
        {
            var response = await _LoginDataSource.GetNewInvestorKYC_Details(objPAN);
            return Ok(response);
        }
    }
}