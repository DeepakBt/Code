﻿using ApiCore.DTOs;
using ApiCore.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MFTransaction.Models;
using ApiCore.Exceptions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using karvyAPI;
using MFTransaction.Utils;
using System.IO;

namespace MFTransaction.ETF
{
    public class ETFRepository : IETFDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly TokenHelper _tokenHelper;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        public ETFRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
        }

        public async Task<ResponseDataArrayModel<folioListRes>> folioList(string PanNo)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var folioDetails = await conn.QueryAsync("AMCMob_PROC_GETPANWISESCHEME_ETF", new
                {
                    PAN = PanNo,
                    TYPEOFCUSTOMER = "MF",
                }, commandType: CommandType.StoredProcedure);
                {
                    List<folioListRes> ofolioListRes = new List<folioListRes>();
                    var VerifiedList2 = folioDetails.ToList();
                    if (VerifiedList2.Count > 0)
                    {
                        foreach (var p in VerifiedList2.ToList())
                        {
                            ofolioListRes.Add(new folioListRes
                            {
                                foliono = Convert.ToString(p.FOLIONO),
                                schemecode = Convert.ToString(p.SCHEMECODE),
                                schemename = Convert.ToString(p.SCHEMENAME),
                                groupcode = Convert.ToString(p.GROUPCODE),
                                accounttype = Convert.ToString(p.ACCOUNTTYPE),
                                plancode = Convert.ToString(p.PLANCODE),
                                planname = Convert.ToString(p.PLANNAME),
                                optioncode = Convert.ToString(p.OPTIONCODE),
                                optionname = Convert.ToString(p.OPTIONNAME),
                                dematAccount = Convert.ToBoolean(p.DEMATFLAG)
                            });

                        }
                        return new ResponseDataArrayModel<folioListRes>(ofolioListRes);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }

                }

            }

        }
    }
}
