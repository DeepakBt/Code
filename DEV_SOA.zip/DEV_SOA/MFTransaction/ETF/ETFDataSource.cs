﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MFTransaction.Models;
namespace MFTransaction.ETF
{
    public interface IETFDataSource
    {
        Task<ResponseDataArrayModel<folioListRes>> folioList(string PANNo);
    }
}
