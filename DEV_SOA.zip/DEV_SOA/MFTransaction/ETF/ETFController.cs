﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MFTransaction.Models;
using MFTransaction.Utils;
using ApiCore.Exceptions;

namespace MFTransaction.ETF
{
    [Produces("application/json")]
    [Route("api/ETF")]
    [ValidateModel]
    [Authorize]
    public class ETFController : ControllerBase
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly IETFDataSource _ETFDataSource;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        public ETFController(TokenHelper tokenHelper, IETFDataSource ETFDataSource, IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _ETFDataSource = ETFDataSource;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
        }
        [Produces("application/json")]
        [HttpGet("ETFfolioList")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<folioListRes>), 200)]
        public async Task<IActionResult> folioList()
        {
            var panNo = User.Identity.Name;
            if (!string.IsNullOrEmpty(panNo))
            {
                var response = await _ETFDataSource.folioList(panNo);
                return Ok(response);
            }
            else
            {
                throw new NoDataException(true, "Session expired");
            }
        }
    }
}
