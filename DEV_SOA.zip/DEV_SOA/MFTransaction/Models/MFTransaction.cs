﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Helpers;
using ApiCore.Model;
namespace MFTransaction.Models
{
    public class LumpsumInvestmentDetail
    {
        /// <summary> Ex.  9104299XXX </summary>
        public string FolioNo { get; set; }

        /// <summary> Ex. CP </summary>
        public string Scheme { get; set; }

        /// <summary> Ex. GP </summary>
        public string Plan { get; set; }

        /// <summary> Ex. G </summary>
        public string Option { get; set; }

        /// <summary> Ex. lumpsum </summary>
        public string TrType { get; set; }

        /// <summary> Ex. 5000 </summary>
        public string Amount { get; set; }

        /// <summary> Ex. "" </summary>
        public string TransRefNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string MandateLimit { get; set; }

        /// <summary> Ex. "" </summary>
        public string MandateStatus { get; set; }

        /// <summary> Ex. MO000018-B0XXXX </summary>
        public string URNNO { get; set; }

        /// <summary> Ex. 2019-08-18 </summary>
        public string URNexpirydate { get; set; }

        /// <summary> Ex. 2019-08-18 </summary>
        public string UMRNexpirydate { get; set; }

        /// <summary> Ex. ARN-00XX </summary>
        public string BrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string SubBrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINFlag { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINOpt { get; set; }

        /// <summary> Ex. E1234XX </summary>
        public string EUINNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINSubARNCode { get; set; }

        /// <summary> Ex. ICICI BANK </summary>
        public string BankName { get; set; }

        /// <summary> Ex. 000111222XXX </summary>
        public string BankAccountNo { get; set; }

        /// <summary> Ex. ICIC0000008 </summary>
        public string IFSCCode { get; set; }

        /// <summary> Ex. 23456 </summary>
        public string MICRCode { get; set; }

        /// <summary> Ex. Goal-XXX </summary>
        public string GoalId { get; set; }

        /// <summary> Ex. MOGP-XXX </summary>
        public string MOGPID { get; set; }

        /// <summary> Ex. Y </summary>
        public string MOGPFREEZE { get; set; }

        /// <summary> Ex. "" </summary>
        public string CompanyCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string EmployeeCode { get; set; }

        /// <summary> Ex. Online </summary>
        public string accOpeningMode { get; set; }

        /// <summary> Ex. N </summary>
        public string HoldingDematMode { get; set; }

        /// <summary> Ex. "" </summary>
        public string NSDLCDSL { get; set; }

        /// <summary> Ex. "" </summary>
        public string DPIdClientId { get; set; }

        /// <summary> Ex. "" </summary>
        public string Paymode { get; set; }

        /// <summary> Ex. "" </summary>
        public string PG { get; set; }

        /// <summary> Ex. OrderId_1 </summary>
        public string OrderId { get; set; }

        /// <summary> Ex. DCB </summary>
        public string ChequeType { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string InternalCode { get; set; }
    }

    public class LumpsumInvestmentDetailConsolidate
    {
        /// <summary> Ex.  9104299XXX </summary>
        public string FolioNo { get; set; }

        /// <summary> Ex. CP </summary>
        public string Scheme { get; set; }

        /// <summary> Ex. GP </summary>
        public string Plan { get; set; }

        /// <summary> Ex. G </summary>
        public string Option { get; set; }

        /// <summary> Ex. lumpsum </summary>
        public string TrType { get; set; }

        /// <summary> Ex. 10000 </summary>
        public string Amount { get; set; }

        //public string TransRefNo { get; set; }
        //public string MandateLimit { get; set; }
        //public string MandateStatus { get; set; }
        //public string URNNO { get; set; }
        //public string URNexpirydate { get; set; }
        //public string UMRNexpirydate { get; set; }

        /// <summary> Ex. ARN-00XX </summary>
        public string BrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string SubBrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINFlag { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINOpt { get; set; }

        /// <summary> Ex. E1234XX </summary>
        public string EUINNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINSubARNCode { get; set; }

        /// <summary> Ex. ICICI BANK </summary>
        public string BankName { get; set; }

        /// <summary> Ex. 000111222XXX </summary>
        public string BankAccountNo { get; set; }

        /// <summary> Ex. ICIC0000008 </summary>
        public string IFSCCode { get; set; }

        /// <summary> Ex. 23456 </summary>
        public string MICRCode { get; set; }

        //public string GoalId { get; set; }
        //public string MOGPID { get; set; }
        //public string MOGPFREEZE { get; set; }
        //public string CompanyCode { get; set; }
        //public string EmployeeCode { get; set; }
        //public string accOpeningMode { get; set; }
        //public string HoldingDematMode { get; set; }
        //public string NSDLCDSL { get; set; }
        //public string DPIdClientId { get; set; }
        //public string Paymode { get; set; }
        //public string PG { get; set; }

        /// <summary> Ex. OrderId_1 </summary>
        public string OrderId { get; set; }

        //public string ChequeType { get; set; }
    }
    

    //public class SipRef
    //{
    //    public List<InvestmentDetailConsolidateRef> SipDetailRef { get; set; }
    //}

    public class InvestmentDetailConsolidateRef
    {
        public string FolioNo { get; set; }
        public string Amount { get; set; }
        public string IHNON { get; set; }
        public string Scheme { get; set; }
    }

    public class SIPInvestmentDetail
    {
        /// <summary> Ex. 91042990XX </summary>
        public string FolioNo { get; set; }

        /// <summary> Ex. KrishnXX </summary>
        public string InvName { get; set; }

        /// <summary> Ex. LT </summary>
        public string Scheme { get; set; }

        /// <summary> Ex. GD </summary>
        public string Plan { get; set; }

        /// <summary> Ex. G</summary>
        public string Option { get; set; }

        /// <summary> Ex. iSIP </summary>
        public string TrType { get; set; }

        /// <summary> Ex. 5000 </summary>
        public string Amount { get; set; }

        /// <summary> Ex. Monthly </summary>
        public string Frequency { get; set; }

        /// <summary> Ex. 2019-08-02</summary>
        public string SIPStartDate { get; set; }

        /// <summary> Ex. 2020-08-02</summary>
        public string SIPEndDate { get; set; }

        /// <summary> Ex. 12 </summary>
        public string NoOfInstallment { get; set; }

        /// <summary> Ex. 5 </summary>
        public string SIPmonth { get; set; }

        /// <summary> Ex. "" </summary>
        public string TransRefNo { get; set; }

        /// <summary> Ex. MO000018-B03XXX</summary>
        public string URNNO { get; set; }

        /// <summary> Ex. 2019-08-18 </summary>
        public string URNexpirydate { get; set; }

        /// <summary> Ex. "" </summary>
        public string UMRNNo { get; set; }

        /// <summary> Ex. 2019-08-18 </summary>
        public string UMRNexpirydate { get; set; }

        /// <summary> Ex. Online </summary>
        public string Siptype { get; set; }

        /// <summary> Ex. Goal-001 </summary>
        public string GoalId { get; set; }

        /// <summary> Ex. SIF-001 </summary>
        public string SIPRefno { get; set; }

        /// <summary> Ex. ARN-00XX </summary>
        public string BrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string SubBrokerCode { get; set; }

        /// <summary> Ex. ""</summary>
        public string EUINFlag { get; set; }

        /// <summary> Ex. ""</summary>
        public string EUINOpt { get; set; }

        /// <summary> Ex. E123456 </summary>
        public string EUINNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINSubARNCode { get; set; }

        /// <summary> Ex. "ICICI BANK" </summary>
        public string BankName { get; set; }

        /// <summary> Ex. 0001112223XX </summary>
        public string BankAccountNo { get; set; }

        /// <summary> Ex. ICIC0000008 </summary>
        public string IFSCCode { get; set; }

        /// <summary> Ex. 23456 </summary>
        public string MICRCode { get; set; }

        /// <summary> Ex. MOGP-001 </summary>
        public string MOGPID { get; set; }

        /// <summary> Ex. Y </summary>
        public string MOGPFREEZE { get; set; }

        /// <summary> Ex. "" </summary>
        public string CompanyCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string EmployeeCode { get; set; }

        /// <summary> Ex. Online </summary>
        public string accOpeningMode { get; set; }

        /// <summary> Ex. N </summary>
        public string HoldingDematMode { get; set; }

        /// <summary> Ex. "" </summary>
        public string NSDLCDSL { get; set; }

        /// <summary> Ex. "" </summary>
        public string DPIdClientId { get; set; }

        /// <summary> Ex. OrderId_2 </summary>
        public string OrderId { get; set; }

        /// <summary> Ex. DCB </summary>
        public string ChequeType { get; set; }

        /// <summary> Ex. "" </summary>
        public string SIPTopUpFlag { get; set; }

        /// <summary> Ex. "" </summary>
        public string SIPTopUpFrequency { get; set; }

        /// <summary> Ex. "" </summary>
        public string SIPTopUpAmount { get; set; }

        /// <summary> Ex. "" </summary>
        public string Settopuplimit { get; set; }

        /// <summary> Ex. "" </summary>
        [DefaultValue("")]
        public string InternalCode { get; set; }
    }
    public class SIPInvestmentDetailConsolidate
    {
        /// <summary> Ex. 91042990XX </summary>
        public string FolioNo { get; set; }

        /// <summary> Ex. KrishnXX </summary>
        public string InvName { get; set; }

        /// <summary> Ex. LT </summary>
        public string Scheme { get; set; }

        /// <summary> Ex. GD </summary>
        public string Plan { get; set; }

        /// <summary> Ex. G </summary>
        public string Option { get; set; }

        /// <summary> Ex. iSIP </summary>
        public string TrType { get; set; }

        /// <summary> Ex. 10000 </summary>
        public string Amount { get; set; }

        /// <summary> Ex. iSIP </summary>
        public string Frequency { get; set; }

        /// <summary> Ex. 2019-08-02</summary>
        public string SIPStartDate { get; set; }

        /// <summary> Ex. 2020-08-02</summary>
        public string SIPEndDate { get; set; }

        /// <summary> Ex. 12 </summary>
        public string NoOfInstallment { get; set; }

        /// <summary> Ex. 5 </summary>
        public string SIPmonth { get; set; }

        //public string TransRefNo { get; set; }

        /// <summary> Ex. MO000018-B03XXX </summary>
        public string URNNO { get; set; }

        /// <summary> Ex. 2019-08-18 </summary>
        public string URNexpirydate { get; set; }

        /// <summary> Ex. "" </summary>
        public string UMRNNo { get; set; }

        /// <summary> Ex. 2019-08-18 </summary>
        public string UMRNexpirydate { get; set; }

        /// <summary> Ex. Online </summary>
        public string Siptype { get; set; }

        /// <summary> Ex. Goal-001 </summary>
        public string GoalId { get; set; }

        /// <summary> Ex. SIF-001 </summary>
        public string SIPRefno { get; set; }

        /// <summary> Ex. ARN-00XX </summary>
        public string BrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string SubBrokerCode { get; set; }

        /// <summary> Ex. "" </summary>
        public string EUINFlag { get; set; }

        //public string EUINOpt { get; set; }
        //public string EUINNo { get; set; }
        //public string EUINSubARNCode { get; set; }

        /// <summary> Ex. ICICI BANK </summary>
        public string BankName { get; set; }

        /// <summary> Ex. 0001112223XX </summary>
        public string BankAccountNo { get; set; }

        /// <summary> Ex. ICIC0000008 </summary>
        public string IFSCCode { get; set; }

        /// <summary> Ex. 23456 </summary>
        public string MICRCode { get; set; }

        //public string MOGPID { get; set; }
        //public string MOGPFREEZE { get; set; }
        //public string CompanyCode { get; set; }
        //public string EmployeeCode { get; set; }
        //public string accOpeningMode { get; set; }
        //public string HoldingDematMode { get; set; }
        //public string NSDLCDSL { get; set; }
        //public string DPIdClientId { get; set; }

        /// <summary> Ex. OrderId_1 </summary>
        public string OrderId { get; set; }

        //public string ChequeType { get; set; }

        /// <summary> Ex. "" </summary>
        public string SIPTopUpFlag { get; set; }

        /// <summary> Ex. "" </summary>
        public string SIPTopUpFrequency { get; set; }

        /// <summary> Ex. "" </summary>
        public string SIPTopUpAmount { get; set; }

        /// <summary> Ex. "" </summary>
        public string Settopuplimit { get; set; }
    }
    public class TransactionRequest
    {
        /// <summary> Ex. "2019-08-02"</summary>
        public string PurchaseDate { get; set; }

        /// <summary> Ex. "DC"</summary>
        public string PaymentMode { get; set; }

        /// <summary> Ex. "10000"</summary>
        public string TotalInvestAMount { get; set; }

        /// <summary> Ex. "MB88"</summary>
        public string Branch { get; set; }

        /// <summary> Ex. "Billdesk"</summary>
        public string PG { get; set; }

        /// <summary> Ex. "ADDTIONALPURCHASE"</summary>
        public string Campaign { get; set; }

        /// <summary> Ex. "343434"</summary>
        public string MORefNo { get; set; }

        /// <summary> Ex. ""</summary>
        public string UTRNo { get; set; }

        /// <summary> Ex. "192.168.XXX.XXX"</summary>
        public string IPAddress { get; set; }

        /// <summary> Ex. ""</summary>
        public string QueryString { get; set; }

        public List<LumpsumInvestmentDetail> LumpsumInvestmentDetails { get; set; }
        public List<SIPInvestmentDetail> SIPInvestmentDetails { get; set; }
    }

    public class TransactionRequestConsolidate
    {
        /// <summary> Ex. "DC" </summary>
        public string PaymentMode { get; set; }

        /// <summary> Ex.  10000 </summary>
        public string TotalInvestAMount { get; set; }

        //public string Branch { get; set; }

        /// <summary> Ex. "Billdesk" </summary>
        public string PG { get; set; }

        /// <summary> Ex. "ADDTIONALPURCHASE" </summary>
        public string Campaign { get; set; }

        //public string MORefNo { get; set; }
        //public string UTRNo { get; set; }

        /// <summary> Ex. "192.168.XXX.XXX" </summary>
        public string IPAddress { get; set; }

        /// <summary> Ex. "" </summary>
        public string QueryString { get; set; }
        public List<LumpsumInvestmentDetailConsolidate> LumpsumInvestmentDetails { get; set; }
        public List<SIPInvestmentDetailConsolidate> SIPInvestmentDetails { get; set; }
    }

    public class LumpsumInvResponseDtl
    {
        public string Amount { get; set; }
        public string FolioNo { get; set; }
        public string GoalId { get; set; }
        public string MOGPFREEZE { get; set; }
        public string MOGPID { get; set; }
        public string Message { get; set; }
        public string Option { get; set; }
        public string Plan { get; set; }
        public string Scheme { get; set; }
        public string Status_Code { get; set; }
        public string TIME_STAMP { get; set; }
        public string TrType { get; set; }
        public string TransRefNo { get; set; }
        public string UMRNNo { get; set; }
        public string UMRNexpirydate { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
        public string OrderId { get; set; }
    }

    public class SipInvResponseDtl
    {
        public string Amount { get; set; }
        public string FolioNo { get; set; }
        public string Frequency { get; set; }
        public string GoalId { get; set; }
        public string MOGPFREEZE { get; set; }
        public string MOGPID { get; set; }
        public string Message { get; set; }
        public string NoOfInstallment { get; set; }
        public string Option { get; set; }
        public string Plan { get; set; }
        public string SIPEndDate { get; set; }
        public string SIPStartDate { get; set; }
        public string Scheme { get; set; }
        public string Status_Code { get; set; }
        public string TIME_STAMP { get; set; }
        public string TrType { get; set; }
        public string TransRefNo { get; set; }
        public string UMRNNo { get; set; }
        public string UMRNexpirydate { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
        public string OrderId { get; set; }
    }

    public class TransactionResponse
    {
        public long PurRefNo { get; set; }
        public string BucketId { get; set; }
        public string Campaign { get; set; }
        public List<LumpsumInvResponseDtl> LumpsumInvResponseDtls { get; set; }
        public string MORefNo { get; set; }
        public List<SipInvResponseDtl> SipInvResponseDtls { get; set; }
        public string TotalInvestAMount { get; set; }
        public string TimeStamp { get; set; }
        public string Status_Code { get; set; }
        public string Message { get; set; }
        public string BankId { get; set; }
    }

    
   
    public class BillDeskConsolidateResponse
    {
        public string ExceptionMsg { get; set; }
        public string ExceptionLineNo { get; set; }
        public string LumpsumtotalAmount { get; set; }
        public string SIPtotalAmount { get; set; }
        public string BucketId { get; set; }
        public string PurRefNo { get; set; }
        public string PaymentURL { get; set; }
        public List<SipInvResponseDtl> SIPResponse { get; set; }
        public List<InvestmentDetailConsolidateRef> LumpSumResponse { get; set; }
    }
    public class TransactionReqResponse
    {
        public TransactionRequest _TransactionRequest { get; set; }
        public TransactionResponse _TransactionResponse { get; set; }
    }

    public class TransactionReqResponseConsolidate
    {
        public TransactionRequestConsolidate _TransactionRequest { get; set; }
        public TransactionResponse _TransactionResponse { get; set; }
    }

    public class TransactionConfirmationReq
    {
        public string BucketId { get; set; }
        public string Acno { get; set; }
        public string Appno { get; set; }
        public string MerchantID { get; set; }
        public string CustomerId { get; set; }
        public string BankRefno { get; set; }
        public string BankRemarks { get; set; }
        public string TxnAmount { get; set; }
        public string TxnId { get; set; }
        public string BankID { get; set; }
        public string BankMerchantID { get; set; }
        public string CurrencyName { get; set; }
        public string ItemCode { get; set; }
        public string SecurityType { get; set; }
        public string SecurityID { get; set; }
        public string SecurityPassword { get; set; }
        public string SettlementType { get; set; }
        public string PaymentStatus { get; set; }
        public string ErrorDescription { get; set; }
    }
    public class TransactionConfirmationRes
    {
        public string Acno { get; set; }
        public string Appno { get; set; }
        public string Message { get; set; }
        public string Status_Code { get; set; }
        public string TxnAmount { get; set; }
    }

    public class EMandateRegReq : IValidatableObject
    {
        /// <summary> Ex. "" </summary>
        public string UMRN { get; set; }

        /// <summary> Ex. 2019-08-14 </summary>
        [Required]
        public string OTMDate { get; set; }

        /// <summary> Ex. "" </summary>
        [Required]
        public string SponsorBank { get; set; }

        /// <summary> Ex. Motilaloswal Mutual Fund </summary>
        [Required]
        public string Authorize { get; set; }

        /// <summary> Ex. Code1 </summary>
        [Required]
        public string Utilitycode { get; set; }

        /// <summary> Ex. Create </summary>
        [Required]
        public string Mode { get; set; }

        /// <summary> Ex. SB </summary>
        [Required]
        public string ToDebit { get; set; }

        /// <summary> Ex. ICICI Bank </summary>
        [Required]
        public string BankName { get; set; }

        /// <summary> Ex. Khairtabad </summary>
        [Required]
        public string BankHolderName { get; set; }

        /// <summary> Ex. 4546677 </summary>
        public string MICRCode { get; set; }

        /// <summary> Ex. ICIC0000008 </summary>
        [Required]
        public string IFSCCode { get; set; }

        /// <summary> Ex. 0001112223XX </summary>
        [Required]
        public string BankAcno { get; set; }

        /// <summary> Ex. MB88 </summary>
        [Required]
        public string BranchCode { get; set; }

        /// <summary> Ex. Monthly </summary>
        [Required]
        public string Frequency { get; set; }

        /// <summary> Ex. Fixed </summary>
        [Required]
        public string Debittype { get; set; }

        /// <summary> Ex. XXXXX1234X </summary>
        [Required]
        public string ClientId { get; set; }

        /// <summary> Ex. Single </summary>
        public string AccountType { get; set; }

        /// <summary> Ex. "" </summary>
        public string ReferenceID { get; set; }

        /// <summary> Ex. abc@gmail.com </summary>
        public string EmailId { get; set; }

        /// <summary> Ex. 2019-08-14 </summary>
        [Required]
        public string FromDate { get; set; }

        /// <summary> Ex. 2020-08-14 </summary>
        [Required]
        public string Todate { get; set; }

        /// <summary> Ex. "0" </summary>
        public string RefNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string Image { get; set; }

        /// <summary> Ex. 9494253XXX </summary>
        [Required]
        public string MobileNo { get; set; }

        /// <summary> Ex. 500 </summary>
        [Required]
        public string Amount { get; set; }

        /// <summary> Ex. "" </summary>
        public string RegMode { get; set; }

        /// <summary> Ex. "" </summary>
        public string ReceiptNo { get; set; }

        /// <summary> Ex. "" </summary>
        public string ChequeCopy { get; set; }

        /// <summary> Ex. XXXXX1234X </summary>
        [Required]
        public string PANNO { get; set; }

        /// <summary> Ex. "" </summary>
        [Required]
        public string InvestorName { get; set; }

        /// <summary> Ex. "" </summary>
        public string ImageType { get; set; }

        /// <summary> Ex.  </summary>

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            
            if (this.Image != null && this.Image.Trim() != "")
            {
                string OTMImageExtension = GetFileExtension(this.Image);
                if (OTMImageExtension != "png" && OTMImageExtension != "jpg")
                {
                    results.Add(new ValidationResult("Invalid OTM Image Format", new List<string> { nameof(Image) }));
                }
            }
            if (this.ChequeCopy != null && this.ChequeCopy.Trim() != "")
            {
                string ChequeImageExt = GetFileExtension(this.ChequeCopy);
                if (ChequeImageExt != "png" && ChequeImageExt != "jpg")
                {
                    results.Add(new ValidationResult("Invalid Cheque Image Format", new List<string> { nameof(ChequeCopy) }));
                }
            }
            if(this.OTMDate==null || this.OTMDate.Trim() == "")
            {
                results.Add(new ValidationResult("OTMDate is required.", new List<string> { nameof(OTMDate) }));
            }
            if (Utilities.ContainsXHTML(this.OTMDate))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(OTMDate) }));
            }
            if (Utilities.CheckSpecialChar(this.OTMDate))
            {
                results.Add(new ValidationResult("OTMDate special characters are not allowed", new List<string> { nameof(OTMDate) }));
            }
            if (this.SponsorBank == null || this.SponsorBank.Trim() == "")
            {
                results.Add(new ValidationResult("SponsorBank is required.", new List<string> { nameof(SponsorBank) }));
            }
            if (Utilities.ContainsXHTML(this.SponsorBank))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(SponsorBank) }));
            }
            if (Utilities.CheckSpecialChar(this.SponsorBank))
            {
                results.Add(new ValidationResult("SponsorBank special characters are not allowed", new List<string> { nameof(SponsorBank) }));
            }
            if (this.Authorize == null || this.Authorize.Trim() == "")
            {
                results.Add(new ValidationResult("Authorize is required.", new List<string> { nameof(Authorize) }));
            }
            if (Utilities.ContainsXHTML(this.Authorize))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(Authorize) }));
            }
            if (Utilities.CheckSpecialChar(this.Authorize))
            {
                results.Add(new ValidationResult("Authorize special characters are not allowed", new List<string> { nameof(Authorize) }));
            }

            if (this.Utilitycode == null || this.Utilitycode.Trim() == "")
            {
                results.Add(new ValidationResult("Utilitycode is required.", new List<string> { nameof(Utilitycode) }));
            }
            if (Utilities.ContainsXHTML(this.Utilitycode))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(Utilitycode) }));
            }
            if (Utilities.CheckSpecialChar(this.Utilitycode))
            {
                results.Add(new ValidationResult("Utilitycode special characters are not allowed", new List<string> { nameof(Utilitycode) }));
            }

            if (this.Mode == null || this.Mode.Trim() == "")
            {
                results.Add(new ValidationResult("Mode is required.", new List<string> { nameof(Mode) }));
            }
            if (Utilities.ContainsXHTML(this.Mode))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(Mode) }));
            }
            if (Utilities.CheckSpecialChar(this.Mode))
            {
                results.Add(new ValidationResult("Mode special characters are not allowed", new List<string> { nameof(Mode) }));
            }

            if (this.ToDebit == null || this.ToDebit.Trim() == "")
            {
                results.Add(new ValidationResult("ToDebit is required.", new List<string> { nameof(ToDebit) }));
            }
            if (Utilities.ContainsXHTML(this.ToDebit))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(ToDebit) }));
            }
            if (Utilities.CheckSpecialChar(this.ToDebit))
            {
                results.Add(new ValidationResult("ToDebit special characters are not allowed", new List<string> { nameof(ToDebit) }));
            }


            if (this.BankName == null || this.BankName.Trim() == "")
            {
                results.Add(new ValidationResult("BankName is required.", new List<string> { nameof(BankName) }));
            }
            if (Utilities.ContainsXHTML(this.BankName))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(BankName) }));
            }
            if (Utilities.CheckSpecialChar(this.BankName))
            {
                results.Add(new ValidationResult("BankName special characters are not allowed", new List<string> { nameof(BankName) }));
            }
            if (this.IFSCCode == null || this.IFSCCode.Trim() == "")
            {
                results.Add(new ValidationResult("IFSCCode is required.", new List<string> { nameof(IFSCCode) }));
            }
            if (Utilities.ContainsXHTML(this.IFSCCode))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(IFSCCode) }));
            }
            if (Utilities.CheckSpecialChar(this.IFSCCode))
            {
                results.Add(new ValidationResult("IFSCCode special characters are not allowed", new List<string> { nameof(IFSCCode) }));
            }
            if (this.BankAcno == null || this.BankAcno.Trim() == "")
            {
                results.Add(new ValidationResult("BankAcno is required.", new List<string> { nameof(BankAcno) }));
            }
            if (Utilities.ContainsXHTML(this.BankAcno))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(BankAcno) }));
            }
            if (Utilities.CheckSpecialChar(this.BankAcno))
            {
                results.Add(new ValidationResult("BankAcno special characters are not allowed", new List<string> { nameof(BankAcno) }));
            }
            if (this.BranchCode == null || this.BranchCode.Trim() == "")
            {
                results.Add(new ValidationResult("BranchCode is required.", new List<string> { nameof(BranchCode) }));
            }
            if (Utilities.ContainsXHTML(this.BranchCode))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(BranchCode) }));
            }
            if (Utilities.CheckSpecialChar(this.BranchCode))
            {
                results.Add(new ValidationResult("BranchCode special characters are not allowed", new List<string> { nameof(BranchCode) }));
            }
            if (this.Frequency == null || this.Frequency.Trim() == "")
            {
                results.Add(new ValidationResult("Frequency is required.", new List<string> { nameof(Frequency) }));
            }
            if (Utilities.ContainsXHTML(this.Frequency))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(Frequency) }));
            }
            if (Utilities.CheckSpecialChar(this.Frequency))
            {
                results.Add(new ValidationResult("Frequency special characters are not allowed", new List<string> { nameof(Frequency) }));
            }

            if (this.Debittype == null || this.Debittype.Trim() == "")
            {
                results.Add(new ValidationResult("Debittype is required.", new List<string> { nameof(Debittype) }));
            }
            if (Utilities.ContainsXHTML(this.Debittype))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(Debittype) }));
            }
            if (Utilities.CheckSpecialChar(this.Debittype))
            {
                results.Add(new ValidationResult("Debittype special characters are not allowed", new List<string> { nameof(Debittype) }));
            }

            if (this.ClientId == null || this.ClientId.Trim() == "")
            {
                results.Add(new ValidationResult("ClientId is required.", new List<string> { nameof(ClientId) }));
            }
            if (Utilities.ContainsXHTML(this.ClientId))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(ClientId) }));
            }
            if (Utilities.CheckSpecialChar(this.ClientId))
            {
                results.Add(new ValidationResult("ClientId special characters are not allowed", new List<string> { nameof(ClientId) }));
            }
           if (this.FromDate == null || this.FromDate.Trim() == "")
            {
                results.Add(new ValidationResult("FromDate is required.", new List<string> { nameof(FromDate) }));
            }
            if (Utilities.ContainsXHTML(this.FromDate))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(FromDate) }));
            }
            if (Utilities.CheckSpecialChar(this.FromDate))
            {
                results.Add(new ValidationResult("FromDate special characters are not allowed", new List<string> { nameof(FromDate) }));
            }

            if (this.Todate == null || this.Todate.Trim() == "")
            {
                results.Add(new ValidationResult("Todate is required.", new List<string> { nameof(Todate) }));
            }
            if (Utilities.ContainsXHTML(this.Todate))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(Todate) }));
            }
            if (Utilities.CheckSpecialChar(this.Todate))
            {
                results.Add(new ValidationResult("Todate special characters are not allowed", new List<string> { nameof(Todate) }));
            }

            if (this.PANNO == null || this.PANNO.Trim() == "" || this.PANNO.Trim().Length!=10)
            {
                results.Add(new ValidationResult("PANNO is required and should be 10 character.", new List<string> { nameof(PANNO) }));
            }

            if (Utilities.ContainsXHTML(this.PANNO))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(PANNO) }));
            }
            if (Utilities.CheckSpecialChar(this.PANNO))
            {
                results.Add(new ValidationResult("PANNO special characters are not allowed", new List<string> { nameof(PANNO) }));
            }

            if (this.InvestorName == null || this.InvestorName.Trim() == "")
            {
                results.Add(new ValidationResult("InvestorName is required.", new List<string> { nameof(InvestorName) }));
            }
            if (Utilities.ContainsXHTML(this.InvestorName))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(InvestorName) }));
            }
            if (Utilities.CheckSpecialChar(this.InvestorName))
            {
                results.Add(new ValidationResult("InvestorName special characters are not allowed", new List<string> { nameof(InvestorName) }));
            }

            if (this.MobileNo == null || this.MobileNo.Trim() == "" || this.MobileNo.Trim().Length < 7)
            {
                results.Add(new ValidationResult("MobileNo is required.", new List<string> { nameof(MobileNo) }));
            }
            if (Utilities.ContainsXHTML(this.MobileNo))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(MobileNo) }));
            }
            if (Utilities.CheckSpecialChar(this.MobileNo))
            {
                results.Add(new ValidationResult("MobileNo special characters are not allowed", new List<string> { nameof(MobileNo) }));
            }

            if (this.Amount == null || this.Amount.Trim() == "" || this.Amount.Trim() == "0" || IsNumeric(this.Amount) == false)
            {
                results.Add(new ValidationResult("Amount is required and should be greater then or equal to 200000.", new List<string> { nameof(Amount) }));
            }
            if (IsNumeric(this.Amount) == true)
            {
                if (Convert.ToInt64(this.Amount) < 200000)
                {
                    results.Add(new ValidationResult("Amount is required and should be greater then or equal to 200000.", new List<string> { nameof(Amount) }));
                }
            }
            return results;
        }
        public static bool IsNumeric(string Amt)
        {
            Int64 Amt64;
            bool isNumeric = Int64.TryParse(Amt, out Amt64);
            return isNumeric;
        }
        public static string GetFileExtension(string base64String)
        {
            var data = base64String.Substring(0, 5);

            switch (data.ToUpper())
            {
                case "IVBOR":
                    return "png";
                case "/9J/4":
                    return "jpg";
                default:
                    return string.Empty;
            }
        }
    }
    public class EMandateRegRes
    {
        public string Message { get; set; }
        public string RefNo { get; set; }
        public string ReferenceID { get; set; }
        public string Status_Code { get; set; }
    }
    public class EMandateReqResponse
    {
        public EMandateRegReq _EMandateRegReq { get; set; }
        public EMandateRegRes _EMandateRegRes { get; set; }
    }
    public class OTMDetails
    {
        public string RefNo { get; set; }
        public string RegistrationDate { get; set; }
        public string BankName { get; set; }
        public string BankAccNo { get; set; }
        public string UMRN_NO { get; set; }
        public decimal MinAmount { get; set; }
        public string Status { get; set; }

        public string OTMDate { get; set; }
        public string SponsorBank { get; set; }
        public string Authorize { get; set; }
        public string Utilitycode { get; set; }
        public string Mode { get; set; }
        public string ToDebit { get; set; }
        public string BankHolderName { get; set; }
        public string MICRCode { get; set; }
        public string IFSCCode { get; set; }
        public string BankAcno { get; set; }
        public string BranchCode { get; set; }
        public string Frequency { get; set; }
        public string Debittype { get; set; }
        public string ClientId { get; set; }
        public string AccountType { get; set; }
        public string ReferenceID { get; set; }
        public string EmailId { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string Image { get; set; }
        public string MobileNo { get; set; }
        public string ChequeImage { get; set; }
        public string PANNO { get; set; }
        public string InvestorName { get; set; }
        public string ImageType { get; set; }
    }
    public class OTMReq : IValidatableObject
    {
        /// <summary> Ex. "SINGLE" </summary>
        [Required]
        public string ModeOfHolding { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            if (this.ModeOfHolding == null || this.ModeOfHolding.Trim() == "")
            {
                results.Add(new ValidationResult("ModeOfHolding is required.", new List<string> { nameof(ModeOfHolding) }));
            }
            if (Utilities.ContainsXHTML(this.ModeOfHolding))
            {
                results.Add(new ValidationResult("Alert XSS Scripts.", new List<string> { nameof(ModeOfHolding) }));
            }
            if (Utilities.CheckSpecialChar(this.ModeOfHolding))
            {
                results.Add(new ValidationResult("ModeOfHolding special characters are not allowed", new List<string> { nameof(ModeOfHolding) }));
            }
            return results;
        }
    }
    public class FinalSubmitEMandate
    {
        /// <summary> Ex. 1044</summary>
        public int RefNo { get; set; }
    }

    public class SaveOTMConsolidateRes
    {
        public EMandateRegRes ObjEMandateRegRes { get; set; }
        public List<OTMDetails> ObjLstOTMDetails { get; set; }
    }

    public class EMandateRegReqConsolidate
    {
        public EMandateRegReq ObjEMandateRegReq { get; set; }
        public OTMReq ObjOTMReq { get; set; }
    }

    public class ResSIPURNDetails
    {
        public string InvestorName { get; set; }
        public string Foliono { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Pan { get; set; }
        public string ReferenceNumber { get; set; }
        public string URNNumber { get; set; }
        public string UMRNNo { get; set; }
        public string SchemeCode { get; set; }
        public string SchemeDescription { get; set; }
        public string UrnStatus { get; set; }
        public string RegistrationDate { get; set; }
        public string Frequency { get; set; }
        public string Amount { get; set; }
        public string ActivationDate { get; set; }
        public string ExpiryDate { get; set; }
        public string WithEffectDate { get; set; }
        public string Holdingtype { get; set; }
        public string BankName { get; set; }
        public string Accountnumber { get; set; }
        public string IFSCCode { get; set; }
        public string BillerName { get; set; }
        public string SponsorBankCode { get; set; }
        public string MandateStatus { get; set; }
        public string MandateAmount { get; set; }
        public string MandateExpiryDate { get; set; }
        public string Curvalue { get; set; }
        public string Tenure { get; set; }
        public string InvestmentAmt { get; set; }
        public string Distributor { get; set; }
        public bool Boosted { get; set; }
        public double GainLoss { get; set; }
        public string BoostedAmount { get; set; }
        public string FrequencyBoost { get; set; }
        public string LimitAmountofBooster { get; set; }
    }

    public class ReqSIPURN
    {
        public string scheme { get; set; }
        public string plan { get; set; }
        public string option { get; set; }
        public string folioNo { get; set; }
        public string amount { get; set; }
        public string Invname { get; set; }
        public string entby { get; set; }
        public string frequency { get; set; }
        public string startdate { get; set; }
        public string enddate { get; set; }
        public string BnkActype { get; set; }
        public string Bnkname { get; set; }
        public string BnkAcno { get; set; }
        public string Mandate { get; set; }
        public string URNNo { get; set; }
        public string UMRno { get; set; }
        public string ifsccode { get; set; }
        public string Mandateregtype { get; set; }
        public string holdingtype { get; set; }
        public string SponsorBankcode { get; set; }
        public string MandateStatus { get; set; }
        public string RegistrationDt { get; set; }
        public string sipstepupflag { get; set; }
        public string sipstepupfrequency { get; set; }
        public string sipstepupamount { get; set; }
        public string SIPStatus { get; set; }
        public string sipTopUpLimit { get; set; }
        public string sipstepupstartdt { get; set; }
        public string sipstepupenddt { get; set; }
    }

    public class ResSIPURN
    {
        public string IHNO { get; set; }
        public string REFNO { get; set; }
        public string BATCHNO { get; set; }
        public string TIME_STAMP { get; set; }
        public string ERRNO { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
    }
    public class SavePaymentRequest
    {
        /// <summary> Ex. 408132906 </summary>
        [Required(ErrorMessage = "Please Enter Bucket_Id")]
        public int Bucket_Id { get; set; }

        /// <summary> Ex. {
        ///  "amount": 50000,
        ///  "currency": "INR",
        ///  "receipt": "4081329XX",
        ///  "payment_capture": "1",
        ///  "bank_account": {
        ///    "account_number": "50100096178XXX",
        ///    "name": "HDFC BANK LIMITED",
        ///    "ifsc": "HDFC0000001"
        ///  },
        ///  "method": "netbanking"
        ///}
        ///</summary>
        public string ReqXML { get; set; }

        /// <summary> Ex. "" | order_FXpd606EKcsAM4 </summary>
        public string ResXML { get; set; }

        /// <summary> Ex. "" </summary>
        public string ReqPGString { get; set; }

        /// <summary> Ex. "" </summary>
        public string Payment_URL { get; set; }
    }
    public class ResSipBoosterDetails
    {
        public string EndDate { get; set; }
        public string TopUpAmount { get; set; }
        public string TopUpLimit { get; set; }
        public string TopUpFrequency { get; set; }
    }
    public class ReqSipBoosterDetails : IValidatableObject
    {
        /// <summary> Ex. MODIRECT-A88653 </summary>
        public string UrnORUmrnNO { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            if (this.UrnORUmrnNO.Length < 2)
            {
                results.Add(new ValidationResult("Check UrnORUmrnNO might be wrong", new List<string> { nameof(UrnORUmrnNO) }));
            }
            return results;
        }
    }
}
