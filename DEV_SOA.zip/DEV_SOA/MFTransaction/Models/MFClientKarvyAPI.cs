﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Model;

namespace MFTransaction.Models
{
    public class MFClientKarvy
    {
        public string trtype { get; set; }
        public string fatca_flag { get; set; }
        public string nominee_flag { get; set; }
        public string KYC_flag { get; set; }
        public string branch { get; set; }
        public string FPoliticallyExposed { get; set; }
        public string FRelatedToPoliticallyExposed { get; set; }
        public string SPoliticallyExposed { get; set; }
        public string SRelatedToPoliticallyExposed { get; set; }
        public string TPoliticallyExposed { get; set; }
        public string TRelatedToPoliticallyExposed { get; set; }
        public string GPoliticallyExposed { get; set; }
        public string GRelatedToPoliticallyExposed { get; set; }
        public string FKRA { get; set; }
        public string FCOB { get; set; }
        public string accountNumber { get; set; }
        public string accountType { get; set; }
        public string bankName { get; set; }
        public string branchCity { get; set; }
        public string branchName { get; set; }
        public string ifscCode { get; set; }
        public string micrCode { get; set; }
        public string branchPin { get; set; }
        public string schemeCategory { get; set; }
        public string schemeName { get; set; }
        public string schemePlan { get; set; }
        public string schemeOption { get; set; }
        public int investmentAmount { get; set; }
        public string brokerCode { get; set; }
        public string subBrokerCode { get; set; }
        public string subBrokerArn { get; set; }
        public string euin { get; set; }
        public string euinDeclaration { get; set; }
        public string Nomname { get; set; }
        public string relationship { get; set; }
        public string percentageAllocation { get; set; }
        public string Nomaddress1 { get; set; }
        public string Nomaddress2 { get; set; }
        public string Nomaddress3 { get; set; }
        public string Nomcountry { get; set; }
        public string Nomcity { get; set; }
        public string NomzipCode { get; set; }
        public string Nomdob { get; set; }
        public string NomguardianName { get; set; }
        public string nominee2 { get; set; }
        public string nom2Relation { get; set; }
        public string nominee2percentage { get; set; }
        public string nom2add1 { get; set; }
        public string nom2add2 { get; set; }
        public string nom2add3 { get; set; }
        public string nom2country { get; set; }
        public string nom2city { get; set; }
        public string nom2pin { get; set; }
        public string nom2DOB { get; set; }
        public string nom2Gaurdian { get; set; }
        public string nominee3 { get; set; }
        public string nom3Relation { get; set; }
        public string nominee3percentage { get; set; }
        public string nom3add1 { get; set; }
        public string nom3add2 { get; set; }
        public string nom3add3 { get; set; }
        public string nom3country { get; set; }
        public string nom3city { get; set; }
        public string nom3pin { get; set; }
        public string nom3DOB { get; set; }
        public string nom3Gaurdian { get; set; }
        public string annualIncome { get; set; }
        public string countryOfBirth { get; set; }
        public string nationality { get; set; }
        public string countryOfTaxResident { get; set; }
        public string foreignTaxNumber { get; set; }
        public string pep { get; set; }
        public string relatedToPEP { get; set; }
        public string Nriaddress1 { get; set; }
        public string Nriaddress2 { get; set; }
        public string Nriaddress3 { get; set; }
        public string Nricountry { get; set; }
        public string Nricity { get; set; }
        public string NrizipCode { get; set; }
        public string Invname { get; set; }
        public string Invaddress1 { get; set; }
        public string Invaddress2 { get; set; }
        public string Invaddress3 { get; set; }
        public string Invoccupation { get; set; }
        public string InvresidenceCategory { get; set; }
        public string Invpan { get; set; }
        public string InvmobileNumber { get; set; }
        public string Invemail { get; set; }
        public string Invdob { get; set; }
        public string ModeOfHolding { get; set; }
        public string CompanyCode { get; set; }
        public string EmployeeCode { get; set; }
        public string accOpeningMode { get; set; }
        public string HoldingDematMode { get; set; }
        public string NSDLCDSL { get; set; }
        public string DPIdClientId { get; set; }
        public string GoalId { get; set; }
        public string MOGSipflag { get; set; }
        public string Refno { get; set; }
        public string GuardianName { get; set; }
        public string GMobileNo { get; set; }
        public string GPan { get; set; }
        public string GGender { get; set; }
        public string GDob { get; set; }
        public string GRelation { get; set; }
        public string GCOB { get; set; }
        public string GAnnualIncome { get; set; }
        public string GNationality { get; set; }
        public string GTaxResident { get; set; }
        public string GForeignTaxId { get; set; }
        public string GFather { get; set; }
        public string GKRA { get; set; }
        public string SecondInvName { get; set; }
        public string ThirdInvName { get; set; }
        public string SecondInvOccupation { get; set; }
        public string ThirdInvOccupation { get; set; }
        public string SecondInvDOB { get; set; }
        public string ThirdInvDOB { get; set; }
        public string SecondInvEMail { get; set; }
        public string ThirdInvEMail { get; set; }
        public string SecondInvMobile { get; set; }
        public string ThirdInvMobile { get; set; }
        public string SecondInvSalutation { get; set; }
        public string ThirdInvSalutation { get; set; }
        public string SAnnualIncome { get; set; }
        public string SNationality { get; set; }
        public string STaxResident { get; set; }
        public string SForeignTaxID { get; set; }
        public string TAnnualIncome { get; set; }
        public string TNationality { get; set; }
        public string TTaxResident { get; set; }
        public string TForeignTaxID { get; set; }
        public string SGender { get; set; }
        public string TGender { get; set; }
        public string SFather { get; set; }
        public string TFather { get; set; }
        public string SecondInvPAN { get; set; }
        public string ThirdInvPAN { get; set; }
        public string ckycrefno1 { get; set; }
        public string ckycrefno2 { get; set; }
        public string ckycrefno3 { get; set; }
        public string ckycrefnog { get; set; }
        public string SCOB { get; set; }
        public string TCOB { get; set; }
        public string chequeCopy { get; set; }
        public string Status { get; set; }
    }
    public class FinalSubmit : IValidatableObject
    {
        [Required]
        [DefaultValue(false)]
        public bool undertaking { get; set; }
        [DefaultValue(false)]
        public bool isETF { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.undertaking != true)
            {
                results.Add(new ValidationResult("UnderTaking is mandatory.", new List<string> { "FinalSubmit" }));
            }
            return results;
        }
    }
    public class FinalSubmitRes
    {
        public string APP_REF_NO { get; set; }
        public string GoalId { get; set; }
        public string GroupId { get; set; }
        public string RefNo { get; set; }
        public string dateTimeStamp { get; set; }
        public string folio { get; set; }
        public string message { get; set; }
        public string statusCode { get; set; }
        public string transactionId { get; set; }
        //Added by Suryakant
        public string modeOfHolding { get; set; }
        public string bankName { get; set; }
        public string accountNo { get; set; }
        public string ifscCode { get; set; }
        public string micrCode { get; set; }

    }

    public class ZBFReq
    {
        public string trType { get; set; }
        public string folioNo { get; set; }
        public string accounttype { get; set; }
        public string bankAccountNo { get; set; }
        public string branchCode { get; set; }
        public char isDemat { get; set; }
    }
}
