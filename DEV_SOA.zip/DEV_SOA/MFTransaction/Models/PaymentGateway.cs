﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ApiCore.Model;

namespace MFTransaction.Models
{
    public class OrderRequest
    {
        //public string Records { get; set; }
        [Required]
        public string MainOrderId { get; set; }
        [Required]
        public string Amount { get; set; }
        [Required]
        public string TimeStamp { get; set; }
        public List<OrderRecord> itemDetails { get; set; }

        //Billdesk Fields
        public string PG_REQID { get; set; }
        public string PG_PGMERCID { get; set; }
        public string PG_MERCHANTID { get; set; }
        public string PG_CHECKSUMKEY { get; set; }
        public string PG_ADDITIONALINFO1 { get; set; }
        public string PG_ADDITIONALINFO2 { get; set; }
        public string PG_ADDITIONALINFO3 { get; set; }
        public string PG_ADDITIONALINFO4 { get; set; }
        public string PG_ADDITIONALINFO5 { get; set; }
        public string PG_ADDITIONALINFO6 { get; set; }
        public string PG_ADDITIONALINFO7 { get; set; }
        public string PG_FILLER1 { get; set; }
        public string PG_FILLER2 { get; set; }
        public string PG_FILLER3 { get; set; }
        public string TnxType { get; set; }

    }

    public class OrderRecord
    {
        //public string ID { get; set; }
        [Required]
        public string ChildOrderId { get; set; }
        //public string BankCode { get; set; }
        //public string BankAccNo { get; set; }
        [Required]
        public string Amount { get; set; }
    }

    #region Request XML classes
    public class REQUEST
    {
        private REQUESTTXNDATA tXNDATAField;
        private string cHECKSUMField;
        public REQUESTTXNDATA TXNDATA
        {
            get
            {
                return this.tXNDATAField;
            }
            set
            {
                this.tXNDATAField = value;
            }
        }
        public string CHECKSUM
        {
            get
            {
                return this.cHECKSUMField;
            }
            set
            {
                this.cHECKSUMField = value;
            }
        }
    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public class REQUESTTXNDATA
    {
        private REQUESTTXNDATATXNSUMMARY tXNSUMMARYField;
        private REQUESTTXNDATARECORD[] rECORDField;
        public REQUESTTXNDATATXNSUMMARY TXNSUMMARY
        {
            get
            {
                return this.tXNSUMMARYField;
            }
            set
            {
                this.tXNSUMMARYField = value;
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("RECORD")]
        public REQUESTTXNDATARECORD[] RECORD
        {
            get
            {
                return this.rECORDField;
            }
            set
            {
                this.rECORDField = value;
            }
        }
    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class REQUESTTXNDATATXNSUMMARY
    {
        private string rEQIDField;
        private string pGMERCIDField;
        private int rECORDSField;
        private string pGCUSTOMERIDField;
        private decimal aMOUNTField;
        private ulong tXNDATEField;

        /// <remarks/>
        public string REQID
        {
            get
            {
                return this.rEQIDField;
            }
            set
            {
                this.rEQIDField = value;
            }
        }
        /// <remarks/>
        public string PGMERCID
        {
            get
            {
                return this.pGMERCIDField;
            }
            set
            {
                this.pGMERCIDField = value;
            }
        }
        /// <remarks/>
        public int RECORDS
        {
            get
            {
                return this.rECORDSField;
            }
            set
            {
                this.rECORDSField = value;
            }
        }
        /// <remarks/>
        public string PGCUSTOMERID
        {
            get
            {
                return this.pGCUSTOMERIDField;
            }
            set
            {
                this.pGCUSTOMERIDField = value;
            }
        }
        /// <remarks/>
        public decimal AMOUNT
        {
            get
            {
                return this.aMOUNTField;
            }
            set
            {
                this.aMOUNTField = value;
            }
        }
        /// <remarks/>
        public ulong TXNDATE
        {
            get
            {
                return this.tXNDATEField;
            }
            set
            {
                this.tXNDATEField = value;
            }
        }
    }

    public partial class REQUESTTXNDATARECORD
    {
        private string mERCIDField;
        private decimal aMOUNTField;
        private string cUSTOMERIDField;
        private string aDDITIONALINFO1Field;
        private string aDDITIONALINFO2Field;
        private string aDDITIONALINFO3Field;
        private string aDDITIONALINFO4Field;
        private string aDDITIONALINFO5Field;
        private string aDDITIONALINFO6Field;
        private string aDDITIONALINFO7Field;
        private string fILLER1Field;
        private string fILLER2Field;
        private string fILLER3Field;
        private string idField;

        /// <remarks/>
        public string MERCID
        {
            get
            {
                return this.mERCIDField;
            }
            set
            {
                this.mERCIDField = value;
            }
        }
        /// <remarks/>
        public decimal AMOUNT
        {
            get
            {
                return this.aMOUNTField;
            }
            set
            {
                this.aMOUNTField = value;
            }
        }
        /// <remarks/>
        public string CUSTOMERID
        {
            get
            {
                return this.cUSTOMERIDField;
            }
            set
            {
                this.cUSTOMERIDField = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO1
        {
            get
            {
                return this.aDDITIONALINFO1Field;
            }
            set
            {
                this.aDDITIONALINFO1Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO2
        {
            get
            {
                return this.aDDITIONALINFO2Field;
            }
            set
            {
                this.aDDITIONALINFO2Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO3
        {
            get
            {
                return this.aDDITIONALINFO3Field;
            }
            set
            {
                this.aDDITIONALINFO3Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO4
        {
            get
            {
                return this.aDDITIONALINFO4Field;
            }
            set
            {
                this.aDDITIONALINFO4Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO5
        {
            get
            {
                return this.aDDITIONALINFO5Field;
            }
            set
            {
                this.aDDITIONALINFO5Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO6
        {
            get
            {
                return this.aDDITIONALINFO6Field;
            }
            set
            {
                this.aDDITIONALINFO6Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO7
        {
            get
            {
                return this.aDDITIONALINFO7Field;
            }
            set
            {
                this.aDDITIONALINFO7Field = value;
            }
        }
        /// <remarks/>
        public string FILLER1
        {
            get
            {
                return this.fILLER1Field;
            }
            set
            {
                this.fILLER1Field = value;
            }
        }
        /// <remarks/>
        public string FILLER2
        {
            get
            {
                return this.fILLER2Field;
            }
            set
            {
                this.fILLER2Field = value;
            }
        }
        /// <remarks/>
        public string FILLER3
        {
            get
            {
                return this.fILLER3Field;
            }
            set
            {
                this.fILLER3Field = value;
            }
        }

        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }
    #endregion

    public class OrderResponse
    {
        public string PGMercID { get; set; }
        public string PGCustomerID { get; set; }
        public string Records { get; set; }
        public string Amount { get; set; }
        public string StatusCode { get; set; }
        public string StatusDesc { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public List<OrderRecordRes> resItemDetails { get; set; }
        public string Checksum { get; set; }
        public string ExceptionMsg { get; set; }
        public string ExceptionLineNo { get; set; }
    }

    public class OrderRecordRes
    {
        //public string ID { get; set; }
        public string CustomerID { get; set; }
        public string EComTxnID { get; set; }
    }

    #region Response XML classes
    public class RESPONSE
    {
        private RESPONSETXNDATA tXNDATAField;
        private string cHECKSUMField;
        public RESPONSETXNDATA TXNDATA
        {
            get
            {
                return this.tXNDATAField;
            }
            set
            {
                this.tXNDATAField = value;
            }
        }
        public string CHECKSUM
        {
            get
            {
                return this.cHECKSUMField;
            }
            set
            {
                this.cHECKSUMField = value;
            }
        }
    }

    public class RESPONSETXNDATA
    {
        private RESPONSETXNDATATXNSUMMARY tXNSUMMARYField;
        private RESPONSETXNDATARECORD[] rECORDField;
        public RESPONSETXNDATATXNSUMMARY TXNSUMMARY
        {
            get
            {
                return this.tXNSUMMARYField;
            }
            set
            {
                this.tXNSUMMARYField = value;
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("RECORD")]
        public RESPONSETXNDATARECORD[] RECORD
        {
            get
            {
                return this.rECORDField;
            }
            set
            {
                this.rECORDField = value;
            }
        }
    }

    public class RESPONSETXNDATATXNSUMMARY
    {

        private string pGMERCIDField;

        private string pGCUSTOMERIDField;

        private int rECORDSField;

        private decimal aMOUNTField;

        private byte sTATUSCODEField;

        private string sTATUSDESCField;

        private string fILLER1Field;

        private string fILLER2Field;

        private string fILLER3Field;

        /// <remarks/>
        public string PGMERCID
        {
            get
            {
                return this.pGMERCIDField;
            }
            set
            {
                this.pGMERCIDField = value;
            }
        }

        /// <remarks/>
        public string PGCUSTOMERID
        {
            get
            {
                return this.pGCUSTOMERIDField;
            }
            set
            {
                this.pGCUSTOMERIDField = value;
            }
        }

        /// <remarks/>
        public int RECORDS
        {
            get
            {
                return this.rECORDSField;
            }
            set
            {
                this.rECORDSField = value;
            }
        }

        /// <remarks/>
        public decimal AMOUNT
        {
            get
            {
                return this.aMOUNTField;
            }
            set
            {
                this.aMOUNTField = value;
            }
        }

        /// <remarks/>
        public byte STATUSCODE
        {
            get
            {
                return this.sTATUSCODEField;
            }
            set
            {
                this.sTATUSCODEField = value;
            }
        }

        /// <remarks/>
        public string STATUSDESC
        {
            get
            {
                return this.sTATUSDESCField;
            }
            set
            {
                this.sTATUSDESCField = value;
            }
        }

        /// <remarks/>
        public string FILLER1
        {
            get
            {
                return this.fILLER1Field;
            }
            set
            {
                this.fILLER1Field = value;
            }
        }

        /// <remarks/>
        public string FILLER2
        {
            get
            {
                return this.fILLER2Field;
            }
            set
            {
                this.fILLER2Field = value;
            }
        }

        /// <remarks/>
        public string FILLER3
        {
            get
            {
                return this.fILLER3Field;
            }
            set
            {
                this.fILLER3Field = value;
            }
        }
    }

    public class RESPONSETXNDATARECORD
    {
        private string cUSTOMERIDField;
        private string eCOMTXNIDField;
        private byte idField;
        public string CUSTOMERID
        {
            get
            {
                return this.cUSTOMERIDField;
            }
            set
            {
                this.cUSTOMERIDField = value;
            }
        }
        public string ECOMTXNID
        {
            get
            {
                return this.eCOMTXNIDField;
            }
            set
            {
                this.eCOMTXNIDField = value;
            }
        }
        public byte ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }
    #endregion

    public class PaymentRequest
    {
        /// <summary>This is CustomerID for Billdesk</summary>
        [Required]
        public string MainOrderId { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed in bankAccNo field.")]
        public string BankAccNo { get; set; }
        [Required]
        public string TxnAmount { get; set; }
        [Required]
        public string BankID { get; set; }
        [Required]
        public string PG_ReturnURL { get; set; }
        public string PG_AdditionalInfo1 { get; set; }
        public string PG_AdditionalInfo2 { get; set; }
        public string PG_AdditionalInfo3 { get; set; }
        public string PG_AdditionalInfo4 { get; set; }
        public string PG_AdditionalInfo5 { get; set; }
        public string PG_AdditionalInfo6 { get; set; }
        public string PG_AdditionalInfo7 { get; set; }

        public string PG_MerchantID { get; set; }
        public string PG_CurrencyType { get; set; }
        public string PG_ProductID { get; set; }
        public string PG_TypeField1 { get; set; }
        public string PG_TypeField2 { get; set; }
        public string PG_SecurityID { get; set; }
        public string PG_ChecksumKey { get; set; }
        public string Mode { get; set; }
        public string TnxType { get; set; }

        //public string Checksum { get; set; }
    }

    public class PaymentResponse
    {
        public string PaymentURL { get; set; }
        public string ExceptionMsg { get; set; }
        public string ExceptionLineNo { get; set; }

    }

    #region Related to Serialization
    public class Utf8StringWriter : StringWriter
    {
        public override Encoding Encoding => Encoding.UTF8;
    }

    public static class XmlExtension
    {
        public static string Serialize<T>(this T value)
        {
            if (value == null) return string.Empty;
            try
            {
                var xmlSerializer = new XmlSerializer(typeof(T));
                using (var stringWriter = new Utf8StringWriter())
                {
                    //using (var xmlWriter = XmlWriter.Create(stringWriter, new XmlWriterSettings { Indent = true }))
                    using (var xmlWriter = XmlWriter.Create(stringWriter))
                    {
                        var ns = new XmlSerializerNamespaces();  //add empty namespace
                        ns.Add("", "");
                        xmlSerializer.Serialize(xmlWriter, value, ns);
                        return stringWriter.ToString().Replace("utf-8", "UTF-8");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred", ex);
            }
        }
    }
    #endregion

    public class PaymentConfirmationRes
    {
        public string pmsCode { get; set; }
        public string strategyName { get; set; }
        public string transactionRefrenceNumber { get; set; }
        public double transactionAmount { get; set; }
    }

    public class PaymentConfirm
    {
        [Required]
        /// <summary> "transactionRefrenceNumber" </summary>
        public Int64 transactionNo { get; set; }
        /// <summary> "MOTILALOAM" </summary>
        [Required]
        [DefaultValue("")]
        public string merchantId { get; set; }
        /// <summary> "GHDF4558070213" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionReferenceNo { get; set; }
        [Required]
        [DefaultValue("")]
        public string bankRef { get; set; }
        /// <summary> "Minimum Amount 1 lakh" </summary>
        [Required]
        [DefaultValue(0)]
        public double transactionAmount { get; set; }
        /// <summary> "Bank Short name" </summary>
        [Required]
        [DefaultValue("")]
        public string bankId { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string bankMerchantId { get; set; }
        /// <summary> "01" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionType { get; set; }
        /// <summary> "INR" </summary>
        [Required]
        [DefaultValue("")]
        public string currency { get; set; }
        [Required]
        [DefaultValue("")]
        public string itemCode { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityType { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityPassword { get; set; }
        [Required]
        [DefaultValue("")]
        public string transactionDate { get; set; }
        /// <summary> "0300: success" </summary>
        [DefaultValue("")]
        public string authStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string settlementType { get; set; }
        /// <summary> "PMSCODE" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info1 { get; set; }
        [Required]
        /// <summary> "Order no" </summary>
        [DefaultValue("")]
        public string additional_Info2 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info3 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info4 { get; set; }
        /// <summary> "NONLIQUID" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info5 { get; set; }
        /// <summary> "logic for generating Code-(RESIDENT-VAL-NA-L-NA-NA)" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info6 { get; set; }
        /// <summary> "Date Time in String " </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info7 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string erroStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string errorDescription { get; set; }
        [Required]
        [DefaultValue("")]
        public string checkSum { get; set; }
    }

    public class PaymentStatusResponse
    {
        public string _PaymentStatus { get; set; }
    }
    public class PaymentStatusRequest
    {
        public string CustomerID { get; set; }
        public string Checksum { get; set; }
    }
    public class ReqSIPPending
    {
        public OrderRequest _OrderRequest { get; set; }
        public string BankAccNo { get; set; }
        public string BankId { get; set; }
        public string FolioNo { get; set; }
    }

    public class RazorOrderRequest
    {
        [Required]
        public string amount { get; set; }
        [Required]
        public string method { get; set; }
        public string currency { get; set; }
        public string receipt { get; set; }
        public string payment_capture { get; set; }
        public List<OrderRecord> notes { get; set; }
        public string account_number { get; set; }
        public string name { get; set; }
        public string ifsc { get; set; }
        public Boolean IsTPV { get; set; }
    }

    public class RazorOrderResponse
    {
        public string orderid { get; set; }
    }

    public class ResponseOrderReq
    {
        public string razorpay_order_id { get; set; }
        public string razorpay_payment_id { get; set; }
        public string razorpay_signature { get; set; }
        public string receipt { get; set; }
        public string error { get; set; }
    }
    public class ResponseOrderRes
    {
        public string payment_status { get; set; }
    }
    public class WebhooksResponse
    {
        public string Karvystatus { get; set; }
        public string errorMessage { get; set; }
        public string webhooksrequest { get; set; }
    }
        public class WebhooksRequest
    {
        public string entity { get; set; }
        public string account_id { get; set; }
        public string Event { get; set; }
        public List<string> contains { get; set; }   //make it array  
        public webhookPaymentList payload { get; set; }
        public int created_at { get; set; }
    }
   
    public class webhookPaymentList
    {
        public webhookpayment payment { get; set; }
    }

    public class webhookpayment
    {
        public webhooksEntity entity { get; set; }
    }

    public class webhooksEntity
    {
        string _fee = string.Empty;
        string _tax = string.Empty;
            public string id { get; set; } 
            public string entity { get; set; } 
            public int amount { get; set; } 
            public string currency { get; set; } 
            public string status { get; set; } 
            public string order_id { get; set; } 
            public string invoice_id { get; set; } 
            public bool international { get; set; } 
            public string method { get; set; } 
            public int amount_refunded { get; set; } 
            public string refund_status { get; set; } 
            public bool captured { get; set; } 
            public string description { get; set; } 
            public string card_id { get; set; } 
            public string bank { get; set; } 
            public string wallet { get; set; } 
            public string vpa { get; set; } 
            public string email { get; set; } 
            public string contact { get; set; } 
            public Notes notes { get; set; } //make it array
            public int? fee { get; set; } 
            public int? tax { get; set; } 
            public string error_code { get; set; } 
            public string error_description { get; set; } 
            public string error_source { get; set; } 
            public string error_step { get; set; } 
            public string error_reason { get; set; } 
            public int created_at { get; set; } 
    }
    public class Notes
    {
       public string  ChildOrderId { get; set; }
       public string Amount { get; set; }
       public string BucketID { get; set; }
                 
    }
    public class EMandateReq : IValidatableObject
    {
        //public string holdingType { get; set; }
        //public string folioNo { get; set; }
        //public string period { get; set; }
        //public string accountType { get; set; }
        /// <summary> Ex. 10000 </summary>
        [Required]
        public int amount { get; set; }

        // public string currency { get; set; }
        /// <summary> 12 p.m. Meals </summary>
        [Required]
        public string description { get; set; }

        public Subscription_RegistrationsREQ _subscription_registration { get; set; }
        /// <summary> "13/11/2020" </summary>
        [Required]
        public string expire_by { get; set; }
        public NotesEmandate notes { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();

            var results = new List<ValidationResult>();
            //if (this.userId == 0)
            //{
            //    results.Add(new ValidationResult("Invalid userId.", new List<string> { nameof(userId) }));
            //}
            if (this.amount <=0 )
            {
                results.Add(new ValidationResult("Amount should be equal to Zero or Less then Zero", new List<string> { nameof(amount) }));
            }
            if (this._subscription_registration.max_amount <= 0)
            {
                results.Add(new ValidationResult("max_amount should be equal to Zero or Less then Zero", new List<string> { nameof(this._subscription_registration.max_amount) }));
            }
            return results;
        }
    }
    public class RazorPayEMandateReq
    {
        public Customers customer { get; set; }
        public string type { get; set; }
        public int amount { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        public Subscription_Registrations subscription_registration { get; set; }
        public string receipt { get; set; }
        public int expire_by { get; set; }
        public int sms_notify { get; set; }
        public int email_notify { get; set; }
        public NotesEmandate notes { get; set; }
        
    }
    public class Customers
    {
        public string name { get; set; }
        public string email { get; set; }
        public string contact { get; set; }
    }
    public class Subscription_RegistrationsREQ
    {
        /// <summary> emandate </summary>
        [Required]
        public string method { get; set; }
        /// <summary> netbanking </summary>
        [Required]
        public string auth_type { get; set; }
        /// <summary> "13/11/2020" </summary>
        [Required]
        public string expire_at { get; set; }
        /// <summary> 50000 </summary>
        [Required]
        public int max_amount { get; set; }
        public Bank_Account bank_account { get; set; }
    }
    public class Subscription_Registrations
    {
        /// <summary> emandate </summary>
        [Required]
        public string method { get; set; }
        /// <summary> netbanking </summary>
        [Required]
        public string auth_type { get; set; }
        /// <summary> 1980480689 </summary>
        [Required]
        public int expire_at { get; set; }
        /// <summary> 50000 </summary>
        [Required]
        public int max_amount { get; set; }
        public Bank_Account bank_account { get; set; }
    }
    public class Bank_Account
    {
        /// <summary> SuryaKant Kataria </summary>
        [Required]
        public string beneficiary_name { get; set; }
        /// <summary> 11214311215411 </summary>
        [Required]
        public string account_number { get; set; }
        /// <summary> savings </summary>
        [Required]
        public string account_type { get; set; }
        /// <summary> HDFC0001233 </summary>
        [Required]
        public string ifsc_code { get; set; }
    }
    public class NotesEmandate
    {
        /// <summary> test123 </summary>
        [Required]
        public string note_key1 { get; set; }
        /// <summary> test123 </summary>
        [Required]
        public string note_key2 { get; set; }
    }
    public class RazorPayEMandateRes
    {
        public string id { get; set; }
        public string entity { get; set; }
        public string receipt { get; set; }
        public string invoice_number { get; set; }
        public Customer_Details customer_details { get; set; }
        public string order_id { get; set; }
        public string[] line_items { get; set; }
        public string payment_id { get; set; }
        public string status { get; set; }
        public int? expire_by { get; set; }
        public int? issued_at { get; set; }
        public string paid_at { get; set; }
        public string cancelled_at { get; set; }
        public string expired_at { get; set; }
        public string sms_status { get; set; }
        public string email_status { get; set; }
        public int date { get; set; }
        public string terms { get; set; }
        public bool partial_payment { get; set; }
        public int gross_amount { get; set; }
        public int tax_amount { get; set; }
        public int taxable_amount { get; set; }
        public int amount { get; set; }
        public int amount_paid { get; set; }
        public int amount_due { get; set; }
        public string currency { get; set; }
        public string currency_symbol { get; set; }
        public string description { get; set; }
        public NotesEmandate notes { get; set; }
        public string comment { get; set; }
        public string short_url { get; set; }
        public string view_less { get; set; }
        public string billing_start { get; set; }
        public string billing_end { get; set; }
        public string type { get; set; }
        public string group_taxes_discounts { get; set; }
        public int created_at { get; set; }
        public string idempotency_key { get; set; }
    }
    public class Customer_Details
    {
        public string id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string contact { get; set; }
        public string gstin { get; set; }
        public string billing_address { get; set; }
        public string shipping_address { get; set; }
        public string customer_name { get; set; }
        public string customer_email { get; set; }
        public string customer_contact { get; set; }
    }
    public class RazorPayEMandateError
    {
       public ErrorRes error { get; set; }
    }
    public class ErrorRes
    {
        public string code { get; set; }
        public string description { get; set; }
        public string source { get; set; }
        public string step { get; set; }
        public string reason { get; set; }
        public metdataerrores metadata { get; set; }
    }
    public class metdataerrores
    {

    }
    public class RazorPayEmandateResponse
    {
        public string id { get; set; }
        public string receipt { get; set; }
       public string order_id { get; set; }
       public string Customer_id { get; set; }
       public string status { get; set; }
        public int? expire_by { get; set; }
    }
}