﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using ApiCore.Model;
using karvyAPI;
using MFTransaction.Models;
using MFTransaction.Utils;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Configuration;
using Dapper;
using ApiCore.Exceptions;
using System.IO;
using System.Collections.Generic;
using ApiCore.Helpers;
using MFTransaction.PaymentGateway;
namespace MFTransaction.InvestorDetails
{
    public class MFTransactionRepository : IMFTransactionDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly TokenHelper _tokenHelper;
        private readonly IOptionsSnapshot<DbConnections> _optionsSnapshot;
        private string ErrorLogFile = string.Empty;
        string serviceUrl = string.Empty;
        string Adminusername = string.Empty;
        string Adminpassword = string.Empty;
        string KarvTrnAPIName = string.Empty;
        string KarvTrnConfAPI = string.Empty;
        string KarvyEMandateAPI = string.Empty;
        string ReqLog = string.Empty;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        public MFTransactionRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _optionsSnapshot = connectionsSnapshot;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
            serviceUrl = _iconfiguration["StaticPath:URL:serviceUrl"];
            Adminusername = _iconfiguration["StaticPath:URL:Adminusername"];
            Adminpassword = _iconfiguration["StaticPath:URL:Adminpassword"];
            KarvTrnAPIName = _iconfiguration["StaticPath:URL:MFTransactionAPIName"];
            KarvTrnConfAPI = _iconfiguration["StaticPath:URL:MFTransactionConfAPIName"];
            KarvyEMandateAPI = _iconfiguration["StaticPath:URL:EMandateAPI"];
        }
        public async Task<ResponseDataModel<TransactionResponse>> saveMFClientTransactionSubmit(string AppID, long userId, TransactionRequest request, string PanNo, string UserAgent)
        {
            TransactionResponse finalSubmitRes = new TransactionResponse();
            TransactionReqResponse objTransactionReqResponse = new TransactionReqResponse();
            List<SipInvResponseDtl> LstsipInvResponseDtls = new List<SipInvResponseDtl>();
            List<LumpsumInvResponseDtl> LstLumpsumInvResponseDtls = new List<LumpsumInvResponseDtl>();
            string ErrorMsg = string.Empty;
            string inputJson = string.Empty;
            string ReqResponseXML = string.Empty;
            try
            {
                for (int i = 0; i < request.LumpsumInvestmentDetails.Count(); i++)
                {
                    request.LumpsumInvestmentDetails[i].OrderId = "OrderId_" + Convert.ToString(i + 1);
                }
                for (int i = 0; i < request.SIPInvestmentDetails.Count(); i++)
                {
                    request.SIPInvestmentDetails[i].OrderId = "OrderId_" + Convert.ToString(i + 1);
                }
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                input.Remove("IPAddress");
                input.Remove("QueryString");
                inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_MFTnx_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                    await File.AppendAllTextAsync(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r PanNo :" + Convert.ToString(PanNo) + "\r Request :" + inputJson);
                }
                objTransactionReqResponse._TransactionRequest = request;
                var result = KarvyRequest.CreateHTTPRequest(KarvTrnAPIName, serviceUrl, inputJson);
                var _Jobj = JObject.Parse(result);

                finalSubmitRes.BucketId = Convert.ToString(_Jobj["BucketId"]);
                finalSubmitRes.Campaign = Convert.ToString(_Jobj["Campaign"]);
                finalSubmitRes.TotalInvestAMount = Convert.ToString(_Jobj["TotalInvestAMount"]);
                finalSubmitRes.MORefNo = Convert.ToString(_Jobj["MORefNo"]);
                finalSubmitRes.TimeStamp = Convert.ToString(_Jobj["TimeStamp"]);
                finalSubmitRes.Message = Convert.ToString(_Jobj["Message"]);
                finalSubmitRes.BankId = Convert.ToString(_Jobj["BankId"]);
                finalSubmitRes.Status_Code = Convert.ToString(_Jobj["Status_Code"]);
                if (_Jobj["SipInvResponseDtls"].Count() > 0)
                {
                    for (int i = 0; i < _Jobj["SipInvResponseDtls"].Count(); i++)
                    {
                        SipInvResponseDtl objSipInvResponseDtl = new SipInvResponseDtl();
                        objSipInvResponseDtl.Amount = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Amount"]);
                        objSipInvResponseDtl.FolioNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["FolioNo"]);
                        objSipInvResponseDtl.Frequency = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Frequency"]);
                        objSipInvResponseDtl.GoalId = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["GoalId"]);
                        objSipInvResponseDtl.Message = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Message"]);
                        objSipInvResponseDtl.MOGPFREEZE = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["MOGPFREEZE"]);
                        objSipInvResponseDtl.MOGPID = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["MOGPID"]);
                        objSipInvResponseDtl.NoOfInstallment = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["NoOfInstallment"]);
                        objSipInvResponseDtl.Option = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Option"]);
                        objSipInvResponseDtl.Plan = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Plan"]);
                        objSipInvResponseDtl.Scheme = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Scheme"]);
                        objSipInvResponseDtl.SIPEndDate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["SIPEndDate"]);
                        objSipInvResponseDtl.SIPStartDate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["SIPStartDate"]);
                        objSipInvResponseDtl.Status_Code = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Status_Code"]);
                        objSipInvResponseDtl.TIME_STAMP = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TIME_STAMP"]);
                        objSipInvResponseDtl.TransRefNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TransRefNo"]);
                        objSipInvResponseDtl.TrType = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TrType"]);
                        objSipInvResponseDtl.UMRNexpirydate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["UMRNexpirydate"]);
                        objSipInvResponseDtl.UMRNNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["UMRNNo"]);
                        objSipInvResponseDtl.URNexpirydate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["URNexpirydate"]);
                        objSipInvResponseDtl.URNNO = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["URNNO"]);
                        objSipInvResponseDtl.OrderId = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["OrderId"]);
                        ErrorMsg = ErrorMsg + "," + objSipInvResponseDtl.Message;
                        LstsipInvResponseDtls.Add(objSipInvResponseDtl);
                    }
                    finalSubmitRes.SipInvResponseDtls = LstsipInvResponseDtls;
                }
                if (_Jobj["LumpsumInvResponseDtls"].Count() > 0)
                {
                    for (int i = 0; i < _Jobj["LumpsumInvResponseDtls"].Count(); i++)
                    {
                        LumpsumInvResponseDtl objLumpsumInvResponseDtl = new LumpsumInvResponseDtl();
                        objLumpsumInvResponseDtl.Amount = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Amount"]);
                        objLumpsumInvResponseDtl.FolioNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["FolioNo"]);
                        objLumpsumInvResponseDtl.GoalId = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["GoalId"]);
                        objLumpsumInvResponseDtl.Message = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Message"]);
                        objLumpsumInvResponseDtl.MOGPFREEZE = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["MOGPFREEZE"]);
                        objLumpsumInvResponseDtl.MOGPID = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["MOGPID"]);
                        objLumpsumInvResponseDtl.Option = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Option"]);
                        objLumpsumInvResponseDtl.Plan = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Plan"]);
                        objLumpsumInvResponseDtl.Scheme = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Scheme"]);
                        objLumpsumInvResponseDtl.Status_Code = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Status_Code"]);
                        objLumpsumInvResponseDtl.TIME_STAMP = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TIME_STAMP"]);
                        objLumpsumInvResponseDtl.TransRefNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TransRefNo"]);
                        objLumpsumInvResponseDtl.TrType = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TrType"]);
                        objLumpsumInvResponseDtl.UMRNexpirydate = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["UMRNexpirydate"]);
                        objLumpsumInvResponseDtl.UMRNNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["UMRNNo"]);
                        objLumpsumInvResponseDtl.URNexpirydate = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["URNexpirydate"]);
                        objLumpsumInvResponseDtl.URNNO = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["URNNO"]);
                        objLumpsumInvResponseDtl.OrderId = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["OrderId"]);
                        ErrorMsg = ErrorMsg + "," + objLumpsumInvResponseDtl.Message;
                        LstLumpsumInvResponseDtls.Add(objLumpsumInvResponseDtl);
                    }
                    finalSubmitRes.LumpsumInvResponseDtls = LstLumpsumInvResponseDtls;
                }
                objTransactionReqResponse._TransactionResponse = finalSubmitRes;
                ReqResponseXML = Utilities.ObjectToXMLString(objTransactionReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_CLIENT_TRANSACTION", new
                    {
                        ReqResponseData = ReqResponseXML,
                        PanNo = PanNo,
                        AppId = AppID,
                        ReqJson = inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<string>().FirstOrDefault();
                        finalSubmitRes.PurRefNo = Convert.ToInt64(Returnvalue);
                    }
                }
                if (finalSubmitRes.Status_Code == "200")
                {
                    return new ResponseDataModel<TransactionResponse>(finalSubmitRes);
                }
                else
                {
                    return new ResponseDataModel<TransactionResponse>(null, finalSubmitRes.Message.ToString()+" "+ ErrorMsg);
                }

            }
            catch (Exception ex)
            {
                if (request.SIPInvestmentDetails.Count() > 0)
                {
                    for (int i = 0; i < request.SIPInvestmentDetails.Count(); i++)
                    {
                        SipInvResponseDtl objSipInvResponseDtl = new SipInvResponseDtl();
                        objSipInvResponseDtl.Amount = Convert.ToString(request.SIPInvestmentDetails[i].Amount);
                        objSipInvResponseDtl.FolioNo = Convert.ToString(request.SIPInvestmentDetails[i].FolioNo);
                        objSipInvResponseDtl.Frequency = Convert.ToString(request.SIPInvestmentDetails[i].Frequency);
                        objSipInvResponseDtl.GoalId = Convert.ToString(request.SIPInvestmentDetails[i].GoalId);
                        objSipInvResponseDtl.Message = Convert.ToString(ex.Message);
                        objSipInvResponseDtl.MOGPFREEZE = Convert.ToString(request.SIPInvestmentDetails[i].MOGPFREEZE);
                        objSipInvResponseDtl.MOGPID = Convert.ToString(request.SIPInvestmentDetails[i].MOGPID);
                        objSipInvResponseDtl.NoOfInstallment = Convert.ToString(request.SIPInvestmentDetails[i].NoOfInstallment);
                        objSipInvResponseDtl.Option = Convert.ToString(request.SIPInvestmentDetails[i].Option);
                        objSipInvResponseDtl.Plan = Convert.ToString(request.SIPInvestmentDetails[i].Plan);
                        objSipInvResponseDtl.Scheme = Convert.ToString(request.SIPInvestmentDetails[i].Scheme);
                        objSipInvResponseDtl.SIPEndDate = Convert.ToString(request.SIPInvestmentDetails[i].SIPEndDate);
                        objSipInvResponseDtl.SIPStartDate = Convert.ToString(request.SIPInvestmentDetails[i].SIPStartDate);
                        objSipInvResponseDtl.Status_Code = Convert.ToString("0");
                        objSipInvResponseDtl.TIME_STAMP = Convert.ToString("");
                        objSipInvResponseDtl.TransRefNo = Convert.ToString(request.SIPInvestmentDetails[i].TransRefNo);
                        objSipInvResponseDtl.TrType = Convert.ToString(request.SIPInvestmentDetails[i].TrType);
                        objSipInvResponseDtl.UMRNexpirydate = Convert.ToString(request.SIPInvestmentDetails[i].URNexpirydate);
                        objSipInvResponseDtl.UMRNNo = Convert.ToString(request.SIPInvestmentDetails[i].UMRNNo);
                        objSipInvResponseDtl.OrderId = Convert.ToString(request.SIPInvestmentDetails[i].OrderId);
                        LstsipInvResponseDtls.Add(objSipInvResponseDtl);
                    }
                    finalSubmitRes.SipInvResponseDtls = LstsipInvResponseDtls;
                }
                if (request.LumpsumInvestmentDetails.Count() > 0)
                {
                    for (int i = 0; i < request.LumpsumInvestmentDetails.Count(); i++)
                    {
                        LumpsumInvResponseDtl objLumpsumInvResponseDtl = new LumpsumInvResponseDtl();
                        objLumpsumInvResponseDtl.Amount = Convert.ToString(request.LumpsumInvestmentDetails[i].Amount);
                        objLumpsumInvResponseDtl.FolioNo = Convert.ToString(request.LumpsumInvestmentDetails[i].FolioNo);
                        objLumpsumInvResponseDtl.GoalId = Convert.ToString(request.LumpsumInvestmentDetails[i].GoalId);
                        objLumpsumInvResponseDtl.Message = Convert.ToString(ex.Message);
                        objLumpsumInvResponseDtl.MOGPFREEZE = Convert.ToString(request.LumpsumInvestmentDetails[i].MOGPFREEZE);
                        objLumpsumInvResponseDtl.MOGPID = Convert.ToString(request.LumpsumInvestmentDetails[i].MOGPID);
                        objLumpsumInvResponseDtl.Option = Convert.ToString(request.LumpsumInvestmentDetails[i].Option);
                        objLumpsumInvResponseDtl.Plan = Convert.ToString(request.LumpsumInvestmentDetails[i].Plan);
                        objLumpsumInvResponseDtl.Scheme = Convert.ToString(request.LumpsumInvestmentDetails[i].Scheme);
                        objLumpsumInvResponseDtl.Status_Code = Convert.ToString("0");
                        objLumpsumInvResponseDtl.TIME_STAMP = Convert.ToString("");
                        objLumpsumInvResponseDtl.TransRefNo = Convert.ToString(request.LumpsumInvestmentDetails[i].TransRefNo);
                        objLumpsumInvResponseDtl.TrType = Convert.ToString(request.LumpsumInvestmentDetails[i].TrType);
                        objLumpsumInvResponseDtl.UMRNexpirydate = Convert.ToString(request.LumpsumInvestmentDetails[i].UMRNexpirydate);
                        objLumpsumInvResponseDtl.UMRNNo = Convert.ToString("");
                        objLumpsumInvResponseDtl.URNexpirydate = Convert.ToString(request.LumpsumInvestmentDetails[i].URNexpirydate);
                        objLumpsumInvResponseDtl.URNNO = Convert.ToString(request.LumpsumInvestmentDetails[i].URNNO);
                        objLumpsumInvResponseDtl.OrderId = Convert.ToString(request.LumpsumInvestmentDetails[i].OrderId);
                        LstLumpsumInvResponseDtls.Add(objLumpsumInvResponseDtl);
                    }
                    finalSubmitRes.LumpsumInvResponseDtls = LstLumpsumInvResponseDtls;
                }
                objTransactionReqResponse._TransactionResponse = finalSubmitRes;
                ReqResponseXML = Utilities.ObjectToXMLString(objTransactionReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_CLIENT_TRANSACTION", new
                    {
                        ReqResponseData = ReqResponseXML,
                        PanNo = PanNo,
                        AppId = AppID,
                        ReqJson = inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<string>().FirstOrDefault();
                        finalSubmitRes.PurRefNo = Convert.ToInt64(Returnvalue);
                    }
                }
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "saveMFClientTransactionSubmit \r ERROR:" + ex.Message);
                return new ResponseDataModel<TransactionResponse>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<BillDeskConsolidateResponse>> BillDeskConsolidate(string AppID, long userId, TransactionRequestConsolidate request, string PanNo, string UserAgent)
        {
            BillDeskConsolidateResponse FinalResponse = new BillDeskConsolidateResponse();
            long SIPTotal=0, LumpSumTotal=0;
            var branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            string TrTypeLumpSum = string.Empty;
            string TrTypeSIP = string.Empty;
            string ErrorMsg = string.Empty;
            TransactionResponse finalSubmitRes = new TransactionResponse();
            //TransactionResponseConsolidate finalSubmitSIPRes = new TransactionResponseConsolidate();
            TransactionReqResponseConsolidate objTransactionReqResponse = new TransactionReqResponseConsolidate();
            List<SipInvResponseDtl> LstsipInvResponseDtls = new List<SipInvResponseDtl>();
            List<LumpsumInvResponseDtl> LstLumpsumInvResponseDtls = new List<LumpsumInvResponseDtl>();

            List<InvestmentDetailConsolidateRef> LstLumpSumRefDetails = new List<InvestmentDetailConsolidateRef>();
            //LumSumResponseConsolidate objLumSumResponse = new LumSumResponseConsolidate();

            string inputJson = string.Empty;
            string ReqResponseXML = string.Empty;
            try
            {
                for (int i = 0; i < request.LumpsumInvestmentDetails.Count(); i++)
                {
                    TrTypeLumpSum = "LUMPSUM";
                    request.LumpsumInvestmentDetails[i].OrderId = "OrderId_" + Convert.ToString(i + 1);
                }
                for (int i = 0; i < request.SIPInvestmentDetails.Count(); i++)
                {
                    TrTypeSIP = "SIP";
                    request.SIPInvestmentDetails[i].OrderId = "OrderId_" + Convert.ToString(i + 1);
                }
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                input.Add("PurchaseDate", DateTime.Now.ToString("yyyy-MM-dd"));
                input.Add("Branch", Convert.ToString(branchCode));
                input.Remove("IPAddress");
                input.Remove("QueryString");
                foreach (var MyObj in input["LumpsumInvestmentDetails"])
                {
                    MyObj["ChequeType"] = Convert.ToString(request.PaymentMode);
                    MyObj["Paymode"] = Convert.ToString(request.PaymentMode);
                    MyObj["PG"] = Convert.ToString(request.PG);
                }

                foreach (var MyObj2 in input["SIPInvestmentDetails"])
                {
                    MyObj2["ChequeType"] = Convert.ToString(request.PaymentMode);
                }

                inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_MFTnx_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                   await File.AppendAllTextAsync(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r PanNo :" + Convert.ToString(PanNo) + "\r Request :" + inputJson);
                }
                objTransactionReqResponse._TransactionRequest = request;
                var result = KarvyRequest.CreateHTTPRequest(KarvTrnAPIName, serviceUrl, inputJson);
                var _Jobj = JObject.Parse(result);

                finalSubmitRes.BucketId = Convert.ToString(_Jobj["BucketId"]);
                finalSubmitRes.Campaign = Convert.ToString(_Jobj["Campaign"]);
                finalSubmitRes.TotalInvestAMount = Convert.ToString(_Jobj["TotalInvestAMount"]);
                finalSubmitRes.MORefNo = Convert.ToString(_Jobj["MORefNo"]);
                finalSubmitRes.TimeStamp = Convert.ToString(_Jobj["TimeStamp"]);
                finalSubmitRes.Message = Convert.ToString(_Jobj["Message"]);
                finalSubmitRes.BankId = Convert.ToString(_Jobj["BankId"]);
                finalSubmitRes.Status_Code = Convert.ToString(_Jobj["Status_Code"]);

                FinalResponse.BucketId = finalSubmitRes.BucketId;
                FinalResponse.SIPtotalAmount = "0";
                FinalResponse.LumpsumtotalAmount = "0";

                if (_Jobj["SipInvResponseDtls"].Count() > 0)
                {
                    for (int i = 0; i < _Jobj["SipInvResponseDtls"].Count(); i++)
                    {
                        SipInvResponseDtl objSipInvResponseDtl = new SipInvResponseDtl();
                        objSipInvResponseDtl.Amount = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Amount"]);
                        objSipInvResponseDtl.FolioNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["FolioNo"]);
                        objSipInvResponseDtl.Frequency = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Frequency"]);
                        objSipInvResponseDtl.GoalId = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["GoalId"]);
                        objSipInvResponseDtl.Message = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Message"]);
                        objSipInvResponseDtl.MOGPFREEZE = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["MOGPFREEZE"]);
                        objSipInvResponseDtl.MOGPID = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["MOGPID"]);
                        objSipInvResponseDtl.NoOfInstallment = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["NoOfInstallment"]);
                        objSipInvResponseDtl.Option = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Option"]);
                        objSipInvResponseDtl.Plan = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Plan"]);
                        objSipInvResponseDtl.Scheme = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Scheme"]);
                        objSipInvResponseDtl.SIPEndDate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["SIPEndDate"]);
                        objSipInvResponseDtl.SIPStartDate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["SIPStartDate"]);
                        objSipInvResponseDtl.Status_Code = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Status_Code"]);
                        objSipInvResponseDtl.TIME_STAMP = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TIME_STAMP"]);
                        objSipInvResponseDtl.TransRefNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TransRefNo"]);
                        objSipInvResponseDtl.TrType = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TrType"]);
                        objSipInvResponseDtl.UMRNexpirydate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["UMRNexpirydate"]);
                        objSipInvResponseDtl.UMRNNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["UMRNNo"]);
                        objSipInvResponseDtl.URNexpirydate = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["URNexpirydate"]);
                        objSipInvResponseDtl.URNNO = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["URNNO"]);
                        objSipInvResponseDtl.OrderId = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["OrderId"]);
                        SIPTotal = SIPTotal + Convert.ToInt64(objSipInvResponseDtl.Amount);
                        ErrorMsg = ErrorMsg + "," + objSipInvResponseDtl.Message;
                        LstsipInvResponseDtls.Add(objSipInvResponseDtl);
                    }
                    finalSubmitRes.SipInvResponseDtls = LstsipInvResponseDtls;
                    FinalResponse.SIPtotalAmount = SIPTotal.ToString();
                    FinalResponse.SIPResponse = LstsipInvResponseDtls;

                }
                if (_Jobj["LumpsumInvResponseDtls"].Count() > 0)
                {
                    for (int i = 0; i < _Jobj["LumpsumInvResponseDtls"].Count(); i++)
                    {
                        LumpsumInvResponseDtl objLumpsumInvResponseDtl = new LumpsumInvResponseDtl();
                        objLumpsumInvResponseDtl.Amount = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Amount"]);
                        objLumpsumInvResponseDtl.FolioNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["FolioNo"]);
                        objLumpsumInvResponseDtl.GoalId = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["GoalId"]);
                        objLumpsumInvResponseDtl.Message = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Message"]);
                        objLumpsumInvResponseDtl.MOGPFREEZE = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["MOGPFREEZE"]);
                        objLumpsumInvResponseDtl.MOGPID = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["MOGPID"]);
                        objLumpsumInvResponseDtl.Option = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Option"]);
                        objLumpsumInvResponseDtl.Plan = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Plan"]);
                        objLumpsumInvResponseDtl.Scheme = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Scheme"]);
                        objLumpsumInvResponseDtl.Status_Code = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Status_Code"]);
                        objLumpsumInvResponseDtl.TIME_STAMP = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TIME_STAMP"]);
                        objLumpsumInvResponseDtl.TransRefNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TransRefNo"]);
                        objLumpsumInvResponseDtl.TrType = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TrType"]);
                        objLumpsumInvResponseDtl.UMRNexpirydate = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["UMRNexpirydate"]);
                        objLumpsumInvResponseDtl.UMRNNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["UMRNNo"]);
                        objLumpsumInvResponseDtl.URNexpirydate = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["URNexpirydate"]);
                        objLumpsumInvResponseDtl.URNNO = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["URNNO"]);
                        objLumpsumInvResponseDtl.OrderId = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["OrderId"]);
                        LumpSumTotal = LumpSumTotal + Convert.ToInt64(objLumpsumInvResponseDtl.Amount);
                        ErrorMsg = ErrorMsg + "," + objLumpsumInvResponseDtl.Message;
                        LstLumpsumInvResponseDtls.Add(objLumpsumInvResponseDtl);

                        InvestmentDetailConsolidateRef ObjInvestmentDetailConsolidateRef = new InvestmentDetailConsolidateRef();
                        ObjInvestmentDetailConsolidateRef.Amount = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Amount"]);
                        ObjInvestmentDetailConsolidateRef.FolioNo = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["FolioNo"]);
                        ObjInvestmentDetailConsolidateRef.IHNON = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TransRefNo"]);
                        ObjInvestmentDetailConsolidateRef.Scheme = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Scheme"]);
                        LstLumpSumRefDetails.Add(ObjInvestmentDetailConsolidateRef);
                    }
                    finalSubmitRes.LumpsumInvResponseDtls = LstLumpsumInvResponseDtls;
                    FinalResponse.LumpsumtotalAmount = LumpSumTotal.ToString();
                    FinalResponse.LumpSumResponse = LstLumpSumRefDetails;
                }
                objTransactionReqResponse._TransactionResponse = finalSubmitRes;
                ReqResponseXML = Utilities.ObjectToXMLString(objTransactionReqResponse);
                ReqResponseXML = ReqResponseXML.Replace("<LumpsumInvestmentDetailConsolidate>", "<LumpsumInvestmentDetail>").Replace("</LumpsumInvestmentDetailConsolidate>", "</LumpsumInvestmentDetail>").Replace("<TransactionReqResponseConsolidate", "<TransactionReqResponse").Replace("</TransactionReqResponseConsolidate>", "</TransactionReqResponse>").Replace("<SIPInvestmentDetailConsolidate>", "<SIPInvestmentDetail>").Replace("</SIPInvestmentDetailConsolidate>", "</SIPInvestmentDetail>");
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_CLIENT_TRANSACTION", new
                    {
                        ReqResponseData = ReqResponseXML,
                        PanNo = PanNo,
                        AppId = AppID,
                        ReqJson = inputJson,
                        Branch = Convert.ToString(branchCode)
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<string>().FirstOrDefault();
                        finalSubmitRes.PurRefNo = Convert.ToInt64(Returnvalue);
                        FinalResponse.PurRefNo = finalSubmitRes.PurRefNo.ToString();
                    }
                }
                if (finalSubmitRes.Status_Code == "200")
                {
                    if (TrTypeSIP == "SIP" && TrTypeLumpSum=="")
                    {
                        return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse);
                    }
                    else if (TrTypeSIP == "SIP" && TrTypeLumpSum == "LUMPSUM")
                    {
                        OrderRequest ObjOrderRequest = new OrderRequest();
                        List<OrderRecord> itemDetails = new List<OrderRecord>();
                        if (finalSubmitRes.LumpsumInvResponseDtls.Count > 0)
                        {
                            foreach (var req in finalSubmitRes.LumpsumInvResponseDtls)
                            {
                                OrderRecord ObjOrderRecord = new OrderRecord();
                                ObjOrderRecord.Amount = req.Amount;
                                ObjOrderRecord.ChildOrderId = req.TransRefNo;
                                itemDetails.Add(ObjOrderRecord);
                            }
                            ObjOrderRequest.MainOrderId = finalSubmitRes.BucketId;
                            ObjOrderRequest.Amount = finalSubmitRes.TotalInvestAMount;
                            ObjOrderRequest.TimeStamp = finalSubmitRes.TimeStamp;
                            ObjOrderRequest.itemDetails = itemDetails;
                            PGBillDeskRepository ObjBGRepo = new PGBillDeskRepository(_optionsSnapshot, _iconfiguration);
                            var ResOrderGeneration = await ObjBGRepo.PaymentOrderGeneration(AppID, ObjOrderRequest);
                            if (ResOrderGeneration.data != null)
                            {
                                if (ResOrderGeneration.success == true && ResOrderGeneration.data.StatusCode == "0")
                                {
                                    //ResOrderGeneration.data.StatusCode ==20 Meaning
                                    PaymentRequest ObjPaymentRequest = new PaymentRequest();
                                    ObjPaymentRequest.MainOrderId = finalSubmitRes.BucketId;
                                    ObjPaymentRequest.BankAccNo = request.LumpsumInvestmentDetails[0].BankAccountNo;
                                    ObjPaymentRequest.TxnAmount = finalSubmitRes.TotalInvestAMount;
                                    ObjPaymentRequest.BankID = (request.PaymentMode == "DCB" || request.PaymentMode == "DC") ? finalSubmitRes.BankId : "HD4";
                                    ObjPaymentRequest.PG_ReturnURL = _iconfiguration["StaticPath:URL:PG_ReturnURL"];
                                    ObjPaymentRequest.PG_AdditionalInfo3 = request.LumpsumInvestmentDetails[0].FolioNo;
                                    ObjPaymentRequest.Mode = request.PaymentMode == "DC" ? "CARD" : "NETBANKING";
                                    var ResPaymentReq = await ObjBGRepo.PaymentRequest(AppID, ObjPaymentRequest);
                                    if (ResPaymentReq.success == true)
                                    {
                                        FinalResponse.PaymentURL = ResPaymentReq.data.PaymentURL;
                                        using (var conn = MOAMCMOBILEDB)
                                        {
                                            using (var SaveKarvyResp = await conn.QueryMultipleAsync("PROC_SAVE_PAYMENT_REQUEST", new
                                            {
                                                BucketId = ObjPaymentRequest.MainOrderId,
                                                PaymentURL = FinalResponse.PaymentURL
                                            }, commandType: CommandType.StoredProcedure)) ;
                                        }
                                        return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse);
                                    }
                                }
                                else
                                {
                                    return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse, Convert.ToString(ResOrderGeneration.data.StatusDesc),"Successful");
                                }
                            }else
                            {
                                return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse, Convert.ToString(ResOrderGeneration.message), "Successful");
                            }
                        }
                        return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse,"LumpSum is blank", "Successful");
                    }
                    else
                    {
                        OrderRequest ObjOrderRequest = new OrderRequest();
                        List<OrderRecord> itemDetails = new List<OrderRecord>();
                        if (finalSubmitRes.LumpsumInvResponseDtls.Count > 0)
                        {
                            foreach (var req in finalSubmitRes.LumpsumInvResponseDtls)
                            {
                                OrderRecord ObjOrderRecord = new OrderRecord();
                                ObjOrderRecord.Amount = req.Amount;
                                ObjOrderRecord.ChildOrderId = req.TransRefNo;
                                itemDetails.Add(ObjOrderRecord);
                            }
                            ObjOrderRequest.MainOrderId = finalSubmitRes.BucketId;
                            ObjOrderRequest.Amount = finalSubmitRes.TotalInvestAMount;
                            ObjOrderRequest.TimeStamp = finalSubmitRes.TimeStamp;
                            ObjOrderRequest.itemDetails = itemDetails;
                            PGBillDeskRepository ObjBGRepo = new PGBillDeskRepository(_optionsSnapshot, _iconfiguration);
                            var ResOrderGeneration = await ObjBGRepo.PaymentOrderGeneration(AppID, ObjOrderRequest);
                            if (ResOrderGeneration.data != null)
                            {
                                if (ResOrderGeneration.success == true && ResOrderGeneration.data.StatusCode == "0")
                                {
                                    //ResOrderGeneration.data.StatusCode ==20 Meaning
                                    PaymentRequest ObjPaymentRequest = new PaymentRequest();
                                    ObjPaymentRequest.MainOrderId = finalSubmitRes.BucketId;
                                    ObjPaymentRequest.BankAccNo = request.LumpsumInvestmentDetails[0].BankAccountNo;
                                    ObjPaymentRequest.TxnAmount = finalSubmitRes.TotalInvestAMount;
                                    ObjPaymentRequest.BankID = (request.PaymentMode == "DCB" || request.PaymentMode == "DC") ? finalSubmitRes.BankId : "HD4";
                                    ObjPaymentRequest.PG_ReturnURL = _iconfiguration["StaticPath:URL:PG_ReturnURL"];
                                    ObjPaymentRequest.PG_AdditionalInfo3 = request.LumpsumInvestmentDetails[0].FolioNo;
                                    ObjPaymentRequest.Mode = request.PaymentMode == "DC" ? "CARD" : "NETBANKING";
                                    var ResPaymentReq = await ObjBGRepo.PaymentRequest(AppID, ObjPaymentRequest);
                                    if (ResPaymentReq.success == true)
                                    {
                                        FinalResponse.PaymentURL = ResPaymentReq.data.PaymentURL;
                                        using (var conn = MOAMCMOBILEDB)
                                        {
                                            using (var SaveKarvyResp = await conn.QueryMultipleAsync("PROC_SAVE_PAYMENT_REQUEST", new
                                            {
                                                BucketId = ObjPaymentRequest.MainOrderId,
                                                PaymentURL = FinalResponse.PaymentURL
                                            }, commandType: CommandType.StoredProcedure)) ;
                                        }
                                        return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse);
                                    }
                                }
                                else
                                {
                                    return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse, Convert.ToString(ResOrderGeneration.data.StatusDesc),"Successful");
                                }
                            }else
                            {
                                return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse, Convert.ToString(ResOrderGeneration.message),"Successful");
                            }
                        }
                        return new ResponseDataModel<BillDeskConsolidateResponse>(FinalResponse, "LumpSum is blank","Successful");
                    }
                }
                else
                {
                    return new ResponseDataModel<BillDeskConsolidateResponse>(null, finalSubmitRes.Message.ToString()+ ErrorMsg);
                }

            }
            catch (Exception ex)
            {
                if (request.SIPInvestmentDetails.Count() > 0)
                {
                    for (int i = 0; i < request.SIPInvestmentDetails.Count(); i++)
                    {
                        SipInvResponseDtl objSipInvResponseDtl = new SipInvResponseDtl();
                        objSipInvResponseDtl.Amount = Convert.ToString(request.SIPInvestmentDetails[i].Amount);
                        objSipInvResponseDtl.FolioNo = Convert.ToString(request.SIPInvestmentDetails[i].FolioNo);
                        objSipInvResponseDtl.Frequency = Convert.ToString(request.SIPInvestmentDetails[i].Frequency);
                        objSipInvResponseDtl.GoalId = Convert.ToString(request.SIPInvestmentDetails[i].GoalId);
                        objSipInvResponseDtl.Message = Convert.ToString(ex.Message);
                        //objSipInvResponseDtl.MOGPFREEZE = Convert.ToString(request.SIPInvestmentDetails[i].MOGPFREEZE);
                        //objSipInvResponseDtl.MOGPID = Convert.ToString(request.SIPInvestmentDetails[i].MOGPID);
                        objSipInvResponseDtl.NoOfInstallment = Convert.ToString(request.SIPInvestmentDetails[i].NoOfInstallment);
                        objSipInvResponseDtl.Option = Convert.ToString(request.SIPInvestmentDetails[i].Option);
                        objSipInvResponseDtl.Plan = Convert.ToString(request.SIPInvestmentDetails[i].Plan);
                        objSipInvResponseDtl.Scheme = Convert.ToString(request.SIPInvestmentDetails[i].Scheme);
                        objSipInvResponseDtl.SIPEndDate = Convert.ToString(request.SIPInvestmentDetails[i].SIPEndDate);
                        objSipInvResponseDtl.SIPStartDate = Convert.ToString(request.SIPInvestmentDetails[i].SIPStartDate);
                        objSipInvResponseDtl.Status_Code = Convert.ToString("0");
                        objSipInvResponseDtl.TIME_STAMP = Convert.ToString("");
                        //objSipInvResponseDtl.TransRefNo = Convert.ToString(request.SIPInvestmentDetails[i].TransRefNo);
                        objSipInvResponseDtl.TrType = Convert.ToString(request.SIPInvestmentDetails[i].TrType);
                        objSipInvResponseDtl.UMRNexpirydate = Convert.ToString(request.SIPInvestmentDetails[i].URNexpirydate);
                        objSipInvResponseDtl.UMRNNo = Convert.ToString(request.SIPInvestmentDetails[i].UMRNNo);
                        objSipInvResponseDtl.OrderId = Convert.ToString(request.SIPInvestmentDetails[i].OrderId);
                        LstsipInvResponseDtls.Add(objSipInvResponseDtl);
                    }
                    finalSubmitRes.SipInvResponseDtls = LstsipInvResponseDtls;
                }
                if (request.LumpsumInvestmentDetails.Count() > 0)
                {
                    for (int i = 0; i < request.LumpsumInvestmentDetails.Count(); i++)
                    {
                        LumpsumInvResponseDtl objLumpsumInvResponseDtl = new LumpsumInvResponseDtl();
                        objLumpsumInvResponseDtl.Amount = Convert.ToString(request.LumpsumInvestmentDetails[i].Amount);
                        objLumpsumInvResponseDtl.FolioNo = Convert.ToString(request.LumpsumInvestmentDetails[i].FolioNo);
                        //objLumpsumInvResponseDtl.GoalId = Convert.ToString(request.LumpsumInvestmentDetails[i].GoalId);
                        objLumpsumInvResponseDtl.Message = Convert.ToString(ex.Message);
                        //objLumpsumInvResponseDtl.MOGPFREEZE = Convert.ToString(request.LumpsumInvestmentDetails[i].MOGPFREEZE);
                        //objLumpsumInvResponseDtl.MOGPID = Convert.ToString(request.LumpsumInvestmentDetails[i].MOGPID);
                        objLumpsumInvResponseDtl.Option = Convert.ToString(request.LumpsumInvestmentDetails[i].Option);
                        objLumpsumInvResponseDtl.Plan = Convert.ToString(request.LumpsumInvestmentDetails[i].Plan);
                        objLumpsumInvResponseDtl.Scheme = Convert.ToString(request.LumpsumInvestmentDetails[i].Scheme);
                        objLumpsumInvResponseDtl.Status_Code = Convert.ToString("0");
                        objLumpsumInvResponseDtl.TIME_STAMP = Convert.ToString("");
                        //objLumpsumInvResponseDtl.TransRefNo = Convert.ToString(request.LumpsumInvestmentDetails[i].TransRefNo);
                        objLumpsumInvResponseDtl.TrType = Convert.ToString(request.LumpsumInvestmentDetails[i].TrType);
                        // objLumpsumInvResponseDtl.UMRNexpirydate = Convert.ToString(request.LumpsumInvestmentDetails[i].UMRNexpirydate);
                        objLumpsumInvResponseDtl.UMRNNo = Convert.ToString("");
                        //objLumpsumInvResponseDtl.URNexpirydate = Convert.ToString(request.LumpsumInvestmentDetails[i].URNexpirydate);
                        //objLumpsumInvResponseDtl.URNNO = Convert.ToString(request.LumpsumInvestmentDetails[i].URNNO);
                        objLumpsumInvResponseDtl.OrderId = Convert.ToString(request.LumpsumInvestmentDetails[i].OrderId);
                        LstLumpsumInvResponseDtls.Add(objLumpsumInvResponseDtl);
                    }
                    finalSubmitRes.LumpsumInvResponseDtls = LstLumpsumInvResponseDtls;
                }
                objTransactionReqResponse._TransactionResponse = finalSubmitRes;
                ReqResponseXML = Utilities.ObjectToXMLString(objTransactionReqResponse);
                ReqResponseXML = ReqResponseXML.Replace("<LumpsumInvestmentDetailConsolidate>", "<LumpsumInvestmentDetail>").Replace("</LumpsumInvestmentDetailConsolidate>", "</LumpsumInvestmentDetail>").Replace("<TransactionReqResponseConsolidate", "<TransactionReqResponse").Replace("</TransactionReqResponseConsolidate>", "</TransactionReqResponse>").Replace("<SIPInvestmentDetailConsolidate>", "<SIPInvestmentDetail>").Replace("</SIPInvestmentDetailConsolidate>", "</SIPInvestmentDetail>");
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_CLIENT_TRANSACTION", new
                    {
                        ReqResponseData = ReqResponseXML,
                        PanNo = PanNo,
                        AppId = AppID,
                        ReqJson = inputJson,
                        Branch = Convert.ToString(branchCode)
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<string>().FirstOrDefault();
                        finalSubmitRes.PurRefNo = Convert.ToInt64(Returnvalue);
                    }
                }
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "BillDeskConsolidate \r ERROR:" + ex.Message);
                return new ResponseDataModel<BillDeskConsolidateResponse>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<TransactionConfirmationRes>> TransactionConfirmation(string AppID, long userId, TransactionConfirmationReq request, string UserAgent)
        {
            try
            {
                TransactionConfirmationRes ObjResponse = new TransactionConfirmationRes();
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                string inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxConfLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_MFTnxConf_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                    await File.AppendAllTextAsync(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r Request :" + inputJson);
                }
                var result = KarvyRequest.CreateHTTPRequest(KarvTrnConfAPI, serviceUrl, inputJson);
                var _Jobj = JObject.Parse(result);

                if (_Jobj.Count > 0)
                {
                    ObjResponse.Acno = Convert.ToString(_Jobj["Acno"]);
                    ObjResponse.Appno = Convert.ToString(_Jobj["Appno"]);
                    ObjResponse.Message = Convert.ToString(_Jobj["Message"]);
                    ObjResponse.Status_Code = Convert.ToString(_Jobj["Status_Code"]);
                    ObjResponse.TxnAmount = Convert.ToString(_Jobj["TxnAmount"]);
                }

                return new ResponseDataModel<TransactionConfirmationRes>(ObjResponse);
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "TransactionConfirmation \r ERROR:" + ex.Message);
                return new ResponseDataModel<TransactionConfirmationRes>(null, ex.Message);
            }
        }
        public async Task<ResponseDataModel<EMandateRegRes>> EMandateRegistration(string AppID, long userId, int RefNo, string UserAgent)
        {
            EMandateRegRes ObjResponse = new EMandateRegRes();
            EMandateRegReq request = new EMandateRegReq();
            string inputJson = string.Empty;
            EMandateReqResponse objEMandateReqResponse = new EMandateReqResponse();
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var dataSave = await conn.QueryAsync("MF.GET_OTM_DETAILS", new
                    {
                        RefNo = RefNo,
                        Flag = 1
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var EMandateReq = dataSave.ToList();
                        if (EMandateReq.Count > 0)
                        {
                            request.AccountType = EMandateReq[0].AccountType ?? "";
                            request.Amount = Convert.ToString(EMandateReq[0].Amount) ?? "0";
                            request.Authorize = EMandateReq[0].Authorize ?? "";
                            request.BankAcno = EMandateReq[0].BankAcno ?? "";
                            request.SponsorBank = EMandateReq[0].SponsorBank_Code ?? "";
                            request.BankName = EMandateReq[0].BankName ?? "";
                            request.BranchCode = EMandateReq[0].BranchCode ?? "";
                            request.BankHolderName = EMandateReq[0].BankHolderName ?? "";
                            request.ChequeCopy = EMandateReq[0].Cheque_Image ?? "";
                            request.ClientId = EMandateReq[0].ClientId ?? "";
                            request.Debittype = EMandateReq[0].Debittype ?? "";
                            request.EmailId = EMandateReq[0].EmailId ?? "";
                            request.Frequency = EMandateReq[0].Frequency ?? "";
                            request.FromDate = Convert.ToString(EMandateReq[0].FromDate.ToString("yyyy-MM-dd"));
                            if (string.IsNullOrEmpty(EMandateReq[0].ToDate))
                            {
                                request.Todate = "";
                            }
                            else
                            {
                                request.Todate = Convert.ToString(Convert.ToDateTime(EMandateReq[0].ToDate).ToString("yyyy-MM-dd"));
                            }
                            request.IFSCCode = EMandateReq[0].IFSCCode ?? "";
                            request.Image = EMandateReq[0].OTM_Image ?? "";
                            request.MICRCode = EMandateReq[0].MICRCode ?? "";
                            request.MobileNo = EMandateReq[0].MobileNo ?? "";
                            request.Mode = EMandateReq[0].OTM_MODE ?? "";
                            request.OTMDate = Convert.ToString(EMandateReq[0].OTM_DATE.ToString("yyyy-MM-dd"));
                            request.ReferenceID = EMandateReq[0].ReferenceID ?? "";
                            request.RefNo = Convert.ToString(EMandateReq[0].RefNo);
                            request.UMRN = EMandateReq[0].UMRN_NO ?? "";
                            request.Utilitycode = EMandateReq[0].Utility_Code ?? "";
                            request.RegMode = EMandateReq[0].RegMode ?? "";
                            request.ReceiptNo = Convert.ToString(EMandateReq[0].ReceiptNo) ?? "";
                            request.ToDebit = EMandateReq[0].ToDebit ?? "";
                            request.PANNO = EMandateReq[0].PANNO ?? "";
                            request.InvestorName = EMandateReq[0].InvestorName ?? "";
                            request.ImageType = EMandateReq[0].ImageType ?? "";
                        }
                    }
                }
                objEMandateReqResponse._EMandateRegReq = request;
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxEMandateLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_EMandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Date.ToString("dd") + ".txt";
                    await File.AppendAllTextAsync(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r Request :" + inputJson);
                }
                var result = KarvyRequest.CreateHTTPRequest(KarvyEMandateAPI, serviceUrl, inputJson);
                if (Convert.ToString(result) != "" && Convert.ToString(result) != null)
                {
                    var _Jobj = JObject.Parse(result);
                    if (_Jobj.Count > 0)
                    {
                        ObjResponse.RefNo = Convert.ToString(_Jobj["RefNo"]);
                        ObjResponse.ReferenceID = Convert.ToString(_Jobj["ReferenceID"]);
                        ObjResponse.Message = Convert.ToString(_Jobj["Message"]);
                        ObjResponse.Status_Code = Convert.ToString(_Jobj["Status_Code"]);
                    }
                    objEMandateReqResponse._EMandateRegRes = ObjResponse;
                }
                else
                {
                    ObjResponse.RefNo = Convert.ToString(RefNo);
                    ObjResponse.Message = "Blank Response By Karvy";
                    ObjResponse.ReferenceID = "";
                    ObjResponse.Status_Code = "";
                    objEMandateReqResponse._EMandateRegRes = ObjResponse;
                }
                string ReqResponseXML = Utilities.ObjectToXMLString(objEMandateReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_OTM_EMANDATE", new
                    {
                        ReqResponseData = ReqResponseXML,
                        ReqJson = inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<int>().FirstOrDefault();
                    }
                }
                if (ObjResponse.Status_Code == "200")
                {
                    return new ResponseDataModel<EMandateRegRes>(ObjResponse);
                }
                else
                {
                    return new ResponseDataModel<EMandateRegRes>(null, Convert.ToString(ObjResponse.Message));
                }
            }
            catch (Exception ex)
            {
                objEMandateReqResponse._EMandateRegRes.Message = ex.Message.ToString();
                string ReqResponseXML = Utilities.ObjectToXMLString(objEMandateReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_OTM_EMANDATE", new
                    {
                        ReqResponseData = ReqResponseXML,
                        ReqJson = inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<int>().FirstOrDefault();
                    }
                }
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "EMandateRegistration \r ERROR:" + ex.Message);
                return new ResponseDataModel<EMandateRegRes>(null, ex.Message);
            }
        }
        public async Task<ResponseDataArrayModel<OTMDetails>> GetOTMDetails(OTMReq request, string PanNo)
        {
            List<OTMDetails> objLstOTMDetails = new List<OTMDetails>();
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("MF.GET_OTM_DETAILS", new
                    {
                        PanNo = PanNo,
                        HoldingType = request.ModeOfHolding,
                    }, commandTimeout: 0, commandType: CommandType.StoredProcedure);

                    var ObjOTMList = multi.ToList();
                    if (ObjOTMList.Count > 0)
                    {
                        for (int i = 0; i < ObjOTMList.Count; i++)
                        {
                            OTMDetails ObjOTMDetails = new OTMDetails();
                            ObjOTMDetails.RefNo = Convert.ToString(ObjOTMList[i].RefNo ?? 0);
                            ObjOTMDetails.BankName = ObjOTMList[i].BankName ?? "";
                            ObjOTMDetails.BankAccNo = ObjOTMList[i].BankAccNo ?? "";
                            ObjOTMDetails.MinAmount = ObjOTMList[i].MinAmount ?? 0;
                            ObjOTMDetails.RegistrationDate = ObjOTMList[i].RegistrationDate.ToString("yyyy-MM-dd");
                            ObjOTMDetails.Status = Convert.ToString(ObjOTMList[i].Status);
                            ObjOTMDetails.UMRN_NO = ObjOTMList[i].UMRN_NO ?? "";

                            ObjOTMDetails.AccountType = ObjOTMList[i].AccountType ?? "";
                            ObjOTMDetails.Authorize = ObjOTMList[i].Authorize ?? "";
                            ObjOTMDetails.BankAcno = ObjOTMList[i].BankAcno ?? "";
                            ObjOTMDetails.SponsorBank = ObjOTMList[i].SponsorBank_Code ?? "";
                            ObjOTMDetails.BankName = ObjOTMList[i].BankName ?? "";
                            ObjOTMDetails.BranchCode = ObjOTMList[i].BranchCode ?? "";
                            ObjOTMDetails.BankHolderName = ObjOTMList[i].BankHolderName ?? "";
                            ObjOTMDetails.ChequeImage = ObjOTMList[i].Cheque_Image ?? "";
                            ObjOTMDetails.ClientId = ObjOTMList[i].ClientId ?? "";
                            ObjOTMDetails.Debittype = ObjOTMList[i].Debittype ?? "";
                            ObjOTMDetails.EmailId = ObjOTMList[i].EmailId ?? "";
                            ObjOTMDetails.Frequency = ObjOTMList[i].Frequency ?? "";
                            if (ObjOTMList[i].FromDate == null)
                            {
                                ObjOTMDetails.FromDate = Convert.ToString(default(DateTime).ToString("yyyy-MM-dd"));
                            }
                            else
                            {
                                ObjOTMDetails.FromDate = Convert.ToString(ObjOTMList[i].FromDate.ToString("yyyy-MM-dd"));
                            }
                            if (string.IsNullOrEmpty(ObjOTMList[i].ToDate))
                            {
                                ObjOTMDetails.Todate = ObjOTMList[i].ToDate ?? "";
                            }
                            else
                            {
                                ObjOTMDetails.Todate = Convert.ToString(Convert.ToDateTime(ObjOTMList[i].ToDate).ToString("yyyy-MM-dd"));
                            }
                            ObjOTMDetails.IFSCCode = ObjOTMList[i].IFSCCode ?? "";
                            ObjOTMDetails.Image = ObjOTMList[i].OTM_Image ?? "";
                            ObjOTMDetails.MICRCode = ObjOTMList[i].MICRCode ?? "";
                            ObjOTMDetails.MobileNo = ObjOTMList[i].MobileNo ?? "";
                            ObjOTMDetails.Mode = ObjOTMList[i].OTM_MODE ?? "";
                            if (ObjOTMList[i].OTM_DATE == null)
                            {
                                ObjOTMDetails.OTMDate = Convert.ToString(default(DateTime).ToString("yyyy-MM-dd"));
                            }
                            else
                            {
                                ObjOTMDetails.OTMDate = Convert.ToString(ObjOTMList[i].OTM_DATE.ToString("yyyy-MM-dd"));
                            }
                            ObjOTMDetails.ReferenceID = ObjOTMList[i].ReferenceID ?? "";
                            ObjOTMDetails.Utilitycode = ObjOTMList[i].Utility_Code ?? "";
                            ObjOTMDetails.ToDebit = ObjOTMList[i].ToDebit ?? "";
                            ObjOTMDetails.PANNO = ObjOTMList[i].PANNO ?? "";
                            ObjOTMDetails.InvestorName = ObjOTMList[i].InvestorName ?? "";
                            ObjOTMDetails.ImageType = ObjOTMList[i].ImageType ?? "";
                            objLstOTMDetails.Add(ObjOTMDetails);
                        }
                    }
                    return new ResponseDataArrayModel<OTMDetails>(objLstOTMDetails);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetOTMDetails \r ERROR:" + ex.Message);
                return new ResponseDataArrayModel<OTMDetails>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<FinalSubmitEMandate>> SaveOTMDetails(EMandateRegReq request)
        {
            EMandateReqResponse objEMandateReqResponse = new EMandateReqResponse();
            FinalSubmitEMandate objFinalSubmitEMandate = new FinalSubmitEMandate();
            objEMandateReqResponse._EMandateRegReq = request;
            objEMandateReqResponse._EMandateRegRes = null;
            try
            {
                string ReqResponseXML = Utilities.ObjectToXMLString(objEMandateReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_OTM_EMANDATE", new
                    {
                        ReqResponseData = ReqResponseXML,
                    }, commandType: CommandType.StoredProcedure))
                    {
                        int RefNo = 0;
                        var Returnvalue = SaveKarvyResp.Read<int>().FirstOrDefault();
                        RefNo = Convert.ToInt32(Returnvalue);
                        objFinalSubmitEMandate.RefNo = RefNo;
                    }
                    return new ResponseDataModel<FinalSubmitEMandate>(objFinalSubmitEMandate);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveOTMDetails \r ERROR:" + ex.Message);
                return new ResponseDataModel<FinalSubmitEMandate>(null, Convert.ToString(ex.Message));
            }
        }

        public async Task<ResponseDataModel<SaveOTMConsolidateRes>> SaveOTMDetailsConsolidate(EMandateRegReqConsolidate request, string AppID, long userId, string PanNo, string UserAgent)
        {
            try
            {
                SaveOTMConsolidateRes ObjSaveOTMConsolidateRes = new SaveOTMConsolidateRes();
                ObjSaveOTMConsolidateRes.ObjEMandateRegRes = new EMandateRegRes();
                ObjSaveOTMConsolidateRes.ObjLstOTMDetails = new List<OTMDetails>();
                EMandateRegReq ObjEMandateRegReq = new EMandateRegReq();
                EMandateRegRes ObjEMandateRegResponse = new EMandateRegRes();
                ObjEMandateRegReq = request.ObjEMandateRegReq;
                var SaveOTMresponse = await SaveOTMDetails(ObjEMandateRegReq);
                if (SaveOTMresponse.message == "Successful")
                {
                    var EMandateRegistrationRes = await EMandateRegistration(AppID, userId, SaveOTMresponse.data.RefNo, UserAgent);
                    if (EMandateRegistrationRes.message == "Successful")
                    {
                        ObjEMandateRegResponse.Message = Convert.ToString(EMandateRegistrationRes.data.Message);
                        ObjEMandateRegResponse.ReferenceID = Convert.ToString(EMandateRegistrationRes.data.ReferenceID);
                        ObjEMandateRegResponse.RefNo = Convert.ToString(EMandateRegistrationRes.data.RefNo);
                        ObjEMandateRegResponse.Status_Code = Convert.ToString(EMandateRegistrationRes.data.Status_Code);
                        ObjSaveOTMConsolidateRes.ObjEMandateRegRes = ObjEMandateRegResponse;
                    }
                }
                var ListOfOTM = await GetOTMDetails(request.ObjOTMReq, PanNo);
                if (ListOfOTM.message == "Successful" && ListOfOTM.data.Count() > 0)
                {
                    ObjSaveOTMConsolidateRes.ObjLstOTMDetails = ListOfOTM.data.ToList();
                }
                return new ResponseDataModel<SaveOTMConsolidateRes>(ObjSaveOTMConsolidateRes);
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveOTMDetailsConsolidate \r ERROR:" + ex.Message);
                return new ResponseDataModel<SaveOTMConsolidateRes>(null, Convert.ToString(ex.Message));
            }
        }

        public async Task<ResponseDataArrayModel<ResSIPURNDetails>> GetSipMandateUmrnDetails(string PanNo)
        {
            string inputJson = string.Empty;
            List<ResSIPURNDetails> objSIPURN = new List<ResSIPURNDetails>();
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Pan = PanNo
                };
                inputJson = JsonConvert.SerializeObject(input);
                //var result = KarvyRequest.CreateHTTPRequest("MOSLSipMandateUmrnDetails", serviceUrl, inputJson);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSipMandateUmrnDetails", "https://online.motilaloswalmf.com/MobileAPIServicesLive/MasterAPIService.svc", inputJson);
                var s = JArray.Parse(result);

                var listBoosted = new List<ResSIPURNDetails>();
                if ((s.Count > 0))
                {
                    using (var conn3 = MOAMCMOBILEDB)
                    {
                        var multi = await conn3.QueryAsync("MF.Get_SipMandate_UmrnDetails", new
                        {
                            PAN_NO = PanNo,
                        }, commandType: CommandType.StoredProcedure);
                        listBoosted = (from value in multi.ToList()
                                       select new ResSIPURNDetails
                                       {
                                           URNNumber = value.URN_NO,
                                           UMRNNo = value.UMRN_NO,
                                           BoostedAmount = value.TOPUP_AMOUNT,
                                           FrequencyBoost = value.TOPUP_FREQUENCY,
                                           LimitAmountofBooster = value.TOPUP_LIMIT
                                       }).ToList();
                    }

                    foreach (var p in s.ToList())
                    {
                        ResSIPURNDetails ObjResSIPURNDetails = new ResSIPURNDetails();
                        ObjResSIPURNDetails.InvestorName = Convert.ToString(p["InvestorName"]);
                        ObjResSIPURNDetails.Foliono = Convert.ToString(p["FolioNo"]);
                        ObjResSIPURNDetails.Mobile = Convert.ToString(p["MobileNo"]);
                        ObjResSIPURNDetails.Email = Convert.ToString(p["Email"]);
                        ObjResSIPURNDetails.Pan = Convert.ToString(p["Pan"]);
                        ObjResSIPURNDetails.ReferenceNumber = Convert.ToString(p["ReferenceNumber"]);
                        ObjResSIPURNDetails.URNNumber = Convert.ToString(p["URNNumber"]);
                        ObjResSIPURNDetails.SchemeCode = Convert.ToString(p["SchemeCode"]);
                        ObjResSIPURNDetails.SchemeDescription = Convert.ToString(p["SchemeDescription"]);
                        ObjResSIPURNDetails.UrnStatus = Convert.ToString(p["UrnStatus"]);
                        ObjResSIPURNDetails.RegistrationDate = Convert.ToString(p["RegistrationDate"]);
                        ObjResSIPURNDetails.Frequency = Convert.ToString(p["Frequency"]);
                        ObjResSIPURNDetails.Amount = Convert.ToString(p["Amount"]);
                        ObjResSIPURNDetails.ActivationDate = Convert.ToString(p["ActivationDate"]);
                        ObjResSIPURNDetails.ExpiryDate = Convert.ToString(p["ExpiryDate"]);
                        ObjResSIPURNDetails.WithEffectDate = Convert.ToString(p["WithEffectDate"]);
                        ObjResSIPURNDetails.Holdingtype = Convert.ToString(p["Holdingtype"]);
                        ObjResSIPURNDetails.BankName = Convert.ToString(p["BankName"]);
                        ObjResSIPURNDetails.Accountnumber = Convert.ToString(p["Accountnumber"]);
                        ObjResSIPURNDetails.IFSCCode = Convert.ToString(p["IFSCCode"]);
                        ObjResSIPURNDetails.BillerName = Convert.ToString(p["BillerName"]);
                        ObjResSIPURNDetails.SponsorBankCode = Convert.ToString(p["SponsorBankCode"]);
                        ObjResSIPURNDetails.MandateStatus = Convert.ToString(p["MandateStatus"]);
                        ObjResSIPURNDetails.Curvalue = Convert.ToString(p["Currentvalue"]);
                        ObjResSIPURNDetails.MandateAmount = Convert.ToString(p["MandateAmount"]);
                        ObjResSIPURNDetails.MandateExpiryDate = Convert.ToString(p["MandateExpiryDate"]);
                        ObjResSIPURNDetails.UMRNNo = Convert.ToString(p["UMRNNo"]);
                        ObjResSIPURNDetails.Tenure = !string.IsNullOrEmpty(Convert.ToString(p["ActivationDate"])) ? !string.IsNullOrEmpty(Convert.ToString(p["ExpiryDate"])) ? Utilities.DateDiffInYear(Convert.ToDateTime(p["ActivationDate"]), Convert.ToDateTime(p["ExpiryDate"])) : "" : "";
                        ObjResSIPURNDetails.InvestmentAmt = Convert.ToString(p["InvestmentAmt"]);
                        ObjResSIPURNDetails.Distributor = Convert.ToString(p["Distributor"]);
                        foreach (var d in listBoosted)
                        {
                            string URNURM = string.Empty;
                            if (!string.IsNullOrEmpty(d.URNNumber))
                            {
                                URNURM = d.URNNumber;
                            }
                            else
                            {
                                URNURM = d.UMRNNo;
                            }
                            if (URNURM == Convert.ToString(p["URNNumber"]))
                            {
                                ObjResSIPURNDetails.Boosted = true;
                                ObjResSIPURNDetails.BoostedAmount = Convert.ToString(d.BoostedAmount);
                                ObjResSIPURNDetails.FrequencyBoost = Convert.ToString(d.FrequencyBoost);
                                ObjResSIPURNDetails.LimitAmountofBooster = Convert.ToString(d.LimitAmountofBooster);
                                break;
                            }
                            else if (URNURM == Convert.ToString(p["UMRNNo"]))
                            {
                                ObjResSIPURNDetails.Boosted = true;
                                ObjResSIPURNDetails.BoostedAmount = Convert.ToString(d.BoostedAmount);
                                ObjResSIPURNDetails.FrequencyBoost = Convert.ToString(d.FrequencyBoost);
                                ObjResSIPURNDetails.LimitAmountofBooster = Convert.ToString(d.LimitAmountofBooster);
                                break;
                            }
                            else
                            {
                                ObjResSIPURNDetails.Boosted = false;
                                ObjResSIPURNDetails.BoostedAmount = "";
                                ObjResSIPURNDetails.FrequencyBoost = "";
                                ObjResSIPURNDetails.LimitAmountofBooster = "";
                            }
                        }
                        ObjResSIPURNDetails.GainLoss = Math.Round(Convert.ToDouble(p["InvestmentAmt"]) != 0.00 ? (Convert.ToDouble(p["Currentvalue"]) - Convert.ToDouble(p["InvestmentAmt"])) / Convert.ToDouble(p["InvestmentAmt"]) * 100 : 0.0, 2);
                        objSIPURN.Add(ObjResSIPURNDetails);
                    };


                    //objSIPURN = (from p in s.ToList()
                    //             select new ResSIPURNDetails
                    //             {
                    //                 InvestorName = Convert.ToString(p["InvestorName"]),
                    //                 Foliono = Convert.ToString(p["FolioNo"]),
                    //                 Mobile = Convert.ToString(p["MobileNo"]),
                    //                 Email = Convert.ToString(p["Email"]),
                    //                 Pan = Convert.ToString(p["Pan"]),
                    //                 ReferenceNumber = Convert.ToString(p["ReferenceNumber"]),
                    //                 URNNumber = Convert.ToString(p["URNNumber"]),
                    //                 SchemeCode = Convert.ToString(p["SchemeCode"]),
                    //                 SchemeDescription = Convert.ToString(p["SchemeDescription"]),
                    //                 UrnStatus = Convert.ToString(p["UrnStatus"]),
                    //                 RegistrationDate = Convert.ToString(p["RegistrationDate"]),
                    //                 Frequency = Convert.ToString(p["Frequency"]),
                    //                 Amount = Convert.ToString(p["Amount"]),
                    //                 ActivationDate = Convert.ToString(p["ActivationDate"]),
                    //                 ExpiryDate = Convert.ToString(p["ExpiryDate"]),
                    //                 WithEffectDate = Convert.ToString(p["WithEffectDate"]),
                    //                 Holdingtype = Convert.ToString(p["Holdingtype"]),
                    //                 BankName = Convert.ToString(p["BankName"]),
                    //                 Accountnumber = Convert.ToString(p["Accountnumber"]),
                    //                 IFSCCode = Convert.ToString(p["IFSCCode"]),
                    //                 BillerName = Convert.ToString(p["BillerName"]),
                    //                 SponsorBankCode = Convert.ToString(p["SponsorBankCode"]),
                    //                 MandateStatus = Convert.ToString(p["MandateStatus"]),
                    //                 Curvalue = Convert.ToString(p["Currentvalue"]),
                    //                 MandateAmount = Convert.ToString(p["MandateAmount"]),
                    //                 MandateExpiryDate = Convert.ToString(p["MandateExpiryDate"]),
                    //                 UMRNNo = Convert.ToString(p["UMRNNo"]),
                    //                 Tenure = !string.IsNullOrEmpty(Convert.ToString(p["ActivationDate"])) ? !string.IsNullOrEmpty(Convert.ToString(p["ExpiryDate"])) ? Utilities.DateDiffInYear(Convert.ToDateTime(p["ActivationDate"]), Convert.ToDateTime(p["ExpiryDate"])) : "" : "",
                    //                 InvestmentAmt = Convert.ToString(p["InvestmentAmt"]),
                    //                 Distributor = Convert.ToString(p["Distributor"]),
                    //                 Boosted = Convert.ToBoolean(listBoosted.Where(i => i.URNNumber == Convert.ToString(p["URNNumber"]) || i.UMRNNo == Convert.ToString(p["UMRNNo"]))),
                    //                 GainLoss = Math.Round(Convert.ToDouble(p["InvestmentAmt"]) != 0.00 ? (Convert.ToDouble(p["Currentvalue"]) - Convert.ToDouble(p["InvestmentAmt"])) / Convert.ToDouble(p["InvestmentAmt"]) * 100 :0.0,2)
                    //             }).ToList();


                    //foreach (var list1 in listBoosted)
                    //{
                    //    foreach (var p in s.ToList())
                    //    {
                    //          ResSIPURNDetails objResSIPURNDetails = new ResSIPURNDetails();
                    //            objResSIPURNDetails.InvestorName = Convert.ToString(p["InvestorName"]);
                    //            objResSIPURNDetails.Foliono = Convert.ToString(p["FolioNo"]);
                    //            objResSIPURNDetails.Mobile = Convert.ToString(p["MobileNo"]);
                    //            objResSIPURNDetails.Email = Convert.ToString(p["Email"]);
                    //            objResSIPURNDetails.Pan = Convert.ToString(p["Pan"]);
                    //            objResSIPURNDetails.Mdate = Convert.ToString(p["Mdate"]);
                    //            objResSIPURNDetails.ReferenceNumber = Convert.ToString(p["ReferenceNumber"]);
                    //            objResSIPURNDetails.URNNumber = Convert.ToString(p["URNNumber"]);
                    //            objResSIPURNDetails.SchemeCode = Convert.ToString(p["SchemeCode"]);
                    //            objResSIPURNDetails.SchemeDescription = Convert.ToString(p["SchemeDescription"]);
                    //            objResSIPURNDetails.UrnStatus = Convert.ToString(p["UrnStatus"]);
                    //            objResSIPURNDetails.RegistrationDate = Convert.ToString(p["RegistrationDate"]);
                    //            objResSIPURNDetails.Frequency = Convert.ToString(p["Frequency"]);
                    //            objResSIPURNDetails.Amount = Convert.ToString(p["Amount"]);
                    //            objResSIPURNDetails.ActivationDate = Convert.ToString(p["ActivationDate"]);
                    //            objResSIPURNDetails.ExpiryDate = Convert.ToString(p["ExpiryDate"]);
                    //            objResSIPURNDetails.WithEffectDate = Convert.ToString(p["WithEffectDate"]);
                    //            objResSIPURNDetails.Holdingtype = Convert.ToString(p["Holdingtype"]);
                    //            objResSIPURNDetails.BankName = Convert.ToString(p["BankName"]);
                    //            objResSIPURNDetails.Accountnumber = Convert.ToString(p["Accountnumber"]);
                    //            objResSIPURNDetails.IFSCCode = Convert.ToString(p["IFSCCode"]);
                    //            objResSIPURNDetails.BillerName = Convert.ToString(p["BillerName"]);
                    //            objResSIPURNDetails.SponsorBankCode = Convert.ToString(p["SponsorBankCode"]);
                    //            objResSIPURNDetails.MandateStatus = Convert.ToString(p["MandateStatus"]);
                    //            objResSIPURNDetails.Curvalue = Convert.ToString(p["Currentvalue"]);
                    //            objResSIPURNDetails.MandateAmount = Convert.ToString(p["MandateAmount"]);
                    //            objResSIPURNDetails.MandateExpiryDate = Convert.ToString(p["MandateExpiryDate"]);
                    //            if (!string.IsNullOrEmpty(Convert.ToString(p["ActivationDate"])) && !string.IsNullOrEmpty(Convert.ToString(p["ExpiryDate"])))
                    //            {
                    //                objResSIPURNDetails.Tenure = Utilities.DateDiffInYear(Convert.ToDateTime(p["ActivationDate"]), Convert.ToDateTime(p["ExpiryDate"]));
                    //            }
                    //            objResSIPURNDetails.InvestmentAmt = Convert.ToString(p["InvestmentAmt"]);
                    //            objResSIPURNDetails.Distributor = Convert.ToString(p["Distributor"]);
                    //            objSIPURN.Add(objResSIPURNDetails);

                    //    }
                    //}
                }
                return new ResponseDataArrayModel<ResSIPURNDetails>(objSIPURN);
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "__SIPBooster__" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetSipMandateUmrnDetails \r ERROR:" + ex.Message + "\n" + "InputJson:" + inputJson);
                return new ResponseDataArrayModel<ResSIPURNDetails>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<ResSIPURN>> SaveSIPMandateUmrnDetails(ReqSIPURN request, string PanNo)
        {
            string inputJson = string.Empty;

            ResSIPURN objResSIPURN = new ResSIPURN();
            string Siptype = "Online";
            string scheme = request.scheme;
            string plan = request.plan;
            string option = request.option;
            string acno = request.folioNo;
            string trtype = "Top up";
            string amount = request.amount;
            string Invname = request.Invname;
            string entby = request.entby;
            string freq = request.frequency;
            string Activationdt = request.startdate;
            string Expirydt = request.enddate;
            string distributor = "";
            string riacode = "";
            string BnkActype = request.BnkActype;
            string Bnkname = request.Bnkname;
            string BnkAcno = request.BnkAcno;
            string Mandate = request.Mandate;
            string URNNo = request.URNNo;
            string UMRno = request.UMRno;
            string Bnkifsc = request.ifsccode;
            string PAN = PanNo;
            string Mandateregtype = request.Mandateregtype;
            string moh = request.holdingtype;
            string BillerName = "Billdesk";
            string SponsorBankcode = "MOTILALMF";
            string MandateStatus = request.MandateStatus;
            string RegistrationDt = request.RegistrationDt;
            string SubBroker = "";
            string EUINno = "";
            string EUINopt = "";
            string EUINsubarncode = "";
            string sipstepupflag = "";
            string sipstepupfrequency = request.sipstepupfrequency;
            string sipstepupamount = request.sipstepupamount;
            string SIPStatus = request.SIPStatus;
            string sipstepupstartdt = request.sipstepupstartdt;
            string sipstepupenddt = request.sipstepupenddt;
            string sipTopUpLimit = request.sipTopUpLimit;
            long AutoId = 0;
            try
            {
                object input = new
                {
                    Adminusername,
                    Adminpassword,
                    Siptype,
                    scheme,
                    plan,
                    option,
                    acno,
                    trtype,
                    amount,
                    Invname,
                    entby,
                    freq,
                    Activationdt,
                    Expirydt,
                    distributor,
                    riacode,
                    BnkActype,
                    Bnkname,
                    BnkAcno,
                    Mandate,
                    URNNo,
                    UMRno,
                    Bnkifsc,
                    PAN,
                    Mandateregtype,
                    moh,
                    BillerName,
                    SponsorBankcode,
                    MandateStatus,
                    RegistrationDt,
                    SubBroker,
                    EUINno,
                    EUINopt,
                    EUINsubarncode,
                    sipstepupflag,
                    sipstepupfrequency,
                    sipstepupamount,
                    SIPStatus,
                    sipstepupstartdt,
                    sipstepupenddt,
                    errno = "",
                    sipTopUpLimit
                };

                inputJson = JsonConvert.SerializeObject(input);
                var result = KarvyRequest.CreateHTTPRequest("MOSLSipTopUpMandateInsert", serviceUrl, inputJson);
                var s = JObject.Parse(result);


                if ((s.Count > 0 && Convert.ToString(s["STATUS_CODE"]) == "200"))
                {
                    objResSIPURN.BATCHNO = Convert.ToString(s["BATCHNO"]);
                    objResSIPURN.ERRNO = Convert.ToString(s["ERRNO"]);
                    objResSIPURN.IHNO = Convert.ToString(s["IHNO"]);
                    objResSIPURN.REFNO = Convert.ToString(s["REFNO"]);
                    objResSIPURN.TIME_STAMP = Convert.ToString(s["TIME_STAMP"]);
                    objResSIPURN.URNNO = Convert.ToString(s["URNNO"]);
                    objResSIPURN.URNexpirydate = Convert.ToString(s["URNexpirydate"]);
                    using (var conn2 = MOAMCMOBILEDB)
                    {
                        var multi = await conn2.QueryAsync("MF.USP_INSERT_UPDATE_SIP_HUB_TRANSACTION", new
                        {
                            PAN_NO = PanNo,
                            FOLIO_NO = request.folioNo,
                            REG_DATE = request.RegistrationDt,
                            SCHEME = request.scheme,
                            PLAN = request.plan,
                            OPTION = request.option,
                            URN_NO = request.URNNo,
                            FREQUENCY = request.frequency,
                            AMOUNT = request.amount,
                            FROM_DATE = request.sipstepupstartdt,
                            END_DATE = request.sipstepupenddt,
                            STATUS = request.SIPStatus,
                            BANK_ACCNO = request.BnkAcno,
                            TENURE = "",
                            TOPUP_AMOUNT = request.sipstepupamount,
                            TOPUP_LIMIT = request.sipTopUpLimit,
                            TOPUP_FREQUENCY = request.sipstepupfrequency,
                            ID = AutoId,
                            RES_IHNO_NO = Convert.ToString(s["IHNO"]),
                            REF_NO = Convert.ToString(s["REFNO"]),
                            STATUS_CODE = Convert.ToString(s["STATUS_CODE"]),
                            MESSAGE = Convert.ToString(s["MESSAGE"]),
                            SUCCESS_FLAG = Convert.ToBoolean(s["SUCCESS_FLAG"]),
                            BATCHNO = Convert.ToString(s["BATCHNO"]),
                            TIME_STAMP = Convert.ToDateTime(s["TIME_STAMP"]),
                            ERRNO = Convert.ToString(s["ERRNO"]),
                            URNexpirydate = Convert.ToDateTime(s["URNexpirydate"]),
                            UMRN_NO = UMRno,
                            RES_URN_NO = Convert.ToString(s["URNNO"]),
                        }, commandType: CommandType.StoredProcedure);
                        {
                            AutoId = 0;
                        }
                    }
                }
                else
                {
                    objResSIPURN.BATCHNO = Convert.ToString(s["BATCHNO"]);
                    objResSIPURN.ERRNO = Convert.ToString(s["ERRNO"]);
                    objResSIPURN.IHNO = Convert.ToString(s["IHNO"]);
                    objResSIPURN.REFNO = Convert.ToString(s["REFNO"]);
                    objResSIPURN.TIME_STAMP = Convert.ToString(s["TIME_STAMP"]);
                    objResSIPURN.URNNO = Convert.ToString(s["URNNO"]);
                    objResSIPURN.URNexpirydate = Convert.ToString(s["URNexpirydate"]);

                    using (var conn2 = MOAMCMOBILEDB)
                    {
                        var multi = await conn2.QueryAsync("MF.USP_INSERT_UPDATE_SIP_HUB_TRANSACTION", new
                        {
                            PAN_NO = PanNo,
                            FOLIO_NO = request.folioNo,
                            REG_DATE = request.RegistrationDt,
                            SCHEME = request.scheme,
                            PLAN = request.plan,
                            OPTION = request.option,
                            URN_NO = request.URNNo,
                            FREQUENCY = request.frequency,
                            AMOUNT = request.amount,
                            FROM_DATE = request.sipstepupstartdt,
                            END_DATE = request.sipstepupenddt,
                            STATUS = request.SIPStatus,
                            BANK_ACCNO = request.BnkAcno,
                            TENURE = "",
                            TOPUP_AMOUNT = request.sipstepupamount,
                            TOPUP_LIMIT = request.sipTopUpLimit,
                            TOPUP_FREQUENCY = request.sipstepupfrequency,
                            ID = AutoId,
                            STATUS_CODE = Convert.ToString(s["STATUS_CODE"]),
                            MESSAGE = Convert.ToString(s["MESSAGE"]),
                            SUCCESS_FLAG = Convert.ToBoolean(s["SUCCESS_FLAG"]),
                            ERRNO = Convert.ToString(s["ERRNO"]),
                            UMRN_NO = UMRno,
                            RES_URN_NO = Convert.ToString(s["URNNO"]),
                            URNexpirydate = Convert.ToString(s["URNexpirydate"]),
                        }, commandType: CommandType.StoredProcedure);
                        {
                            AutoId = 0;
                        }
                    }

                    return new ResponseDataModel<ResSIPURN>(null, Convert.ToString(s["MESSAGE"]));
                }
                return new ResponseDataModel<ResSIPURN>(objResSIPURN);
            }
            catch (Exception ex)
            {
                using (var conn2 = MOAMCMOBILEDB)
                {
                    var multi = await conn2.QueryAsync("MF.USP_INSERT_UPDATE_SIP_HUB_TRANSACTION", new
                    {
                        PAN_NO = PanNo,
                        FOLIO_NO = request.folioNo,
                        REG_DATE = request.RegistrationDt,
                        SCHEME = request.scheme,
                        PLAN = request.plan,
                        OPTION = request.option,
                        URN_NO = request.URNNo,
                        FREQUENCY = request.frequency,
                        AMOUNT = request.amount,
                        FROM_DATE = request.sipstepupstartdt,
                        END_DATE = request.sipstepupenddt,
                        STATUS = request.SIPStatus,
                        BANK_ACCNO = request.BnkAcno,
                        TENURE = "",
                        TOPUP_AMOUNT = request.sipstepupamount,
                        TOPUP_LIMIT = request.sipTopUpLimit,
                        TOPUP_FREQUENCY = request.sipstepupfrequency,
                        ID = AutoId,
                        STATUS_CODE = "",
                        MESSAGE = "Karvy Exception. Check log",
                        SUCCESS_FLAG = "",
                        ERRNO = "",
                        UMRN_NO = "",
                        RES_URN_NO = "",
                        URNexpirydate = "",
                    }, commandType: CommandType.StoredProcedure);
                    {
                        AutoId = 0;
                    }
                }
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_SIPBooster_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
               await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveSIPMandateUmrnDetails \r ERROR:" + ex.Message + "\n" + "InputJson:" + inputJson);
                throw new LogDBException(ex, Convert.ToString(ex.Message));
            }
        }

        public async Task<ResponseDataModel<string>> SavePaymentReq(SavePaymentRequest savePayment)
        {
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("PROC_SAVE_PAYMENT_REQUEST", new
                    {
                        BucketId = savePayment.Bucket_Id,
                        Req_XML = savePayment.ReqXML,
                        Res_XML = savePayment.ResXML,
                        Req_PGString = savePayment.ReqPGString,
                        PaymentURL = savePayment.Payment_URL
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var VerifiedList = multi.ToList();
                        var value = Convert.ToBoolean(VerifiedList[0].FLAG);
                        if (Convert.ToBoolean(VerifiedList[0].FLAG) == true)
                        {
                            return new ResponseDataModel<string>(Convert.ToString(value));
                        }
                        else
                        {
                            return new ResponseDataModel<string>(Convert.ToString(value), "Bucket_Id did not match");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SavePaymentReq \r ERROR:" + ex.Message);
                return new ResponseDataModel<string>(null, ex.Message);
            }
        }

        public async Task<ResponseDataArrayModel<ResSipBoosterDetails>> GetSipBoosterDetails(ReqSipBoosterDetails reqSipBooster, string panNo)
        {
            try
            {
                var listEdited = new List<ResSipBoosterDetails>();
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("MF.Get_SipBooster_Details", new
                    {
                        PAN_NO = panNo,
                        URN_OR_UMRNNO = reqSipBooster.UrnORUmrnNO

                    }, commandType: CommandType.StoredProcedure);
                    listEdited = (from list in multi.ToList()
                                  select new ResSipBoosterDetails
                                  {
                                      EndDate = list.END_DATE,
                                      TopUpAmount = list.TOPUP_AMOUNT,
                                      TopUpFrequency = list.TOPUP_FREQUENCY,
                                      TopUpLimit = list.TOPUP_LIMIT
                                  }).ToList();
                    return new ResponseDataArrayModel<ResSipBoosterDetails>(listEdited);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
               await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetSipBoosterDetails \r ERROR:" + ex.Message);
                return new ResponseDataArrayModel<ResSipBoosterDetails>(null, ex.Message);
            }
        }
    }
}