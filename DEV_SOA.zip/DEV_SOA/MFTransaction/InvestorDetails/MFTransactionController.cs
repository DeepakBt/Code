﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MFTransaction.Models;
using MFTransaction.Utils;
using Microsoft.AspNetCore.Cors;

namespace MFTransaction.InvestorDetails
{
    [Produces("application/json")]
    [Route("api/MFTransaction")]
    [ValidateModel]
    public class MFTransactionController : Controller
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly IMFTransactionDataSource _MFTransactionDataSource;
        public MFTransactionController(TokenHelper tokenHelper, IMFTransactionDataSource MFTransactionDataSource, IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _MFTransactionDataSource = MFTransactionDataSource;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
        }
        [HttpPost("MFClientTransactionSubmit")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<TransactionResponse>), 200)]
        public async Task<IActionResult> MFClientTransactionSubmit([FromBody] TransactionRequest request)
        {
            string AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            string UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            string panNo = User.Identity.Name;
            var results = new List<ValidationResult>();
            if (panNo == "" || panNo == null)
            {
                results.Add(new ValidationResult("PanNo is mandatory..", new List<string> { "panNo" }));
                if (results.Count > 0)
                {
                    return BadRequest(results);
                }
            }
            var response = await _MFTransactionDataSource.saveMFClientTransactionSubmit(AppId, userid, request, panNo, UserAgent);
            return Ok(response);
        }

        [HttpPost("BillDeskConsolidate")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<BillDeskConsolidateResponse>), 200)]
        public async Task<IActionResult> BillDeskConsolidate([FromBody] TransactionRequestConsolidate request)
        {
            string AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            string UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            string panNo = User.Identity.Name;
            var results = new List<ValidationResult>();
            if (panNo == "" || panNo == null)
            {
                results.Add(new ValidationResult("PanNo is mandatory..", new List<string> { "panNo" }));
                if (results.Count > 0)
                {
                    return BadRequest(results);
                }
            }
            var response = await _MFTransactionDataSource.BillDeskConsolidate(AppId, userid, request, panNo, UserAgent);
            return Ok(response);
        }

        [HttpPost("MFClientTransactionConfirmation")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<TransactionConfirmationRes>), 200)]
        public async Task<IActionResult> MFClientTransactionConfirmation([FromBody] TransactionConfirmationReq request)
        {
            string AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            string UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            string panNo = User.Identity.Name;
            var response = await _MFTransactionDataSource.TransactionConfirmation(AppId, userid, request, UserAgent);
            return Ok(response);
        }
        [EnableCors("MOSLPolicy")]
        [HttpPost("EMandateRegistration")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<EMandateRegRes>), 200)]
        public async Task<IActionResult> EMandateRegistration([FromBody] FinalSubmitEMandate request)
        {
            string AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            string UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            string panNo = User.Identity.Name;
            var response = await _MFTransactionDataSource.EMandateRegistration(AppId, userid, request.RefNo, UserAgent);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("GetOTMDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataArrayModel<OTMDetails>), 200)]
        public async Task<IActionResult> GetOTMDetails([FromBody] OTMReq request)
        {
            string panNo = User.Identity.Name;
            var response = await _MFTransactionDataSource.GetOTMDetails(request, panNo);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("SaveOTMDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataArrayModel<FinalSubmitEMandate>), 200)]
        public async Task<IActionResult> SaveOTMDetails([FromBody] EMandateRegReq request)
        {
            string panNo = User.Identity.Name;
            var response = await _MFTransactionDataSource.SaveOTMDetails(request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("SaveOTMDetailsConsolidate")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<SaveOTMConsolidateRes>), 200)]
        public async Task<IActionResult> SaveOTMDetailsConsolidate([FromBody] EMandateRegReqConsolidate request)
        {
            string panNo = User.Identity.Name;
            string AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            string UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var response = await _MFTransactionDataSource.SaveOTMDetailsConsolidate(request, AppId, userid, panNo, UserAgent);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("GetSipMandateUmrnDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ResSIPURNDetails>), 200)]
        public async Task<IActionResult> GetSipMandateUmrnDetails()
        {
            string panNo = User.Identity.Name;//"DBLPS6346N";//User.Identity.Name;  //"AIBPP7556M";//User.Identity.Name;
            var response = await _MFTransactionDataSource.GetSipMandateUmrnDetails(panNo);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("SaveSIPMandateUmrnDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ResSIPURN>), 200)]
        public async Task<IActionResult> SaveSIPMandateUmrnDetails([FromBody] ReqSIPURN request)
        {
            string panNo = User.Identity.Name; // "AXOPK0787H"; //User.Identity.Name;//"AIBPP7556M";//User.Identity.Name; //"AIBPP7556M"; //User.Identity.Name;// 
            string AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            string UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var response = await _MFTransactionDataSource.SaveSIPMandateUmrnDetails(request, panNo);
            return Ok(response);
        }


        [EnableCors("MOSLPolicy")]
        [HttpPost("SavePaymentRequest")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> SavePaymentReq([FromBody] SavePaymentRequest savePayment)
        {
            var response = await _MFTransactionDataSource.SavePaymentReq(savePayment);
            return Ok(response);
        }
        [EnableCors("MOSLPolicy")]
        [HttpPost("GetSipBoosterDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ResSipBoosterDetails>), 200)]
        public async Task<IActionResult> GetSipBoosterDetails([FromBody]ReqSipBoosterDetails reqSipBooster)
        {
            string panNo = User.Identity.Name;//"DBLPS6346N";//User.Identity.Name;  //"AIBPP7556M";//User.Identity.Name;
            var response = await _MFTransactionDataSource.GetSipBoosterDetails(reqSipBooster, panNo);
            return Ok(response);
        }
    }
}