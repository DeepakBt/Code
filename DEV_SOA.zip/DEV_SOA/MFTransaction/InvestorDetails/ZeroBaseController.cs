﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MFTransaction.Models;
using MFTransaction.Utils;

namespace MFTransaction.InvestorDetails
{
    [Produces("application/json")]
    [Route("api/MFClientKarvy")]
    [ValidateModel]

    public class ZeroBaseController : ControllerBase
    {

        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly IZeroBaseDataSource _ZeroBaseDataSource;
        public ZeroBaseController(TokenHelper tokenHelper, IZeroBaseDataSource ZeroBaseDataSource, IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _ZeroBaseDataSource = ZeroBaseDataSource;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
        }
        [HttpPost("MFClientKarvySubmit")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<FinalSubmitRes>), 200)]
        public async Task<IActionResult> MFClientKarvySubmit([FromBody] FinalSubmit request)
        {
                var AppId = HeaderAccessors.GetAppId(Request.Headers);
                Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
                var response = await _ZeroBaseDataSource.saveMFClientSubmit(AppId, userid, request);
                return Ok(response);
        }

        [HttpPost("MFZBFSubmit")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<FinalSubmitRes>), 200)]
        public async Task<IActionResult> MFZBFSubmit([FromBody] ZBFReq req)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var panNo = User.Identity.Name;
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _ZeroBaseDataSource.MFZBFSubmit(AppId, userid, panNo, req);
            return Ok(response);
        }

        [HttpPost("PennydropAccountValdation")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<ResPennyDrop>), 200)]
        public async Task<IActionResult> PennydropAccountValdation([FromBody] ReqPennyDrop req)
        {
            var panNo = User.Identity.Name;
            var response = await _ZeroBaseDataSource.PennyDropValidation(req,panNo);
            return Ok(response);
        }
    }
}