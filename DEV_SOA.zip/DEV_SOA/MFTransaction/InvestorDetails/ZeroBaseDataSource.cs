﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MFTransaction.Models;

namespace MFTransaction.InvestorDetails
{
    public interface IZeroBaseDataSource
    {
        Task<ResponseDataModel<FinalSubmitRes>> saveMFClientSubmit(string AppID, Int64 userId, FinalSubmit request);
        Task<ResponseDataModel<FinalSubmitRes>> MFZBFSubmit(string AppID, Int64 userId,string PanNo, ZBFReq req);
        Task<ResponseDataModel<ResPennyDrop>> PennyDropValidation(ReqPennyDrop req,string panNo);
    }
}
