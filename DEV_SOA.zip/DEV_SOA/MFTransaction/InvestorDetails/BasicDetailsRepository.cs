﻿using ApiCore.DTOs;
using ApiCore.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MFTransaction.Models;
using ApiCore.Exceptions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using karvyAPI;
using MFTransaction.Utils;
using System.IO;

namespace MFTransaction.InvestorDetails
{
    public class BasicDetailsRepository : IBasicDetailsDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly TokenHelper _tokenHelper;
        private string ErrorLogFile = string.Empty;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        
        public BasicDetailsRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
        }
        public async Task<ResponseDataModel<MFClientsPanDetailsRes>> saveMFClientPanDetails(string AppID, string Role,string UserAgent,MFClientsPanDetails request)
        {
            try
            {
                var branchCode = "";
                if (UserAgent != null)
                {
                    if (Convert.ToString(UserAgent).Contains("ChatApi"))
                    {
                        branchCode = "WH99";
                    }
                    else if (Convert.ToString(UserAgent).Contains("MOGP"))
                    {
                        branchCode = "WH99";
                    }
                    else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                    {
                        branchCode = "WB99";
                    }
                    else
                    {
                        branchCode = "MB88";
                    }
                }
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("MF.USP_INSERT_CLIENT_PANDETAILS", new
                    {
                        PANNO = Convert.ToString(request.panNo),
                        AADHARNO = Convert.ToString(request.aadharNo),
                        NAME = Convert.ToString(request.name),
                        APPID = Convert.ToString(AppID),
                        OTP = Convert.ToInt32(request.otp),
                        SAVEFORLATER = false,
                        BranchCode = branchCode,
                        USER_AGENT = UserAgent,
                        ARNCode=request.ARNCode
                    }, commandType: CommandType.StoredProcedure);
                    MFClientsPanDetailsRes osceenOneRes = new MFClientsPanDetailsRes();
                    var Data = multi.ToList();
                    if (Data[0].successFlag == 1)
                    {
                        var userId = Convert.ToString(Data[0].userId);
                        var ScreenNo = Convert.ToString(Data[0].screenNo) ?? "2";
                        osceenOneRes.accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppID, userId);
                        osceenOneRes.expiresIn = _tokenHelper.GetAccessTokenValiditySeconds();
                        osceenOneRes.screenNo = ScreenNo;
                        return new ResponseDataModel<MFClientsPanDetailsRes>(osceenOneRes);
                    }
                    else if (Data[0].successFlag == 0)
                    {
                        var msg = Convert.ToString(Data[0].MsgCode);
                        return new ResponseDataModel<MFClientsPanDetailsRes>(null, msg);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
            catch (Exception)
            {
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<string>> saveMFClientBasicDetails(string AppID, Int64 userid, string UserAgent, MFClientsBasicDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("MF.USP_INSERT_CLIENT_BASICDETAILS", new
                {
                    USERID = userid,
                    MODEOFHOLDING = request.modeOfHolding,
                    CATEGORY = request.holderDetails[0].category,
                    FHIFNRI = request.holderDetails[0].ifNri,
                    INVESTORSTATUS = request.firstHolderTaxStatus,
                    FHOCCUPATION = request.holderDetails[0].occupation,
                    FHSALUTATION = request.holderDetails[0].title,
                    FHNAME = request.holderDetails[0].name,
                    FHDOB = request.holderDetails[0].dob,
                    FHPANNO = request.holderDetails[0].panNo,
                    FHAADHARNO = request.holderDetails[0].aadharNo,
                    FHEMAILID = request.holderDetails[0].email,
                    FHMOBILENO = request.holderDetails[0].mobileNo,
                    FHLANDLINENO = request.holderDetails[0].landlineNo,
                    FHKYCSTATUS = request.holderDetails[0].kycStatus,

                    SHCATEGORY = request.holderDetails.Count > 1 ? request.holderDetails[1].category : 0,
                    SHIFNRI = request.holderDetails.Count > 1 ? request.holderDetails[1].ifNri : 0,
                    SHOCCUPATION = request.holderDetails.Count > 1 ? request.holderDetails[1].occupation : 0,
                    SHSALUTATION = request.holderDetails.Count > 1 ? request.holderDetails[1].title : "",
                    SHNAME = request.holderDetails.Count > 1 ? request.holderDetails[1].name : "",
                    SHDOB = request.holderDetails.Count > 1 ? request.holderDetails[1].dob : "",
                    SHPANNO = request.holderDetails.Count > 1 ? request.holderDetails[1].panNo : "",
                    SHAADHARNO = request.holderDetails.Count > 1 ? request.holderDetails[1].aadharNo : "",
                    SHEMAILID = request.holderDetails.Count > 1 ? request.holderDetails[1].email : "",
                    SHMOBILENO = request.holderDetails.Count > 1 ? request.holderDetails[1].mobileNo : "",
                    SHLANDLINENO = request.holderDetails.Count > 1 ? request.holderDetails[1].landlineNo : "",
                    SHKYCSTATUS = request.holderDetails.Count > 1 ? request.holderDetails[1].kycStatus : "1",

                    THCATEGORY = request.holderDetails.Count > 2 ? request.holderDetails[2].category : 0,
                    THIFNRI = request.holderDetails.Count > 2 ? request.holderDetails[2].ifNri : 0,
                    THOCCUPATION = request.holderDetails.Count > 2 ? request.holderDetails[2].occupation : 0,
                    THSALUTATION = request.holderDetails.Count > 2 ? request.holderDetails[2].title : "",
                    THNAME = request.holderDetails.Count > 2 ? request.holderDetails[2].name : "",
                    THDOB = request.holderDetails.Count > 2 ? request.holderDetails[2].dob : "",
                    THPANNO = request.holderDetails.Count > 2 ? request.holderDetails[2].panNo : "",
                    THAADHARNO = request.holderDetails.Count > 2 ? request.holderDetails[2].aadharNo : "",
                    THEMAILID = request.holderDetails.Count > 2 ? request.holderDetails[2].email : "",
                    THMOBILENO = request.holderDetails.Count > 2 ? request.holderDetails[2].mobileNo : "",
                    THLANDLINENO = request.holderDetails.Count > 2 ? request.holderDetails[2].landlineNo : "",
                    THKYCSTATUS = request.holderDetails.Count > 2 ? request.holderDetails[2].kycStatus : "1",

                    FHGAURDIANPAN = request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.panNo,
                    FHGAURDIANKYCSTATUS = request.firstHolderGurdian == null ? "N" : request.firstHolderGurdian.kycStatus,
                    FHGAURDIANNAME = request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.name,
                    FHGAURDIANAADHARNO = request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.aadhar,
                    FHGAURDIANDOB = request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.dob,
                    FHGAURDIANEMAIL=request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.email,
                    FHGAURDIANMOBILENO=request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.mobileno,
                    FHGAURDIANRELATION=request.firstHolderGurdian == null ? "" : request.firstHolderGurdian.relation,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    USER_AGENT = UserAgent,
                    CLIENTID=request.ClientId,
                    DPID=request.DPID
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null, "There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveMFClientFatcaDetails(string AppID, Int64 userid, string UserAgent, MFClientsFatchDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("MF.USP_INSERT_CLIENT_FATCADETAILS", new
                {

                    USERID = userid,
                    FHINCOMESLAB = request.fatcaDetails[0].incomeSlab,
                    FHBIRTHCOUNTRY = request.fatcaDetails[0].birthCountry,
                    FHNATIONALITY = request.fatcaDetails[0].nationality,
                    FHTAXRESIDENTOTHERTHANINDIA = request.fatcaDetails[0].taxResidentNonIndian,
                    FHTAXRESIDENT = request.fatcaDetails[0].taxResident,
                    FHFORIGNTAXID = request.fatcaDetails[0].foreignTaxId,
                    FHPEP = request.fatcaDetails[0].pep,
                    FHRPEP = request.fatcaDetails[0].relationalPep,

                    SHINCOMESLAB = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].incomeSlab : 0,
                    SHBIRTHCOUNTRY = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].birthCountry : "",
                    SHNATIONALITY = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].nationality : "",
                    SHTAXRESIDENTOTHERTHANINDIA = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].taxResidentNonIndian : false,
                    SHTAXRESIDENT = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].taxResident : "",
                    SHFORIGNTAXID = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].foreignTaxId : "",
                    SHPEP = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].pep : false,
                    SHRPEP = request.fatcaDetails.Count > 1 ? request.fatcaDetails[1].relationalPep : false,

                    THINCOMESLAB = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].incomeSlab : 0,
                    THBIRTHCOUNTRY = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].birthCountry : "",
                    THNATIONALITY = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].nationality : "",
                    THTAXRESIDENTOTHERTHANINDIA = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].taxResidentNonIndian : false,
                    THTAXRESIDENT = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].taxResident : "",
                    THFORIGNTAXID = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].foreignTaxId : "",
                    THPEP = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].pep : false,
                    THRPEP = request.fatcaDetails.Count > 2 ? request.fatcaDetails[2].relationalPep : false,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    USER_AGENT = UserAgent,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null,"There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveMFClientContactDetails(string AppID, Int64 userid, string UserAgent, MFClientsContactDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("MF.USP_INSERT_CLIENT_CONTACTDETAILS", new
                {

                    USERID = userid,
                    FHWING = request.contactDetails.Count > 1?request.contactDetails[0].wing:"",
                    FHAREA = request.contactDetails.Count > 1 ? request.contactDetails[0].area :"",
                    FHLANDMARK = request.contactDetails.Count > 1 ? request.contactDetails[0].landmark:"",
                    FHSTATE = request.contactDetails.Count > 1 ? request.contactDetails[0].state:"",
                    FHCITY = request.contactDetails.Count > 1 ? request.contactDetails[0].city:"",
                    FHCOUNTRY = request.contactDetails.Count > 1 ? request.contactDetails[0].country:"",
                    FHPINCODE = request.contactDetails.Count > 1 ? request.contactDetails[0].pincode : 0,

                    SHWING = request.contactDetails.Count > 1 ? request.contactDetails[1].wing : "",
                    SHAREA = request.contactDetails.Count > 1 ? request.contactDetails[1].area : "",
                    SHLANDMARK = request.contactDetails.Count > 1 ? request.contactDetails[1].landmark : "",
                    SHSTATE = request.contactDetails.Count > 1 ? request.contactDetails[1].state : "",
                    SHCITY = request.contactDetails.Count > 1 ? request.contactDetails[1].city : "",
                    SHCOUNTRY = request.contactDetails.Count > 1 ? request.contactDetails[1].country : "",
                    SHPINCODE = request.contactDetails.Count > 1 ? request.contactDetails[1].pincode : 0,

                    THWING = request.contactDetails.Count > 2 ? request.contactDetails[2].wing : "",
                    THAREA = request.contactDetails.Count > 2 ? request.contactDetails[2].area : "",
                    THLANDMARK = request.contactDetails.Count > 2 ? request.contactDetails[2].landmark : "",
                    THSTATE = request.contactDetails.Count > 2 ? request.contactDetails[2].state : "",
                    THCITY = request.contactDetails.Count > 2 ? request.contactDetails[2].city : "",
                    THCOUNTRY = request.contactDetails.Count > 2 ? request.contactDetails[2].country : "",
                    THPINCODE = request.contactDetails.Count > 2 ? request.contactDetails[2].pincode : 0,

                    NRIADDRESS1 = request.nriContact == null ? "" : request.nriContact.address1,
                    NRIADDRESS2 = request.nriContact == null ? "" : request.nriContact.address2,
                    NRIADDRESS3 = request.nriContact == null ? "" : request.nriContact.address3,
                    NRICITY = request.nriContact == null ? "" : request.nriContact.city,
                    NRICOUNTRY = request.nriContact == null ? "" : request.nriContact.country,
                    NRIZIPCODE = request.nriContact == null ? "" : request.nriContact.zipcode,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    USER_AGENT = UserAgent,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null,"There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveMFClientNomineeDetails(string AppID, Int64 userid, string UserAgent, MFClientsNomineeDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                NomineeDetails NomineeDetails = new NomineeDetails();
                if (request.wishToNominate == true)
                {
                    if (request.nomineeDetails.Count == 1)
                    {
                        request.nomineeDetails.Add(NomineeDetails);
                        request.nomineeDetails.Add(NomineeDetails);
                    }
                    else if (request.nomineeDetails.Count == 2)
                    {
                        request.nomineeDetails.Add(NomineeDetails);
                    }
                }
                else
                {
                    request.nomineeDetails.Add(NomineeDetails);
                    request.nomineeDetails.Add(NomineeDetails);
                    request.nomineeDetails.Add(NomineeDetails);
                }




                var dataSave = await conn.QueryAsync("MF.USP_INSERT_CLIENT_NOMINEEDETAILS", new
                {
                    USERID = userid,
                    WISHTONOMINATE = request.wishToNominate,

                    FNOMINEESALUTATION = request.nomineeDetails[0].title,
                    FNOMINEENAME = request.nomineeDetails[0].name,
                    FNOMINEEDOB = request.nomineeDetails[0].dob,
                    FNOMINEEPERCENTAGE = request.nomineeDetails[0].percent,
                    FNOMADDRESSFLAG = request.nomineeDetails[0].addresFlag,
                    FNOMADDRESS1 = request.nomineeDetails[0].address1,
                    FNOMADDRESS2 = request.nomineeDetails[0].address2,
                    FNOMRELATIONSHIP = request.nomineeDetails[0].relationship,
                    FNOMGAURDIANSALUTATION = request.nomineeDetails[0].gurdianTitle,
                    FNOMGAURDIANNAME = request.nomineeDetails[0].gurdianName,
                    FNOMGAURDIANPAN = request.nomineeDetails[0].gurdianPanNo,
                    FNOMGAURDIANKYCSTATUS = request.nomineeDetails[0].gurdianKycStatus,

                    SNOMINEESALUTATION = request.nomineeDetails[1].title,
                    SNOMINEENAME = request.nomineeDetails[1].name,
                    SNOMINEEDOB = request.nomineeDetails[1].dob,
                    SNOMINEEPERCENTAGE = request.nomineeDetails[1].percent,
                    SNOMADDRESSFLAG = request.nomineeDetails[1].addresFlag,
                    SNOMADDRESS1 = request.nomineeDetails[1].address1,
                    SNOMADDRESS2 = request.nomineeDetails[1].address2,
                    SNOMRELATIONSHIP = request.nomineeDetails[1].relationship,
                    SNOMGAURDIANSALUTATION = request.nomineeDetails[1].gurdianTitle,
                    SNOMGAURDIANNAME = request.nomineeDetails[1].gurdianName,
                    SNOMGAURDIANPAN = request.nomineeDetails[1].gurdianPanNo,
                    SNOMGAURDIANKYCSTATUS = request.nomineeDetails[1].gurdianKycStatus,

                    TNOMINEESALUTATION = request.nomineeDetails[2].title,
                    TNOMINEENAME = request.nomineeDetails[2].name,
                    TNOMINEEDOB = request.nomineeDetails[2].dob,
                    TNOMINEEPERCENTAGE = request.nomineeDetails[2].percent,
                    TNOMADDRESSFLAG = request.nomineeDetails[2].addresFlag,
                    TNOMADDRESS1 = request.nomineeDetails[2].address1,
                    TNOMADDRESS2 = request.nomineeDetails[2].address2,
                    TNOMRELATIONSHIP = request.nomineeDetails[2].relationship,
                    TNOMGAURDIANSALUTATION = request.nomineeDetails[2].gurdianTitle,
                    TNOMGAURDIANNAME = request.nomineeDetails[2].gurdianName,
                    TNOMGAURDIANPAN = request.nomineeDetails[2].gurdianPanNo,
                    TNOMGAURDIANKYCSTATUS = request.nomineeDetails[2].gurdianKycStatus,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    USER_AGENT = UserAgent,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null, "There is some technical issue, please try after some time "); ;
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveMFClientSchemeDetails(string AppID, Int64 userid, string UserAgent, MFClientsSchemeDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORSIXTHSCREEN_SCHEMEDETAILS", new
                {
                    USERID = userid,
                    TRANASCTIONTYPE = request.transactionType,
                    SCHEMECODE = request.schemeCode,
                    SCHEMENAME = request.schemeName,
                    PLANCODE = request.planCode,
                    OPTIONCODE = request.optionCode,
                    INVESTEDAMOUNT = Convert.ToString(request.investmentAmount),
                    SCHEMEMINIMUMAMOUNT = request.schemeMinAmount,
                    PLANMODE = request.planMode,
                    FREQUENCY = request.frequency,
                    DEDUCTIONDATE = request.deductionDate,
                    SIPFROMDATE = request.sipFromDate,
                    SIPTODATE = request.sipToDate,
                    PERPETUAL = request.perpetual,
                    NOOFINSTALLMENT = request.noOfInstalment,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    UserAgent = UserAgent,

                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null,"There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveMFClientBrokerDetails(string AppID, Int64 userid, string UserAgent, MFClientsBrokerDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("AMCMOB_NEWINVESTORSEVENTHSCREEN_BROKERDETAILS", new
                {
                    USERID = userid,
                    BROKERCODE = request.brokerCode,
                    SUBBROKER = request.subBroker,
                    SUBBROKERCODE = request.subBrokerCode,
                    EUINDECLARATION = request.declarationEUIN,
                    EUINCODE = request.codeEUIN,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    UserAgent = UserAgent,
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null,"There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }
        public async Task<ResponseDataModel<string>> saveMFClientBankDetails(string AppID, Int64 userid, string UserAgent, MFClientsBankDetails request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("MF.USP_INSERT_CLIENT_BANKDETAILS", new
                {
                    USERID = userid,
                    IFSCCODE = request.ifscCode ?? "",
                    MICRCODE = request.micrCode ?? "",
                    ACCOUNTTYPE = request.accountType ?? "",
                    BANKNAME = request.bankName ?? "",
                    ACCOUNTNO = request.accountNo ?? "",
                    BRANCHNAME = request.branchName ?? "",
                    BRANCHADDRESSLINE1 = request.branchAdd1 ?? "",
                    BRANCHADDRESSLINE2 = request.branchAdd2 ?? "",
                    BRANCHADDRESSLINE3 = request.branchAdd3 ?? "",
                    BRANCHCITY = request.branchCity ?? "",
                    BRANCHPINCODE = Convert.ToString(request.branchPincode) ?? "0",
                    PAYMENTMODE = request.paymentMode ?? "",
                    //CHEQUEIMAGE = Convert.FromBase64String(request.chequeImage),
                    CHEQUEIMAGE=request.chequeImage,
                    APPID = AppID,
                    SAVEFORLATER = request.saveForlater,
                    USER_AGENT = UserAgent,
                    NAMEASPERBANK=request.nameAsPerBank
                }, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList2 = dataSave.ToList();
                    if (VerifiedList2[0].successFlag == 1)
                    {
                        return new ResponseDataModel<string>("Data Saved Successfully.");
                    }
                    else if (VerifiedList2[0].successFlag == 0)
                    {
                        return new ResponseDataModel<string>(null,"There is some technical issue, please try after some time ");
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }

                }

            }

        }

        public async Task<ResponseDataModel<MFClientDetails>> GetClientDetails(string PanNo,bool isETFFlag)
        {
            MFClientDetails ObjResponse = new MFClientDetails();
            
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var ClientData = await conn.QueryMultipleAsync("MF.USP_MF_CLIENT_DETAILS", new
                    {
                        PanNo = PanNo,
                        IsETF=isETFFlag
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var PanDetails = ClientData.Read().ToList();
                        MFPanDetails panDetails = new MFPanDetails();
                        if (PanDetails.Count>0)
                        {
                            panDetails.UserId = Convert.ToString(PanDetails[0].USERID) ?? "";
                            panDetails.Name = Convert.ToString(PanDetails[0].NAME) ?? "";
                            panDetails.OTPSent = Convert.ToString(PanDetails[0].OTPSENT) ?? "";
                            panDetails.PanNo = Convert.ToString(PanDetails[0].PANNO) ?? "";
                            panDetails.BranchCode = Convert.ToString(PanDetails[0].BRANCHCODE) ?? "";
                            panDetails.MobileNo= Convert.ToString(PanDetails[0].MobileNo) ?? "";
                            panDetails.Email = Convert.ToString(PanDetails[0].Email) ?? "";
                        }
                        else
                        {
                            throw new NoDataException(false);
                        }
                        ObjResponse.PanDetails = panDetails;
                        var InvBasicDetails = ClientData.Read().ToList();
                        MFInvBasicDetails ObjInvBDetails = new MFInvBasicDetails();
                        MFFirstHolderGurdian ObjHoldGurdian = new MFFirstHolderGurdian();
                        if (InvBasicDetails.Count>0)
                        {
                            ObjInvBDetails.ModeOfHolding=Convert.ToString(InvBasicDetails[0].MODEOFHOLDING) ?? "";
                            ObjInvBDetails.FirstHolderTaxStatus = Convert.ToString(InvBasicDetails[0].INVESTORSTATUS) ?? "";
                            ObjInvBDetails.ClientId = Convert.ToString(InvBasicDetails[0].CLIENTID) ?? "";
                            ObjInvBDetails.DPID = Convert.ToString(InvBasicDetails[0].DPID) ?? "";
                            ObjHoldGurdian.AadharNo= Convert.ToString(InvBasicDetails[0].FHGAURDIANAADHARNO) ?? "";
                            ObjHoldGurdian.CreateDate= Convert.ToString(InvBasicDetails[0].CREATEDDATE) ?? "";
                            ObjHoldGurdian.Email = Convert.ToString(InvBasicDetails[0].FHGAURDIANEMAIL) ?? "";
                            ObjHoldGurdian.KycStatus = Convert.ToString(InvBasicDetails[0].FHGAURDIANKYCSTATUS) ?? "";
                            ObjHoldGurdian.MobileNo = Convert.ToString(InvBasicDetails[0].FHGAURDIANMOBILENO) ?? "";
                            ObjHoldGurdian.Name= Convert.ToString(InvBasicDetails[0].FHGAURDIANNAME) ?? "";
                            ObjHoldGurdian.PanNo= Convert.ToString(InvBasicDetails[0].FHGAURDIANPAN) ?? "";
                            ObjHoldGurdian.Relation= Convert.ToString(InvBasicDetails[0].FHGAURDIANRELATION) ?? "";
                            ObjHoldGurdian.DOB= Convert.ToString(InvBasicDetails[0].FHGAURDIANDOB) ?? "";
                            ObjHoldGurdian.SaveForLater = Convert.ToBoolean(InvBasicDetails[0].SAVEFORLATER) ??false;
                            ObjHoldGurdian.ScreenId=Convert.ToString(InvBasicDetails[0].SCREENID) ?? "";
                        }
                        ObjInvBDetails.FirstHolderGurdian = ObjHoldGurdian;
                        ObjResponse.InvBasicDetails = ObjInvBDetails;

                        var InvBasicDetailsLst = ClientData.Read().ToList();
                        List<HolderDetails> lstHolding = new List<HolderDetails>();
                        if (InvBasicDetailsLst.Count > 0)
                        {
                            foreach (var objData in InvBasicDetailsLst)
                            {
                                HolderDetails holderDetails = new HolderDetails();
                                holderDetails.AadharNo = Convert.ToString(objData.AADHARNO) ?? "";
                                holderDetails.PanNo = Convert.ToString(objData.PANNO) ?? "";
                                holderDetails.Category = Convert.ToString(objData.CATEGORY) ?? "";
                                holderDetails.Dob = Convert.ToString(objData.DOB) ?? "";
                                holderDetails.Email = Convert.ToString(objData.EMAIL) ?? "";
                                holderDetails.HFalg = Convert.ToString(objData.HFlag) ?? "";
                                holderDetails.IfNri = Convert.ToString(objData.IFNRI) ?? "";
                                holderDetails.KycStatus = Convert.ToString(objData.KYCSTATUS) ?? "";
                                holderDetails.LandlineNo = Convert.ToString(objData.LANDLINENO) ?? "";
                                holderDetails.MobileNo = Convert.ToString(objData.MOBILENO) ?? "";
                                holderDetails.Name = Convert.ToString(objData.NAME) ?? "";
                                holderDetails.Occupation = Convert.ToString(objData.OCCUPATION) ?? "";
                                holderDetails.Title = Convert.ToString(objData.SALUTATION) ?? "";
                                lstHolding.Add(holderDetails);
                            }
                        }
                        ObjResponse.InvBasicDetails.HolderDetails = lstHolding;
                        var Nomeeni = ClientData.Read().ToList();
                        MFNomineeDetails mFNomineeDetails = new MFNomineeDetails();
                        if (Nomeeni.Count()>0)
                        {
                            mFNomineeDetails.WishToNominate = Convert.ToBoolean(InvBasicDetails[0].WISHTONOMINATE) ??false;
                        }
                        var NomeeniLst = ClientData.Read().ToList();
                        List<_NomineeDetails> lstNominee = new List<_NomineeDetails>();
                        if (NomeeniLst.Count() > 0)
                        {
                            foreach (var ObjNomeeni in NomeeniLst)
                            {
                                _NomineeDetails Obj_NomineeDetails = new _NomineeDetails();
                                Obj_NomineeDetails.AddresFlag = Convert.ToBoolean(ObjNomeeni.NOMADDRESSFLAG) ?? false;
                                Obj_NomineeDetails.Address1 = Convert.ToString(ObjNomeeni.NOMADDRESS1) ?? "";
                                Obj_NomineeDetails.Address2 = Convert.ToString(ObjNomeeni.NOMADDRESS2) ?? "";
                                Obj_NomineeDetails.Dob = Convert.ToString(ObjNomeeni.NOMINEEDOB) ?? "";
                                if(Convert.ToString(ObjNomeeni.NOMGAURDIANKYCSTATUS)=="" || Convert.ToString(ObjNomeeni.NOMGAURDIANKYCSTATUS) == "0")
                                {
                                    Obj_NomineeDetails.GurdianKycStatus = false;
                                }
                                else
                                {
                                    Obj_NomineeDetails.GurdianKycStatus = true;
                                }
                                Obj_NomineeDetails.GurdianName = Convert.ToString(ObjNomeeni.NOMGAURDIANNAME) ?? "";
                                Obj_NomineeDetails.GurdianPanNo = Convert.ToString(ObjNomeeni.NOMGAURDIANPAN) ?? "";
                                Obj_NomineeDetails.GurdianTitle = Convert.ToString(ObjNomeeni.NOMGAURDIANSALUTATION) ?? "";
                                Obj_NomineeDetails.HFlag = Convert.ToString(ObjNomeeni.HFlag) ?? "";
                                Obj_NomineeDetails.Name = Convert.ToString(ObjNomeeni.NOMINEENAME) ?? "";
                                Obj_NomineeDetails.Percent = Convert.ToString(ObjNomeeni.NOMINEEPERCENTAGE) ?? "";
                                Obj_NomineeDetails.Relationship = Convert.ToString(ObjNomeeni.NOMRELATIONSHIP) ?? "";
                                Obj_NomineeDetails.Title = Convert.ToString(ObjNomeeni.NOMINEESALUTATION) ?? "";
                                lstNominee.Add(Obj_NomineeDetails);
                            }
                        }
                        mFNomineeDetails.NomineeDetails = lstNominee;
                        ObjResponse.NomineeDetails = mFNomineeDetails;

                        var FatcaDetails = ClientData.Read().ToList();
                        List<MFFatcaDetails> LstFatca = new List<MFFatcaDetails>();
                        if(FatcaDetails.Count()>0)
                        {
                            foreach(var Facta in FatcaDetails)
                            {
                                MFFatcaDetails mFFatcaDetails = new MFFatcaDetails();
                                mFFatcaDetails.BirthCountry= Convert.ToString(Facta.BIRTHCOUNTRY) ?? "";
                                mFFatcaDetails.ForeignTaxId= Convert.ToString(Facta.FORIGNTAXID) ?? "";
                                mFFatcaDetails.HFlag = Convert.ToString(Facta.HFlag) ?? "";
                                mFFatcaDetails.IncomeSlab = Convert.ToString(Facta.INCOMESLAB) ?? "";
                                mFFatcaDetails.Nationality= Convert.ToString(Facta.NATIONALITY) ?? "";
                                mFFatcaDetails.Pep = Convert.ToBoolean(Facta.PEP) ??false;
                                mFFatcaDetails.RelationalPep = Convert.ToBoolean(Facta.RPEP) ?? false;
                                mFFatcaDetails.TaxResident = Convert.ToString(Facta.TAXRESIDENT) ?? "";
                                mFFatcaDetails.TaxResidentNonIndian = Convert.ToBoolean(Facta.TAXRESIDENTOTHERTHANINDIA) ?? false;
                                LstFatca.Add(mFFatcaDetails);
                            }
                        }
                        ObjResponse.FatcaDetails = LstFatca;

                        var NRIContact = ClientData.Read().ToList();
                        MFContactDetails mFContactDetails = new MFContactDetails();
                        List<MFContact> LstContact = new List<MFContact>();
                        MFNRIContact mFNRIContact = new MFNRIContact();
                        if (NRIContact.Count()>0)
                        {
                            mFNRIContact.Address1= Convert.ToString(NRIContact[0].NRIADDRESS1) ?? "";
                            mFNRIContact.Address2 = Convert.ToString(NRIContact[0].NRIADDRESS2) ?? "";
                            mFNRIContact.Address3 = Convert.ToString(NRIContact[0].NRIADDRESS3) ?? "";
                            mFNRIContact.City= Convert.ToString(NRIContact[0].NRICITY) ?? "";
                            mFNRIContact.Country = Convert.ToString(NRIContact[0].NRICOUNTRY) ?? "";
                            mFNRIContact.Zipcode = Convert.ToString(NRIContact[0].NRIZIPCODE) ?? "";
                        }
                        mFContactDetails.NRIContact = mFNRIContact;
                        var ContactLst = ClientData.Read().ToList();
                        if(ContactLst.Count>0)
                        {
                            foreach(var Contact in ContactLst)
                            {
                                MFContact mFContact = new MFContact();
                                mFContact.Area= Convert.ToString(Contact.AREA) ?? "";
                                mFContact.City= Convert.ToString(Contact.CITY) ?? "";
                                mFContact.Country= Convert.ToString(Contact.COUNTRY) ?? "";
                                mFContact.HFlag= Convert.ToString(Contact.HFlag) ?? "";
                                mFContact.Landmark= Convert.ToString(Contact.LANDMARK) ?? "";
                                mFContact.Pincode = Convert.ToString(Contact.PINCODE) ?? "";
                                mFContact.State= Convert.ToString(Contact.STATE) ?? "";
                                mFContact.Wing= Convert.ToString(Contact.WING) ?? "";
                                LstContact.Add(mFContact);
                            }
                        }
                        mFContactDetails.ContactDetails = LstContact;
                        ObjResponse.ContactDetails = mFContactDetails;

                        var BankDetails = ClientData.Read().ToList();
                        MFClientBankDetail mFClientBankDetail = new MFClientBankDetail();
                        if (BankDetails.Count()>0)
                        {
                            mFClientBankDetail.AccountNo= Convert.ToString(BankDetails[0].ACCOUNTNO) ?? "";
                            mFClientBankDetail.AccountType= Convert.ToString(BankDetails[0].ACCOUNTTYPE) ?? "";
                            mFClientBankDetail.BankName = Convert.ToString(BankDetails[0].BANKNAME) ?? "";
                            mFClientBankDetail.BranchAdd1 = Convert.ToString(BankDetails[0].BRANCHADDRESSLINE1) ?? "";
                            mFClientBankDetail.BranchAdd2 = Convert.ToString(BankDetails[0].BRANCHADDRESSLINE2) ?? "";
                            mFClientBankDetail.BranchAdd3 = Convert.ToString(BankDetails[0].BRANCHADDRESS3) ?? "";
                            mFClientBankDetail.BranchCity = Convert.ToString(BankDetails[0].BRANCHCITY) ?? "";
                            mFClientBankDetail.BranchName = Convert.ToString(BankDetails[0].BRANCHNAME) ?? "";
                            mFClientBankDetail.BranchPincode = Convert.ToString(BankDetails[0].BRANCHPINCODE) ?? "";
                            mFClientBankDetail.ChequeImage = Convert.ToString(BankDetails[0].CHEQUEIMAGE) ?? "";
                            mFClientBankDetail.IFSCCode= Convert.ToString(BankDetails[0].IFSCCODE) ?? "";
                            mFClientBankDetail.MICRCode = Convert.ToString(BankDetails[0].MICRCODE) ?? "";
                            mFClientBankDetail.PaymentMode= Convert.ToString(BankDetails[0].PAYMENTMODE) ?? "";
                            mFClientBankDetail.NameAsPerBank = Convert.ToString(BankDetails[0].NameAsPerBank) ?? "";
                        }
                        ObjResponse.BankDetail = mFClientBankDetail;

                        var FolioDetails = ClientData.Read().ToList();
                        MFClientFolioDetails mFClientFolioDetails = new MFClientFolioDetails();
                        if(FolioDetails.Count()>0)
                        {
                            mFClientFolioDetails.AccOpeningMode = Convert.ToString(FolioDetails[0].ACCOPENINGMODE) ?? "";
                            mFClientFolioDetails.CompanyCode= Convert.ToString(FolioDetails[0].COMPANYCODE) ?? "";
                            mFClientFolioDetails.DPIdClientId= Convert.ToString(FolioDetails[0].DPIDCLIENTID) ?? "";
                            mFClientFolioDetails.EmployeeCode = Convert.ToString(FolioDetails[0].EMPLOYEECODE) ?? "";
                            mFClientFolioDetails.FatcaFlag = Convert.ToString(FolioDetails[0].FATCA_FLAG) ?? "";
                            mFClientFolioDetails.FCOB= Convert.ToString(FolioDetails[0].FCOB) ?? "";
                            mFClientFolioDetails.HoldingDematMode= Convert.ToString(FolioDetails[0].HOLDINGDEMATMODE) ?? "";
                            mFClientFolioDetails.MOGSIPFlag = Convert.ToString(FolioDetails[0].MOGSIPFLAG) ?? "";
                            mFClientFolioDetails.NomineeFlag= Convert.ToString(FolioDetails[0].NOMINEE_FLAG) ?? "";
                            mFClientFolioDetails.NSDLCDSL = Convert.ToString(FolioDetails[0].NSDLCDSL) ?? "";
                            mFClientFolioDetails.Res_App_Ref_No = Convert.ToString(FolioDetails[0].RES_APP_REF_NO) ?? "";
                            mFClientFolioDetails.Res_DateTimeStamp= Convert.ToString(FolioDetails[0].RES_DATETIMESTAMP) ?? "";
                            mFClientFolioDetails.Res_Folio= Convert.ToString(FolioDetails[0].RES_FOLIO) ?? "";
                            mFClientFolioDetails.Res_GoalId = Convert.ToString(FolioDetails[0].RES_GOALID) ?? "";
                            mFClientFolioDetails.Res_Message = Convert.ToString(FolioDetails[0].RES_MESSAGE) ?? "";
                            mFClientFolioDetails.Res_StatusCode = Convert.ToString(FolioDetails[0].RES_STATUSCODE) ?? "";
                            mFClientFolioDetails.Res_TransactionId = Convert.ToString(FolioDetails[0].RES_TRANSACTIONID) ?? "";
                            mFClientFolioDetails.TrType= Convert.ToString(FolioDetails[0].TRTYPE) ?? "";
                        }
                        ObjResponse.FolioDetails = mFClientFolioDetails;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                await File.AppendAllTextAsync(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetClientDetails \r ERROR:" + ex.Message);
                return new ResponseDataModel<MFClientDetails>(null, ex.Message);
            }
            return new ResponseDataModel<MFClientDetails>(ObjResponse);
        }

        public async Task<ResponseDataModel<validateUserRes>> validateNewMFInvestorPan(string Appid,string UserAgent, PanKYCReq request)
        {
            validateUserRes oPANCheck = new validateUserRes();
            var branchCode = "";
            if (UserAgent != null)
            {
                if (Convert.ToString(UserAgent).Contains("ChatApi"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("MOGP"))
                {
                    branchCode = "WH99";
                }
                else if (Convert.ToString(UserAgent).Contains("WEB/MultipleCampaign"))
                {
                    branchCode = "WB99";
                }
                else
                {
                    branchCode = "MB88";
                }
            }
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("MF.USP_VALIDATE_GENERATEOTP_NEWINVESTOR", 
                    new {
                        PANNO = request.panNo,
                        APPID = Appid,
                        BranchCode= branchCode,
                        USER_AGENT= UserAgent
                    }, commandType: CommandType.StoredProcedure);
                var ClientData = multi.ToList();
                if (ClientData.Count > 0)
                {
                    oPANCheck.authorizeUser = Convert.ToBoolean(ClientData[0].authorizeUser);
                    oPANCheck.message = ClientData[0].MsgMessage;
                    if (ClientData[0].AllowOTP == 0)
                    {
                        return new ResponseDataModel<validateUserRes>(null, ClientData[0].MsgMessage);
                    }
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
            return new ResponseDataModel<validateUserRes>(oPANCheck);
        }
    }
}
