﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MFTransaction.Models;

namespace MFTransaction.InvestorDetails
{
    public interface IMFTransactionDataSource
    {
        Task<ResponseDataModel<TransactionResponse>> saveMFClientTransactionSubmit(string AppID, Int64 userId, TransactionRequest request, string PanNo, string UserAgent);
        Task<ResponseDataModel<BillDeskConsolidateResponse>> BillDeskConsolidate(string AppID, Int64 userId, TransactionRequestConsolidate request, string PanNo, string UserAgent);
        Task<ResponseDataModel<TransactionConfirmationRes>> TransactionConfirmation(string AppID, Int64 userId, TransactionConfirmationReq Req, string UserAgent);
        Task<ResponseDataModel<EMandateRegRes>> EMandateRegistration(string AppID, Int64 userId, int RefNo, string UserAgent);
        Task<ResponseDataArrayModel<OTMDetails>> GetOTMDetails(OTMReq request, string PanNo);
        Task<ResponseDataModel<FinalSubmitEMandate>> SaveOTMDetails(EMandateRegReq request);
        Task<ResponseDataModel<SaveOTMConsolidateRes>> SaveOTMDetailsConsolidate(EMandateRegReqConsolidate request, string AppID, Int64 userId, string PanNo, string UserAgent);
        Task<ResponseDataArrayModel<ResSIPURNDetails>> GetSipMandateUmrnDetails(string PanNo);
        Task<ResponseDataModel<ResSIPURN>> SaveSIPMandateUmrnDetails(ReqSIPURN request, string PanNo);
        Task<ResponseDataModel<string>> SavePaymentReq(SavePaymentRequest savePayment);
        Task<ResponseDataArrayModel<ResSipBoosterDetails>> GetSipBoosterDetails(ReqSipBoosterDetails reqSipBooster, string panNo);
    }
}
