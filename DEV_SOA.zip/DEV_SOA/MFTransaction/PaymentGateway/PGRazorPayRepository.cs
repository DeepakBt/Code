﻿using ApiCore.DTOs;
using ApiCore.Model;
using Dapper;
using MFTransaction.InvestorDetails;
using MFTransaction.Models;
using MFTransaction.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;

namespace MFTransaction.PaymentGateway
{
    public class PGRazorPayRepository : IPGRazorPayDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCPORTAL);
        private readonly IOptionsSnapshot<DbConnections> _optionsSnapshot;
        private readonly TokenHelper _tokenHelper;
        string key = string.Empty;
        string Uatkey = string.Empty;
        string secret = string.Empty;
        string Uatsecret = string.Empty;
        string orderapi = string.Empty;
        string registrationLink = string.Empty;
        string orderId = string.Empty;
        string ErrorLogFile = "";
        string SP_PGLog = string.Empty;
        string inputjson = string.Empty;
        string SP_RazorPayWebhooks = string.Empty;
        string ReqLog = string.Empty;
        string merchantID = string.Empty;

        public PGRazorPayRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _optionsSnapshot = connectionsSnapshot;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
            key = _iconfiguration["RazorPay:key"];
            Uatkey = _iconfiguration["RazorPay:Uatkey"];
            secret = _iconfiguration["RazorPay:secret"];
            Uatsecret = _iconfiguration["RazorPay:Uatsecret"];
            orderapi = _iconfiguration["RazorPay:orderapi"];
            registrationLink = _iconfiguration["RazorPay:registrationLink"];
            SP_PGLog = _iconfiguration["PaymentGateway:SP_PGLog"];
            SP_RazorPayWebhooks= _iconfiguration["RazorPay:SP_RazorPayWebhooks"];
            merchantID = _iconfiguration["RazorPay:merchantID"];
        }

        public async Task<ResponseDataModel<RazorOrderResponse>> PaymentOrderGeneration(string AppId, RazorOrderRequest req)
        {
            RazorOrderResponse oResponse = null;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(orderapi);
                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://prod-api-static.razorpay.com/");
                request.Method = "POST";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                string authString = string.Format("{0}:{1}", key, secret);
                request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(authString));

                long amount = 0;
                amount = Convert.ToInt64(string.Format("{0:0}", Convert.ToDouble(req.amount)));
                if (!string.IsNullOrEmpty(req.amount) && amount > 0)
                {
                    amount = amount * 100; // Razorpay accepts money in paisa so need to convert to rupees
                }

                Dictionary<string, object> input = new Dictionary<string, object>();
                input.Add("amount", amount); // this amount should be same as transaction amount
                input.Add("currency", req.currency);
                input.Add("receipt", req.receipt);
                input.Add("payment_capture", req.payment_capture);
                //input.Add("bank",req.ban);
                object bank_account = null;
                if (!string.IsNullOrEmpty(req.account_number))
                {
                    bank_account = new { account_number = req.account_number, name = req.name, ifsc = req.ifsc };
                }

                if (req.method != "card" && req.IsTPV == true)
                {
                  //  input.Add("name", req.name); 
                    input.Add("bank_account", bank_account);
                    input.Add("method", req.method);
                }

                if (!string.IsNullOrEmpty(Convert.ToString(req.notes)) && req.notes.ToList().Count > 0)
                {
                    //string notesjson=JsonConvert.SerializeObject(req.notes, Formatting.Indented);
                    //notesjson = notesjson.Replace(System.Environment.NewLine, string.Empty);
                    //var result = JArray.Parse(notesjson);
                    //input.Add("notes", result);
                    input.Add("notes", req.notes);
                }
                var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(input));
                request.ContentLength = data.Length;
                inputjson = JsonConvert.SerializeObject(input, Formatting.Indented);
                await PGLog_Insert(req.receipt, inputjson, "", "", "", "Pending");
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                var orderResponse = (HttpWebResponse)request.GetResponse();

                JObject orderData = ParseResponse(orderResponse);
                orderId = orderData["id"].ToString();
                await PGLog_Insert(req.receipt, inputjson, orderId , "", "", "Pending");
                oResponse = new RazorOrderResponse();
                oResponse.orderid = orderId;
                return new ResponseDataModel<RazorOrderResponse>(oResponse);
            }
            catch (Exception ex)
            {
                await PGLog_Insert(req.receipt, inputjson, orderId+" |"+ ex.Message.ToString(), "", "", "failure");
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "PaymentOrderGeneration \r ERROR:" + ex.Message);
                return new ResponseDataModel<RazorOrderResponse>(null);

            }
        }

        public async Task<ResponseDataModel<ResponseOrderRes>> SaveOrderResponse(ResponseOrderReq req)
        {
            ResponseOrderRes obj = null;
            try
            {
                RazorpayClient client = new RazorpayClient(key, secret);

                Dictionary<string, string> attributes = new Dictionary<string, string>();
                if (req.razorpay_signature == null || req.razorpay_signature == "")
                {
                    obj = new ResponseOrderRes();
                    obj.payment_status = "failure";
                    await PGLog_Insert(req.receipt, "", "", "", req.error + " |" + obj.payment_status, "failure");
                    return new ResponseDataModel<ResponseOrderRes>(obj);
                }

                attributes.Add("razorpay_payment_id", req.razorpay_payment_id);
                attributes.Add("razorpay_order_id", req.razorpay_order_id);
                attributes.Add("razorpay_signature", req.razorpay_signature);

                Utility.verifyPaymentSignature(attributes);
                obj = new ResponseOrderRes();
                obj.payment_status = "success";
                await PGLog_Insert(req.receipt, "", "", "", req.razorpay_payment_id + " |"+ req.razorpay_order_id + " |"+ obj.payment_status, "success");
                return new ResponseDataModel<ResponseOrderRes>(obj);
            }
            catch (Exception)
            {
                obj.payment_status = "Failure";
                await PGLog_Insert(req.receipt, "", "", "", req.razorpay_payment_id + " |" + req.razorpay_order_id + " |" + obj.payment_status, "failure");
                return new ResponseDataModel<ResponseOrderRes>(null, "Invalid Signature");
            }
        }

        private JObject ParseResponse(HttpWebResponse response)
        {
            string responseValue = string.Empty;
            using (var responseStream = response.GetResponseStream())
            {
                if (responseStream != null)
                    using (var reader = new StreamReader(responseStream))
                    {
                        responseValue = reader.ReadToEnd();
                    }
            }

            JObject responseObject = JObject.Parse(responseValue);

            return responseObject;
        }

        public async Task<string> PGLog_Insert(string MainOrderId, string Req_XML, string Res_XML, string Req_PGString, string Res_PGString,string Payment_Res)
        {
            using (var conn = MOAMCPORTAL)
            {
                var dataLog = await conn.QueryAsync(SP_PGLog, new
                {
                    BucketId = MainOrderId,
                    Req_XML,
                    Res_XML,
                    Req_PGString,
                    PaymentURL= Res_PGString,
                    PaymentRes= Payment_Res
                }, commandType: CommandType.StoredProcedure);
                {
                    var LogRes = dataLog.ToList();
                    return "";
                }
            }
        }
        public async Task<ResponseDataModel<WebhooksResponse>> RazorPayWebhooks(WebhooksRequest request, Int64 userid)
        {

            try
            {
                string AppID = "99D97163M527AA476EM944AC8BC85D39D141";
                string UserAgent = "";
                string jsonReq = JsonConvert.SerializeObject(request);
                if (_iconfiguration["MFTnxConfLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_RazorPayWebhooks_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                    File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userid) + "\r Request :" + jsonReq);
                }
                string BucketId = request.payload.payment.entity.notes.BucketID.Split("|")[0];
                string status = Convert.ToString(request.payload.payment.entity.captured);
                using (var conn = MOAMCPORTAL)
                {
                    var dataLog = await conn.QueryAsync(SP_RazorPayWebhooks, new
                    {
                        BucketId,
                        status,
                        webhooksRequest=jsonReq
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var LogRes = dataLog.ToList();
                        
                        TransactionConfirmationReq req = new TransactionConfirmationReq();
                        req.BucketId = request.payload.payment.entity.notes.BucketID.Split("|")[0];
                        req.Acno = Convert.ToString(LogRes[0].FolioNo).Trim();
                        req.Appno = request.payload.payment.entity.order_id;
                        req.MerchantID = merchantID;
                        req.CustomerId = request.payload.payment.entity.notes.BucketID.Split("|")[0];
                        req.BankRefno = "RazorPay";
                        req.BankRemarks = "NA";
                        req.TxnAmount = Convert.ToString(request.payload.payment.entity.amount/100);
                        req.TxnId = "01";
                        req.BankID = Convert.ToString(LogRes[0].BankId).Trim();
                        req.BankMerchantID = "NA";
                        req.CurrencyName = request.payload.payment.entity.currency;
                        req.ItemCode = "DIRECT";
                        req.SecurityType = "NA";
                        req.SecurityID = "NA";
                        req.SecurityPassword = "0.00";
                        req.SettlementType= "NA";
                        req.PaymentStatus = request.payload.payment.entity.captured == true ? "0300" : "0399";

                        if (request.payload.payment.entity.captured == false)
                            req.ErrorDescription = request.payload.payment.entity.error_code + "|" + request.payload.payment.entity.error_description + "|" + request.payload.payment.entity.error_source + "|" + request.payload.payment.entity.error_step;
                        else
                            req.ErrorDescription = "Payment Success";
                        MFTransactionRepository mFTransactionRepository = new MFTransactionRepository(_optionsSnapshot, _iconfiguration, _tokenHelper);
                       var value=await  mFTransactionRepository.TransactionConfirmation(AppID, userid, req, UserAgent);
                        WebhooksResponse webhooks = new WebhooksResponse();
                        if (value.success== true)
                            webhooks.Karvystatus = "true";
                        else
                            webhooks.Karvystatus = "false";
                        return new ResponseDataModel<WebhooksResponse>(webhooks);
                    }
                }
            }
            catch (Exception ex)
            {
                WebhooksResponse webhooks = new WebhooksResponse();
                webhooks.Karvystatus = "false";
                webhooks.errorMessage = ex.Message;
                webhooks.webhooksrequest = request.ToString();
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_RazorPayWebhooks_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Karvystatus :" + "false" + "\r UserId :" + Convert.ToString(userid) + "\r Error :" + ex.Message);
                return new ResponseDataModel<WebhooksResponse>(webhooks);
            }

        }

        public async Task<ResponseDataModel<RazorPayEmandateResponse>> RazorPayEMandate(EMandateReq request, string panNo)
        {
            try
            {
                string clientName = string.Empty;
                string email = string.Empty;
                string mobileno = string.Empty;
                using (var conn = MOAMCPORTAL)
                {
                    var multi = await conn.QueryAsync("AMCMob_ClientInfo", new
                    {
                        panno = panNo.Trim(),    //From TOKEN 
                        PMSCODE = "",
                        MOSLCODE = "X",

                    }, commandType: CommandType.StoredProcedure);
                    {
                        var result = multi.ToList();
                        if(result.Count>0)
                        { 
                            clientName = Convert.ToString(result[0].ClientName);
                            email = Convert.ToString(result[0].Email);
                            mobileno = Convert.ToString(result[0].MobileNumber);
                        }
                        else
                        {
                            ErrorLogFile = _iconfiguration["ErrorLogFile"];
                            ErrorLogFile = ErrorLogFile + "_RazorPayEmandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                            File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Panno :" + Convert.ToString(panNo) + "\r Error :" + "SP not return basic client Details");
                            return new ResponseDataModel<RazorPayEmandateResponse>(null,"Client Data not found" );
                        }
                    }
                    RazorPayEMandateReq req = new RazorPayEMandateReq();
                    Customers cus = new Customers();
                    cus.name = clientName;
                    if(_iconfiguration["RazorPay:UATEnable"] =="Y")
                    {
                        cus.email = _iconfiguration["RazorPay:UATEMAIL"];
                        cus.contact = _iconfiguration["RazorPay:UATMobileNo"];
                    }
                    else {
                        cus.email = email;
                        cus.contact = mobileno;
                    }
                    var expiryat = Convert.ToDateTime(request._subscription_registration.expire_at);
                    var unixexpiryat = Convert.ToInt32(expiryat.Subtract(new DateTime(1970, 1, 1)).TotalSeconds); 
                    var expiryby = Convert.ToDateTime(request.expire_by);
                    var unixexapiryby = Convert.ToInt32(expiryby.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
                    var maxAmount= request._subscription_registration.max_amount * 100;
                    request._subscription_registration.max_amount = maxAmount;
                    req.customer = cus;
                    req.amount = request.amount*100;
                    req.type = _iconfiguration["RazorPay:type"];
                    req.currency = _iconfiguration["RazorPay:Currency"];
                    req.description = request.description;
                    Subscription_Registrations sub = new Subscription_Registrations();
                    sub.method = request._subscription_registration.method;
                    sub.auth_type = request._subscription_registration.auth_type;
                    sub.max_amount = request._subscription_registration.max_amount;
                    sub.expire_at = unixexpiryat;
                    Bank_Account bank = new Bank_Account();
                   bank.beneficiary_name = request._subscription_registration.bank_account.beneficiary_name;
                    bank.account_number = request._subscription_registration.bank_account.account_number;
                    bank.account_type = request._subscription_registration.bank_account.account_type;
                    bank.ifsc_code = request._subscription_registration.bank_account.ifsc_code;
                    sub.bank_account = bank;
                    req.subscription_registration = sub;
                    //req.subscription_registration.auth_type = Convert.ToString(authtype);
                    //req.subscription_registration.expire_at = unixexpiryat;
                    //req.subscription_registration.method = method;
                    //req.subscription_registration.max_amount = maxamount;
                    //req.subscription_registration.bank_account.beneficiary_name = beneficiaryName;
                    //req.subscription_registration.bank_account.account_number = accountnumber;
                    //req.subscription_registration.bank_account.account_type = accounttype;
                    //req.subscription_registration.bank_account.ifsc_code = ifsccode;
                    req.expire_by = unixexapiryby;
                    req.sms_notify = 1;
                    req.email_notify = 1;
                    req.notes = request.notes;
                    var multivalue = await conn.QueryAsync("Proc_Emandate", new
                    {
                            CUST_NAME = clientName,
                            CUST_EMAIL = email,
                            CUST_MOBILE = mobileno,
                            AMOUNT = request.amount,
                            DESCRIPTION=request.description,
                            SUBSCR_METHOD=request._subscription_registration.method,
                            SUBSCR_AUTH_TYPE=request._subscription_registration.auth_type,
                           SUBSCR_EXPIRE_AT=Convert.ToString(request._subscription_registration.expire_at),
                           SUBSCR_MAX_AMOUNT=request._subscription_registration.max_amount,
                            SUBSCR_BANK_ACC_NO = request._subscription_registration.bank_account.account_number,
                           SUBSCR_BANK_BENEFICIARY_NAME=request._subscription_registration.bank_account.beneficiary_name,
                           SUBSCR_ACCOUNT_TYPE=request._subscription_registration.bank_account.account_type,
                           SUBSCR_IFSC_CODE=request._subscription_registration.bank_account.ifsc_code,
                           EXPIRE_BY=Convert.ToString(request.expire_by),
                           SMS_NOTIFY=1,
                           EMAIL_NOTIFY=1,
                           notes=""

                    }, commandType: CommandType.StoredProcedure);
                    {
                             RazorPayEmandateResponse razor = new RazorPayEmandateResponse();
                            var result = multivalue.ToList();
                            if (result.Count > 0)
                            {
                                if(Convert.ToInt32(result[0].Result)==1)
                                {
                                    req.receipt = Convert.ToString(result[0].Recipt);
                                    string authString = string.Format("{0}:{1}", Uatkey, Uatsecret);
                                    inputjson = JsonConvert.SerializeObject(req, Formatting.Indented);
                                    if (_iconfiguration["MFTnxConfLog"] == "On")
                                    {
                                        ReqLog = _iconfiguration["RequestLog"];
                                        ReqLog = ReqLog + "_RazorPayEMandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                                        File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r Recipt :" + req.receipt + "\r Request :" + inputjson);
                                    }
                                    HttpClient client = new HttpClient();
                                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(authString)));
                                    var jsonData = new StringContent(inputjson, Encoding.UTF8, "application/json");
                                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                                    var result1 = await client.PostAsync(registrationLink, jsonData);
                                    var content = await result1.Content.ReadAsStringAsync();
                                    if (_iconfiguration["MFTnxConfLog"] == "On")
                                    {
                                        ReqLog = _iconfiguration["RequestLog"];
                                        ReqLog = ReqLog + "_RazorPayEMandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                                        File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r Recipt :" + req.receipt+ "\r Response :" + content);
                                    }
                                    var FinalRsponse = JsonConvert.DeserializeObject<RazorPayEMandateRes>(content.ToString());
                                    if (!string.IsNullOrEmpty(FinalRsponse.id))
                                    {
                                        var multiupdatevalue = await conn.QueryAsync("Proc_Emandate", new
                                        {
                                            RES_ID =FinalRsponse.id,
                                           RES_receipt=FinalRsponse.receipt,
                                           RES_customer_id=FinalRsponse.customer_details.id,
                                           RES_order_id=FinalRsponse.order_id,
                                           RES_status=FinalRsponse.status,
                                           RES_expire_by=Convert.ToString(FinalRsponse.expire_by),
                                           RES_short_url=FinalRsponse.short_url

                                        }, commandType: CommandType.StoredProcedure);
                                        {
                                            var updateresult = multiupdatevalue.ToList();
                                            if (updateresult.Count > 0)
                                            {
                                                if (Convert.ToInt32(updateresult[0].Result) == 1)
                                                {
                                                    req.receipt = Convert.ToString(updateresult[0].Recipt);
                                               
                                                    razor.id = FinalRsponse.id;
                                                    razor.receipt = FinalRsponse.receipt;
                                                    razor.order_id = FinalRsponse.order_id;
                                                    razor.Customer_id = FinalRsponse.customer_details.id;
                                                    razor.status = FinalRsponse.status;
                                                    razor.expire_by = FinalRsponse.expire_by;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        var FinalErrorRsponse = JsonConvert.DeserializeObject<RazorPayEMandateError>(content.ToString());
                                        return new ResponseDataModel<RazorPayEmandateResponse>(null,FinalErrorRsponse.error.description);
                                    }
                                }
                                return new ResponseDataModel<RazorPayEmandateResponse>(razor);
                            }
                            else
                            {
                                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                                ErrorLogFile = ErrorLogFile + "_RazorPayEmandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Panno :" + Convert.ToString(panNo) + "\r Error :" + "SP no treturn basic client Details");
                                return new ResponseDataModel<RazorPayEmandateResponse>(null, "Error Occured");
                            }
                    }
                }
            }
            catch(Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_RazorPayEmandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString()  + "\r Panno :" + Convert.ToString(panNo) + "\r Error :" + ex.Message);
                return new ResponseDataModel<RazorPayEmandateResponse>(null, ex.Message);
            }
        }
    }
}

