﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using APICore.Auth;
using APICore.Helpers;
using MFTransaction.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace MFTransaction.PaymentGateway
{
    [Route("api/PGRazorPay")]
    [ValidateModel]

    public class PGRazorPayController : ControllerBase
    {
        private readonly IPGRazorPayDataSource _PGRazorPayDataSource;
        public PGRazorPayController(IPGRazorPayDataSource PGRazorPayDataSource)
        {
            _PGRazorPayDataSource = PGRazorPayDataSource;
        }

        [HttpPost("OrderGeneration")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> PaymentOrderGeneration([FromBody] RazorOrderRequest request)
        {
            var AppId = IdentityHelper.GetAppId(User.Identity);
            var response = await _PGRazorPayDataSource.PaymentOrderGeneration(AppId, request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("SaveOrderResponse")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> OrderResponse([FromBody] ResponseOrderReq request)
        {
           // var AppId = IdentityHelper.GetAppId(User.Identity);
            var response = await _PGRazorPayDataSource.SaveOrderResponse(request);
            return Ok(response);
        }
        [HttpPost("RazorPayWebhooks")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<WebhooksResponse>), 200)]
        public async Task<IActionResult> RazorPayWebhooks([FromBody] WebhooksRequest request)
        {
            // var AppId = IdentityHelper.GetAppId(User.Identity);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var response = await _PGRazorPayDataSource.RazorPayWebhooks(request, userid);
            return Ok(response);
        }
        [HttpPost("EMandate")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<RazorPayEmandateResponse>), 200)]
        public async Task<IActionResult> RazorPayEMandate([FromBody] EMandateReq request)
        {
            string panNo = User.Identity.Name;
            var results = new List<ValidationResult>();
            if (panNo == "" || panNo == null)
            {
                results.Add(new ValidationResult("PanNo is mandatory..", new List<string> { "panNo" }));
                if (results.Count > 0)
                {
                    return BadRequest(results);
                }
            }
            var response = await _PGRazorPayDataSource.RazorPayEMandate(request, panNo);
            return Ok(response);
        }
    }
}