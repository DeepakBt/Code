﻿using ApiCore.DTOs;
using MFTransaction.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MFTransaction.PaymentGateway
{
    public interface IPGRazorPayDataSource
    {
        Task<ResponseDataModel<RazorOrderResponse>> PaymentOrderGeneration(string AppId, RazorOrderRequest request);
        Task<ResponseDataModel<ResponseOrderRes>> SaveOrderResponse(ResponseOrderReq request);
        Task<ResponseDataModel<WebhooksResponse>> RazorPayWebhooks(WebhooksRequest request, Int64 userid);
        Task<ResponseDataModel<RazorPayEmandateResponse>> RazorPayEMandate(EMandateReq request, string panNo);


    }
}
