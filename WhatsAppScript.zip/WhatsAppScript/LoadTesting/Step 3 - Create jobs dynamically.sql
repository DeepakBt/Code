USE msdb
GO
DECLARE @ID				INT			= 1
	, @Job_Name			VARCHAR(100)

WHILE (@ID <= 1000)
	BEGIN
		SET @Job_Name = 'Chat_Storage_Architecture_Load_Testing_Job_' + CAST(@ID AS VARCHAR(10))

		IF NOT EXISTS (SELECT 1 FROM sysjobs WHERE name = @Job_Name)
			BEGIN
				exec dbo.sp_add_job_quick 
					@job				=		@Job_Name,																			-- The job name
					@mycommand			=		'EXEC [WhatsAppAmcDB].[Chat].[usp_CHAT_STORAGE_ARCHITECTURE_LOAD_TESTING]',			-- The T-SQL command to run in the step
					@servername			=		@@SERVERNAME																		-- SQL Server name. If running localy, you can use @servername=@@Servername
			END
		
		SET @ID = @ID + 1;
	eND