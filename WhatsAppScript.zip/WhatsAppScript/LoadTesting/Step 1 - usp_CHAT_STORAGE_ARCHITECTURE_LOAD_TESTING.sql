CREATE PROCEDURE Chat.usp_CHAT_STORAGE_ARCHITECTURE_LOAD_TESTING
AS
BEGIN
	SET NOCOUNT ON
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 

	IF OBJECT_ID('tempdb..#AMC_Client_Details') IS NOT NULL DROP TABLE #AMC_Client_Details
	IF OBJECT_ID('tempdb..#TBL_EXECUTION') IS NOT NULL DROP TABLE #TBL_EXECUTION
	
	SELECT TOP 1000 IDENTITY(INT,1,1) AS ID
				, PAN_NO
				, primary_contact_number 
		INTO #AMC_Client_Details
		FROM MOAMCPORTAL.DBO.AMC_Client_Details
		WHERE ISNULL(PAN_NO,'')!= '' AND LEN(primary_contact_number) = 10

		DECLARE @MOBILE_NO VARCHAR(10)
			, @PAN_NO VARCHAR(10)
			, @STARTDATE DATETIME
			, @ENDDATE DATETIME
			, @STEP INT = 1

		CREATE TABLE #TBL_EXECUTION
		(
			STEP INT NULL
			, PANNO VARCHAR(10) NULL
			, STARTDATE DATETIME NULL
			, ENDDATE DATETIME NULL
			, TIMEDIFF VARCHAR(100) NULL
		)

	START:

		SELECT @PAN_NO = PAN_NO
			, @MOBILE_NO = primary_contact_number 
		FROM #AMC_Client_Details
		WHERE ID = FLOOR(RAND() * 1000)

			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	'Hi'
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(
					1
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)

			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	@PAN_NO
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(	
					2
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)

			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	'1'
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(
					3
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)
	
			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	'5,500,25'
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(
					4
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)
	
			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	'Y'
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(
					5
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)

			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	'9999'
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(
					6
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)
	
			SET @STARTDATE = GETDATE()
			EXEC [Chat_BLG].[USP_GatewayRequestResponse]
				@RequestText				=	'Y'
				, @Mobile_Number			=	@MOBILE_NO
				, @ChatSourceId				=	1
			SET @ENDDATE = GETDATE()
			INSERT INTO #TBL_EXECUTION
				(
					STEP
					, PANNO
					, STARTDATE
					, ENDDATE
					, TIMEDIFF
				)VALUES
				(
					7
					, @PAN_NO
					, @STARTDATE
					, @ENDDATE
					, DATEDIFF(MILLISECOND,@STARTDATE, @ENDDATE)
				)
		SELECT * FROM #TBL_EXECUTION

		GOTO START;
END