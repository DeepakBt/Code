USE msdb
GO
IF EXISTS (SELECT 1 FROM sys.procedures WHERE name = 'sp_add_job_quick' AND schema_id = 1)
	BEGIN
		DROP PROCEDURE [dbo].[sp_add_job_quick]
	END
go
CREATE procedure [dbo].[sp_add_job_quick] 
@job nvarchar(128),
@mycommand nvarchar(max), 
@servername nvarchar(28)

as
--Add a job
EXEC dbo.sp_add_job
    @job_name = @job ;
--Add a job step named process step. This step runs the stored procedure
EXEC sp_add_jobstep
    @job_name = @job,
    @step_name = N'process step',
    @subsystem = N'TSQL',
    @command = @mycommand
-- Add the job to the SQL Server Server
EXEC dbo.sp_add_jobserver
    @job_name =  @job,
    @server_name = @servername