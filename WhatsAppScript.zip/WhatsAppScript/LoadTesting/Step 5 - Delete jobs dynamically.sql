USE msdb
GO
DECLARE @ID				INT			= 1
	, @Job_Name			VARCHAR(100)

WHILE (@ID <= 100)
	BEGIN
		SET @Job_Name = 'Chat_Storage_Architecture_Load_Testing_Job_' + CAST(@ID AS VARCHAR(10))

		IF EXISTS (SELECT 1 FROM sysjobs WHERE name = @Job_Name)
			BEGIN
				EXEC dbo.sp_delete_job 
					@job_name = @Job_Name
			END

		SET @ID = @ID + 1;
	END