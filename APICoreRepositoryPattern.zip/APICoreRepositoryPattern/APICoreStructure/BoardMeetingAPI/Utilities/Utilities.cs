﻿using System;
using System.IO;

namespace BoardMeetingAPI.Utilities
{
    public static class Utilities
    {
        public static void LogErrors(string ErrorLogFile, string MethodName, string Message)
        {
            ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
            File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + MethodName + " \r ERROR:" + Message);
        }
    }
}
