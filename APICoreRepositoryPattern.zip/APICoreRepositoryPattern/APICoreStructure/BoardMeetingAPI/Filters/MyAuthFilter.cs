﻿using System;
using Microsoft.AspNetCore.Mvc.Filters;

namespace BoardMeetingAPI.Filters
{
    public class MyAuthFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine("OnActionExecuting");
        }
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("OnActionExecuted");
        }
    }
}
