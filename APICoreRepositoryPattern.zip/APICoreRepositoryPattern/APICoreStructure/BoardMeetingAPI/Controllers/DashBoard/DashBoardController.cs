﻿using Microsoft.AspNetCore.Mvc;
using BoardMeetingAPI.Model;
using BoardMeetingAPI.Filters;
using Microsoft.AspNetCore.Authorization;

namespace BoardMeetingAPI.Controllers.DashBoard
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class DashBoardController : ControllerBase
    {
        private readonly IDashBoardDataSource ObjDs;
        public DashBoardController(IDashBoardDataSource _ObjDs)
        {
            ObjDs = _ObjDs;
        }
        [HttpGet]
        [Authorize]
        [ServiceFilter(typeof(MyAuthFilter))]
        public ActionResult<EmpDashBoard> GetDashBoard()
        {
            EmpDashBoard ObjEmp = new EmpDashBoard();
            ObjEmp = ObjDs.GetData();
            return Ok(ObjEmp);
        }
    }
}