﻿using BoardMeetingAPI.Model;

namespace BoardMeetingAPI.Controllers.DashBoard
{
    public class DashBoardRepository : IDashBoardDataSource
    {
        public EmpDashBoard GetData()
        {
            EmpDashBoard ObjEmp = new EmpDashBoard();
            ObjEmp.Id = 1;
            ObjEmp.Name = "Jack";
            return ObjEmp;
        }
    }
}
