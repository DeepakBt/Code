﻿using BoardMeetingAPI.Model;
namespace BoardMeetingAPI.Controllers.DashBoard
{
    public interface IDashBoardDataSource
    {
        EmpDashBoard GetData();
    }
}
