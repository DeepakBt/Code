﻿using Microsoft.AspNetCore.Mvc;
using BoardMeetingAPI.Repository;
using BoardMeetingAPI.Model;
using Microsoft.Extensions.Configuration;
namespace BoardMeetingAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration _configuration;
        public LoginController(IConfiguration Configuration)
        {
            _configuration = Configuration;
        }
        [HttpPost]
        public ActionResult AuthUser([FromBody]LoginModel ObjLoginModel)
        {
            Login ObjLogin = new Login(_configuration);
            return Ok(ObjLogin.IsAuth(ObjLoginModel));
        }
    }
}