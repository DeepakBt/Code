﻿namespace BoardMeetingAPI.Model
{
    public class LoginModel
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
    }
    public class IsAuthResponse
    {
        public string Token { get; set; }
        public bool IsValid { get; set; }
    }
}
