﻿namespace BoardMeetingAPI.Model
{
    public class EmpDashBoard
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
