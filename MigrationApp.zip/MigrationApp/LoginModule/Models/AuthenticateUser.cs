﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using ApiCore.Validation;
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using ApiCore.Models;

namespace LoginModule.Models
{
    public class AuthenticateUser : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        /// <summary>Enter valid 4 digit OTP e.g. "XXXX"</summary>
        [Required]
        public int otp { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.panNo == null || this.panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(panNo) }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(panNo) }));
                }
            }
            return results;
        }
    }

    public class AuthorizeUser : IValidatableObject
    {
        /// <summary>SILENT|EXPLICIT</summary>
        [Required]
        public string mode { get; set; }
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        /// <summary>Enter valid 4 digit OTP e.g. "XXXX"</summary>
        public int otp { get; set; }
        /// <summary>RefreshToken</summary>
        public string accessToken { get; set; }
        /// <summary>RefreshToken</summary>
        public string refreshToken { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.mode.ToUpper().Trim() != "SILENT" && this.mode.ToUpper().Trim() != "EXPLICIT")
            {
                results.Add(new ValidationResult("Invalid Mode.", new List<string> { nameof(mode) }));
            }
            if (ParamValid.IsValidPanno(this.panNo) == false)
            {
                results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(panNo) }));
            }
            if (this.mode.ToUpper().Trim() == "SILENT")
            {
                if (this.accessToken.ToUpper().Trim() == "")
                {
                    results.Add(new ValidationResult("Access Token Required in case of 'SILENT' Mode.", new List<string> { nameof(mode) }));
                }
                if (this.refreshToken.ToUpper().Trim() == "")
                {
                    results.Add(new ValidationResult("Refresh Token Required in case of 'SILENT' Mode.", new List<string> { nameof(mode) }));
                }
            }
            else
            {
                if (this.otp == 0)
                {
                    results.Add(new ValidationResult("OTP Required in case of 'EXPLICIT' Mode.", new List<string> { nameof(mode) }));
                }
            }

            return results;
        }
    }

    public class AuthorizeUserWhatsappReq : IValidatableObject
    {
        /// <summary>SILENT|EXPLICIT</summary>
        [Required]
        public string mode { get; set; }
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        /// <summary>Enter valid 4 digit OTP e.g. "XXXX"</summary>
        public string otp { get; set; }
        /// <summary>RefreshToken</summary>
        public string accessToken { get; set; }
        /// <summary>RefreshToken</summary>
        public string refreshToken { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();

            string DecryptedPayload = RSACSP.Decrypt(this.panNo);
            string DecryptedOtp = RSACSP.Decrypt(this.otp);
            string DecryptedMode = RSACSP.Decrypt(this.mode);

            if (DecryptedPayload == "0")
            {
                results.Add(new ValidationResult("Invalid Input.", new List<string> { nameof(panNo) }));
                return results;
            }
            if (DecryptedOtp == "0")
            {
                results.Add(new ValidationResult("Invalid Input.", new List<string> { nameof(otp) }));
                return results;
            }
            if (DecryptedMode == "0")
            {
                results.Add(new ValidationResult("Invalid Input.", new List<string> { nameof(mode) }));
                return results;
            }
            this.panNo = DecryptedPayload;
            this.otp = DecryptedOtp;
            this.mode = DecryptedMode;


            if (this.mode.ToUpper().Trim() != "SILENT" && this.mode.ToUpper().Trim() != "EXPLICIT")
            {
                results.Add(new ValidationResult("Invalid Mode.", new List<string> { nameof(mode) }));
            }
            if (ParamValid.IsValidPanno(this.panNo) == false)
            {
                results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(panNo) }));
            }
            if (this.mode.ToUpper().Trim() == "SILENT")
            {
                if (this.accessToken.ToUpper().Trim() == "")
                {
                    results.Add(new ValidationResult("Access Token Required in case of 'SILENT' Mode.", new List<string> { nameof(mode) }));
                }
                if (this.refreshToken.ToUpper().Trim() == "")
                {
                    results.Add(new ValidationResult("Refresh Token Required in case of 'SILENT' Mode.", new List<string> { nameof(mode) }));
                }
            }
            else
            {
                if (this.otp == "0")
                {
                    results.Add(new ValidationResult("OTP Required in case of 'EXPLICIT' Mode.", new List<string> { nameof(mode) }));
                }
            }

            return results;
        }
    }
}
