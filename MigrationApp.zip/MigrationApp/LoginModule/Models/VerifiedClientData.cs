﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginModule.Models
{
    public class VerifiedClientData 
    {
        public string ClientName { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string ClientType { get; set; }
        public string Major { get; set; }
        public string PmsActive { get; set; }
        public string MarketValue { get; set; }
        public string NewTopup { get; set; }
        public string nri { get; set; }
    }
}
