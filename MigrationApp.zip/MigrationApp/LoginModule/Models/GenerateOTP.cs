﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using ApiCore.Validation;
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using ApiCore.Models;

namespace LoginModule.Models
{
    public class GenerateOtp : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.panNo == null || this.panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(panNo) }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.",new List<string> { nameof(panNo) }));
                   
                }
            }
            return results;
        }
    }

    public class GenerateOtpWhatsappReq : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();

            string DecryptedPANNo = RSACSP.Decrypt(this.panNo);
            this.panNo = DecryptedPANNo;

            if (this.panNo == null || this.panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan No cannot be left blank.", new List<string> { nameof(panNo) }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(panNo) }));

                }
            }
            return results;
        }
    }

}
