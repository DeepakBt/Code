﻿using System.Threading.Tasks;
using ApiCore.Model;
using Microsoft.Extensions.Options;
using System.Data;
using System.Data.SqlClient;
using LoginModule.Utils;
using LoginModule.Models;
using System;
using Dapper;
using System.Collections.Generic;
using System.Linq;
using ApiCore.Auth;
using ApiCore.DTOs;
using Microsoft.AspNetCore.Http;
using APICore.Auth;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Globalization;
using ApiCore.Exceptions;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;
using Microsoft.Extensions.Configuration;
using ApiCore.Helpers;
namespace LoginModule.Controllers
{
    public class LoginRepository  : ControllerBase , ILoginDataSource
    {

        private readonly DbConnections _connections;
        private readonly JwtSettings _jwtSettings;
        private readonly TokenHelper _tokenHelper;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        public string ErrorLogFile;
        public LoginRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IOptionsSnapshot<JwtSettings> jwtSnapshot, TokenHelper tokenHelper, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _jwtSettings = jwtSnapshot.Value;
            _tokenHelper = tokenHelper;
            _iconfiguration = iconfiguration;

        }
        //string UserAgent = AppIdValidatorMiddleware.getUserAgent();
        public async Task<ResponseDataModel<string>> OtpGenerate(string AppId, GenerateOtp request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_Proc_GENERATEOTP", new
                {
                    request.panNo,
                    AppId,

                }, commandType: CommandType.StoredProcedure))
                {
                    var Success = multi.ReadFirst<string>();
                    if (Success == "true")
                    {
                        var VerifiedList = multi.Read<Message>().ToList();
                        return new ResponseDataModel<string>(VerifiedList[0].MsgMessage);
                    }
                    else
                    {
                        var error = multi.Read<Message>().FirstOrDefault();
                        return new ResponseDataModel<string>(null, error.MsgCode);

                    }
                }
            }
        }

        public async Task<ResponseDataModel<Credentials>> AuthenticateUser(string AppId, AuthenticateUser request)
        {
            using (var conn = MOAMCMOBILEDB)
            {

                using (var multi = await conn.QueryMultipleAsync("AMCMob_Proc_VERIFYOTP", new
                {
                    request.panNo,
                    request.otp,
                    AppId,

                }, commandType: CommandType.StoredProcedure))
                {
                    var Success = multi.ReadFirst<string>();
                    if (Success == "true")
                    {
                        var VerifiedList = multi.Read().ToList();

                        VerifiedClientData objCredential = new VerifiedClientData();
                        if (VerifiedList.Count > 0)
                        {
                            objCredential.ClientName = VerifiedList[0].ClientName ?? "";
                            objCredential.MobileNumber = Convert.ToString(VerifiedList[0].MobileNumber) ?? "";
                            objCredential.Email = Convert.ToString(VerifiedList[0].Email) ?? "";
                            objCredential.ClientType = VerifiedList[0].ClientType ?? "";
                            objCredential.Major = VerifiedList[0].Major ?? "";
                            objCredential.PmsActive = VerifiedList[0].PmsActive ?? "";
                            objCredential.MarketValue = Convert.ToString(VerifiedList[0].MarketValue) ?? "";
                            objCredential.NewTopup = VerifiedList[0].NewTopup ?? "";
                            objCredential.nri = Convert.ToString(VerifiedList[0].NRI) ?? "";
                        }
                        var Role = "";
                        if (objCredential.ClientType.ToUpper() == "MF") { Role = UserRoles.MF_Investor; }
                        else if (objCredential.ClientType.ToUpper() == "PMS"){ Role = UserRoles.PMS_Investor; }
                        else if (objCredential.ClientType.ToUpper() == "BOTH"){ Role = UserRoles.Both; }
                        else { Role = UserRoles.Guest; }
                        var userId = "";
                        var credentials = new Credentials()
                        {
                            accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppId, userId) ?? "",
                            refreshToken = _tokenHelper.CreateRefreshToken(request.panNo, Role, AppId) ?? "",
                            expiresIn = _tokenHelper.GetAccessTokenValiditySeconds(),
                            reLoginAfter = _jwtSettings.RefreshTokenRenewalMinutes * 60,
                            serverTime = VerifiedList[0].SERVERTIME,
                            UserInfo = objCredential,
                        };
                        return new ResponseDataModel<Credentials>(credentials);
                    }
                    else
                    {
                        var error = multi.Read<Message>().FirstOrDefault();
                        return new ResponseDataModel<Credentials>(null, error.MsgCode);
                    }
                }
            }
        }

        public async Task<ResponseDataModel<Credentials>> AuthorizeUser(string AppId, AuthorizeUser request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_Proc_VERIFYOTP", new
                {
                    request.panNo,
                    request.otp,
                    AppId,
                    request.mode,
                }, commandType: CommandType.StoredProcedure))
                {
                    var Success = multi.ReadFirst<string>();
                    if (Success == "true")
                    {
                        var VerifiedList = multi.Read().ToList();
                            VerifiedClientData objCredential = new VerifiedClientData();
                            if (VerifiedList.Count > 0)
                            {
                                objCredential.ClientName = VerifiedList[0].ClientName ?? "";
                                objCredential.MobileNumber = Convert.ToString(VerifiedList[0].MobileNumber) ?? "";
                                objCredential.Email = Convert.ToString(VerifiedList[0].Email) ?? "";
                                objCredential.ClientType = VerifiedList[0].ClientType ?? "";
                                objCredential.Major = VerifiedList[0].Major ?? "";
                                objCredential.PmsActive = VerifiedList[0].PmsActive ?? "";
                                objCredential.MarketValue = Convert.ToString(VerifiedList[0].MarketValue) ?? "";
                                objCredential.NewTopup = VerifiedList[0].NewTopup ?? "";
                                objCredential.nri = Convert.ToString(VerifiedList[0].NRI) ?? "";
                            }
                            var Role = "";
                            if (objCredential.ClientType.ToUpper() == "MF") { Role = UserRoles.MF_Investor; }
                            else if (objCredential.ClientType.ToUpper() == "PMS") { Role = UserRoles.PMS_Investor; }
                            else if (objCredential.ClientType.ToUpper() == "BOTH") { Role = UserRoles.Both; }
                            else { Role = UserRoles.Guest;}
                           
                            var refreshToken = request.refreshToken;
                            JwtSecurityToken refreshtokenData = _tokenHelper.ReadToken(request.refreshToken);
                            JwtSecurityToken accesstokenData = _tokenHelper.ReadToken(request.accessToken);
                            using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                            {
                                writer.WriteLine("\r\n Checking Repository _tokenHelper.ValidateAccessToken(request.accessToken");
                            }
                            var AccessTokenData = _tokenHelper.ValidateAccessToken(request.accessToken);
                            var AccessTokenData2 = Convert.ToString(accesstokenData);
                            string userId ="";
                            double refreshTokenPendingMinutes = 0;
                             if (request.mode.ToUpper().Trim() == "SILENT")
                            {
                            using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                            {
                                writer.WriteLine("\r\n Checking Repository for userid");
                            }
                            if (AccessTokenData2.Contains("userid"))
                                {
                                    userId = Convert.ToString(accesstokenData.Payload["userid"].ToString()) ?? "";
                                }
                                refreshTokenPendingMinutes = _jwtSettings.RefreshTokenValidityMinutes - (DateTime.Now - refreshtokenData.ValidFrom).TotalMinutes;
                            }
                       
                            if (refreshTokenPendingMinutes <= _jwtSettings.RefreshTokenRenewalMinutes)
                            {
                                refreshToken = _tokenHelper.CreateRefreshToken(request.panNo, Role, AppId);
                            }
                            using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                            {
                                writer.WriteLine("\r\n Giving value to object in Repository");
                            }
                            var credentials = new Credentials()
                            {
                                accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppId, userId),
                                refreshToken = refreshToken,
                                expiresIn = _tokenHelper.GetAccessTokenValiditySeconds(),
                                reLoginAfter = _jwtSettings.RefreshTokenRenewalMinutes * 60,
                                serverTime = VerifiedList[0].SERVERTIME,
                                UserInfo = objCredential,
                            };
                            using (StreamWriter writer = System.IO.File.AppendText("Authuser.txt"))
                            {
                                writer.WriteLine("\r\n Value given to object in Repository");
                            }
                        return new ResponseDataModel<Credentials>(credentials);
                    }
                    else
                    {
                        var error = multi.Read<Message>().FirstOrDefault();
                        return new ResponseDataModel<Credentials>(null, error.MsgCode);
                    }
                }
            }
        }

        public async Task<ResponseDataModel<VerifiedToken>> Token(string AppId, Token request)
        {
            var refreshToken = request.refreshToken;
            JwtSecurityToken RefreshToken = _tokenHelper.ReadToken(request.refreshToken);
            JwtSecurityToken accesstokenData = _tokenHelper.ReadToken(request.accessToken);
            var AccessTokenData = _tokenHelper.ValidateAccessToken(request.accessToken);
            var AccessTokenData2 = Convert.ToString(accesstokenData);
            string Role = RefreshToken.Payload["role"].ToString();
            string panNo = RefreshToken.Payload["unique_name"].ToString();
            var userId ="";
            if (AccessTokenData2.Contains("userid"))
            {
                userId = Convert.ToString(accesstokenData.Payload["userid"].ToString()) ?? "";
            }
            double refreshTokenPendingMinutes = _jwtSettings.RefreshTokenValidityMinutes - (DateTime.Now - RefreshToken.ValidFrom).TotalMinutes;
            if (refreshTokenPendingMinutes <= _jwtSettings.RefreshTokenRenewalMinutes)
            {
                refreshToken = _tokenHelper.CreateRefreshToken(panNo, Role, AppId);
            }
            var credentials = new VerifiedToken()
            {
                accessToken = _tokenHelper.CreateAccessToken(panNo, Role, AppId, userId),
                refreshToken = refreshToken,
                expiresIn = _tokenHelper.GetAccessTokenValiditySeconds(),
            };
            return new ResponseDataModel<VerifiedToken>(credentials);
        }

        public async Task<ResponseDataModel<string>> Logout(Token request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var claimsPrincipal = _tokenHelper.ValidateRefreshToken(request.refreshToken);
                if (claimsPrincipal != null)
                {
                    string expiryTime = IdentityHelper.GetExpiryTime(claimsPrincipal.Identity);
                    string TokenType = "RefreshToken";
                    int Expiry = (Convert.ToInt32(expiryTime));
                    using (var multi = await conn.QueryMultipleAsync("AMCMob_Token_Insert", new
                    {
                        request.refreshToken,
                        TokenType,
                        Expiry
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Success = multi.ReadFirst<string>();
                        if (Success == "true")
                        {
                            var VerifiedList = multi.Read<Message>().ToList();
                            return new ResponseDataModel<string>(VerifiedList[0].MsgMessage);
                        }
                        else
                        {
                            var error = multi.Read<Message>().FirstOrDefault();
                            return new ResponseDataModel<string>(null, error.MsgCode);
                        }
                    }
                }
                else
                {
                    return new ResponseDataModel<string>(null, "ERUL007");
                }
            }
        }

        public async Task<ResponseDataModel<Credentials>> authorizeUserForWhatsapp(string AppId, AuthorizeUserWhatsappReq request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_Proc_VERIFYOTP", new
                {
                    request.panNo,
                    request.otp,
                    AppId,
                    request.mode,
                }, commandType: CommandType.StoredProcedure))
                {
                    var Success = multi.ReadFirst<string>();
                    if (Success == "true")
                    {
                        var VerifiedList = multi.Read().ToList();
                        VerifiedClientData objCredential = new VerifiedClientData();
                        if (VerifiedList.Count > 0)
                        {
                            objCredential.ClientName = VerifiedList[0].ClientName ?? "";
                            objCredential.MobileNumber = Convert.ToString(VerifiedList[0].MobileNumber) ?? "";
                            objCredential.Email = Convert.ToString(VerifiedList[0].Email) ?? "";
                            objCredential.ClientType = VerifiedList[0].ClientType ?? "";
                            objCredential.Major = VerifiedList[0].Major ?? "";
                            objCredential.PmsActive = VerifiedList[0].PmsActive ?? "";
                            objCredential.MarketValue = Convert.ToString(VerifiedList[0].MarketValue) ?? "";
                            objCredential.NewTopup = VerifiedList[0].NewTopup ?? "";
                            objCredential.nri = Convert.ToString(VerifiedList[0].NRI) ?? "";
                        }
                        var Role = "";
                        if (objCredential.ClientType.ToUpper() == "MF") { Role = UserRoles.MF_Investor; }
                        else if (objCredential.ClientType.ToUpper() == "PMS") { Role = UserRoles.PMS_Investor; }
                        else if (objCredential.ClientType.ToUpper() == "BOTH") { Role = UserRoles.Both; }
                        else { Role = UserRoles.Guest; }

                        var refreshToken = request.refreshToken;
                        JwtSecurityToken refreshtokenData = _tokenHelper.ReadToken(request.refreshToken);
                        JwtSecurityToken accesstokenData = _tokenHelper.ReadToken(request.accessToken);
                        var AccessTokenData = _tokenHelper.ValidateAccessToken(request.accessToken);
                        var AccessTokenData2 = Convert.ToString(accesstokenData);
                        string userId = "";
                        double refreshTokenPendingMinutes = 0;
                        if (request.mode.ToUpper().Trim() == "SILENT")
                        {
                            if (AccessTokenData2.Contains("userid"))
                            {
                                userId = Convert.ToString(accesstokenData.Payload["userid"].ToString()) ?? "";
                            }
                            refreshTokenPendingMinutes = _jwtSettings.RefreshTokenValidityMinutes - (DateTime.Now - refreshtokenData.ValidFrom).TotalMinutes;
                        }

                        if (refreshTokenPendingMinutes <= _jwtSettings.RefreshTokenRenewalMinutes)
                        {
                            refreshToken = _tokenHelper.CreateRefreshToken(request.panNo, Role, AppId);
                        }
                        var credentials = new Credentials()
                        {
                            accessToken = _tokenHelper.CreateAccessToken(request.panNo, Role, AppId, userId),
                            refreshToken = refreshToken,
                            expiresIn = _tokenHelper.GetAccessTokenValiditySeconds(),
                            reLoginAfter = _jwtSettings.RefreshTokenRenewalMinutes * 60,
                            serverTime = VerifiedList[0].SERVERTIME,
                            UserInfo = objCredential,
                        };
                        return new ResponseDataModel<Credentials>(credentials);
                    }
                    else
                    {
                        var error = multi.Read<Message>().FirstOrDefault();
                        return new ResponseDataModel<Credentials>(null, error.MsgCode);
                    }
                }
            }
        }

        public async Task<ResponseDataModel<string>> GenerateOtpWhatsapp(string AppId, GenerateOtpWhatsappReq request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_Proc_GENERATEOTP", new
                {
                    request.panNo,
                    AppId,
                }, commandType: CommandType.StoredProcedure))
                {
                    var Success = multi.ReadFirst<string>();
                    if (Success == "true")
                    {
                        var VerifiedList = multi.Read<Message>().ToList();
                        return new ResponseDataModel<string>(VerifiedList[0].MsgMessage);
                    }
                    else
                    {
                        var error = multi.Read<Message>().FirstOrDefault();
                        return new ResponseDataModel<string>(null, error.MsgCode);

                    }
                }
            }
        }

        public async Task<ResponseDataModel<KYC_DETAILS>> saveNewInvestorKYC_Details(RequestPANKYC ObjPAN)
        {
            KYC_DETAILS objkYC_DETAILS = new KYC_DETAILS();
            try
            {
                string KYC_XMLData = string.Empty;
                CVLPanKycData objCVLPanKycData = new CVLPanKycData(_iconfiguration);
                KYC_XMLData = objCVLPanKycData.GetPanServiceKYC_Data(ObjPAN);
                XmlDocument xmlDoc = new XmlDocument();
                if (KYC_XMLData != null && KYC_XMLData != "")
                {
                    XmlNode chkXMLNodeExist;
                    xmlDoc.LoadXml(KYC_XMLData);
                    objkYC_DETAILS.UPDATE_FLAG = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_UPDTFLG").InnerText;
                    objkYC_DETAILS.POS_CODE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_INT_CODE").InnerText;
                    objkYC_DETAILS.ENTITY_TYPE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_TYPE").InnerText;
                    objkYC_DETAILS.APPLICATION_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_NO").InnerText;
                    objkYC_DETAILS.APPLICATION_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_DATE").InnerText;
                    objkYC_DETAILS.EXEMPT = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_EXMT").InnerText;
                    objkYC_DETAILS.EXEMPTION_CATEGORY = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_EXMT_CAT").InnerText;
                    objkYC_DETAILS.PROOF_OF_ID = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_EXMT_ID_PROOF").InnerText;
                    objkYC_DETAILS.IN_PERSON_VERIFICATION = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_IPV_FLAG").InnerText;
                    objkYC_DETAILS.IN_PERSON_VERIFICATION_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_IPV_DATE").InnerText;
                    objkYC_DETAILS.GENDER = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_GEN").InnerText;
                    objkYC_DETAILS.APPLICANT_NAME = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_NAME").InnerText;
                    objkYC_DETAILS.FATHERS_NAME = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_F_NAME").InnerText;
                    objkYC_DETAILS.DATE_OF_BIRTH = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_DOB_DT").InnerText;
                    objkYC_DETAILS.ENTITY_REGSITRATION_NUMBER = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_REGNO").InnerText;
                    objkYC_DETAILS.COMMENCEMENT_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COMMENCE_DT").InnerText;
                    objkYC_DETAILS.NATIONALITY = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_NATIONALITY").InnerText;
                    objkYC_DETAILS.NATIONALITY_OTHERS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OTH_NATIONALITY").InnerText;
                    objkYC_DETAILS.COMPANY_STATUS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COMP_STATUS").InnerText;
                    objkYC_DETAILS.COMPANY_STATUS_OTHERS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OTH_COMP_STATUS").InnerText;
                    objkYC_DETAILS.RESIDENTIAL_STATUS_INDIVIDUALS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_RES_STATUS").InnerText;
                    objkYC_DETAILS.RESIDENTIAL_STATUS_NON_RESIDENT_INDIAN = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_RES_STATUS_PROOF").InnerText;
                    objkYC_DETAILS.PAN_GIR_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PAN_NO").InnerText;
                    objkYC_DETAILS.PAN_COPY_FLAG = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PAN_COPY").InnerText;
                    objkYC_DETAILS.AADHAR_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_UID_NO").InnerText;
                    objkYC_DETAILS.CORR_ADD_1 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_ADD1").InnerText;
                    objkYC_DETAILS.CORR_ADD_2 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_ADD2").InnerText;
                    objkYC_DETAILS.CORR_ADD_3 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_ADD3").InnerText;
                    objkYC_DETAILS.CORR_CITY = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_CITY").InnerText;
                    objkYC_DETAILS.CORR_PIN_CODE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_PINCD").InnerText;
                    objkYC_DETAILS.CORR_STATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_STATE").InnerText;
                    objkYC_DETAILS.CORR_COUNTRY = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_CTRY").InnerText;
                    objkYC_DETAILS.OFF_TEL_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OFF_NO").InnerText;
                    objkYC_DETAILS.RES_TEL_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_RES_NO").InnerText;
                    objkYC_DETAILS.MOBILE_TEL_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_MOB_NO").InnerText;
                    objkYC_DETAILS.FAX_TEL_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FAX_NO").InnerText;
                    objkYC_DETAILS.EMAIL_ID = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_EMAIL").InnerText;
                    objkYC_DETAILS.COR_ADDRESS_PROOF = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_ADD_PROOF").InnerText;
                    objkYC_DETAILS.COR_ADDRESS_PROOF_REF_ID = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_ADD_REF").InnerText;
                    objkYC_DETAILS.COR_ADDRESS_PROOF_REF_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_COR_ADD_DT").InnerText;
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_PER_ADD_FLAG");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.PERMANENT_FOREIGN_REGISTERED_ADDRESS_FLAG = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD_FLAG").InnerText;
                        chkXMLNodeExist = null;
                    }
                    objkYC_DETAILS.PERM_FOREIGN_REGD_ADD_1 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD1").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_ADD_2 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD2").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_ADD_3 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD3").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_CITY = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_CITY").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_ZIP_CODE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_PINCD").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_STATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_STATE").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_COUNTRY = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_CTRY").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_ADD_PROOF = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD_PROOF").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_REGD_ADD_PROOF_REF_ID = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD_REF").InnerText;
                    objkYC_DETAILS.PERM_FOREIGN_ADD_PROOF_REF_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_PER_ADD_DT").InnerText;
                    objkYC_DETAILS.GROSS_ANNUAL_INCOME = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_INCOME").InnerText;
                    objkYC_DETAILS.OCCUPATION_DETAILS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OCC").InnerText;
                    objkYC_DETAILS.OCCUPATION_DETAILS_OTHERS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OTH_OCC").InnerText;
                    objkYC_DETAILS.POLITICAL_CONNECTION = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_POL_CONN").InnerText;
                    objkYC_DETAILS.DOCUMENT_SUBMISSION_DETAILS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_DOC_PROOF").InnerText;
                    objkYC_DETAILS.INTERMEDIARY_INTERNAL_REF_NO = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_INTERNAL_REF").InnerText;
                    objkYC_DETAILS.BRANCH_CODE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_BRANCH_CODE").InnerText;
                    objkYC_DETAILS.MARITAL_STATUS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_MAR_STATUS").InnerText;
                    objkYC_DETAILS.NETWORTH = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_NETWRTH").InnerText;
                    objkYC_DETAILS.NETWORTH_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_NETWORTH_DT").InnerText;
                    objkYC_DETAILS.PLACE_OF_INCORPORATION = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_INCORP_PLC").InnerText;
                    objkYC_DETAILS.ANY_OTHER_INFORMATION = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OTHERINFO").InnerText;
                    objkYC_DETAILS.Hold_REMARK = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_REMARKS").InnerText;
                    objkYC_DETAILS.FILLER_1 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FILLER1").InnerText;
                    objkYC_DETAILS.FILLER_2 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FILLER2").InnerText;
                    objkYC_DETAILS.FILLER_3 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FILLER3").InnerText;
                    objkYC_DETAILS.FILLER_3 = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FILLER3").InnerText;
                    objkYC_DETAILS.KYC_STATUS = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_STATUS").InnerText;
                    objkYC_DETAILS.KYC_STATUS_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_STATUSDT").InnerText;
                    objkYC_DETAILS.REJECTION_REASON = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_ERROR_DESC").InnerText;
                    objkYC_DETAILS.DUMP_TYPE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_DUMP_TYPE").InnerText;
                    objkYC_DETAILS.DOWNLOAD_DATE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_DNLDDT").InnerText;
                    objkYC_DETAILS.KRA_Name = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_KRA_INFO").InnerText;
                    objkYC_DETAILS.KYC_MODE = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_KYC_MODE").InnerText;
                    objkYC_DETAILS.CVLKRA_Vault_Ref_Number = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_VAULT_REF").InnerText;
                    objkYC_DETAILS.Aadhaar_Ref_Number = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_UID_TOKEN").InnerText;
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_OFF_ISD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.OFF_TEL_ISD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OFF_ISD").InnerText;
                        chkXMLNodeExist = null;
                    }
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_OFF_STD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.OFF_TEL_STD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_OFF_STD").InnerText;
                        chkXMLNodeExist = null;
                    }
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_RES_ISD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.RES_TEL_ISD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_RES_ISD").InnerText;
                        chkXMLNodeExist = null;
                    }
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_RES_STD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.RES_TEL_STD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_RES_STD").InnerText;
                        chkXMLNodeExist = null;
                    }
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_MOB_ISD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.MOBILE_TEL_ISD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_MOB_ISD").InnerText;
                        chkXMLNodeExist = null;
                    }
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_FAX_ISD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.FAX_TEL_ISD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FAX_ISD").InnerText;
                    }
                    chkXMLNodeExist = xmlDoc.SelectSingleNode("APP_FAX_STD");
                    if (chkXMLNodeExist != null)
                    {
                        objkYC_DETAILS.FAX_TEL_STD = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_FAX_STD").InnerText;
                        chkXMLNodeExist = null;
                    }
                    objkYC_DETAILS.Version_Number = xmlDoc.SelectSingleNode("ROOT/KYCDATA/APP_VER_NO").InnerText;

                    string KYCXML_NewString =  Utilities.ObjectToXMLString(objkYC_DETAILS);
                    if (objkYC_DETAILS.CORR_ADD_1 != null && objkYC_DETAILS.CORR_ADD_1 != "")
                    {
                        objkYC_DETAILS = null;
                        XElement doc = XElement.Parse(KYCXML_NewString);
                        doc.Descendants().Where(e => string.IsNullOrEmpty(e.Value)).Remove();
                        KYCXML_NewString = Convert.ToString(doc);
                        using (var conn = MOAMCMOBILEDB)
                        {
                            using (var multi = await conn.QueryMultipleAsync("CVL.usp_KYC_DETAILS", new
                            {
                                Flag = 2,
                                XMLData = KYCXML_NewString

                            }, commandType: CommandType.StoredProcedure))
                            {
                                var result = multi.ReadSingle<string>();
                                if (result == "2" || result == "1")
                                {
                                    objkYC_DETAILS = multi.ReadSingle<KYC_DETAILS>();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "CVLErrorLog_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                System.IO.File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r\n Method :" + "saveNewInvestorKYC_Details" + "\r\n REQUEST:" + ObjPAN.panNo + "\r\n ERROR:" + ex.Message);
                throw new NoDataException(false);
            }
            return new ResponseDataModel<KYC_DETAILS>(objkYC_DETAILS);

        }
        public async Task<ResponseDataModel<KYC_DETAILS>> GetNewInvestorKYC_Details(RequestPANKYC ObjPAN)
        {
            KYC_DETAILS objkYC_DETAILS = new KYC_DETAILS();
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var multi = await conn.QueryMultipleAsync("CVL.usp_KYC_DETAILS", new
                    {
                        Flag = 1,
                        XMLData = "<KYC_DETAILS><PAN_GIR_NO>" + Convert.ToString(ObjPAN.panNo) + "</PAN_GIR_NO></KYC_DETAILS>"

                    }, commandType: CommandType.StoredProcedure))
                    {
                        var result = multi.ReadSingle<string>();
                        if (result == "1")
                        {
                            objkYC_DETAILS = multi.ReadSingle<KYC_DETAILS>();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "CVLErrorLog_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                System.IO.File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r\n Method :" + "GetNewInvestorKYC_Details" + "\r\n REQUEST:" + ObjPAN.panNo + "\r\n ERROR:" + ex.Message);
                throw new NoDataException(false);
            }
            return new ResponseDataModel<KYC_DETAILS>(objkYC_DETAILS);
        }
    }
}

