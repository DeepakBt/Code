﻿using ApiCore.DTOs;
using ApiCore.Model;
using LoginModule.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginModule.Controllers
{
   public interface ILoginDataSource
    {
        Task<ResponseDataModel<string>> OtpGenerate(string AppId, GenerateOtp request);
        Task<ResponseDataModel<Credentials>> AuthenticateUser(string AppId, AuthenticateUser request);
        Task<ResponseDataModel<Credentials>>  AuthorizeUser(string AppId, AuthorizeUser request);
        Task<ResponseDataModel<VerifiedToken>> Token(string AppId, Token request);        
        Task<ResponseDataModel<string>> Logout(Token request);
        Task<ResponseDataModel<Credentials>> authorizeUserForWhatsapp(string AppId, AuthorizeUserWhatsappReq request);
        Task<ResponseDataModel<string>> GenerateOtpWhatsapp(string AppId, GenerateOtpWhatsappReq request);
        Task<ResponseDataModel<KYC_DETAILS>> saveNewInvestorKYC_Details(RequestPANKYC ObjPAN);
        Task<ResponseDataModel<KYC_DETAILS>> GetNewInvestorKYC_Details(RequestPANKYC ObjPAN);
    }
}
