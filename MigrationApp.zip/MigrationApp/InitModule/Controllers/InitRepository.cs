﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Model;
using InitModule.Models;
using Microsoft.Extensions.Options;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using ApiCore.DTOs;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;
using ApiCore.Exceptions;
using ApiCore.Auth;
using Microsoft.AspNetCore.Http;
using ApiCore.Helpers;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net;
using System.Xml;
using Newtonsoft.Json.Linq;
using karvyAPI;

namespace InitModule.Controllers
{
    public class InitRepository : InitDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCMobileDB);
        string UserValidationTime = "0";
        string userName = string.Empty;
        string PosCode = string.Empty;
        string password = string.Empty;
        string PassKey = string.Empty;
        string CVLserviceUrl = string.Empty;
        string KarvyserviceUrl = string.Empty;
        string Adminusername = string.Empty;
        string Adminpassword = string.Empty;

        public InitRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            UserValidationTime = _iconfiguration["UserSession:UserValidationTime"];
            userName = _iconfiguration["panEnquiry:username"];
            PosCode = _iconfiguration["panEnquiry:poscode"];
            password = _iconfiguration["panEnquiry:password"];
            PassKey = _iconfiguration["panEnquiry:passkey"];
            CVLserviceUrl = _iconfiguration["panEnquiry:CVLAPI"];
            KarvyserviceUrl = _iconfiguration["StaticPath:URL:serviceUrl"];
            Adminusername = _iconfiguration["StaticPath:URL:Adminusername"];
            Adminpassword = _iconfiguration["StaticPath:URL:Adminpassword"];
        }

        ParamValid oParamValid = new ParamValid();

        //string UserAgent = AppIdValidatorMiddleware.getUserAgent(); Suryakant Testing
        public async Task<ResponseDataModel<InitGet>> InitApp(InitPost request)
        {
            using (var conn = MOAMCPORTAL)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_Init_NewUser", new
                {
                    request.appId,
                    request.appMarket,
                    request.appName,
                    request.appVersion,
                    deviceIMEI = "",
                    request.deviceModel,
                    request.deviceScreen,
                    request.deviceUUID,
                    request.deviceVendor,
                    mobileNo = "",
                    request.osName,
                    request.osVendor,
                    request.osVersion,
                    request.osVersionNumber,
                    request.updatedTimeStamp,
                }, commandType: CommandType.StoredProcedure))
                {

                    var Returnvalue = multi.Read<InitGet>().FirstOrDefault();
                    bool UpdateTable = multi.Read<Boolean>().FirstOrDefault();
                    Returnvalue.userValidationtime = Convert.ToInt64(UserValidationTime);
                    Returnvalue.errorMessages = new List<ErrorMessage>();
                    Returnvalue.MFProducts = new List<MFProduct>();
                    Returnvalue.MFScheme = new List<MF>();
                    Returnvalue.PMSProducts = new List<PMS>();

                    if (UpdateTable)
                    {
                        List<ErrorMessage> ErrList = new List<Models.ErrorMessage>();
                        ErrList = multi.Read<ErrorMessage>().ToList();
                        Returnvalue.errorMessages = ErrList;

                        List<MFProduct> oMFProductList = new List<Models.MFProduct>();
                        oMFProductList = multi.Read<MFProduct>().ToList();
                        Returnvalue.MFProducts = oMFProductList;

                        List<MF> oMFList = new List<Models.MF>();
                        oMFList = multi.Read<MF>().ToList();
                        Returnvalue.MFScheme = oMFList;

                        List<PMS> oPMSList = new List<PMS>();
                        oPMSList = multi.Read<PMS>().ToList();
                        Returnvalue.PMSProducts = oPMSList;
                    }
                    return new ResponseDataModel<InitGet>(Returnvalue);
                }

            }
        }


        public async Task<ResponseDataModel<InitGet>> InitWeb(WebInitPost request)
        {
            using (var conn = MOAMCPORTAL)
            {
                var osName = request.osName;
                using (var multi = await conn.QueryMultipleAsync("AMCWEB_Init_NewUser", new
                {
                    request.appId,
                    request.appMarket,
                    request.appName,
                    appVersion = "0",
                    deviceIMEI = request.machineIp,
                    deviceModel = osName,
                    request.deviceScreen,
                    deviceUUID = "",
                    deviceVendor = osName,
                    mobileNo = "",
                    osName = osName,
                    request.osVendor,
                    request.osVersion,
                    osVersionNumber = 0,
                    updatedTimeStamp = 0
                }, commandType: CommandType.StoredProcedure))
                {

                    var Returnvalue = multi.Read<InitGet>().FirstOrDefault();
                    bool UpdateTable = multi.Read<Boolean>().FirstOrDefault();
                    Returnvalue.userValidationtime = Convert.ToInt64(UserValidationTime);
                    Returnvalue.errorMessages = new List<ErrorMessage>();
                    Returnvalue.MFProducts = new List<MFProduct>();
                    Returnvalue.MFScheme = new List<MF>();
                    Returnvalue.PMSProducts = new List<PMS>();

                    if (UpdateTable)
                    {
                        List<ErrorMessage> ErrList = new List<Models.ErrorMessage>();
                        ErrList = multi.Read<ErrorMessage>().ToList();
                        Returnvalue.errorMessages = ErrList;

                        List<MFProduct> oMFProductList = new List<Models.MFProduct>();
                        oMFProductList = multi.Read<MFProduct>().ToList();
                        Returnvalue.MFProducts = oMFProductList;

                        List<MF> oMFList = new List<Models.MF>();
                        oMFList = multi.Read<MF>().ToList();
                        Returnvalue.MFScheme = oMFList;

                        List<PMS> oPMSList = new List<PMS>();
                        oPMSList = multi.Read<PMS>().ToList();
                        Returnvalue.PMSProducts = oPMSList;
                    }
                    return new ResponseDataModel<InitGet>(Returnvalue);
                }

            }
        }
        public async Task<ResponseDataModel<InitGetBasicInfoRes>> GetAppBasicDetails()
        {

            using (var conn = MOAMCPORTAL)
            {

                using (var multi = await conn.QueryMultipleAsync("AMCMob_Init_GetbasicDetails", null, commandType: CommandType.StoredProcedure))
                {

                    InitGetBasicInfoRes Returnvalue = new InitGetBasicInfoRes();
                    List<ErrorMessage> ErrList = new List<Models.ErrorMessage>();
                    ErrList = multi.Read<ErrorMessage>().ToList();
                    Returnvalue.errorMessages = ErrList;


                    List<MFProduct> oMFProductList = new List<Models.MFProduct>();
                    oMFProductList = multi.Read<MFProduct>().ToList();
                    Returnvalue.MFProducts = oMFProductList;


                    List<MF> oMFList = new List<Models.MF>();
                    oMFList = multi.Read<MF>().ToList();
                    Returnvalue.MFScheme = oMFList;

                    List<PMS> oPMSList = new List<PMS>();
                    oPMSList = multi.Read<PMS>().ToList();
                    Returnvalue.PMSProducts = oPMSList;

                    return new ResponseDataModel<InitGetBasicInfoRes>(Returnvalue);

                }
            }
        }

        public async Task<ResponseDataModel<AppUpdatedInfo>> GetAppUpdatedInfo(GetAppInfo request)
        {

            using (var conn = MOAMCPORTAL)
            {

                using (var multi = await conn.QueryMultipleAsync("AMCMOB_GetAppUpdateInfo", new
                {
                    request.appChannel,
                }, commandType: CommandType.StoredProcedure))
                {
                    AppUpdatedInfo objApp = new AppUpdatedInfo();
                    var Data = multi.Read<AppUpdatedInfo>().ToList();
                    if (Data.Count > 0)
                    {
                        string channel = (from p in Data.ToList()
                                          select p.channel).SingleOrDefault();
                        string version = (from p in Data.ToList()
                                          select p.version).SingleOrDefault();
                        bool isMandatory = Convert.ToBoolean((from p in Data.ToList()
                                                              select p.isMandatory).SingleOrDefault());
                        string url = (from p in Data.ToList()
                                      select p.url).SingleOrDefault();
                        string releaseNotes = (from p in Data.ToList()
                                               select oParamValid.RemoveHTMLTag(p.releaseNotes)).SingleOrDefault();
                        objApp.channel = channel ?? "";
                        objApp.version = version ?? "";
                        objApp.isMandatory = isMandatory;
                        objApp.url = url ?? "";
                        objApp.releaseNotes = releaseNotes ?? "";
                        return new ResponseDataModel<AppUpdatedInfo>(objApp);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }

            }
        }

        // made to Capture Client infor and trigger SMS and Email to client
        public async Task<ResponseDataModel<string>> saveDigitalClientInfo(clientInfo request)
        {
            using (var conn = MOAMCPORTAL)
            {
                using (var multi = await conn.QueryMultipleAsync("USP_INSERT_DIGITAL_CLIENT_INFO", new
                {
                    request.data_from,
                    request.client_Mobile,
                    request.client_Email,
                    request.client_Name,
                    request.client_PAN,
                    request.client_Add1,
                    request.client_Add2,
                    request.client_Add3,
                    request.client_State,
                    request.client_City
                }, commandType: CommandType.StoredProcedure))
                {

                    var Returnvalue = multi.Read<string>().FirstOrDefault();
                    return new ResponseDataModel<string>(Returnvalue);
                }

            }
        }

        public async Task<ResponseDataModel<string>> SaveApplicationForm(ApplicationForms request)
        {
            string ErrorLogFile = string.Empty;
            try
            {
                string AttchmentPath = string.Empty;
                string XmlData = Utilities.ObjectToXMLString(request);
                AttchmentPath = _iconfiguration["AttchmentPath"];
                string FinancialModelFile = string.Empty;
                string ApplicationFormFile = string.Empty;
                FinancialModelFile = AttchmentPath + request.NameOfInstitute.Replace(" ", "_").Replace(",", "").Replace(";", "") + request.FinancialModelExtension;
                ApplicationFormFile = AttchmentPath + request.NameOfInstitute.Replace(" ", "_").Replace(",", "").Replace(";", "") + request.ApplicationFormExtension;
                if (File.Exists(FinancialModelFile))
                {
                    File.Delete(FinancialModelFile);
                }
                if (File.Exists(ApplicationFormFile))
                {
                    File.Delete(ApplicationFormFile);
                }
                File.WriteAllBytes(@"" + FinancialModelFile, Convert.FromBase64String(request.FinancialModel));
                File.WriteAllBytes(@"" + ApplicationFormFile, Convert.FromBase64String(request.ApplicationForm));
                using (var conn = MOAMCPORTAL)
                {
                    using (var multi = await conn.QueryMultipleAsync("USP_APPLICATION_FORM", new
                    {
                        Flag = 1,
                        XMLFormData = XmlData,
                        AttachmentPath = _iconfiguration["MailAttchmentPath"]
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = multi.Read<string>().FirstOrDefault();
                        return new ResponseDataModel<string>(Returnvalue);
                    }
                }
            }
            catch (Exception ex)
            {

                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveApplicationForm \r ERROR:" + ex.Message);
                throw new NoDataException(false);
            }
        }
        public async Task<ResponseDataModel<BannerResfor>> GetLink(BannerReqfor req, string AppId)
        {
            BannerResfor objRes = new BannerResfor();
            using (var conn = MOAMCPORTAL)
            {
                var multi = await conn.QueryAsync("USP_GENERATE_NFO_URL", new
                {
                    BannerReqFor = req.Bannerfor,
                    AppId = AppId
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);

                var ObjBannerList = multi.ToList();
                if (ObjBannerList.Count > 0)
                {
                    objRes.URL = ObjBannerList[0].URL ?? "";
                    return new ResponseDataModel<BannerResfor>(objRes);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }

        public async Task<ResponseDataModel<string>> saveData(submitData request)
        {
            string ErrorLogFile = string.Empty;
            try
            {
                using (var conn = MOAMCPORTAL)
                {
                    using (var multi = await conn.QueryMultipleAsync("[USP_INSERTFORM_DATA]", new
                    {
                        SAVEDATA = request.frmdata
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = multi.Read<string>().FirstOrDefault();
                        return new ResponseDataModel<string>(Returnvalue);
                    }
                }
            }
            catch (Exception ex)
            {

                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveData \r ERROR:" + ex.Message);
                throw new NoDataException(false);
            }
        }

        public async Task<ResponseDataModel<CVLRes>> GetCVLKYCCheck(CVLReq req)
        {
            string PanNo = req.PanNo;
            string ErrorLogFile = string.Empty;

            CVLRes objRes = new CVLRes();
            try
            {
                // Step: 1 Check in existing investor or not
                using (var conn = MOAMCPORTAL)
                {
                    var multi = await conn.QueryAsync("PROC_CHECKPANEXISTING ", new { PAN_NO = PanNo }, commandType: CommandType.StoredProcedure);
                    var ClientData = multi.ToList();
                    if (ClientData[0].KYCDONE == "YES")
                    {
                        objRes.KycStatus = "Y";
                        objRes.NameAsOnPan = Convert.ToString(ClientData[0].FHNAME);
                        return new ResponseDataModel<CVLRes>(objRes);
                    }
                    else
                    {
                        // Step: 2 Check in new investor with CVL API

                        string input = "panNo=" + PanNo + "&userName=" + userName + "&PosCode=" + PosCode + "&password=" + password + "&PassKey=" + PassKey;
                        input = CVLserviceUrl + "?" + input;
                        var client = new WebClient();
                        client.Headers.Add("Content-type", "text/xml; charset=utf-8");
                        client.Headers.Add("Content-Length", "length");
                        for (int i = 1; i <= 3; i++)
                        {
                            var response = client.DownloadString(input);
                            if (response.Contains("xml"))
                            {
                                XmlDocument doc = new XmlDocument();
                                doc.LoadXml(response);
                                string json = JsonConvert.SerializeXmlNode(doc);
                                var result = JObject.Parse(json);
                                string Name = Convert.ToString(result["APP_RES_ROOT"]["APP_PAN_INQ"]["APP_NAME"]);
                                string App_Status = Convert.ToString(result["APP_RES_ROOT"]["APP_PAN_INQ"]["APP_STATUS"]);
                                if (!string.IsNullOrEmpty(Name))
                                {
                                    objRes.KycStatus = "Y";
                                    objRes.NameAsOnPan = Name;
                                    return new ResponseDataModel<CVLRes>(objRes);
                                }
                                else
                                {
                                    objRes.KycStatus = "N";
                                    objRes.NameAsOnPan = "";
                                    return new ResponseDataModel<CVLRes>(objRes);
                                }
                            }
                            else
                            {
                                // Step: 3 If CVL API gets fail then check in with Karvy KYC API
                                object inputPan = new
                                {
                                    Adminusername,
                                    Adminpassword,
                                    PanNumber = PanNo,
                                };
                                string inputJson = JsonConvert.SerializeObject(inputPan);
                                string result = KarvyRequest.CreateHTTPRequest("KYCCheck", KarvyserviceUrl, inputJson);
                                if (result.IsValidJson())
                                {
                                    if (!string.IsNullOrEmpty(result))
                                    {
                                        var s = JsonConvert.DeserializeObject<List<PANRes>>(Convert.ToString(result));
                                        if (s != null && s.Count > 0 && Convert.ToString(s[0].ReturnCode) == "200")
                                        {
                                            var pandetail = new string[2];
                                            if (s[0].ReturnMessage.Contains("~"))
                                            {
                                                pandetail = s[0].ReturnMessage.Split("~");
                                                objRes.KycStatus = Convert.ToBoolean(pandetail[0]) == true ? "Y" : "N";
                                                objRes.NameAsOnPan = Convert.ToString(pandetail[1]);
                                                return new ResponseDataModel<CVLRes>(objRes);
                                            }
                                        }
                                        else
                                        {
                                            objRes.KycStatus = "N";
                                            objRes.NameAsOnPan = "";
                                            return new ResponseDataModel<CVLRes>(objRes);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return new ResponseDataModel<CVLRes>(objRes);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetCVLKYCCheck: \r ERROR:" + ex.Message);
                return new ResponseDataModel<CVLRes>(null, "Issue with CVL");
                //throw new NoDataException(false);
            }
        }
    }
}
