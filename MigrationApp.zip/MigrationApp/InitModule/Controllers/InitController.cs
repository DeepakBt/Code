﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using APICore.Auth;
using APICore.Helpers;
using InitModule.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace InitModule.Controllers
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class InitController : ControllerBase
    {
        private readonly InitDataSource _dataSource;

        public InitController(InitDataSource dataSource)
        {
            _dataSource = dataSource;
        }

        // Post api/values
        [HttpPost]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<InitGet>), 200)]
        public async Task<IActionResult> InitApp([FromBody] InitPost request)
        {
            var response = await _dataSource.InitApp(request);
            return Ok(response);
        }


        // Post api/values
        //[EnableCors("MOSLPolicy")]
        [HttpPost("WebInit")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<InitGet>), 200)]
        public async Task<IActionResult> InitWeb([FromBody] WebInitPost request)
        {
            var response = await _dataSource.InitWeb(request);
            return Ok(response);
        }

        // GET api/values
        [HttpGet("appConfigData")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<InitGetBasicInfoRes>), 200)]
        public async Task<IActionResult> GetAppBasicDetails()
        {
            var response = await _dataSource.GetAppBasicDetails();
            return Ok(response);
        }


        // GET api/values
        [HttpGet("AppUpdateInfo")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AppUpdatedInfo>), 200)]
        public async Task<IActionResult> GetAppUpdateInfo(GetAppInfo request)
        {
            var response = await _dataSource.GetAppUpdatedInfo(request);
            return Ok(response);
        }
        // made to Capture Client infor and trigger SMS and Email to client
        //[EnableCors("MOSLPolicy")]
        [HttpPost("DigitalClientInfo")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveDigitalClientInfo([FromBody] clientInfo request)
        {
            var response = await _dataSource.saveDigitalClientInfo(request);
            return Ok(response);
        }
        
        [HttpPost("SaveApplicationForm")]
        [Produces("application/json")]
        [EnableCors("MOSLPolicy")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> SaveApplicationForm([FromBody] ApplicationForms request)
        {
            var response = await _dataSource.SaveApplicationForm(request);
            return Ok(response);
        }

        [HttpPost("GetLink")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<BannerResfor>), 200)]
        public async Task<IActionResult> GetLink([FromBody] BannerReqfor req)
        {
            string AppId = Convert.ToString(Request.Headers["AppId"]);
            var response = await _dataSource.GetLink(req, AppId);
            return Ok(response);
        }

        [HttpPost("saveData")]
        [Produces("application/json")]
        [EnableCors("MOSLPolicy")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveData([FromBody] submitData request)
        {
            var response = await _dataSource.saveData(request);
            return Ok(response);
        }

        [HttpPost("CVLKYCCheck")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<CVLRes>), 200)]
        public async Task<IActionResult> GetCVLKYCCheck([FromBody]CVLReq req)
        {
            var response = await _dataSource.GetCVLKYCCheck(req);
            return Ok(response);
        }
    }
}
