﻿using ApiCore.DTOs;
using InitModule.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InitModule.Controllers
{
    public interface InitDataSource
    {
        Task<ResponseDataModel<InitGet>> InitApp(InitPost request);
        Task<ResponseDataModel<InitGet>> InitWeb(WebInitPost request);
        Task<ResponseDataModel<AppUpdatedInfo>> GetAppUpdatedInfo(GetAppInfo request);
        Task<ResponseDataModel<InitGetBasicInfoRes>> GetAppBasicDetails();
        Task<ResponseDataModel<string>> saveDigitalClientInfo(clientInfo request); // made to Capture Client infor and trigger SMS and Email to client
        Task<ResponseDataModel<string>> SaveApplicationForm(ApplicationForms request);
        Task<ResponseDataModel<BannerResfor>> GetLink(BannerReqfor req, string AppId);
        Task<ResponseDataModel<string>> saveData(submitData request);
        Task<ResponseDataModel<CVLRes>> GetCVLKYCCheck(CVLReq req);
    }
}
