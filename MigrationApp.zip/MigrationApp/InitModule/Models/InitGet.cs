﻿using ApiCore.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace InitModule.Models
{
    public class ErrorMessage
    {
        public string MsgCode { get; set; }
        public string MsgMessage { get; set; }
    }

    public class MFProduct
    {
        public string schemeCode { get; set; }
        public string schemeName { get; set; }
        public string groupCode { get; set; }
        public string inceptionDate { get; set; }
        public decimal inceptionPercent { get; set; }
        public int orderToDisplay { get; set; }
    }

    public class MF
    {
        public string schemeCode { get; set; }
        public string schemeName { get; set; }
        public string groupCode { get; set; }
        public string planModeId { get; set; }
        public string planMode { get; set; }
    }

    public class PMS
    {
        public string strategyCode { get; set; }
        public string strategyname { get; set; }
        public string inceptionDate { get; set; }
        public decimal inceptionPercent { get; set; }
        public int orderToDisplay { get; set; }
    }

    public class InitGet
    {
        public string appId { get; set; }
        public Int64 currentTime { get; set; }
        public string versionUpdate { get; set; }
        public Int64 userValidationtime { get; set; }
        public Int64 serverTime { get; set; }
        [DefaultValue(false)]
        public bool clearCache { get; set; }
        public bool nfoOptionAvailable { get; set; }
        public List<ErrorMessage> errorMessages { get; set; }
        public List<MFProduct> MFProducts { get; set; }
        public List<MF> MFScheme { get; set; }
        public List<PMS> PMSProducts { get; set; }
        
    }
    public class InitGetBasicInfoRes
    {
        public List<ErrorMessage> errorMessages { get; set; }
        public List<MFProduct> MFProducts { get; set; }
        public List<MF> MFScheme { get; set; }
        public List<PMS> PMSProducts { get; set; }
    }
}
