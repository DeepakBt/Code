﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using ApiCore.Validation;
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Text.RegularExpressions;

namespace InitModule.Models
{
    public class GetAppInfo : IValidatableObject
    {
        /// <summary>One of ANDROIDMARKET | APPSTORE</summary>
        [Required]
        public string appChannel { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.appChannel.Trim().ToUpper() != "ANDROIDMARKET" && this.appChannel.Trim().ToUpper() != "APPSTORE")
            {
                results.Add(new ValidationResult("Invalid appMarket.", new List<string> { nameof(appChannel) }));
            }
            return results;
        }
    }
}
