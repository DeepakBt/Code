﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InitModule.Models
{
    public class AppUpdatedInfo
    {
        public string channel { get; set; }
        public string version { get; set; }
        public bool? isMandatory { get; set; }
        public string url { get; set; }
        public string releaseNotes { get; set; }
    }
}
