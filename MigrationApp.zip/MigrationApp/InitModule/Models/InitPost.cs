﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using ApiCore.Validation;
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Text.RegularExpressions;
using ApiCore.Models;
using APICore.Auth;

namespace InitModule.Models
{

    public class InitPost : IValidatableObject
    {

        /// <summary>0/Valid appId </summary>
        [DefaultValue("0")]
        public string appId { get; set; }
        /// <summary>ANDROIDMARKET/APPSTORE </summary>
        [DefaultValue("ANDROIDMARKET | APPSTORE ")]
        public string appMarket { get; set; }
        /// <summary>Application name </summary>
        [DefaultValue("Application name")]
        public string appName { get; set; }
        /// <summary>Valid Version Format eg 1.0.0/1.02.03</summary>
        [DefaultValue("1.0.0")]
        public string appVersion { get; set; }
        /// <summary>Android SDK built for x86</summary>
        [DefaultValue("Android SDK built for x86")]
        public string deviceModel { get; set; }
        /// <summary>768 X 1184</summary>
        [DefaultValue("768 X 1184")]
        public string deviceScreen { get; set; }
        /// <summary>c7583a1f70eec554</summary>
        [DefaultValue("c7583a1f70eec554")]
        public string deviceUUID { get; set; }
        /// <summary>unknown</summary>
        [DefaultValue("unknown")]
        public string deviceVendor { get; set; }
        /// <summary>Android/ISO</summary>
        [DefaultValue("Android | iOS")]
        public string osName { get; set; }
        /// <summary>Google</summary>
         [DefaultValue("Google")]
        public string osVendor { get; set; }
        /// <summary>Valid Version Format eg 1.0.0/1.02.03</summary>
        [DefaultValue("1.0.0")]
        public string osVersion { get; set; }
        /// <summary>0/Num value</summary>
       [DefaultValue(0)]
        public Int64 osVersionNumber { get; set; }
        /// <summary>Num value in Seconds</summary>
        [DefaultValue(0)]
        public Int64 updatedTimeStamp { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();

            var match = Regex.Match(this.appVersion, @"(?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+)", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                results.Add(new ValidationResult("Invalid appVersion.", new List<string> { nameof(appVersion) }));
            }

            if (this.appMarket.Trim().ToUpper() != "ANDROIDMARKET" && this.appMarket.Trim().ToUpper() != "APPSTORE")
            {
                results.Add(new ValidationResult("Invalid appMarket.", new List<string> { nameof(appMarket) }));
            }
            if (this.osName.Trim().ToUpper() != "ANDROID" && this.osName.Trim().ToUpper() != "IOS")
            {
                results.Add(new ValidationResult("Invalid osVersion.", new List<string> { nameof(osName) }));
            }
            return results;
        }
    }
    public class clientInfo : IValidatableObject
    {
        [Required]
        public string data_from { get; set; }
        [Required]
        public string client_Mobile { get; set; }
        [Required]
        public string client_Email { get; set; }
        public string client_Name { get; set; }
        public string client_PAN { get; set; }
        public string client_Add1 { get; set; }
        public string client_Add2 { get; set; }
        public string client_Add3 { get; set; }
        public string client_State { get; set; }
        public string client_City { get; set; }

        // made to Capture Client infor and trigger SMS and Email to client
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            this.data_from =  RSAProvider.DecryptRSAAsy(this.data_from, "");
            this.client_Mobile = RSAProvider.DecryptRSAAsy(this.client_Mobile, "");
            this.client_Email = RSAProvider.DecryptRSAAsy(this.client_Email, "");
            //this.client_Name = RSAProvider.DecryptRSAAsy(this.client_Name, "");
            //this.client_PAN = RSAProvider.DecryptRSAAsy(this.client_PAN, "");
            //this.client_PAN = RSACSP.Decrypt(this.client_PAN);
            //this.client_Add1 = RSACSP.Decrypt(this.client_Add1);
            //this.client_Add2 = RSACSP.Decrypt(this.client_Add2);
            //this.client_Add3 = RSACSP.Decrypt(this.client_Add3);
            //this.client_State = RSACSP.Decrypt(this.client_State);
            //this.client_City = RSACSP.Decrypt(this.client_City);
            if (client_Mobile == "")
            {
                    results.Add(new ValidationResult("Invalid Mobile no.", new List<string> { nameof(client_Mobile) }));
            }
            else if(client_Email == "")
            {
                results.Add(new ValidationResult("Invalid Email.", new List<string> { nameof(client_Email) }));
            }
            else if (client_PAN != "")
            {
                if (ParamValid.IsValidPanno(this.client_PAN) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { nameof(client_PAN) }));
                }
            }
           
            return results;
        }
    }
    public class WebInitPost : IValidatableObject
    {
        /// <summary>0</summary>
        [DefaultValue("0")]
        public string appId { get; set; }
        /// <summary>WEB</summary>
        [DefaultValue("WEB")]
        public string appMarket { get; set; }
        /// <summary>AMC Campaign</summary>
        [DefaultValue("AMC Campaign")]
        public string appName { get; set; }
        /// <summary>machineIp</summary>
        [Required]
        public string machineIp { get; set; }
        /// <summary>Screen Size</summary>
        [DefaultValue("768 X 1184")]
        public string deviceScreen { get; set; }
        /// <summary>System OS Windows/mac/linux/ubando</summary>
        [DefaultValue("Windows/mac/linux")]
        public string osName { get; set; }
        /// <summary>IE/Chrome/Safari/Mozilaa/UC browser</summary>
        [DefaultValue("Chrome")]
        public string osVendor { get; set; }
        /// <summary>Version of Browser</summary>
        [DefaultValue("1.0.0")]
        public string osVersion { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();

            var match = Regex.Match(this.osVersion, @"(?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+)", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                results.Add(new ValidationResult("Invalid Browser Version.", new List<string> { nameof(osVersion) }));
            }

            if (this.appMarket.Trim().ToUpper() != "WEB")
            {
                results.Add(new ValidationResult("Invalid Input.", new List<string> { nameof(appMarket) }));
            }
            return results;
        }
    }
    public class ApplicationForms : IValidatableObject
    {
        [Required]
        public string NameOfInstitute { get; set; }
        [Required]
        public string ScreenAuthorityName { get; set; }
        [Required]
        public string ScreenAuthorityPhone { get; set; }
        [Required]
        public string ScreenAuthorityEmail { get; set; }
        [Required]
        public string FirstTMName { get; set; }
        [Required]
        public string FirstTMPhone { get; set; }
        [Required]
        public string FirstTMEmail { get; set; }
        [Required]
        public string SecondTMName { get; set; }
        [Required]
        public string SecondTMPhone { get; set; }
        [Required]
        public string SecondTMEmail { get; set; }
        [Required]
        public string ThirdTMName { get; set; }
        [Required]
        public string ThirdTMPhone { get; set; }
        [Required]
        public string ThirdTMEmail { get; set; }
        [Required]
        public string ApplicationForm { get; set; }
        [Required]
        public string FinancialModel { get; set; }
        [Required]
        public string AppSource { get; set; }
        [Required]
        public string FinancialModelExtension { get; set; }
        [Required]
        public string ApplicationFormExtension { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            this.NameOfInstitute = RSAProvider.DecryptRSAAsy(this.NameOfInstitute, "");
            this.ScreenAuthorityName = RSAProvider.DecryptRSAAsy(this.ScreenAuthorityName, "");
            this.ScreenAuthorityPhone = RSAProvider.DecryptRSAAsy(this.ScreenAuthorityPhone, "");
            this.ScreenAuthorityEmail = RSAProvider.DecryptRSAAsy(this.ScreenAuthorityEmail, "");
            this.FirstTMName = RSAProvider.DecryptRSAAsy(this.FirstTMName, "");
            this.FirstTMPhone = RSAProvider.DecryptRSAAsy(this.FirstTMPhone, "");
            this.FirstTMEmail = RSAProvider.DecryptRSAAsy(this.FirstTMEmail, "");
            this.SecondTMName = RSAProvider.DecryptRSAAsy(this.SecondTMName, "");
            this.SecondTMPhone = RSAProvider.DecryptRSAAsy(this.SecondTMPhone, "");
            this.SecondTMEmail = RSAProvider.DecryptRSAAsy(this.SecondTMEmail, "");
            this.ThirdTMName = RSAProvider.DecryptRSAAsy(this.ThirdTMName, "");
            this.ThirdTMPhone = RSAProvider.DecryptRSAAsy(this.ThirdTMPhone, "");
            this.ThirdTMEmail = RSAProvider.DecryptRSAAsy(this.ThirdTMEmail, "");
            this.AppSource = RSAProvider.DecryptRSAAsy(this.AppSource, "");
            this.FinancialModelExtension = RSAProvider.DecryptRSAAsy(this.FinancialModelExtension, "");
            this.ApplicationFormExtension = RSAProvider.DecryptRSAAsy(this.ApplicationFormExtension, "");

            var match1 = Regex.Match(this.FirstTMEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!match1.Success)
            {
                results.Add(new ValidationResult("Invalid First Team Member Email.", new List<string> { nameof(FirstTMEmail) }));
            }

            var match2 = Regex.Match(this.ScreenAuthorityEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!match2.Success)
            {
                results.Add(new ValidationResult("Invalid Screen Authority Email.", new List<string> { nameof(ScreenAuthorityEmail) }));
            }

            var match3 = Regex.Match(this.SecondTMEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!match3.Success)
            {
                results.Add(new ValidationResult("Invalid Second Team Member Email.", new List<string> { nameof(SecondTMEmail) }));
            }

            var match4 = Regex.Match(this.ThirdTMEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!match4.Success)
            {
                results.Add(new ValidationResult("Invalid Third Team Member Email.", new List<string> { nameof(ThirdTMEmail) }));
            }
            if(this.NameOfInstitute==null || this.NameOfInstitute=="")
            {
                results.Add(new ValidationResult("Name Of Institue is Mandatory.", new List<string> { nameof(NameOfInstitute) }));
            }
            if (this.ScreenAuthorityName == null || this.ScreenAuthorityName == "")
            {
                results.Add(new ValidationResult("Name Of Screen Authority Mandatory.", new List<string> { nameof(ScreenAuthorityName) }));
            }
            if (this.ScreenAuthorityPhone == null || this.ScreenAuthorityPhone == "")
            {
                results.Add(new ValidationResult("Phone Number Of Screen Authority Mandatory.", new List<string> { nameof(ScreenAuthorityPhone) }));
            }
            if (this.ScreenAuthorityEmail == null || this.ScreenAuthorityEmail == "")
            {
                results.Add(new ValidationResult("Email Of Screen Authority Mandatory.", new List<string> { nameof(ScreenAuthorityEmail) }));
            }
            double FModelSize = (this.FinancialModel.Length * ((double)3 / (double)4));
            if(FModelSize>=2020000)
            {
                results.Add(new ValidationResult("Financial Model Size Lenght Should Be Less Then 2Mb.", new List<string> { nameof(FinancialModel) }));
            }
            double AppFormSize = (this.ApplicationForm.Length * ((double)3 / (double)4));
            if (AppFormSize >= 2020000)
            {
                results.Add(new ValidationResult("Application Form Size Lenght Should Be Less Then 2Mb.", new List<string> { nameof(ApplicationForm) }));
            }
            if(this.ApplicationFormExtension != ".pptx" && this.ApplicationFormExtension !=".pdf")
            {
                results.Add(new ValidationResult("Application Form Should Be Either .pptx or .pdf.", new List<string> { nameof(ApplicationFormExtension) }));
            }
            if(this.FinancialModelExtension!=".xlsx" && this.FinancialModelExtension!=".xls")
            {
                results.Add(new ValidationResult("Financial Model Should Be In Excel Format.", new List<string> { nameof(ApplicationFormExtension) }));
            }
            return results;
        }
    }
    public class BannerReqfor
    {
        public string Bannerfor { get; set; }
    }
    public class BannerResfor
    {
        public string URL { get; set; }
    }
    public class submitData : IValidatableObject
    {
        [Required]
        public string frmdata { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            this.frmdata = RSAProvider.DecryptRSAAsy(this.frmdata, "");
            return results;
        }
    }

    public class CVLReq
    {
        public string PanNo { get; set; }
    }

    public class CVLRes
    {
        public string KycStatus { get; set; }
        public string NameAsOnPan { get; set; }
    }
    public class PANRes
    {
        public string ReturnMessage { get; set; }
        public string ReturnCode { get; set; }
    }
}
