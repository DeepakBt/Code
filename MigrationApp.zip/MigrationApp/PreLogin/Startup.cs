﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ApiCore.Constants;
using ApiCore.Helpers;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.PlatformAbstractions;
using PreLogin.Blog;
using PreLogin.Controllers;
using PreLogin.Filters;
using PreLogin.MF;
using PreLogin.PMS;
using PreLogin.Masters;
using Swashbuckle.AspNetCore.Swagger;
using PreLogin.SchemeDetails;
using Microsoft.Net.Http.Headers;

namespace PreLogin
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
         }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddResponseCompression(options =>
            {
                options.Providers.Add<BrotliCompressionProvider>();
                options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "image/svg+xml" });
                options.EnableForHttps = true;
            });
            services.AddMvc(options =>
            {
                options.CacheProfiles.Add("Default",
                    new CacheProfile()
                    {
                        Duration = 7600
                    });
                options.CacheProfiles.Add("Never",
                    new CacheProfile()
                    {
                        Location = ResponseCacheLocation.None,
                        NoStore = true
                    });
            });

            services.AddMvcCore()
                .AddApiExplorer()
                .AddAuthorization()
                .AddFormatterMappings()
                .AddDataAnnotations()
                .AddJsonFormatters();
            services.ConfigureSwaggerGen(options =>
            {
                //Determine base path for the application.
                var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                //Set the comments path for the swagger json and ui.
                options.IncludeXmlComments(basePath + "\\PreLogin.xml");
                options.OperationFilter<FormFileSwaggerFilter>();
            });

            //    services.AddSingleton<IConfiguration>(Configuration.GetSection("URL"));
            services.AddSingleton<IConfiguration>(Configuration.GetSection("StaticPath"));
            services.Configure<DbConnections>(Configuration.GetSection("connections"));
            services.AddScoped<IPreLoginDataSource, PreLoginRepository>();
            services.AddScoped<IBlogsDataSource, BlogsRepository>();
            services.AddScoped<ISchemeDataSource, SchemeRepository>();
            services.AddScoped<IStrategyDataSource, StrategyRepository>();
            services.AddScoped<IMastersDataSource, MastersRepository>();
            services.AddScoped<ISchemeDetailsDataSource, SchemeDetailsRepository>();
            //   services.AddCors(options =>
            //   {
            //       options.AddPolicy("MOSLPolicy",
            //builder =>
            //{
            //    builder.WithOrigins("http://localhost:52595", "http://www.moamc.com", "http://localhost:4200", "http://www.moamc.com:93", "https://moamcmob.motilaloswalmf.com", "https://www.motilaloswalmf.com")
            //                        .WithHeaders(HeaderNames.ContentType, "application/json")
            //                           .WithHeaders(HeaderNames.Vary, "Origin")
            //                        .WithHeaders()
            //                        .AllowAnyMethod()
            //                         .AllowCredentials().Build();
            //});
            //   });
            services.AddCors(options =>
            {
                options.AddPolicy("MOSLPolicy", builder =>
                {
                    builder.WithOrigins("http://localhost:52595", "http://www.moamc.com", "http://localhost:4200", "http://www.moamc.com:93", "https://moamcmob.motilaloswalmf.com", "https://www.motilaloswalmf.com").AllowAnyHeader().AllowAnyMethod().AllowCredentials().Build();
                });
            });
            // Register the Swagger generator, defining one or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "Pre Login", Version = "v1" });

                //c.AddSecurityDefinition("JWT Token", new ApiKeyScheme
                //{
                //    Description = "JWT Token",
                //    Name = "Authorization",
                //    In = "header"
                //});
                c.AddSecurityDefinition("App Id", new ApiKeyScheme
                {
                    Description = "App Id",
                    Name = HeaderConstants.AppId,
                    In = "header"
                });
            });
            //services.AddNodeServices(); //use to work with node js 
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IConfiguration iconfiguration)
        {
            app.UseMiddleware<AppIdValidatorMiddleware>();
            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseMiddleware<ApiLoggingMiddleware>();
            app.UseAuthentication();
            app.UseResponseCompression();
            app.UseCors("MOSLPolicy");
            app.UseMvc();
            string strHostName = "";
            string myIP = "";
            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            myIP = addr[addr.Length - 1].ToString();
            var swagger = iconfiguration["swagger"];
            if (myIP != swagger)
            {
                // Enable middleware to serve generated Swagger as a JSON endpoint.
                app.UseSwagger();

                // Enable middleware to serve swagger-ui (HTML, JS, CSS etc.), specifying the Swagger JSON endpoint.
                app.UseSwaggerUI(c => { c.SwaggerEndpoint("../swagger/v1/swagger.json", "PreLogin API V1"); });

                app.Run(async (context) =>
                {
                    var logger = loggerFactory.CreateLogger("PreLogin.Startup");
                    logger.LogInformation("No endpoint found for request {path}", context.Request.Path);
                    await context.Response.WriteAsync("No endpoint found.");
                });
            }
        }
    }
}
