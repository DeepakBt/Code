﻿using ApiCore.DTOs;
using ApiCore.Model;
using Dapper;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using ApiCore.Exceptions;

namespace PreLogin.PMS
{
    public class StrategyRepository : IStrategyDataSource
    {

        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        public StrategyRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
        }
        ParamValid ParamValid = new ParamValid();
        //// PreLoginPMS
        //pmsProductReturnDetails
        public async Task<ResponseDataModel<ProductReturnDetailsRes>> pmsProductReturnDetails(PMSReturn request)
        {
            using (var conn = MOAMCMOBILEDB)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMob_PROC_PERFORMANCE_DETAILS", new
                {
                    ID = request.productCode,
                    fromdate = "",
                    todate = "",
                    ASSET_SUB_TYPE_ID = 3,

                }, commandTimeout: 0, commandType: CommandType.StoredProcedure))
                {
                    var VerifiedList1 = multi.Read().ToList();
                    var VerifiedList2 = multi.Read().ToList();
                    var Navdetails = multi.Read().ToList();
                    if (Navdetails.Count > 0)
                    {
                        ProductReturnDetailsRes productReturnDetailsRes = new ProductReturnDetailsRes();
                        string Periodictab = (from p in VerifiedList1.ToList()
                                              select p.Periodictab).SingleOrDefault();
                        Periodictab = ParamValid.RemoveHTMLTag(Periodictab).Replace("\n", String.Empty).Replace("\r", String.Empty).Replace("&nbsp;", String.Empty) ?? "";
                        productReturnDetailsRes.returnDetails = Periodictab;

                        string disclaimer = (from p in VerifiedList1.ToList()
                                             select p.DISCLAIMER).SingleOrDefault();
                        disclaimer = ParamValid.RemoveHTMLTag(disclaimer).Replace("\n", String.Empty).Replace("\r", String.Empty).Replace("&nbsp;", String.Empty).Replace("&amp;", "and") ?? "";

                        productReturnDetailsRes.disclaimer = disclaimer;

                        string Schemelist = (from p in VerifiedList1.ToList()
                                             select p.PRODUCTNAME).SingleOrDefault();

                        string INDEX_NAME = (from p in VerifiedList1.ToList()
                                             select p.INDEX_NAME).SingleOrDefault();

                        productReturnDetailsRes.schemeCode = Schemelist;
                        productReturnDetailsRes.indexName = INDEX_NAME;
                        List<DataPoint3> DataPoint3 = new List<Models.DataPoint3>();
                        foreach (var p in VerifiedList2.ToList())
                        {
                            DataPoint3.Add(new DataPoint3
                            {
                                period = p.Period ?? "",
                                productReturn = Convert.ToDecimal(p.ProdReturn) ?? 0.00,
                                indexReturn = Convert.ToDecimal(p.IndexReturn) ?? 0.00,

                            });
                        }
                        productReturnDetailsRes.dataPoints = DataPoint3;

                        return new ResponseDataModel<ProductReturnDetailsRes>(productReturnDetailsRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        //pmsProductDetailsContent
        public async Task<ResponseDataArrayModel<PMSProductDetailContentRes>> pmsProductDetailsContent(PMSDetail request)
        {
            using (var conn = CMSConnection)
            {
                var multi = await conn.QueryAsync("PROC_PMS_PRODUCT_DETAILCONTENT_AMCMOBILEAPP", new
                {
                    Product = request.productCode
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    List<PMSProductDetailContentRes> Contentlist = new List<PMSProductDetailContentRes>();
                    if (VerifiedList.Count > 0)
                    {
                        foreach (var p in VerifiedList.ToList())
                        {
                            Contentlist.Add(new PMSProductDetailContentRes
                            {
                                header = p.header ?? "",
                                content = p.content ?? "",
                                subTab = p.SubTab ?? ""
                            });
                        }
                        return new ResponseDataArrayModel<PMSProductDetailContentRes>(Contentlist);
                    }

                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }

        //pmsInvestmentvalue
        public async Task<ResponseDataModel<ProductInvestRes>> pmsInvestmentvalue(PMSInvestment request)
        {
            using (var conn = CorporateConn)
            {
                using (var multi = await conn.QueryMultipleAsync("AMCMOB_MF_RetwithIndex_LumpsumChart_MOSL_pms", new
                {
                    product = request.productName,
                    invamount = 10000,
                    fromdate = request.fromDate,
                    todate = request.toDate,
           
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure))
                {
                    var VerifiedList1 = multi.Read().ToList();
                    var Navdetails = multi.Read().ToList();
                    if (Navdetails.Count > 0)
                    {

                        ProductInvestRes productReturnDetailsRes = new ProductInvestRes();
                        string Periodictab = (from p in VerifiedList1.ToList()
                                              select p.Periodictab).SingleOrDefault();
                        Periodictab = ParamValid.RemoveHTMLTag(Periodictab).Replace("\n", String.Empty).Replace("\r", String.Empty).Replace("&nbsp;", String.Empty) ?? "";
                        productReturnDetailsRes.returnDetails = Periodictab;

                        string disclaimer = (from p in VerifiedList1.ToList()
                                             select p.DISCLAIMER).SingleOrDefault();
                        disclaimer = ParamValid.RemoveHTMLTag(disclaimer).Replace("\n", String.Empty).Replace("\r", String.Empty).Replace("&nbsp;", String.Empty).Replace("&amp;", "and") ?? "";

                        productReturnDetailsRes.disclaimer = disclaimer;

                        string Schemelist = (from p in VerifiedList1.ToList()
                                             select p.PRODUCTNAME).SingleOrDefault();

                        string INDEX_NAME = (from p in VerifiedList1.ToList()
                                             select p.INDEX_NAME).SingleOrDefault();

                        productReturnDetailsRes.schemeName = Schemelist;
                        productReturnDetailsRes.indexName = INDEX_NAME;
                        List<DataPoint3> DataPoint = new List<Models.DataPoint3>();
                        foreach (var p in Navdetails.ToList())
                        {
                            DataPoint.Add(new DataPoint3
                            {
                                period = Convert.ToString(p.Recorddate) ?? "",
                                productReturn = Convert.ToDecimal(p.MarketValue_Scheme) ?? 0.00,
                                indexReturn = Convert.ToDecimal(p.MarketValue_BM) ?? 0.00
                            });
                        }
                        productReturnDetailsRes.dataPoints = DataPoint;

                        return new ResponseDataModel<ProductInvestRes>(productReturnDetailsRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }


                }
            }
        }

    }
}
