﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using APICore.Helpers;
using Microsoft.AspNetCore.Mvc;
using PreLogin.Controllers;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreLogin.PMS
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class StrategyController : ControllerBase
    {
        private string Day1 = "0";
        private readonly IStrategyDataSource _StrategyDataSource;
        ParamValid ParamValid = new ParamValid();
        public StrategyController(IStrategyDataSource StrategyDataSource)
        {
            _StrategyDataSource = StrategyDataSource;
            var now = DateTime.Now;
            var tomorrow9am = now.AddDays(1).Date.AddHours(9);
            int Duration = Convert.ToInt32((tomorrow9am - now).TotalSeconds);
            Day1 = Convert.ToString(Duration);
        }


        [HttpGet("ReturnDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ProductReturnDetailsRes>), 200)]
        public async Task<IActionResult> pmsProductReturnDetails(PMSReturn request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _StrategyDataSource.pmsProductReturnDetails(request);
            return Ok(response);
        }

        [HttpGet("DetailedContent")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<PMSProductDetailContentRes>), 200)]
        public async Task<IActionResult> pmsProductDetailsContent(PMSDetail request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _StrategyDataSource.pmsProductDetailsContent(request);
            return Ok(response);
        }

        [HttpGet("InvestmentValue")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ProductInvestRes>), 200)]
        public async Task<IActionResult> pmsInvestmentvalue(PMSInvestment request)
        {
            var response = await _StrategyDataSource.pmsInvestmentvalue(request);
            return Ok(response);
        }

    }
}
