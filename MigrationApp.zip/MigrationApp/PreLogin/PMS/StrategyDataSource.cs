﻿using ApiCore.DTOs;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PreLogin.PMS
{
    public interface IStrategyDataSource
    {


        //PreLoginPMS
        Task<ResponseDataModel<ProductReturnDetailsRes>> pmsProductReturnDetails(PMSReturn request);
        Task<ResponseDataArrayModel<PMSProductDetailContentRes>> pmsProductDetailsContent(PMSDetail request);
        Task<ResponseDataModel<ProductInvestRes>> pmsInvestmentvalue(PMSInvestment request);
    }
}
