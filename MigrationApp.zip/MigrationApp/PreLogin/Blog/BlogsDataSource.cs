﻿using ApiCore.DTOs;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PreLogin.Blog
{
    public interface IBlogsDataSource
    {
        Task<ResponseDataModel<BlogsbasicDetailRes>> Blogs();
        Task<ResponseDataArrayModel<BlogListRes>> Blogs(BlogsName request);
        Task<ResponseDataModel<BlogDetailRes>> Blogs(BlogsId request);
    }
}
