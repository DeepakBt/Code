﻿using ApiCore.DTOs;
using ApiCore.Model;
using Dapper;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using ApiCore.Exceptions;

namespace PreLogin.Blog
{
    public class BlogsRepository : IBlogsDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCMobileDB);

        public BlogsRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

        }
        ParamValid ParamValid = new ParamValid();
        //blogCategories
        public async Task<ResponseDataModel<BlogsbasicDetailRes>> Blogs()
        {
            using (var conn = CMSConnection)
            {
                var multi = await conn.QueryAsync("PROC_GETBLOGCATEGORY_AMCMobileApp", null, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    BlogsbasicDetailRes BlogDetails = new BlogsbasicDetailRes();
                    if (VerifiedList.Count > 0)
                    {

                        List<FundManagersName> FundMangName = new List<FundManagersName>();
                        List<AnalystName> AnalystName = new List<AnalystName>();
                        BlogDetails.chairmanName = (from P in VerifiedList
                                                    where P.PageName == "chairman"
                                                    select P.NAME).FirstOrDefault();
                        BlogDetails.chairmanImage = (from P in VerifiedList
                                                     where P.PageName == "chairman"
                                                     select _iconfiguration["URL:AMCPeople"] + P.IMAGEPATH).FirstOrDefault();
                        BlogDetails.ceoName = (from P in VerifiedList
                                               where P.PageName == "ceo"
                                               select P.NAME).FirstOrDefault();
                        BlogDetails.ceoImage = (from P in VerifiedList
                                                where P.PageName == "ceo"
                                                select _iconfiguration["URL:AMCPeople"] + P.IMAGEPATH).FirstOrDefault();

                        foreach (var p in VerifiedList.ToList().Where(p => p.PageName == "fund-managers"))
                        {
                            FundMangName.Add(new FundManagersName
                            {
                                name = p.NAME,
                                image =  _iconfiguration["URL:AMCPeople"] + p.IMAGEPATH

                            });
                        }
                        foreach (var p in VerifiedList.ToList().Where(p => p.PageName == "analyst"))
                        {
                            AnalystName.Add(new AnalystName
                            {
                                name = p.NAME,
                                image = _iconfiguration["URL:AMCPeople"] + p.IMAGEPATH
                            });
                        }
                     
                        BlogDetails.fundManagersName = FundMangName;
                        BlogDetails.analystName = AnalystName;
                        return new ResponseDataModel<BlogsbasicDetailRes>(BlogDetails);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }

            }
        }

        //blogList
        public async Task<ResponseDataArrayModel<BlogListRes>> Blogs(BlogsName request)
        {
            using (var conn = CMSConnection)
            {
                var multi = await conn.QueryAsync("PROC_GET_BLOGS_AMCMOBILEAPP", new
                {
                    request.blogName,
                    BlogId = ""
                }, commandType: CommandType.StoredProcedure);
                {
                    List<BlogListRes> BlogList = new List<BlogListRes>();
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {

                        for (int i = 0; i < VerifiedList.Count; i++)
                        {
                            BlogListRes cls = new BlogListRes();
                            cls.id = VerifiedList[i].id ?? 0;
                            cls.author = VerifiedList[i].author ?? "";
                            cls.authorImage = _iconfiguration["URL:AMCPeople"] + VerifiedList[i].authorImage ?? "";
                            cls.designation = VerifiedList[i].Designation ?? "";
                            cls.publishedDate = VerifiedList[i].publishedDate ?? "";
                            cls.title = VerifiedList[i].Title ?? "";
                            cls.overview = VerifiedList[i].overview ?? "";
                            cls.shareLink = VerifiedList[i].ShareLink ?? "";
                            BlogList.Add(cls);
                        }

                        return new ResponseDataArrayModel<BlogListRes>(BlogList);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }

            }
        }

        //viewBlogDetails
        public async Task<ResponseDataModel<BlogDetailRes>> Blogs(BlogsId request)
        {
            using (var conn = CMSConnection)
            {
                var Blogname = "";
                var multi = await conn.QueryAsync("PROC_GET_BLOGS_AMCMOBILEAPP", new
                {
                    Blogname,
                    request.blogId,
                }, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    BlogDetailRes BlogDetail = new BlogDetailRes();
                    BlogDetail.id = (from P in VerifiedList
                                     select P.id ?? 0).FirstOrDefault();
                    BlogDetail.author = (from P in VerifiedList
                                         select P.author ?? "").FirstOrDefault();
                    BlogDetail.authorImage = (from P in VerifiedList
                                              select _iconfiguration["URL:AMCPeople"] + P.authorImage ?? "").FirstOrDefault();
                    BlogDetail.designation = (from P in VerifiedList
                                              select P.Designation ?? "").FirstOrDefault();
                    BlogDetail.publishedDate = (from P in VerifiedList
                                                select P.publishedDate ?? "").FirstOrDefault();
                    BlogDetail.title = (from P in VerifiedList
                                        select P.Title ?? "").FirstOrDefault();
                    BlogDetail.content = (from P in VerifiedList
                                          select P.Content ?? "").FirstOrDefault();
                    BlogDetail.shareLink = (from P in VerifiedList
                                            select P.ShareLink ?? "").FirstOrDefault();
                    return new ResponseDataModel<BlogDetailRes>(BlogDetail);
                }
                else
                {
                    throw new NoDataException(false);
                }
            }
        }
    }
}
