﻿using ApiCore.DTOs;
using APICore.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebSockets.Internal;
using PreLogin.Controllers;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreLogin.Blog
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class BlogsController : ControllerBase
    {
        private readonly IBlogsDataSource _IBlogsDataSource;
        private string Day1 = "0";
        private string Day15 = "0";
        public BlogsController(IBlogsDataSource IBlogsDataSource)
        {
            _IBlogsDataSource = IBlogsDataSource;
            var now = DateTime.Now;
            var tomorrow9am = now.AddDays(1).Date.AddHours(9);
            int Duration = Convert.ToInt32((tomorrow9am - now).TotalSeconds);
            Day1 = Convert.ToString(Duration);
            var Days15At9am = now.AddDays(15).Date.AddHours(9);
            int Daysinseconds = Convert.ToInt32((Days15At9am - now).TotalSeconds);
            Day15 = Convert.ToString(Daysinseconds);
        }
                                
        [HttpGet("Categories")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<BlogsbasicDetailRes>), 200)]
        public async Task<IActionResult> blogCategories()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _IBlogsDataSource.Blogs();
            return Ok(response);
        }

        [HttpGet("List")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<BlogListRes>), 200)]
        public async Task<IActionResult> GetBlogList(BlogsName request)
        {
            var response = await _IBlogsDataSource.Blogs(request);
            return Ok(response);
        }

        [HttpGet("Details")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<BlogDetailRes>), 200)]
        public async Task<IActionResult> GetViewBlogDetails(BlogsId request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day15);
            var response = await _IBlogsDataSource.Blogs(request);
            return Ok(response);
        }
    }
}
