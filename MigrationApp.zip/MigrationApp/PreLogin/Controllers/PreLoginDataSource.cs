﻿using ApiCore.DTOs;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PreLogin.Controllers
{
    public interface IPreLoginDataSource 
    {
        //PreLogin
        Task<ResponseDataModel<AboutusRes>> AboutUs();
        Task<ResponseDataArrayModel<VideoRes>> Videos(Video request);
        Task<ResponseDataArrayModel<WCThoughtRes>> WealthThought(WCThought request);
        Task<ResponseDataArrayModel<DownloadRes>> Download(Downloads request);
        Task<ResponseDataModel<Top10HoldingRes>> ProductTopHolding(holding request);
        Task<ResponseDataModel<ProductAllocationRes>> allocationDetails(Allocation request);
        Task<ResponseDataArrayModel<ToolRes>> Tool();
        Task<ResponseDataArrayModel<BannerRes>> GetBanner(BannerReq req);
    }
}
