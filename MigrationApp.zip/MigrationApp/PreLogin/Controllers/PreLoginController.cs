﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using APICore.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json.Linq;
using PreLogin.Models;

namespace PreLogin.Controllers
{

    [Route("api/[controller]")]
    [ValidateModel]
    public class PreLoginController : ControllerBase
    {
        private string Day1 = "0";
        private readonly IPreLoginDataSource _PreLoginDataSource;
        public PreLoginController(IPreLoginDataSource PreLoginDataSource) 
        {
            _PreLoginDataSource = PreLoginDataSource;
            var now = DateTime.Now;
            var tomorrow9am = now.AddDays(1).Date.AddHours(9);
            int Duration = Convert.ToInt32((tomorrow9am - now).TotalSeconds);
            Day1 = Convert.ToString(Duration);
        }
        ParamValid ParamValid = new ParamValid();
        // Get api/values
        [HttpGet("aboutUsContent")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<AboutusRes>), 200)]
        [ResponseCache(CacheProfileName = "Default")]
        public async Task<IActionResult> Get()
        {
            var response = await _PreLoginDataSource.AboutUs();
            return Ok(response);
        }

        [HttpGet("videos")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<VideoRes>), 200)]
        [ResponseCache(CacheProfileName = "Default")]
        public async Task<IActionResult> GetVideo(Video request)
        {
            var response = await _PreLoginDataSource.Videos(request);
            return Ok(response);
        }

        

        [HttpGet("thoughts")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<WCThoughtRes>), 200)]
        [ResponseCache(CacheProfileName = "Default")]
        public async Task<IActionResult> GetthoughtList(WCThought request)
        {
            string title = request.title == null ? "" : request.title;
            string fromDate = request.fromDate == null ? "" : request.fromDate;
            string toDate = request.toDate == null ? "" : request.toDate;
            request.title = request.title == null ? "" : request.title;
            if (request.count != null)
            {
                if (request.count > 0) { request.offset = request.offset == null ? 0 : request.offset; }
            }
            if (request.offset != null)
            {
                request.count = request.count == null || request.count == 0 ? 10 : request.count;
            }
            var response = await _PreLoginDataSource.WealthThought(request);
            return Ok(response);
        }

        [HttpGet("downloads")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<DownloadRes>), 200)]
        public async Task<IActionResult> Download(Downloads request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _PreLoginDataSource.Download(request);
            return Ok(response);
        }

        [HttpGet("ProductTopHolding")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<Top10HoldingRes>), 200)]
        public async Task<IActionResult> ProductTopHolding(holding request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _PreLoginDataSource.ProductTopHolding(request);
            return Ok(response);
        }


        [Produces("application/json")]
        [HttpGet("allocationDetails")]
        [ProducesResponseType(typeof(ResponseDataModel<ProductAllocationRes>), 200)]
        public async Task<IActionResult> allocationDetails(Allocation request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _PreLoginDataSource.allocationDetails(request);
            return Ok(response);
        }

        [Produces("application/json")]
        [HttpGet("tool")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ToolRes>), 200)]
        public async Task<IActionResult> Tool()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _PreLoginDataSource.Tool();
            return Ok(response);
        }

        //[Produces("application/json")]
        //[HttpPost("GetBanner")]
        //[ProducesResponseType(typeof(ResponseDataArrayModel<BannerRes>), 200)]
        //public async Task<IActionResult> GetBanner()
        //{
        //    BannerReq objReq = new BannerReq();
        //    objReq.DisplaySource = "Login";
        //    objReq.Platform = "Mobile";
        //    objReq.UserType = "New";
        //    var response = await _PreLoginDataSource.GetBanner(objReq);
        //    return Ok(response);
        //}
    }
}
