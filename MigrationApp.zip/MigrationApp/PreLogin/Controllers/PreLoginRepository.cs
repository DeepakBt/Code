﻿using ApiCore.DTOs;
using ApiCore.Model;
using Dapper;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using ApiCore.Exceptions;

namespace PreLogin.Controllers
{
    public class PreLoginRepository : IPreLoginDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string ReportPath = "";
        string HEADERMFLOGO = ""; string HEADERPMSLOGO = ""; string HEADERBOTHLOGO = "";


        public PreLoginRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            ReportPath = _iconfiguration["ReportPath:CommonPath"];
            HEADERMFLOGO = _iconfiguration["ReportPath:HEADERMFLOGO"];
            HEADERPMSLOGO = _iconfiguration["ReportPath:HEADERPMSLOGO"];
            HEADERBOTHLOGO = _iconfiguration["ReportPath:HEADERBOTHLOGO"];
        }
        ParamValid ParamValid = new ParamValid();

        //// PreLogin

        //aboutUsContent
        public async Task<ResponseDataModel<AboutusRes>> AboutUs()
        {
            using (var conn = CMSConnection)
            {

                var About = await conn.QueryFirstAsync<string>("PROC_GETABOUTUSDETAILS_AMCMOBILEAPP", null, commandTimeout: 0,commandType: CommandType.StoredProcedure);
                AboutusRes ObjAboutusRes = new AboutusRes();
                //string[] ConvertToJson;
                //ConvertToJson = About.Split("\r\n");
                //var aboutUsList = new List<AboutusRes>();
                //AboutusRes aboutUs = null;
                //if (About.Trim() != "")
                //{
                //    for (int i = 0; i <= ConvertToJson.Length - 1; i++)
                //    {

                //        string myString = ConvertToJson[i].Trim();
                //        if (Regex.Match(myString, "h[0-9]>").Index > 0)
                //        {
                //            if (aboutUs != null)
                //            {
                //                aboutUsList.Add(aboutUs);
                //            }
                //            aboutUs = new AboutusRes();
                //            aboutUs.header = ParamValid.RemoveHTMLTag(myString);
                //            aboutUs.content = new List<string>();
                //        }
                //        else if (Regex.Match(myString, "p>").Index > 0)
                //        {
                //            aboutUs.content.Add(ParamValid.RemoveHTMLTag(myString));
                //        }

                //    }
                //    if (aboutUs != null)
                //    {
                //        aboutUsList.Add(aboutUs);
                //    }
                //    return new ResponseDataArrayModel<AboutusRes>(aboutUsList);
                //}
                //else
                //{
                //    throw new NoDataException(true);
                //}
                if (About.Trim() != "")
                {
                    ObjAboutusRes.content = Convert.ToString(About);
                    return new ResponseDataModel<AboutusRes>(ObjAboutusRes);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }

        //videosList
        public async Task<ResponseDataArrayModel<VideoRes>> Videos(Video request)
        {
            using (var conn = CMSConnection)
            {
                List<VideoRes> videoList = new List<VideoRes>();

                request.titleSearch = request.titleSearch == null ? "" : request.titleSearch;
                if (request.count != null)
                {
                    if (request.count > 0) { request.offset = request.offset == null ? 0 : request.offset; }
                }
                if (request.offset != null)
                {
                    request.count = request.count == null || request.count == 0 ? 10 : request.count;
                }
                var multi = await conn.QueryAsync("Proc_GetVideos_AMCMobileApp", new
                {
                    type = "VIDEO",
                    request.titleSearch,
                    request.offset,
                    request.count
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    for (int i = 0; i < VerifiedList.Count; i++)
                    {

                        VideoRes cls = new VideoRes();
                        cls.contentId = VerifiedList[i].Content_Id ?? 0;
                        cls.thumbnailUrl = _iconfiguration["URL:CMSMediaImg"] + VerifiedList[i].ImgThumb1 ?? "";
                        cls.businessName = VerifiedList[i].BusinessName ?? "";
                        cls.publishedDate = VerifiedList[i].PublishDT ?? "";
                        cls.title = VerifiedList[i].Content_Title ?? "";
                        cls.videoUrl = VerifiedList[i].External_Url ?? "";
                        videoList.Add(cls);
                    }
                    return new ResponseDataArrayModel<VideoRes>(videoList);

                }
                else
                {
                    throw new NoDataException(true);
                }

            }
        }

        //thoughtList
        public async Task<ResponseDataArrayModel<WCThoughtRes>> WealthThought(WCThought request)
        {
            List<WCThoughtRes> WCThoughtList = new List<WCThoughtRes>();
            if (request.count != null)
            {
                if (request.count > 0) { request.offset = request.offset == null ? 0 : request.offset; }
            }
            if (request.offset != null)
            {
                request.count = request.count == null || request.count == 0 ? 10 : request.count;
            }
            using (var conn = CMSConnection)
            {
                var multi = await conn.QueryAsync("PROC_GET_WEALTHCREATION_AMCMOBILEAPP", new
                {
                    title = request.title == null ? "" : request.title,
                    fromDate = request.fromDate == null ? "" : request.fromDate,
                    toDate = request.toDate == null ? "" : request.toDate,
                    request.offset,
                    request.count
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);

                var VerifiedList = multi.ToList();
                if (VerifiedList.Count > 0)
                {
                    for (int i = 0; i < VerifiedList.Count; i++)
                    {
                        WCThoughtRes cls = new WCThoughtRes();
                        cls.id = VerifiedList[i].SRNO ?? 0;
                        cls.title = VerifiedList[i].TITLE ?? "";
                        cls.publishedDateTime = VerifiedList[i].publishdate ?? "";
                        cls.url = _iconfiguration["URL:CMSEventImg"] + VerifiedList[i].IMAGEPATH ?? "";
                        WCThoughtList.Add(cls);
                    }
                    return new ResponseDataArrayModel<WCThoughtRes>(WCThoughtList);
                }
                else
                {
                    throw new NoDataException(true);
                }


            }
        }

        //DownLoads
        public async Task<ResponseDataArrayModel<DownloadRes>> Download(Downloads request)
        {
            List<DownloadRes> DataList = new List<DownloadRes>();
            if (request.count != null)
            {
                if (request.count > 0) { request.offset = request.offset == null ? 0 : request.offset; }
            }
            if (request.offset != null)
            {
                request.count = request.count == null || request.count == 0 ? 10 : request.count;
            }
            using (var conn = CMSConnection)
            {

                using (var multi = await conn.QueryMultipleAsync("PROC_NewsLetter_AMCMOBILEAPP", new
                {
                    product = request.type.ToUpper() == "MONTHLY COMMUNIQUE" ? "PMS" : "Mutual Fund",
                    request.type,
                    request.offset,
                    request.count
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure))
                {
                    var VerifiedList = multi.Read().ToList();

                    if (VerifiedList != null)
                    {

                        for (int i = 0; i < VerifiedList.Count; i++)
                        {
                            DownloadRes cls = new DownloadRes();
                            cls.title = VerifiedList[i].TITLE ?? "";
                            cls.publishedDate = VerifiedList[i].PublishedDate ?? "";
                            cls.url = _iconfiguration["URL:AMCEquity"] + VerifiedList[i].url ?? "";
                            DataList.Add(cls);
                        }
                        return new ResponseDataArrayModel<DownloadRes>(DataList);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }

            }
        }

        //ProductTopHolding
        public async Task<ResponseDataModel<Top10HoldingRes>> ProductTopHolding(holding request)
        {
            using (var conn = CMSConnection)
            {
                var multi = await conn.QueryAsync("PROC_GETTOP10HOLDING_AMCMOBILEAPP", new
                {
                    Product = request.productName
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    Top10HoldingRes objPortFolio = new Top10HoldingRes();

                    if (VerifiedList.Count > 0)
                    {
                        objPortFolio.schemeCode = VerifiedList[0].PRODUCT;
                        objPortFolio.DataAsOn = VerifiedList[0].DataAsOn;
                        List<DataPoint2> odataPoint = new List<DataPoint2>();
                        foreach (var p in VerifiedList.ToList())
                        {
                            odataPoint.Add(new DataPoint2
                            {
                                companyName = p.Scrip_Name ?? "",
                                percentAllocation = Convert.ToDecimal(p.holding_per) ?? 0.00,
                            });

                        }
                        objPortFolio.dataPoints = odataPoint;
                        return new ResponseDataModel<Top10HoldingRes>(objPortFolio);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        //allocation
        public async Task<ResponseDataModel<ProductAllocationRes>> allocationDetails(Allocation request)
        {
            using (var conn = CMSConnection)
            {
                var multi = await conn.QueryMultipleAsync("PROC_GETINDUSTRUCLASSIFICATION_AMCMOBILEAPP", new
                {
                    PRODUCT = request.productName,
                    // TPYEOFVALUE = request.markettype,
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {

                    var marketCap = multi.Read().ToList();
                    var sector = multi.Read().ToList();
                    ProductAllocationRes productAllocationRes = new ProductAllocationRes();
                    //if (marketCap.Count > 0)
                    //{
                    //if (marketCap.Count > 0)
                    //{
                    //    List<DataPoint4> MARKETCAP = new List<DataPoint4>();
                    //    foreach (var p in marketCap.ToList())
                    //    {
                    //        DataPoint4 cls = new DataPoint4();
                    //        cls.segmentName = p.NAME ?? "";
                    //        cls.percentAllocation = Convert.ToDecimal(p.PERCENTAGE);
                    //        MARKETCAP.Add(cls);
                    //    }
                    //    productAllocationRes.marketCapital = MARKETCAP;
                    //}

                    if (sector.Count > 0)
                    {
                        List<DataPoint4> SECTOR = new List<DataPoint4>();
                        foreach (var p in sector.ToList())
                        {
                            DataPoint4 cls = new DataPoint4();
                            cls.segmentName = p.NAME ?? "";
                            cls.percentAllocation = Convert.ToDecimal(p.PERCENTAGE);
                            SECTOR.Add(cls);
                        }
                        productAllocationRes.sector = SECTOR;
                        return new ResponseDataModel<ProductAllocationRes>(productAllocationRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }

            }
        }

        //Tool
        public async Task<ResponseDataArrayModel<ToolRes>> Tool()
        {
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_PROC_GETTOOLDATA", null, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    var ToolList = multi.ToList();
                    List<ToolRes> tool = new List<ToolRes>();
                    if (ToolList.Count > 0)
                    {
                        for (int i = 0; i < ToolList.Count; i++)
                        {

                            ToolRes cls = new ToolRes();
                            cls.toolName = ToolList[i].TOOLNAME ?? "";
                            cls.toolURL = ToolList[i].TOOLURL ?? "";
                            cls.imageUrl = ToolList[i].TOOLSICON ?? "";
                            tool.Add(cls);
                        }
                        return new ResponseDataArrayModel<ToolRes>(tool);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }

            }
        }

        //Banner
        public async Task<ResponseDataArrayModel<BannerRes>> GetBanner(BannerReq req)
        {
            List<BannerRes> BannerList = new List<BannerRes>();
            
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("AMCMOB_GET_CMS_BANNER_DETAILS", new
                {
                    Flag=1,
                    PLATFORM =req.Platform,
                    DISPLAY_SOURCE=req.DisplaySource,
                    USER_TYPE=req.UserType
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);

                var ObjBannerList = multi.ToList();
                if (ObjBannerList.Count > 0)
                {
                    for (int i = 0; i < ObjBannerList.Count; i++)
                    {
                        BannerRes ObjBanner = new BannerRes();
                        ObjBanner.bannerID = ObjBannerList[i].ID ?? 0;
                        ObjBanner.bannerType = ObjBannerList[i].TYPE ?? "";
                        ObjBanner.imageURL = ObjBannerList[i].ImagesPath ?? "";
                        ObjBanner.module = ObjBannerList[i].MODULE ?? "";
                        ObjBanner.navigateURL = ObjBannerList[i].CLICK_URL ?? "";
                        ObjBanner.openIn = ObjBannerList[i].OPEN_IN ?? "";
                        ObjBanner.product = ObjBannerList[i].LOGIN_TYPE ?? "";
                        ObjBanner.schemeCode = ObjBannerList[i].SCHEME_CODE ?? "";
                        ObjBanner.schemeName = ObjBannerList[i].SCHEMENAME ?? "";
                        ObjBanner.strategyCode = "";
                        ObjBanner.displayOrder = ObjBannerList[i].DISPLAY_ORDER ?? 0;
                        BannerList.Add(ObjBanner);
                    }
                    return new ResponseDataArrayModel<BannerRes>(BannerList);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }


    }
}


