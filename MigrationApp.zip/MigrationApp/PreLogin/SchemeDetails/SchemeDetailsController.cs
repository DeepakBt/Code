﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using APICore.Auth;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using PreLogin.Models;

namespace PreLogin.SchemeDetails
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class SchemeDetailsController : ControllerBase
    {
        private readonly ISchemeDetailsDataSource _SchemeDetailsDataSource;
        public SchemeDetailsController(ISchemeDetailsDataSource SchemeDetailsDataSource)
        {
            _SchemeDetailsDataSource = SchemeDetailsDataSource;
        }
        [HttpGet("SchemesMaster")]
        [Produces("application/json")]
        [EnableCors("MOSLPolicy")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<SchemeslistItem>>), 200)]
        public async Task<IActionResult> SchemesMaster()
        {
            var response = await _SchemeDetailsDataSource.GetSchemesMaster();
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("LatestNAVList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<NavlistItem>>), 200)]
        public async Task<IActionResult> LatestNAVList([FromBody] LastNAVReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetNavlistItem(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpGet("SchemesBM")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<SchemesbmItem>>), 200)]
        public async Task<IActionResult> SchemesBM()
        {
            var response = await _SchemeDetailsDataSource.GetSchemesBM();
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("GraphLumpsum")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<NavlistItemBM>>), 200)]
        public async Task<IActionResult> GraphLumpsum([FromBody] GraphLumpsumReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetGraphLumpsum(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("GraphSIP")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<NavlistItemSIP>>), 200)]
        public async Task<IActionResult> GraphSIP([FromBody] GraphSIPReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetGraphSIP(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("CAGRReturn")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SingleResponseData<CAGRlist>>), 200)]
        public async Task<IActionResult> CAGRReturn([FromBody] CAGRReturnReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetCAGRReturn(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("LineChart")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<LineChartListItem>>), 200)]
        public async Task<IActionResult> LineChart([FromBody] LineChartReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetLineChart(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("TopHoldings")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ResponseData<TopHoldingsListItem>>), 200)]
        public async Task<IActionResult> TopHoldings([FromBody] TopHoldingReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetTopHolding(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("SchemeDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SingleResponseData<SchemeDetailsList>>), 200)]
        public async Task<IActionResult> SchemeDetails([FromBody] SchemeDetailsReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetSchemeDetails(Req);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("InvestmentObjective")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>), 200)]
        public async Task<IActionResult> InvestmentObjective([FromBody] InvestmentObjectiveReq Req)
        {
            var response = await _SchemeDetailsDataSource.GetInvestmentObjective(Req);
            return Ok(response);
        }
    }
}