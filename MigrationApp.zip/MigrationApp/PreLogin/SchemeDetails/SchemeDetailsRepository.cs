﻿using ApiCore.DTOs;
using ApiCore.Model;
using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using ApiCore.Exceptions;
using ApiCore.Helpers;
using Newtonsoft.Json;

namespace PreLogin.SchemeDetails
{
    public class SchemeDetailsRepository : ISchemeDetailsDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private string ErrorLogFile = string.Empty;
        private string SchemesMasterAPI = string.Empty;
        private string LatestNAVListAPI = string.Empty;
        private string SchemesBenchmarkAPI = string.Empty;
        private string GraphLumpsumAPI = string.Empty;
        private string GraphSIPAPI = string.Empty;
        private string CAGRReturnAPI = string.Empty;
        private string LineChartAPI = string.Empty;
        private string TopHoldingAPI = string.Empty;
        private string SchemeDetailsAPI = string.Empty;
        private string InvestmentObjectiveAPI = string.Empty;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        public SchemeDetailsRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            SchemesMasterAPI = _iconfiguration["CMOTS:SchemesMaster"];
            LatestNAVListAPI = _iconfiguration["CMOTS:LatestNAVList"];
            SchemesBenchmarkAPI = _iconfiguration["CMOTS:SchemesBenchmark"];
            GraphLumpsumAPI = _iconfiguration["CMOTS:GraphLumpsum"];
            GraphSIPAPI = _iconfiguration["CMOTS:GraphSIP"];
            CAGRReturnAPI = _iconfiguration["CMOTS:CAGRReturn"];
            LineChartAPI = _iconfiguration["CMOTS:LineChart"];
            TopHoldingAPI = _iconfiguration["CMOTS:TopHoldings"];
            SchemeDetailsAPI = _iconfiguration["CMOTS:SchemeDetails"];
            InvestmentObjectiveAPI = _iconfiguration["CMOTS:InvestmentObjective"];
        }

        public async Task<ResponseDataModel<ResponseData<SchemeslistItem>>> GetSchemesMaster()
        {
            try
            {
                ResponseData<SchemeslistItem> objresponse = new ResponseData<SchemeslistItem>();
                string ResStr = string.Empty;
                ResStr = Utilities.CreateHTTPGETRequest(SchemesMasterAPI);
                if(! string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"])=="success")
                    {
                        List<SchemeslistItem> ObjListSchema = new List<SchemeslistItem>();
                        objresponse.ListOfData = new List<SchemeslistItem>();
                        if (Jres["response"]["data"]["schemeslistdata"]["schemeslist"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<SchemeslistItem>>(Convert.ToString(Jres["response"]["data"]["schemeslistdata"]["schemeslist"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["schemeslistdata"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<SchemeslistItem>>(objresponse);
                    }
                    else
                    {
                        return new ResponseDataModel<ResponseData<SchemeslistItem>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<SchemeslistItem>>(null, "CMOTS Returned Blank Json");
                }   
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetSchemesMaster \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<SchemeslistItem>>(null, ex.Message);
            }
        }


        public async Task<ResponseDataModel<ResponseData<NavlistItem>>> GetNavlistItem(LastNAVReq Req)
        {
            try
            {
                ResponseData<NavlistItem> objresponse = new ResponseData<NavlistItem>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(LatestNAVListAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        List<NavlistItem> ObjListSchema = new List<NavlistItem>();
                        objresponse.ListOfData = new List<NavlistItem>();
                        if (Jres["response"]["data"]["navdata"]["navlist"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<NavlistItem>>(Convert.ToString(Jres["response"]["data"]["navdata"]["navlist"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["navdata"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<NavlistItem>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<ResponseData<NavlistItem>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<NavlistItem>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetNavlistItem \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<NavlistItem>>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<ResponseData<SchemesbmItem>>> GetSchemesBM()
        {
            try
            {
                ResponseData<SchemesbmItem> objresponse = new ResponseData<SchemesbmItem>();
                string ResStr = string.Empty;
                ResStr = Utilities.CreateHTTPGETRequest(SchemesBenchmarkAPI);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        List<SchemesbmItem> ObjListSchema = new List<SchemesbmItem>();
                        objresponse.ListOfData = new List<SchemesbmItem>();
                        if (Jres["response"]["data"]["schemesbmlistdata"]["schemesbm"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<SchemesbmItem>>(Convert.ToString(Jres["response"]["data"]["schemesbmlistdata"]["schemesbm"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["schemesbmlistdata"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<SchemesbmItem>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<ResponseData<SchemesbmItem>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<SchemesbmItem>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetSchemesBM \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<SchemesbmItem>>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<ResponseData<NavlistItemBM>>> GetGraphLumpsum(GraphLumpsumReq Req)
        {
            try
            {
                ResponseData<NavlistItemBM> objresponse = new ResponseData<NavlistItemBM>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(GraphLumpsumAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        List<NavlistItemBM> ObjListSchema = new List<NavlistItemBM>();
                        objresponse.ListOfData = new List<NavlistItemBM>();
                        if (Jres["response"]["data"]["navdata"]["navlist"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<NavlistItemBM>>(Convert.ToString(Jres["response"]["data"]["navdata"]["navlist"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["navdata"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<NavlistItemBM>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<ResponseData<NavlistItemBM>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<NavlistItemBM>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetGraphLumpsum \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<NavlistItemBM>>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<ResponseData<NavlistItemSIP>>> GetGraphSIP(GraphSIPReq Req)
        {
            try
            {
                ResponseData<NavlistItemSIP> objresponse = new ResponseData<NavlistItemSIP>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(GraphSIPAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        List<NavlistItemSIP> ObjListSchema = new List<NavlistItemSIP>();
                        objresponse.ListOfData = new List<NavlistItemSIP>();
                        if (Jres["response"]["data"]["navdata"]["navlist"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<NavlistItemSIP>>(Convert.ToString(Jres["response"]["data"]["navdata"]["navlist"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["navdata"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<NavlistItemSIP>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<ResponseData<NavlistItemSIP>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<NavlistItemSIP>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetGraphSIP \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<NavlistItemSIP>>(null, ex.Message);
            }
        }


        public async Task<ResponseDataModel<SingleResponseData<CAGRlist>>> GetCAGRReturn(CAGRReturnReq Req)
        {
            try
            {
                SingleResponseData<CAGRlist> objresponse = new SingleResponseData<CAGRlist>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(CAGRReturnAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        CAGRlist ObjListSchema = new CAGRlist();
                        objresponse.SingleObjectData = new CAGRlist();
                        if (Jres["response"]["data"]["CAGRdata"]["CAGRlist"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<CAGRlist>(Convert.ToString(Jres["response"]["data"]["CAGRdata"]["CAGRlist"]));
                            objresponse.SingleObjectData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["CAGRdata"]["@recordcount"]);
                        return new ResponseDataModel<SingleResponseData<CAGRlist>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<SingleResponseData<CAGRlist>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<SingleResponseData<CAGRlist>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetCAGRReturn \r ERROR:" + ex.Message);
                return new ResponseDataModel<SingleResponseData<CAGRlist>>(null, ex.Message);
            }
        }


        public async Task<ResponseDataModel<ResponseData<LineChartListItem>>> GetLineChart(LineChartReq Req)
        {
            try
            {
                ResponseData<LineChartListItem> objresponse = new ResponseData<LineChartListItem>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(LineChartAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        List<LineChartListItem> ObjListSchema = new List<LineChartListItem>();
                        objresponse.ListOfData = new List<LineChartListItem>();
                        if (Jres["response"]["data"]["LineChartData"]["LineChartList"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<LineChartListItem>>(Convert.ToString(Jres["response"]["data"]["LineChartData"]["LineChartList"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["LineChartData"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<LineChartListItem>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<ResponseData<LineChartListItem>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<LineChartListItem>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetLineChart \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<LineChartListItem>>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<ResponseData<TopHoldingsListItem>>> GetTopHolding(TopHoldingReq Req)
        {
            try
            {
                ResponseData<TopHoldingsListItem> objresponse = new ResponseData<TopHoldingsListItem>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(TopHoldingAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        List<TopHoldingsListItem> ObjListSchema = new List<TopHoldingsListItem>();
                        objresponse.ListOfData = new List<TopHoldingsListItem>();
                        if (Jres["response"]["data"]["TopHoldingsData"]["TopHoldingsList"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<List<TopHoldingsListItem>>(Convert.ToString(Jres["response"]["data"]["TopHoldingsData"]["TopHoldingsList"]));
                            objresponse.ListOfData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["TopHoldingsData"]["@recordcount"]);
                        return new ResponseDataModel<ResponseData<TopHoldingsListItem>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<ResponseData<TopHoldingsListItem>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<ResponseData<TopHoldingsListItem>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetTopHolding \r ERROR:" + ex.Message);
                return new ResponseDataModel<ResponseData<TopHoldingsListItem>>(null, ex.Message);
            }
        }


        public async Task<ResponseDataModel<SingleResponseData<SchemeDetailsList>>> GetSchemeDetails(SchemeDetailsReq Req)
        {
            try
            {
                SingleResponseData<SchemeDetailsList> objresponse = new SingleResponseData<SchemeDetailsList>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(SchemeDetailsAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        SchemeDetailsList ObjListSchema = new SchemeDetailsList();
                        objresponse.SingleObjectData = new SchemeDetailsList();
                        if (Jres["response"]["data"]["SchemeDetailsData"]["SchemeDetailsList"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<SchemeDetailsList>(Convert.ToString(Jres["response"]["data"]["SchemeDetailsData"]["SchemeDetailsList"]));
                            objresponse.SingleObjectData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["SchemeDetailsData"]["@recordcount"]);
                        return new ResponseDataModel<SingleResponseData<SchemeDetailsList>>(objresponse);
                    }
                    else
                    {
                        return new ResponseDataModel<SingleResponseData<SchemeDetailsList>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<SingleResponseData<SchemeDetailsList>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetSchemeDetails \r ERROR:" + ex.Message);
                return new ResponseDataModel<SingleResponseData<SchemeDetailsList>>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>> GetInvestmentObjective(InvestmentObjectiveReq Req)
        {
            try
            {
                SingleResponseData<InvestmentObjectiveList> objresponse = new SingleResponseData<InvestmentObjectiveList>();
                string ResStr = string.Empty;
                string JsonReq = JsonConvert.SerializeObject(Req);
                ResStr = Utilities.CreateHTTPPOSTRequest(InvestmentObjectiveAPI, JsonReq);
                if (!string.IsNullOrEmpty(ResStr))
                {
                    JObject Jres = JObject.Parse(ResStr);
                    if (Convert.ToString(Jres["response"]["@type"]) == "success")
                    {
                        InvestmentObjectiveList ObjListSchema = new InvestmentObjectiveList();
                        objresponse.SingleObjectData = new InvestmentObjectiveList();
                        if (Jres["response"]["data"]["InvestmentObjectiveData"]["InvestmentObjectiveList"].Count() > 0)
                        {
                            ObjListSchema = JsonConvert.DeserializeObject<InvestmentObjectiveList>(Convert.ToString(Jres["response"]["data"]["InvestmentObjectiveData"]["InvestmentObjectiveList"]));
                            objresponse.SingleObjectData = ObjListSchema;
                        }
                        objresponse.recordcount = Convert.ToString(Jres["response"]["data"]["InvestmentObjectiveData"]["@recordcount"]);
                        return new ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>(objresponse);
                    }else
                    {
                        return new ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>(null, $"CMOTS Returned type is not success with message : {Convert.ToString(Jres["response"]["@type"])}");
                    }
                }
                else
                {
                    return new ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>(null, "CMOTS Returned Blank Json");
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetInvestmentObjective \r ERROR:" + ex.Message);
                return new ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>(null, ex.Message);
            }
        }
    }
}
