﻿using ApiCore.DTOs;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
namespace PreLogin.SchemeDetails
{
    public interface ISchemeDetailsDataSource
    {
        Task<ResponseDataModel<ResponseData<SchemeslistItem>>> GetSchemesMaster();
        Task<ResponseDataModel<ResponseData<NavlistItem>>> GetNavlistItem(LastNAVReq Req);
        Task<ResponseDataModel<ResponseData<SchemesbmItem>>> GetSchemesBM();
        Task<ResponseDataModel<ResponseData<NavlistItemBM>>> GetGraphLumpsum(GraphLumpsumReq Req);
        Task<ResponseDataModel<ResponseData<NavlistItemSIP>>> GetGraphSIP(GraphSIPReq Req);
        Task<ResponseDataModel<SingleResponseData<CAGRlist>>> GetCAGRReturn(CAGRReturnReq Req);
        Task<ResponseDataModel<ResponseData<LineChartListItem>>> GetLineChart(LineChartReq Req);
        Task<ResponseDataModel<ResponseData<TopHoldingsListItem>>> GetTopHolding(TopHoldingReq Req);
        Task<ResponseDataModel<SingleResponseData<SchemeDetailsList>>> GetSchemeDetails(SchemeDetailsReq Req);
        Task<ResponseDataModel<SingleResponseData<InvestmentObjectiveList>>> GetInvestmentObjective(InvestmentObjectiveReq Req);
    }
}
