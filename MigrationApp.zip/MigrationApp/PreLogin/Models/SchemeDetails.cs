﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace PreLogin.Models
{
    //List Of Body
    public class SchemesbmItem
    {
        public string mf_cocode { get; set; }
        public string mf_schcode { get; set; }
        public string GroupCode { get; set; }
        public string GroupName { get; set; }
        public string bmcode { get; set; }
        public string IndexName { get; set; }
        public string indexnamevalue { get; set; }
        public string Exchange { get; set; }
    }
    public class SchemeslistItem
    {
        public string MF_COCODE { get; set; }
        public string MF_SCHCODE { get; set; }
        public string GRPCODE { get; set; }
        public string GRPName { get; set; }
        public string SCH_NAME { get; set; }
        public string MO_SCH_NAME { get; set; }
        public string ISACTIVE { get; set; }
        public string amficode { get; set; }
        public string isin { get; set; }
    }
    public class NavlistItem
    {
        public string mo_sch_Name { get; set; }
        public string mf_cocode { get; set; }
        public string mf_schcode { get; set; }
        public string latnav { get; set; }
        public string latdate { get; set; }
        public string change { get; set; }
        public string opt { get; set; }
    }

    public class NavlistItemBM
    {
        public string mf_schcode { get; set; }
        public string navdate { get; set; }
        public string MarketValue_Scheme { get; set; }
        public string IndexCode { get; set; }
        public string co_name { get; set; }
        public string Navdate_BM1 { get; set; }
        public string MarketValue_BM1 { get; set; }
    }

    public class NavlistItemSIP
    {
        public string SchemeName { get; set; }
        public string Investment_Date { get; set; }
        public string Invamount { get; set; }
        public string MarketValue_Scheme { get; set; }
        public string BenchmarkIndexName { get; set; }
        public string MarketValue_BM { get; set; }
    }

    public class CAGRlist
    {
        public string mf_cocode { get; set; }
        public string mf_schcode { get; set; }
        public string grpcode { get; set; }
        public string GroupName { get; set; }
        public string InceptionDate { get; set; }
        public string InceptionRs { get; set; }
        public string LatDate { get; set; }
        public string LatNavDate { get; set; }
        public string LatNav { get; set; }
        public string Units { get; set; }
        public string Inception_Ret { get; set; }
        public string IncDays { get; set; }
    }

    public class LineChartListItem
    {
        public string Type { get; set; }
        public string GroupName { get; set; }
        public string LatNavDate { get; set; }
        public string LatNav { get; set; }
        public string OneYearRs { get; set; }
        public string MarketValueOneYear { get; set; }
        public string OneYear_Ret { get; set; }
        public string ThreeYearRs { get; set; }
        public string MarketValueThreeYear { get; set; }
        public string ThreeYear_Ret { get; set; }
        public string FiveYearRs { get; set; }
        public string MarketValueFiveYear { get; set; }
        public string FiveYear_Ret { get; set; }
        public string InceptionRs { get; set; }
        public string MarketValueInception { get; set; }
        public string Inception_Ret { get; set; }
        public string ord { get; set; }
    }

    public class TopHoldingsListItem
    {
        public string co_code { get; set; }
        public string co_name { get; set; }
        public string invdate { get; set; }
        public string Perc_hold { get; set; }
        public string MktValue { get; set; }
        public string TotalShares { get; set; }
        public string AssetType { get; set; }
        public string rating { get; set; }
        public string sect_name { get; set; }
        public string ISIN { get; set; }
    }

    public class SchemeDetailsList
    {
        public string mf_schcode { get; set; }
        public string SchemeName { get; set; }
        public string schemeType { get; set; }
        public string CategoryCode { get; set; }
        public string CategoryName { get; set; }
        public string LaunchDate { get; set; }
        public string BenchmarkName { get; set; }
        public string MonthlyAUM { get; set; }
        public string SIP_MinimumInvestment { get; set; }
        public string FundManager { get; set; }
        public string FundManager_Details { get; set; }
        public string ExitLoad { get; set; }
        public string EntryLoad { get; set; }
        public string IncrementalInvestment { get; set; }
        public string Regular_ExpRatio { get; set; }
        public string Direct_ExpRatio { get; set; }
        public string PF_TurnoverRatio { get; set; }
        public string ISIN { get; set; }
        public string mcap { get; set; }
        public string asondate { get; set; }
    }

    public class InvestmentObjectiveList
    {
        public string mf_schcode { get; set; }
        public string objective { get; set; }
        public string Riskometervalue { get; set; }
    }

    //List Of Generic Response
    public class ResponseData<T>
    {
        public string @recordcount { get; set; }
        public List<T> ListOfData { get; set; }
    }

    //Single Object Generic Response
    public class SingleResponseData<T>
    {
        public string @recordcount { get; set; }
        public T SingleObjectData { get; set; }
    }

    //Request 
    public class LastNAVReq
    {
        public string type { get; set; }
        public string code { get; set; }
    }
    public class GraphLumpsumReq
    {
        public string groupcode { get; set; }
        public string invamount { get; set; }
        public string period { get; set; }
        public string count { get; set; }
        public string bmcode { get; set; }
    }
    public class GraphSIPReq
    {
        public string grpcode { get; set; }
        public string invamount { get; set; }
        public string SIPType { get; set; }
        public string period { get; set; }
        public string cnt { get; set; }
        public string bmcode { get; set; }
    }
    public class CAGRReturnReq
    {
        public string groupcode { get; set; }
    }
    public class LineChartReq
    {
        public string groupcode { get; set; }
    }

    public class TopHoldingReq
    {
        public string mf_schcode { get; set; }
        public string top { get; set; }
    }

    public class SchemeDetailsReq
    {
        public string mf_schcode { get; set; }
    }
    public class InvestmentObjectiveReq
    {
        public string mf_schcode { get; set; }
    }
}
