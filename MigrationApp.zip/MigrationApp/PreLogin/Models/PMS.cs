﻿using ApiCore.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PreLogin.Models
{
    public class PMSInvestment :IValidatableObject
    {
        /// <summary> "Refer Init API  "PMSProduct:strategyName" key from Response eg: value Strategy" </summary>
        [Required]
        public string productName { get; set; }
        /// <summary>2010-01-01 Date Format (yyyy-mm-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string fromDate { get; set; }
        /// <summary>2018-01-01 Date Format (yyyy-mm-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string toDate { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
            {
                results.Add(new ValidationResult("toDate must be larger than fromDate"));
            }
            return results;
        }
    }
    public class PMSReturn
    {
        /// <summary> "Refer Init API  "PMSProduct:strategyCode" key from Response eg: value|ntdop|IOPS" </summary>
        [Required]
        public string productCode { get; set; }

    }
    public class PMSDetail
    {
        /// <summary> "Refer Init API  "PMSProduct:strategyCode" key from Response eg: value|ntdop|IOPS" </summary>
        [Required]
        public string productCode { get; set; }
    }

    public class Allocation
    {
        /// <summary> "Refer Init API  "MFProduct:schemeName|PMSProduct:strategyname" key from Response eg: Motilal Oswal Focused 25 Fund|Value Strategy" </summary>
        [Required]
        public string productName { get; set; }
        ///// <summary> MarketCapital|Sector" </summary>
        //[Required]
        //public string markettype { get; set; }

        //public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        //{
        //    var results = new List<ValidationResult>();
        //    if (this.markettype.ToUpper().Trim() != "MARKETCAPITAL" && this.markettype.ToUpper().Trim() != "SECTOR")
        //    {
        //        results.Add(new ValidationResult("Invalid Market Type", new List<string> { nameof(markettype) }));
        //    }
        //    return results;
        //}
    }

    public class DataPoint3
    {
        public string period { get; set; }
        public decimal productReturn { get; set; }
        public decimal indexReturn { get; set; }
    }

    public class ProductReturnDetailsRes
    {
        public string returnDetails { get; set; }
        public string schemeCode { get; set; }
        public string indexName { get; set; }
        public List<DataPoint3> dataPoints { get; set; }
        public string disclaimer { get; set; }
    }


    public class ProductInvestRes
    {
        public string returnDetails { get; set; }
        public string schemeName { get; set; }
        public string indexName { get; set; }
        public List<DataPoint3> dataPoints { get; set; }
        public string disclaimer { get; set; }
    }

    public class ProductAllocationRes
    {

        //public List<DataPoint4> marketCapital { get; set; }
        public List<DataPoint4> sector { get; set; }
    }

    public class DataPoint4
    {
        public string segmentName { get; set; }
        public decimal percentAllocation { get; set; }
    }

    public class ProductPortfolioRes
    {
        public string schemeCode { get; set; }
        public List<DataPoint4> dataPoints { get; set; }
    }

    public class DownloadRes
    {
        public string title { get; set; }
        public string publishedDate { get; set; }
        public string url { get; set; }
    }
    public class ToolRes
    {
        public string toolName { get; set; }
        public string toolURL { get; set; }
        public string imageUrl { get; set; }
    }

}
