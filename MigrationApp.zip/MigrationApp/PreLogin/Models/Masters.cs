﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PreLogin.Models
{
    public class ResponseMsg
    {
        public int Result { get; set; }
        public string Message { get; set; }
    }
    public class ReqIFSCBank
    {
        [Required]
        public string IFSC { get; set; }
    }
    public class RBIBankDetail
    {
        public string Bank_Name { get; set; }
        public string IFSC { get; set; }
        public string Office { get; set; }
        public string Address { get; set; }
        public string District { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Phone { get; set; }
    }
}
