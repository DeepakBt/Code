﻿using ApiCore.Model;
using ApiCore.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PreLogin.Models
{
    
    public class AboutusRes
    {
        //public string header { get; set; }
        //public List<string> content { get; set; }
        public string content { get; set; }
    }

    public class Video
    {

        /// <summary> ""|"am"|titlesearch can be Search on  "title" Key value from below Response Body </summary>
        public string titleSearch { get; set; }

        /// <summary> ""|0|last No from last Fetch Data  </summary>
        public int? offset { get; set; }

        /// <summary> ""|10|No of Count from last Fetch Data </summary>
        public int? count { get; set; }
    }

    public class VideoRes
    {
        public long contentId { get; set; }
        public string thumbnailUrl { get; set; }
        public string businessName { get; set; }
        public string publishedDate { get; set; }
        public string title { get; set; }
        public string videoUrl { get; set; }
    }

    public class BlogsId
    {
        /// <summary> eg: "1" 
        /// Run API blogList, blogName can be Search from   "id" Key value of API blogList </summary>
        [Required]
        public int blogId { get; set; }
    }
    public class BlogsName
    {
        /// <summary> eg: "Mr. Aashish Somaiyaa" 
        /// blogName can be Search from Key value of API blogCategories </summary>
        [Required]
        public string blogName { get; set; }
    }

    public class FundManagersName
    {
        public string name { get; set; }
        public string image { get; set; }
    }

    public class AnalystName
    {
        public string name { get; set; }
        public string image { get; set; }
    }

    public class BlogsbasicDetailRes
    {
        public string chairmanName { get; set; }
        public string chairmanImage { get; set; }
        public string ceoName { get; set; }
        public string ceoImage { get; set; }
        public List<FundManagersName> fundManagersName { get; set; }
        public List<AnalystName> analystName { get; set; }
    }

    public class BlogListRes
    {
        public int id { get; set; }
        public string author { get; set; }
        public string authorImage { get; set; }
        public string designation { get; set; }
        public string publishedDate { get; set; }
        public string title { get; set; }
        public string overview { get; set; }
        public string shareLink { get; set; }

    }
    public class BlogDetailRes
    {
        public int id { get; set; }
        public string author { get; set; }
        public string authorImage { get; set; }
        public string designation { get; set; }
        public string publishedDate { get; set; }
        public string title { get; set; }
        public string content { get; set; }
        public string shareLink { get; set; }
    }

    public class WCThought : IValidatableObject
    {
        ParamValid ParamValid = new ParamValid();
        /// <summary> ""|title can be Search from "title" Key value from below Response body  </summary>
        public string title { get; set; }

        /// <summary>""|2010-01-01 Date Format (yyyy-MM-dd) </summary>
        public string fromDate { get; set; }

        /// <summary>""|2018-01-01 Date Format (yyyy-MM-dd) </summary>
        public string toDate { get; set; }

        /// <summary> ""|0|last No from last Fetch Data  </summary>
        public int? offset { get; set; }

        /// <summary> ""|10|No of Count from last Fetch Data </summary>
        public int? count { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            bool fromdate = true;
            bool toDate = true;
            // some other random test
            if (this.fromDate != "" && this.fromDate != null)
            {
                if (ParamValid.DateValidate(this.fromDate.Trim(), "yyyy-MM-dd") == false)
                {
                    results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { nameof(fromDate) }));
                    fromdate = false;
                }
            }
            else { fromdate = false; }
            if (this.toDate!= "" && this.toDate != null)
            {
                if (ParamValid.DateValidate(this.toDate.Trim(), "yyyy-MM-dd") == false)
                {
                    results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { nameof(toDate) }));
                    toDate = false;
                }
            }
            else { toDate = false; }
            if (fromdate == true && toDate == true)
            {
                if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
                {
                    results.Add(new ValidationResult("toDate must be larger than fromDate"));
                }
            }
            return results;
        }
    }


    public class WCThoughtRes
    {
        public int id { get; set; }
        public string title { get; set; }
        public string publishedDateTime { get; set; }
        public string url { get; set; }
    }

    public class Downloads : IValidatableObject
    {
        ///// <summary> "PMS"|"Mutual Fund" </summary>
        //[Required]
        //public string product { get; set; }
        /// <summary> "Monthly Communique'|'Factsheet'" </summary>
        [Required]
        public string type { get; set; }
        /// <summary> ""|0|Last No from last Fetch Data  </summary>
        public int? offset { get; set; }
        /// <summary> ""|10|No of Count from last Fetch Data </summary>
        public int? count { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            if (this.type.ToUpper().Trim() != "FACTSHEET" && this.type.ToUpper().Trim() != "MONTHLY COMMUNIQUE")
            {
                results.Add(new ValidationResult("Invalid Type", new List<string> { nameof(type) }));
            }
            return results;
        }
    }
    public class ProductAlloactionRes
    {
        public DataPoint4 dataPoints { get; set; }
    }
    public class BannerRes
    {
        public string product { get; set; }
        public string schemeCode { get; set; }
        public string strategyCode { get; set; }
        public string bannerType { get; set; }
        public string openIn { get; set; }
        public string module { get; set; }
        public string schemeName { get; set; }
        public int bannerID { get; set; }
        public string navigateURL { get; set; }
        public string imageURL { get; set; }
        public int displayOrder { get; set; }
    }
    public class BannerReq
    {
        public string Platform { get; set; }
        public string DisplaySource { get; set; }
        public string UserType { get; set; }
        public int BannerId { get; set; }
    }
}
