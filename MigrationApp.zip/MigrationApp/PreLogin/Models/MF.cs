﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using ApiCore.Validation;
using System.ComponentModel;

namespace PreLogin.Models
{

    public class MFPerformanceTable
    {
        /// <summary> "Refer Init API "groupCode" key from Response eg: MO24095" </summary>
        [Required]
        public string groupSchemeCode { get; set; }
    }
    public class MFPeriodicTable
    {
        /// <summary> "Lumpsum|SIP" </summary>
        [Required]
        public string investorType { get; set; }
        /// <summary> "Refer Init API "schemeCode" key from Response eg: 24095|21098" </summary>
        [Required]
        public double mfSchemeCode { get; set; }
        [Required]
        [DefaultValue(10000)]
        public double amount { get; set; }
        /// <summary>2010-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string fromDate { get; set; }
        /// <summary>2018-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string toDate { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
            {
                results.Add(new ValidationResult("toDate must be larger than fromDate"));
            }
            if (this.investorType.ToUpper().Trim() != "LUMPSUM" && this.investorType.ToUpper().Trim() != "SIP")
            {
                results.Add(new ValidationResult("Invalid investor Type"));
            }
            return results;
        }

    }
    public class MFPeriodicTabularRes
    {
        public string groupName { get; set; }
        public double marketValue { get; set; }
        public double retrun { get; set; }
    }

    public class holding
    {
        /// <summary> "Refer Init API  "MFProduct:schemeName|PMSProduct:strategyname" key from Response eg: Motilal Oswal MoSt Focused 25 Fund|Value Strategy" </summary>
        [Required]
        public string productName { get; set; }
    }

    public class DataPoint
    {
        public string navDate { get; set; }
        public decimal nav { get; set; }
    }

    public class Scheme
    {
        public double schemeCode { get; set; }
        public List<DataPoint> dataPoints { get; set; }
    }


    public class BenchMark
    {
        public string benchMarkName { get; set; }
        public List<DataPoint> dataPoints { get; set; }
    }



    public class TableContent
    {
        public string scheme { get; set; }
        public decimal? CAGR { get; set; }
        public double currentValue { get; set; }
    }

    public class ProdPerfoTabularReq
    {
        /// <summary> "Refer Init API "mfScheme:groupCode" key from Response eg: MO19233|MO26134" </summary>
        [Required]
        public string mfGroupCode { get; set; }

    }
    public class ProductPerfTabularRes
    {
        public List<ProductperfTabular> scheme { get; set; }
        public double investmentvalue { get; set; }
        public string inceptionDate { get; set; }
        public string content { get; set; }
    }
    public class ProductperfTabular
    {
        public string name { get; set; }
        public List<value>  value { get; set; }
    }
    public class value
    {
        public string duration { get; set; }
        public double cagr { get; set; }
        public double marketValue { get; set; }
    }

    public class PMSProductDetailContentRes
    {
        public string header { get; set; }
        public string content { get; set; }
        public string subTab { get; set; }
    }

    public class ProductDetailContentRes
    {
        public string header { get; set; }
        public string content { get; set; }
    }

    public class DataPoint2
    {
        public string companyName { get; set; }
        public decimal percentAllocation { get; set; }
    }

    public class Top10HoldingRes
    {
        public string schemeCode { get; set; }
        public string DataAsOn { get; set; }
        public List<DataPoint2> dataPoints { get; set; }
    }

    public class LatestNAVRes
    {
        public string date { get; set; }
        public string schemeCode { get; set; }
        public string schemeName { get; set; }
        public string planMode { get; set; }
        public decimal NAV { get; set; }
        public decimal perChange { get; set; }
    }

    public class ProdPerfoNavRes
    {
        public string date { get; set; }
        public string scheme { get; set; }
        public string planMode { get; set; }
        public decimal NAV { get; set; }
        public decimal perChange { get; set; }
    }
    public class MFhistoricalNavGraphRes
    {
        public Scheme scheme { get; set; }
    }

    public class Content
    {
        public string navDate { get; set; }
        public decimal nav { get; set; }
        public double rePurchasePrice { get; set; }
        public double salePrice { get; set; }
    }

    public class Scheme3
    {
        public string pdfUrl { get; set; }
        public string xlsUrl { get; set; }
        public double schemeCode { get; set; }
        public List<Content> content { get; set; }
    }

    public class HistDividendRes
    {
        public double schemeCode { get; set; }
        public string schcmeName { get; set; }
        public string recordDate { get; set; }
        public decimal indDiv { get; set; }
        public decimal nonIndDiv { get; set; }
    }

    public class Nav
    {
        /// <summary> "Refer Init API "schemeCode" key from Response eg: 24095" </summary>
        public Int64? mfSchemeCode { get; set; }
    }

    public class NavHistory : IValidatableObject
    {
        /// <summary> "Refer Init API "schemeCode" key from Response eg: 24095|21098" </summary>
        [Required]
        public double mfSchemeCode { get; set; }
        /// <summary>2010-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string fromDate { get; set; }
        /// <summary>2018-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string toDate { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
            {
                results.Add(new ValidationResult("toDate must be larger than fromDate"));
            }
            return results;
        }
    }



    public class ProdPerfoNav
    {
        /// <summary> "Refer Init API "mfScheme:groupCode" key from Response eg: MO33399" </summary>
        [Required]
        public string mfGroupCode { get; set; }

    }

    public class ProdPerfoNavHistory : IValidatableObject
    {
        /// <summary> "Refer Init API "mfScheme:groupCode" key from Response eg: MO33399" </summary>
        [Required]
        public string mfGroupCode { get; set; }
        /// <summary>2010-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string fromDate { get; set; }
        /// <summary>2018-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string toDate { get; set; }
        /// <summary>  "Refer Init API "mfScheme:planMode" key from Response eg: Direct-Dividend-Q"  </summary>
        [Required]
        public string planmode { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
            {
                results.Add(new ValidationResult("toDate must be larger than fromDate"));
            }
            return results;
        }
    }
    public class BenchmarkRes
    {
        public string bmCode { get; set; }
        public string indexName { get; set; }
    }
    public class Benchmark
    {
        /// <summary> "Refer Init API  "schemeCode" key from Response eg: 26134" </summary>
        [Required]
        public string schemeCode { get; set; }
    }
    public class MFPeriodicGraph
    {
        /// <summary> "Lumpsum|SIP" </summary>
        [Required]
        public string investorType { get; set; }
        /// <summary> "Refer Init API "schemeCode" key from Response eg: 29396" </summary>
        [Required]
        public double mfSchemeCode { get; set; }
        [Required]
        [DefaultValue(10000)]
        public double amount { get; set; }
        /// <summary>2010-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string fromDate { get; set; }
        /// <summary>2018-01-01 Date Format (yyyy-MM-dd) </summary>
        [Required]
        [DateFormatValidation("yyyy-MM-dd")]
        public string toDate { get; set; }
        /// <summary> "Refer benchmark API "bmcode" key from Response eg: 2009" </summary>
        [Required]
        public string benchMarkCode { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            if (Convert.ToDateTime(this.fromDate) > Convert.ToDateTime(this.toDate))
            {
                results.Add(new ValidationResult("toDate must be larger than fromDate"));
            }
            if (this.investorType.ToUpper().Trim() != "LUMPSUM" && this.investorType.ToUpper().Trim() != "SIP")
            {
                results.Add(new ValidationResult("Invalid investor Type"));
            }
            return results;
        }

    }
    public class MFPeriodicGraphRes
    {
        public string schemeName { get; set; }
        public List<Datapoint3> scheme { get; set; }

        public string benchmarkName { get; set; }
        public List<Datapoint3> benchMark { get; set; }


    }
    public class Datapoint3
    {
        public string investDate { get; set; }
        public double marketvalue { get; set; }
    }
}
