﻿using ApiCore.DTOs;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PreLogin.MF
{
   public interface ISchemeDataSource
    {
     
       // Task<ResponseDataModel<ProductPerfTabularRes>> MFProductPerformanceTabular(MFPerformanceTable request);
        Task<ResponseDataModel<ProductPerfTabularRes>> MFProductPeriodicTabular(ProdPerfoTabularReq request);
        Task<ResponseDataModel<MFPeriodicGraphRes>> MFProductPeriodicGraph(MFPeriodicGraph request);
        Task<ResponseDataArrayModel<ProductDetailContentRes>> MFProductDetailedContent(MFPerformanceTable request);
        Task<ResponseDataArrayModel<LatestNAVRes>> GetLatestNavDetails();
        Task<ResponseDataModel<Scheme3>> GethistoricalNavDetails(NavHistory request);
        Task<ResponseDataArrayModel<HistDividendRes>> historicalDividend(NavHistory request);
        Task<ResponseDataArrayModel<ProdPerfoNavRes>> GetProductPerfoLatestNavDetails(ProdPerfoNav request);
        Task<ResponseDataModel<Scheme3>> GetProductPerfohistoricalNavDetails(ProdPerfoNavHistory request);
        Task<ResponseDataArrayModel<HistDividendRes>> GetProductPerfohistoricalDividendDetails(ProdPerfoNavHistory request);
        Task<ResponseDataArrayModel<BenchmarkRes>> BenchMark(Benchmark request);
    }
}
