﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using APICore.Helpers;
using Microsoft.AspNetCore.Mvc;
using PreLogin.Controllers;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreLogin.MF
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class SchemeController : ControllerBase
    {
        private readonly ISchemeDataSource _SchemeDataSource;
        private string Day1 = "0";
        ParamValid ParamValid = new ParamValid();
        public SchemeController(ISchemeDataSource SchemeDataSource)
        {
            _SchemeDataSource = SchemeDataSource;
            var now = DateTime.Now;
            var tomorrow9am = now.AddDays(1).Date.AddHours(9);
            int Duration = Convert.ToInt32((tomorrow9am - now).TotalSeconds);
            Day1 = Convert.ToString(Duration);
        }

        //[HttpGet("PerformanceTabular")]
        //[Produces("application/json")]
        //[ProducesResponseType(typeof(ResponseDataModel<ProductPerfTabularRes>), 200)]
        //[ResponseCache(CacheProfileName = "Default")]
        //public async Task<IActionResult> GetMFProductPerformanceTabular(MFPerformanceTable request)
        //{
        //    var response = await _SchemeDataSource.MFProductPerformanceTabular(request);
        //    return Ok(response);
        //}

        [HttpGet("PerformanceTabular")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ProductPerfTabularRes>), 200)]
        public async Task<IActionResult> MFProductPeriodicTabular(ProdPerfoTabularReq request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SchemeDataSource.MFProductPeriodicTabular(request);
            return Ok(response);
        }


        [HttpGet("PerformanceGraph")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<MFPeriodicGraphRes>), 200)]
        public async Task<IActionResult> MFProductPeriodicGraph(MFPeriodicGraph request)
        {
            var response = await _SchemeDataSource.MFProductPeriodicGraph(request);
            return Ok(response);
        }

        [HttpGet("DetailedContent")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ProductDetailContentRes>), 200)]
        public async Task<IActionResult> GetMFProductDetailedContent(MFPerformanceTable request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SchemeDataSource.MFProductDetailedContent(request);
            return Ok(response);
        }

        [HttpGet("NAV/Latest")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<LatestNAVRes>), 200)]
        public async Task<IActionResult> GetLatestNavDetails()
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SchemeDataSource.GetLatestNavDetails();
            return Ok(response);
        }

        [HttpGet("NAV/Historical")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<Scheme3>), 200)]
        public async Task<IActionResult> GethistoricalNavDetails(NavHistory request)
        {
            if (ParamValid.DateValidate(request.fromDate, "yyyy-MM-dd") == false)
            {
                throw new NoDataException(false, "ERUL011");
            }
            if (ParamValid.DateValidate(request.toDate, "yyyy-MM-dd") == false)
            {
                throw new NoDataException(false, "ERUL012");
            }
            if (ParamValid.greaterThen(request.fromDate, request.toDate) == false)
            {
                throw new NoDataException(false, "ERUL014");
            }
            var response = await _SchemeDataSource.GethistoricalNavDetails(request);
            return Ok(response);
        }

        [HttpGet("HistoricalDividend")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<HistDividendRes>), 200)]
        public async Task<IActionResult> historicalDividend(NavHistory request)
        {
            var response = await _SchemeDataSource.historicalDividend(request);
            return Ok(response);
        }

        [HttpGet("Perfomance/NAV/Latest")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<ProdPerfoNavRes>), 200)]
        public async Task<IActionResult> GetProductPerfoLatestNavDetails(ProdPerfoNav request)
        {
            var response = await _SchemeDataSource.GetProductPerfoLatestNavDetails(request);
            return Ok(response);
        }

        [HttpGet("Perfomance/NAV/Historical")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<Scheme3>), 200)]
        public async Task<IActionResult> GetProductPerfohistoricalNavDetails(ProdPerfoNavHistory request)
        {
            var response = await _SchemeDataSource.GetProductPerfohistoricalNavDetails(request);
            return Ok(response);
        }


        [HttpGet("Perfomance/NAV/HistoricalDividend")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<HistDividendRes>), 200)]
        public async Task<IActionResult> GetProductPerfohistoricalDividendDetails(ProdPerfoNavHistory request)
        {
            var response = await _SchemeDataSource.GetProductPerfohistoricalDividendDetails(request);
            return Ok(response);
        }

        [HttpGet("benchMarkList")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataArrayModel<BenchmarkRes>), 200)]
        public async Task<IActionResult> BenchMark(Benchmark request)
        {
            Request.HttpContext.Response.Headers.Add("Cache-Control", "public,max-age=" + Day1);
            var response = await _SchemeDataSource.BenchMark(request);
            return Ok(response);
        }
    }
}

