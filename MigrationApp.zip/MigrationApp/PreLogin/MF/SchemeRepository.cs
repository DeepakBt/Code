﻿using ApiCore.DTOs;
using ApiCore.Model;
using Dapper;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using ApiCore.Exceptions;
using Microsoft.AspNetCore.Http;
using System.Reflection;
using OfficeOpenXml;

namespace PreLogin.MF
{
    public class SchemeRepository : ISchemeDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection CMSConnection => new SqlConnection(_connections.ConCMSDB);
        private IDbConnection CorporateConn => new SqlConnection(_connections.CorporateDB);
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        string ReportPath = "";
        string HEADERMFLOGO = ""; string HEADERPMSLOGO = ""; string HEADERBOTHLOGO = "";


        public SchemeRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;

            ReportPath = _iconfiguration["ReportPath:CommonPath"];
            HEADERMFLOGO = _iconfiguration["ReportPath:HEADERMFLOGO"];
            HEADERPMSLOGO = _iconfiguration["ReportPath:HEADERPMSLOGO"];
            HEADERBOTHLOGO = _iconfiguration["ReportPath:HEADERBOTHLOGO"];
        }
        ParamValid ParamValid = new ParamValid();

        //// PreLoginMF

        //mfProductPerformanceTabular
        //public async Task<ResponseDataModel<ProductPerfTabularRes>> MFProductPerformanceTabular(MFPerformanceTable request)
        //{
        //    using (var conn = CorporateConn)
        //    {
        //        string groupcode = request.groupSchemeCode;

        //        using (var multi = await conn.QueryMultipleAsync("PROC_MF_PERFORMANCE_TABULAR_AMCMOBILEAPP", new
        //        {
        //            groupcode
        //        }, commandType: CommandType.StoredProcedure))
        //        {

        //            ProductPerfTabularRes ProdPerTabRes = new ProductPerfTabularRes();
        //            var VerifiedList = multi.Read().ToList();
        //            var contentList = multi.Read();
        //            if (VerifiedList.Count > 0)
        //            {
        //                List<TableContent> Content = new List<TableContent>();
        //                foreach (var p in VerifiedList.ToList())
        //                {
        //                    Content.Add(new TableContent
        //                    {
        //                        scheme = p.GroupName ?? "",
        //                        CAGR = Convert.ToDecimal(p.OneYear_Ret) ?? 0.00,
        //                        currentValue = p.OneYearRs ?? 0.00,
        //                    });
        //                }
        //                ProdPerTabRes.tableContent = Content;
        //                ProdPerTabRes.inceptionDate = (from p in VerifiedList
        //                                               select Convert.ToString(p.InceptionDate) ?? "").FirstOrDefault();
        //                ProdPerTabRes.content = (from p in contentList
        //                                         select ParamValid.RemoveHTMLTag(p.TabsData) ?? "").FirstOrDefault();
        //                return new ResponseDataModel<ProductPerfTabularRes>(ProdPerTabRes);
        //            }
        //            else
        //            {
        //                throw new NoDataException(false);
        //            }
        //        }
        //    }
        //}


        public async Task<ResponseDataModel<ProductPerfTabularRes>> MFProductPeriodicTabular(ProdPerfoTabularReq request)
        {
            using (var conn = CorporateConn)
            {
                var multi = await conn.QueryMultipleAsync("MF_RetWithIndex_MOSL_AMCMOB", new
                {
                    groupcode = request.mfGroupCode
   
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    ProductPerfTabularRes ProdPerTabRes = new ProductPerfTabularRes();
                    var VerifiedList = multi.Read().ToList();
                    var contentList = multi.Read();
                    if (VerifiedList.Count > 0)
                    {
           
                        List < ProductperfTabular> ContentList = new List<ProductperfTabular>();
                        string[] duration = new string[] { "1 Year", "3 Year", "Since Inception" };
                        foreach (var p in VerifiedList.ToList())
                        {
                            ProductperfTabular Content = new ProductperfTabular();
                            List<value> value = new List<value>();

                            Content.name = Convert.ToString(p.GroupName);
                            if (p.MarketValueOneYear != null || p.Type == "BM")
                            {
                                value.Add(new value
                                {
                                    duration = duration[0] ?? "",
                                    cagr = Convert.ToDouble(Convert.ToString(p.OneYear_Ret)) ?? 0.00,
                                    marketValue = Convert.ToDouble(Convert.ToString(p.MarketValueOneYear)) ?? 0.00,
                                });
                            }

                            if (p.MarketValueThreeYear != null || p.Type == "BM")
                            {
                                value.Add(new value
                                {
                                    duration = duration[1] ?? "",
                                    cagr = Convert.ToDouble(Convert.ToString(p.ThreeYear_Ret)) ?? 0.00,
                                    marketValue = Convert.ToDouble(Convert.ToString(p.MarketValueThreeYear)) ?? 0.00,
                                });
                            }

                            if (p.MarketValueInception != null || p.Type == "BM")
                            {
                                value.Add(new value
                                {
                                    duration = duration[2] ?? "",
                                    cagr = Convert.ToDouble(Convert.ToString(p.Inception_Ret)) ?? 0.00,
                                    marketValue = Convert.ToDouble(Convert.ToString(p.MarketValueInception)) ?? 0.00,
                                });
                            }

                            //if (ContentList.Count > 0)    // This is for both benchmark data & Product performance table no. of result rows should same.
                            //{
                            //    var valueList = ContentList[0].value;
                            //    var query = (from val in valueList.ToList()
                            //                join v in value on val.duration equals v.duration
                            //                select v);
                            //    query = query.Where(c => c.marketValue != 0);
                            //    List<value> list_value = query.ToList<value>();
                            //    Content.value = list_value;
                            //}
                            //else
                            //{
                                Content.value = value.Where(d => d.marketValue !=0).ToList() ;
                            //}
                            ContentList.Add(Content);
                        }
                        ProdPerTabRes.scheme = ContentList;
                        ProdPerTabRes.investmentvalue = (from p in contentList
                                                         select Convert.ToDouble(p.investmentvalue) ?? "").FirstOrDefault();
                        ProdPerTabRes.inceptionDate = (from p in contentList
                                                       select Convert.ToString(p.InceptionDate) ?? "").FirstOrDefault();
                        ProdPerTabRes.content = (from p in contentList
                                                 select ParamValid.RemoveHTMLTag(p.TabsData) ?? "").FirstOrDefault();
                        return new ResponseDataModel<ProductPerfTabularRes>(ProdPerTabRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        //mfProductPerformanceGraph
        public async Task<ResponseDataModel<MFPeriodicGraphRes>> MFProductPeriodicGraph(MFPeriodicGraph request)
        {
            using (var conn = CorporateConn)
            {
                var multi = await conn.QueryAsync("AMCMOB_GETPERIODICRETURN_MF", new
                {
                    TYPEOFDATA = "GRAPH",
                    TYPEOFTRANSACTION = request.investorType,
                    MFSCHEMECODE = request.mfSchemeCode,
                    AMOUNT = request.amount,
                    FROMDATE = request.fromDate,
                    TODATE = request.toDate,
                    BMCODE = request.benchMarkCode,
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    MFPeriodicGraphRes DataRes = new MFPeriodicGraphRes();
                    var SchemeData = multi.ToList();
                    if (SchemeData.Count > 0)
                    {
                        DataRes.schemeName = SchemeData[0].SchemeName;
                        DataRes.benchmarkName = SchemeData[0].BenchmarkIndexName;
                        List<Datapoint3> Schemepoint = new List<Datapoint3>();
                        List<Datapoint3> BenchPoint = new List<Datapoint3>();
                        foreach (var p in SchemeData.ToList())
                        {
                            Schemepoint.Add(new Datapoint3
                            {
                                investDate = p.Investment_Date ?? "",
                                marketvalue = Convert.ToDouble(Convert.ToString(p.MarketValue_Scheme)) ?? 0.00,
                            });
                            BenchPoint.Add(new Datapoint3
                            {
                                investDate = p.Investment_Date ?? "",
                                marketvalue = Convert.ToDouble(Convert.ToString(p.MarketValue_BM)) ?? 0.00,
                            });
                        }
                        DataRes.scheme = Schemepoint;
                        DataRes.benchMark = BenchPoint;
                        return new ResponseDataModel<MFPeriodicGraphRes>(DataRes);
                    }
                    else
                    {
                        throw new NoDataException(false);

                    }
                }
            }
        }


        //mfProductDetailedContent
        public async Task<ResponseDataArrayModel<ProductDetailContentRes>> MFProductDetailedContent(MFPerformanceTable request)
        {
            using (var conn = CMSConnection)
            {
                string groupcode = request.groupSchemeCode;
                using (var multi = await conn.QueryMultipleAsync("PROC_MF_PRODUCT_DETAILCONTENT_AMCMOBILEAPP", new
                {
                    groupcode
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure))
                {
                    var VerifiedList = multi.Read().ToList();
                    List<ProductDetailContentRes> Contentlist = new List<ProductDetailContentRes>();
                    if (VerifiedList.Count > 0)
                    {
                        foreach (var p in VerifiedList.ToList())
                        {
                            Contentlist.Add(new ProductDetailContentRes
                            {
                                header = p.header ?? "",
                                content = p.content ?? ""
                            });
                        }
                        return new ResponseDataArrayModel<ProductDetailContentRes>(Contentlist);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }

        //latestNavDetails
        public async Task<ResponseDataArrayModel<LatestNAVRes>> GetLatestNavDetails()
        {
            using (var conn = CorporateConn)
            {
                dynamic code =  0 ;
                var multi = await conn.QueryAsync("CMMO_MOMFSchemeData_AMC_AMCMOBILEAPP", new
                {
                    type = "latest", //request.navType,
                    code = code == 0 ? "" : code
                }, commandTimeout: 0 , commandType: CommandType.StoredProcedure);
                {
                    List<LatestNAVRes> LatestNAVList = new List<LatestNAVRes>();
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        foreach (var p in VerifiedList.ToList())
                        {
                            LatestNAVList.Add(new LatestNAVRes
                            {
                                date = p.latdate ?? "",
                                schemeCode = Convert.ToString(p.mf_schcode) ?? "",
                                schemeName = p.mo_sch_Name ?? "",
                                planMode = p.opt ?? "",
                                NAV = Convert.ToDecimal(p.latnav) ?? 0.00,
                                perChange = Convert.ToDecimal(p.change) ?? 0.00,

                            });
                        }

                        return new ResponseDataArrayModel<LatestNAVRes>(LatestNAVList);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }

        //historicalNavDetails
        public async Task<ResponseDataModel<Scheme3>> GethistoricalNavDetails(NavHistory request)
        {
           
            using (var conn = CorporateConn)
            {
                using (var multi = await conn.QueryMultipleAsync("CMMO_MOMFSchemeData_AMC_AMCMOBILEAPP", new
                {
                    type = "Hist", //request.navType,
                    code = request.mfSchemeCode,
                    fromdate = request.fromDate,
                    todate = request.toDate
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure))
                {
                    Scheme3 HistnavTabRes = new Scheme3();
                    var VerifiedList = multi.Read().ToList();
                    var dtData = new DataTable();
                    dtData.Load(await conn.ExecuteReaderAsync("CMMO_MOMFSchemeData_AMC_AMCMOBILEAPP", new
                    {
                        type = "Hist", //request.navType,
                        code = request.mfSchemeCode,
                        fromdate = request.fromDate,
                        todate = request.toDate
                    }, commandType: CommandType.StoredProcedure));

                    dtData.Columns.RemoveAt(0);
                    dtData.SetColumnsOrder("navdate", "Schemename", "navrs", "navreprice", "navsaprice");
          
                    if (VerifiedList.Count > 0)
                    {
                        string pdfdata = GeneratePDF(dtData, "HistNav", "", "");
                        string xlsdata = GenerateExcel(dtData, "HistNav", "", "");
                        HistnavTabRes.pdfUrl = pdfdata;
                        HistnavTabRes.xlsUrl = xlsdata;
                        HistnavTabRes.schemeCode = VerifiedList[0].mf_schcode;
                        List<Content> Content = new List<Content>();
                        foreach (var p in VerifiedList.ToList())
                        {
                            Content.Add(new Content
                            {
                                navDate = p.navdate ?? "",
                                nav = Convert.ToDecimal(p.navrs) ?? 0.00,
                                rePurchasePrice = p.navreprice ?? 0.00,
                                salePrice = p.navsaprice ?? 0.00
                            });
                        }
                        HistnavTabRes.content = Content;
                        return new ResponseDataModel<Scheme3>(HistnavTabRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        //historicalDividend
        public async Task<ResponseDataArrayModel<HistDividendRes>> historicalDividend(NavHistory request)
        {
            List<HistDividendRes> HistDivlist = new List<HistDividendRes>();
            using (var conn = CorporateConn)
            {
                var multi = await conn.QueryAsync("CMMO_MODividendDetails_AMC_AMCMOBILEAPP", new
                {

                    frdate = request.fromDate,
                    todate = request.toDate,
                    schcode = request.mfSchemeCode
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {

                    var VerifiedList = multi.ToList();

                    if (VerifiedList.Count > 0)
                    {
                        foreach (var p in VerifiedList.ToList())
                        {
                            HistDivlist.Add(new HistDividendRes
                            {
                                schemeCode = p.mf_schcode ?? 0,
                                schcmeName = p.mo_sch_name ?? "",
                                recordDate = p.recorddate ?? "",
                                indDiv = Convert.ToDecimal(p.IndDiv) ?? 0.00,
                                nonIndDiv = Convert.ToDecimal(p.NonIndDiv) ?? 0.00
                            });
                        }
                        return new ResponseDataArrayModel<HistDividendRes>(HistDivlist);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }

        //latestNavDetails
        public async Task<ResponseDataArrayModel<ProdPerfoNavRes>> GetProductPerfoLatestNavDetails(ProdPerfoNav request)
        {
            using (var conn = CorporateConn)
            {
                dynamic code = request.mfGroupCode == null ? "" : request.mfGroupCode;
                var multi = await conn.QueryAsync("CMMO_MOMFSchemeData_AMC_AMCMOBILEAPP_POSTLOGIN", new
                {
                    type = "latest", //request.navType,
                    MOSLCODE = code,
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    List<ProdPerfoNavRes> ProdPerfoNavList = new List<ProdPerfoNavRes>();
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        foreach (var p in VerifiedList.ToList())
                        {
                            ProdPerfoNavList.Add(new ProdPerfoNavRes
                            {
                                date = p.latdate ?? "",
                                scheme = p.mo_sch_Name ?? "",
                                planMode = p.opt ?? "",
                                NAV = Convert.ToDecimal(p.latnav) ?? 0.00,
                                perChange = Convert.ToDecimal(p.change) ?? 0.00,
                            });
                        }

                        return new ResponseDataArrayModel<ProdPerfoNavRes>(ProdPerfoNavList);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }

        //historicalNavDetails
        public async Task<ResponseDataModel<Scheme3>> GetProductPerfohistoricalNavDetails(ProdPerfoNavHistory request)
        {

            using (var conn = CorporateConn)
            {
                using (var multi = await conn.QueryMultipleAsync("CMMO_MOMFSchemeData_AMC_AMCMOBILEAPP_POSTLOGIN", new
                {
                    type = "Hist", //request.navType,
                    MOSLCODE = request.mfGroupCode,
                    fromdate = request.fromDate,
                    todate = request.toDate,
                    PLANMODE = request.planmode
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure))
                {
                    Scheme3 HistnavTabRes = new Scheme3();
                    var VerifiedList = multi.Read().ToList();
                    var dtData = new DataTable();
                    dtData.Load(await conn.ExecuteReaderAsync("CMMO_MOMFSchemeData_AMC_AMCMOBILEAPP_POSTLOGIN", new
                    {
                        type = "Hist", //request.navType,
                        MOSLCODE = request.mfGroupCode,
                        fromdate = request.fromDate,
                        todate = request.toDate,
                        PLANMODE = request.planmode
                    }, commandTimeout: 0, commandType: CommandType.StoredProcedure));

                    dtData.Columns.RemoveAt(0);
                    dtData.SetColumnsOrder("navdate", "Schemename", "navrs", "navreprice", "navsaprice");
          
                    if (VerifiedList.Count > 0)
                    {
                        string pdfdata = GeneratePDF(dtData, "HistNav", "", "");
                        string xlsdata = GenerateExcel(dtData, "HistNav", "", "");
                        HistnavTabRes.pdfUrl = pdfdata;
                        HistnavTabRes.xlsUrl = xlsdata;
                        HistnavTabRes.schemeCode = VerifiedList[0].mf_schcode;
                        List<Content> Content = new List<Content>();
                        foreach (var p in VerifiedList.ToList())
                        {
                            Content.Add(new Content
                            {
                                navDate = p.navdate ?? "",
                                nav = Convert.ToDecimal(p.navrs) ?? 0.00,
                                rePurchasePrice = p.navreprice ?? 0.00,
                                salePrice = p.navsaprice ?? 0.00
                            });
                        }
                        HistnavTabRes.content = Content;
                        return new ResponseDataModel<Scheme3>(HistnavTabRes);
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        //historicalDividend
        public async Task<ResponseDataArrayModel<HistDividendRes>> GetProductPerfohistoricalDividendDetails(ProdPerfoNavHistory request)
        {
            List<HistDividendRes> HistDivlist = new List<HistDividendRes>();

            using (var conn = CorporateConn)
            {
                var multi = await conn.QueryAsync("CMMO_MODividendDetails_AMC_AMCMOBILEAPP", new
                {

                    frdate = request.fromDate,
                    todate = request.toDate,
                    schcode = "",
                    top ="",
                    groupcode = request.mfGroupCode,
                    PLANMODE = request.planmode
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {

                    var VerifiedList = multi.ToList();

                    if (VerifiedList.Count > 0)
                    {
                        foreach (var p in VerifiedList.ToList())
                        {
                            HistDivlist.Add(new HistDividendRes
                            {
                                schemeCode = p.mf_schcode ?? 0,
                                schcmeName = p.mo_sch_name ?? "",
                                recordDate = p.recorddate ?? "",
                                indDiv = Convert.ToDecimal(p.IndDiv) ?? 0.00,
                                nonIndDiv = Convert.ToDecimal(p.NonIndDiv) ?? 0.00
                            });
                        }
                        return new ResponseDataArrayModel<HistDividendRes>(HistDivlist);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }

        //BeanchMarkList
        public async Task<ResponseDataArrayModel<BenchmarkRes>> BenchMark(Benchmark request)
        {
            using (var conn = CorporateConn)
            {
                var multi = await conn.QueryAsync("AMCMOB_MF_SchemeMaster_MOSL", new
                {
                    mf_schcode = request.schemeCode
                }, commandTimeout: 0, commandType: CommandType.StoredProcedure);
                {
                    var VerifiedList = multi.ToList();
                    if (VerifiedList.Count > 0)
                    {
                        List<BenchmarkRes> objBenmark = new List<BenchmarkRes>();
                        foreach (var p in VerifiedList.ToList())
                        {
                            objBenmark.Add(new BenchmarkRes
                            {
                                bmCode = Convert.ToString(p.bmcode) ?? "",
                                indexName = Convert.ToString(p.indexnamevalue) ?? "",
                            });

                        }
                        return new ResponseDataArrayModel<BenchmarkRes>(objBenmark);
                    }
                    else
                    {
                        throw new NoDataException(true);
                    }
                }
            }
        }
        public string GeneratePDF(DataTable myDataTable, string ReportName, string ColumnWidths, string Optional)
        {
            string strPath = ReportPath;   //ConfigurationManager.AppSettings["FILEPATH"];
            string GUID = Guid.NewGuid().ToString();
            string filename = strPath + ReportName + "_" + GUID + ".pdf";
            string GlobalFilePath = _iconfiguration["ReportPath:GCommonPath"] + ReportName + "_" + GUID + ".pdf";
            string fileNa = ReportName + "_" + GUID + ".pdf";
            byte[] doc;
            try
            {
                //string ColumnWidth = "100, 70, 50, 40, 40, 50, 50, 70, 70, 70, 70, 70";
                using (var fs = File.Create(strPath + ReportName + "_" + GUID + ".pdf"))
                {
                    //using (MemoryStream ms = new MemoryStream())
                    //{
                    Document pdfDoc = new Document(PageSize.A4, 5, 5, 75, 85);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, fs);

                    pdfDoc.Open();
                    PdfContentByte Cb = writer.DirectContent;

                    Font font8 = new Font(Font.FontFamily.TIMES_ROMAN, 7, Font.NORMAL);
                    Font fontheader = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD);
                    DataTable dt = myDataTable;

                    DataTable dthead = myDataTable.Clone();

                    if (dt.Rows.Count > 0)
                    {
                        //Craete instance of the pdf table and set the number of column in that table  
                        PdfPTable PdfTable = new PdfPTable(5);
                        PdfPCell PdfPCell = null;
                        PdfTable.TotalWidth = 100f;
                        PdfTable.HeaderRows = 1;

                        string HeaderImg = string.Empty;

                        string Rtype = "MF";

                        switch (Rtype)
                        {
                            case "MF":
                                HeaderImg = HEADERMFLOGO; //ConfigurationManager.AppSettings["HEADERMFLOGO"].ToString();
                                break;
                            case "PMS":
                                HeaderImg = HEADERPMSLOGO;//ConfigurationManager.AppSettings["HEADERPMSLOGO"].ToString();
                                break;
                            case "BOTH":
                            case "D":
                                HeaderImg = HEADERBOTHLOGO; //ConfigurationManager.AppSettings["HEADERBOTHLOGO"].ToString();
                                break;
                        }

                        var Header = Image.GetInstance(HeaderImg);

                        switch (Rtype)
                        {
                            case "MF":
                                Header.SetAbsolutePosition(270, 785);
                                Header.ScaleAbsolute(150, 50);
                                Header.ScalePercent(35);
                                break;
                            case "PMS":
                                Header.SetAbsolutePosition(270, 785);
                                Header.ScaleAbsolute(150, 50);
                                Header.ScalePercent(35);
                                break;
                            case "BOTH":
                            case "D":
                                Header.SetAbsolutePosition(395, 785);
                                Header.ScaleAbsolute(150, 50);
                                Header.ScalePercent(35);
                                break;
                        }
                        Cb.AddImage(Header);

                        string ColName = "";

                        for (int column = 0; column <= dt.Columns.Count - 1; column++)
                        {
                            if (column == 0)
                            {
                                ColName = "NAV Date";
                            }
                            if (column == 1)
                            {
                                ColName = "Scheme Name";
                            }
                            if (column == 2)
                            {
                                ColName = "NAV (Rs.)";
                            }
                            if (column == 3)
                            {
                                ColName = "Repurchase Price (Rs.)";
                            }
                            if (column == 4)
                            {
                                ColName = "Sale Price (Rs.)";
                            }

                            PdfPCell = new PdfPCell(new Phrase(new Chunk(ColName, fontheader)));
                            PdfPCell.BackgroundColor = new BaseColor(System.Drawing.Color.FromArgb(119, 134, 97));
                            PdfPCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                            PdfTable.AddCell(PdfPCell);
                        }

                        float[] f = new float[] { 1f, 1f, 1f, 1f, 1f };
                        PdfTable.TotalWidth = 300f;
                        PdfTable.LockedWidth = true;

                        PdfTable.SetWidths(f);

                        for (int rows = 0; rows <= dt.Rows.Count - 1; rows++)
                        {
                            for (int column = 0; column <= dt.Columns.Count - 1; column++)
                            {

                                PdfPCell = new PdfPCell(new Phrase(new Chunk(dt.Rows[rows][column].ToString(), font8)));
                                if (rows % 2 == 0)
                                {
                                    PdfPCell.BackgroundColor = new BaseColor(System.Drawing.Color.FromArgb(243, 243, 243));
                                }
                                if (ParamValid.isNumeric(dt.Rows[rows][column].ToString()) == true)
                                {
                                    PdfPCell.HorizontalAlignment = PdfPCell.ALIGN_RIGHT;
                                }
                                else
                                {
                                    PdfPCell.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
                                }
                                PdfTable.AddCell(PdfPCell);
                            }
                        }
                        PdfTable.SpacingBefore = 30f; // Give some space after the text or it may overlap the table    
                                                      //PdfTable1.SpacingBefore = 30f;
                        pdfDoc.Add(PdfTable); // add pdf table to the document   


                        // Footer
                        //string FooterImg = "";
                        //FooterImg = ConfigurationManager.AppSettings["FOOTERLOGO"].ToString();
                        //Image Footer = Image.GetInstance(FooterImg);
                        //Footer.SetAbsolutePosition(10, 10);
                        //Footer.ScaleAbsolute(580, 100);
                        //Footer.ScalePercent(50);
                        //Cb.AddImage(Footer);
                    }
                    BaseFont f_cn = BaseFont.CreateFont(Convert.ToString("C:\\windows\\fonts\\times.ttf"), BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    PdfContentByte cb = writer.DirectContent;
                    cb.SetFontAndSize(f_cn, 9);
                    cb.BeginText();
                    cb.SetTextMatrix(40, 10);  // Left, Top}
                    cb.EndText();
                    pdfDoc.Close();

                }

                //HttpResponseMessage Request = new HttpResponseMessage();

                //Request.StatusCode = HttpStatusCode.OK;
                //Request.Content = new StreamContent(new MemoryStream(doc));
                //Request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
                //Request.Content.Headers.ContentLength = doc.Length;
                //ContentDispositionHeaderValue contentDisposition = null;
                //if (ContentDispositionHeaderValue.TryParse("inline; filename=" + "NavHistory", out contentDisposition))
                //{
                //    Request.Content.Headers.ContentDisposition = contentDisposition;
                //}
                return GlobalFilePath;
                // return Request;
            }

            catch (DocumentException de)
            {
                
                File.AppendAllText("D:\\Log.txt", "\r\n" + DateTime.Now.ToString() +  " Error : " + de.Message);
                return null;
            }
            catch (IOException ioEx)
            {
                //HttpContext.Current.Response.Write(ioEx.Message);
                File.AppendAllText("D:\\Log.txt", "\r\n" + DateTime.Now.ToString() + " Error : " + ioEx.Message);
                return null;
            }
            catch (Exception ex)
            {
                //HttpContext.Current.Response.Write(ex.Message);
                File.AppendAllText("D:\\Log.txt", "\r\n" + DateTime.Now.ToString() + " Error : " + ex.Message);
                return null;

            }

        }

        public string GenerateExcel(DataTable myDataTable, string ReportName, string ColumnWidths, string Optional)
        {
            string strPath = ReportPath;   //ConfigurationManager.AppSettings["FILEPATH"];
            string GUID = Guid.NewGuid().ToString();
            string filename = strPath + ReportName + "_" + GUID + ".xlsx";
            string GlobalFilePath = _iconfiguration["ReportPath:GCommonPath"] + ReportName + "_" + GUID + ".xlsx";
            string fileNa = ReportName + "_" + GUID + ".xlsx";
            byte[] doc;
            DataTable dt = myDataTable;
            try
            {
                string sWebRootFolder = strPath;
                string sFileName = fileNa;
                FileInfo file = new FileInfo(Path.Combine(sWebRootFolder, sFileName));
                string ColName = "";
                if (file.Exists)
                {
                    file.Delete();
                    file = new FileInfo(Path.Combine(sWebRootFolder, sFileName));
                }
                using (ExcelPackage package = new ExcelPackage(file))
                {
                    // add a new worksheet to the empty workbook
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Employee");

                    // column headings
                    //for (int i = 0; i < dt.Columns.Count; i++)
                    //{
                    //    worksheet.Cells[1, i + 1].Value = dt.Columns[i].ColumnName;
                    //}
                    for (int column = 0; column <= dt.Columns.Count - 1; column++)
                    {
                        if (column == 0)
                        {
                            ColName = "NAV Date";
                        }
                        if (column == 1)
                        {
                            ColName = "Scheme Name";
                        }
                        if (column == 2)
                        {
                            ColName = "NAV (Rs.)";
                        }
                        if (column == 3)
                        {
                            ColName = "Repurchase Price (Rs.)";
                        }
                        if (column == 4)
                        {
                            ColName = "Sale Price (Rs.)";
                        }

                        worksheet.Cells[1, column + 1].Value = ColName;
                    }
                    // rows
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        // to do: format datetime values before printing
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            worksheet.Cells[i + 2, j + 1].Value = dt.Rows[i][j];
                        }
                    }
                    package.Save(); //Save the workbook.
                }
                return GlobalFilePath;
   
            }
            catch (DocumentException de)
            {

                File.AppendAllText("D:\\Log.txt", "\r\n" + DateTime.Now.ToString() + " Error : " + de.Message);
                return "";
            }
            catch (IOException ioEx)
            {
                //HttpContext.Current.Response.Write(ioEx.Message);
                File.AppendAllText("D:\\Log.txt", "\r\n" + DateTime.Now.ToString() + " Error : " + ioEx.Message);
                return "";
            }
            catch (Exception ex)
            {
                //HttpContext.Current.Response.Write(ex.Message);
                File.AppendAllText("D:\\Log.txt", "\r\n" + DateTime.Now.ToString() + " Error : " + ex.Message);
                return "";

            }

        }
    }

    public static class DataTableExtensions
    {
        public static void SetColumnsOrder(this DataTable table, params String[] columnNames)
        {
            int columnIndex = 0;
            foreach (var columnName in columnNames)
            {
                table.Columns[columnName].SetOrdinal(columnIndex);
                columnIndex++;
            }
        }
    }
}
