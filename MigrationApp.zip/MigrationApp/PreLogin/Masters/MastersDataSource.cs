﻿using ApiCore.DTOs;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using PreLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PreLogin.Masters
{
   public interface IMastersDataSource
    {
        Task<ResponseDataModel<ResponseMsg>> RBIBankBulkUpload(IFormFile ReqExcelFile);
        Task<ResponseDataArrayModel<RBIBankDetail>> GetRBIIFSCBankDetail(ReqIFSCBank request);
    }
}
