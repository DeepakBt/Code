﻿using ApiCore.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PreLogin.Models;
using System.Threading.Tasks;
namespace PreLogin.Masters
{
    [Produces("application/json")]
    [Route("api/Masters")]
    public class MastersController : Controller
    {
        private readonly IMastersDataSource _IMastersDataSource;
        public MastersController(IMastersDataSource MastersDataSource)
        {
            _IMastersDataSource = MastersDataSource;
        }
        [HttpPost("UploadRBIBankMaster")]
        public async Task<IActionResult> UploadRBIBankMaster(IFormFile ReqExcelFile)
        {
            var response = await _IMastersDataSource.RBIBankBulkUpload(ReqExcelFile);
            return Ok(response);
        }

        [HttpPost("GetRBIBankDetail")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<RBIBankDetail>), 200)]
        public async Task<IActionResult> GetRBIBankDetail([FromBody] ReqIFSCBank ObjIFSC)
        {
            var response = await _IMastersDataSource.GetRBIIFSCBankDetail(ObjIFSC);
            return Ok(response);
        }
    }
}