﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using Dapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using PreLogin.Models;

namespace PreLogin.Masters
{
    public class MastersRepository : IMastersDataSource
    {
        private IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _iconfiguration;
        private readonly DbConnections _connections;
        string ErrorLogFile = string.Empty;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        public MastersRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IHostingEnvironment hostingEnvironment, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _hostingEnvironment = hostingEnvironment;
            _iconfiguration = iconfiguration;
        }

        public async Task<ResponseDataModel<ResponseMsg>> RBIBankBulkUpload(IFormFile ReqExcelFile)
        {
            ResponseMsg responseMsg = new ResponseMsg();
            try
            {
                if (!Path.GetExtension(ReqExcelFile.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    responseMsg.Message = "Only .xlsx file extension is allowed";
                    return new ResponseDataModel<ResponseMsg>(responseMsg);
                }

                string folderName = _iconfiguration["UploadFile:UploadedFolder"];
                string ContentRootPath = _hostingEnvironment.ContentRootPath;
                string newPath = Path.Combine(ContentRootPath, folderName);
                string fullPath = string.Empty;
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }

                if (ReqExcelFile.Length > 0)
                {
                    string fileName = ContentDispositionHeaderValue.Parse(ReqExcelFile.ContentDisposition).FileName.Trim('"');
                    fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        ReqExcelFile.CopyTo(stream);
                    }
                }

                DataTable dtBankData = GetDataTableFromExcel(fullPath);
                SqlConnection con = new SqlConnection(_connections.ConAMCMobileDB);
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con))
                {
                    bulkCopy.BatchSize = 10;
                    bulkCopy.DestinationTableName = "dbo.TBL_RBI_BANKS_DETAILS_EXCEL";
                    try
                    {
                        bulkCopy.ColumnMappings.Add("BANK NAME", "Bank_Name");
                        bulkCopy.ColumnMappings.Add("IFSC", "IFSC");
                        bulkCopy.ColumnMappings.Add("OFFICE", "Office");
                        bulkCopy.ColumnMappings.Add("ADDRESS", "Address");
                        bulkCopy.ColumnMappings.Add("DISTRICT", "District");
                        bulkCopy.ColumnMappings.Add("CITY", "City");
                        bulkCopy.ColumnMappings.Add("STATE", "State");
                        bulkCopy.ColumnMappings.Add("PHONE", "Phone");
                        con.Open();
                        bulkCopy.WriteToServer(dtBankData);
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        ErrorLogFile = _iconfiguration["ErrorLogFile"];
                        ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                        System.IO.File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r\n Method :" + "RBIBankBulkUpload \r\n ERROR:" + ex.Message);
                        responseMsg.Message = "Error occured while uploading excel";
                        if (con.State == ConnectionState.Open)
                        {
                            con.Close();
                        }
                        throw new NoDataException(true);
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                        {
                            con.Close();
                        }
                    }
                }
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("usp_BulkUpload_Get_RBIBank", new { Flag = 1 }, commandType: CommandType.StoredProcedure);
                    {
                        var Result = multi.FirstOrDefault();
                        responseMsg.Result = Result.Result;
                        responseMsg.Message = Result.Message;
                    }
                    if (responseMsg.Result == 0)
                    {
                        throw new NoDataException(true);
                    }
                }
                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r\n Method :" + "RBIBankBulkUpload \r\n ERROR:" + ex.Message);
                throw new NoDataException(true);
            }
            return new ResponseDataModel<ResponseMsg>(responseMsg);
        }

        public DataTable GetDataTableFromExcel(string path, bool hasHeader = true)
        {
            using (var pck = new OfficeOpenXml.ExcelPackage())
            {
                using (var stream = File.OpenRead(path))
                {
                    pck.Load(stream);
                }
                var ws = pck.Workbook.Worksheets.First();
                DataTable UploadedDt = new DataTable();
                foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
                {
                    UploadedDt.Columns.Add(hasHeader ? firstRowCell.Text : string.Format("Column {0}", firstRowCell.Start.Column));
                }
                var startRow = hasHeader ? 2 : 1;
                for (int rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
                {
                    var wsRow = ws.Cells[rowNum, 1, rowNum, ws.Dimension.End.Column];
                    DataRow row = UploadedDt.Rows.Add();
                    foreach (var cell in wsRow)
                    {
                        row[cell.Start.Column - 1] = cell.Text;
                    }
                }
                return UploadedDt;
            }
        }

        public async Task<ResponseDataArrayModel<RBIBankDetail>> GetRBIIFSCBankDetail(ReqIFSCBank ObjIFSC)
        {
            List<RBIBankDetail> LstRBIBankDetails = new List<RBIBankDetail>();
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("usp_BulkUpload_Get_RBIBank", new
                {
                    Flag = 2,
                    IFSCCode = ObjIFSC.IFSC
                }, commandType: CommandType.StoredProcedure);
                var RBIBankList = multi.ToList();
                if (RBIBankList.Count > 0)
                {
                    for (int i = 0; i < RBIBankList.Count; i++)
                    {
                        RBIBankDetail ObjBank = new RBIBankDetail();
                        ObjBank.Bank_Name = RBIBankList[i].Bank_Name;
                        ObjBank.City = RBIBankList[i].City;
                        ObjBank.District = RBIBankList[i].District;
                        ObjBank.IFSC = RBIBankList[i].IFSC;
                        ObjBank.Office = RBIBankList[i].Office;
                        ObjBank.State = RBIBankList[i].State;
                        ObjBank.Address = RBIBankList[i].Address;
                        ObjBank.Phone = RBIBankList[i].Phone;
                        LstRBIBankDetails.Add(ObjBank);
                    }
                    return new ResponseDataArrayModel<RBIBankDetail>(LstRBIBankDetails);
                }
                else
                {
                    throw new NoDataException(true);
                }
            }
        }
    }
}
