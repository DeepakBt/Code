﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using APICore.Constants;

namespace APICore.Auth
{
    public class IdentityHelper
    {
        public static string GetRole(IIdentity identity)
        {
            return ((ClaimsIdentity) identity).Claims.Where(c => c.Type == ClaimTypes.Role)
                .Select(c => c.Value).SingleOrDefault();
        }

        public static string GetPanNumber(IIdentity identity)
        {
            return GetPanNumber(((ClaimsIdentity) identity).Claims);
        }

        public static string GetPanNumber(IEnumerable<Claim> claims)
        {
            return claims.Where(c => c.Type == ClaimTypes.Name || c.Type == TokenConstants.ClaimPanNo)
                .Select(c => c.Value).SingleOrDefault();
        }

        public static string GetAppId(IIdentity identity)
        {
            return GetAppId(((ClaimsIdentity) identity).Claims);
        }

        public static string GetAppId(IEnumerable<Claim> claims)
        {
            return claims.Where(c => c.Type == TokenConstants.ClaimAppId)
                .Select(c => c.Value).SingleOrDefault();
        }
        public static string GetUserId(IIdentity identity)
        {
            return GetUserId(((ClaimsIdentity)identity).Claims);
        }

        public static string GetUserId(IEnumerable<Claim> claims)
        {
            return claims.Where(c => c.Type == TokenConstants.ClaimUserId)
                .Select(c => c.Value).SingleOrDefault();
        }
        public static string GetExpiryTime(IIdentity identity)
        {
            return ((ClaimsIdentity) identity).Claims.Where(c => c.Type == "exp")
                .Select(c => c.Value).SingleOrDefault();
        }
    }
}