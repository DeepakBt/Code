﻿using ApiCore.Constants;
using APICore.Auth;
using Microsoft.AspNetCore.Http;
using System;

namespace ApiCore.Auth
{
    public class HeaderAccessors
    {
        public static string GetAppId(HttpContext context, IHeaderDictionary headers)
        {
            var appId = IdentityHelper.GetAppId(context.User?.Identity);
            return appId ?? GetAppId(headers);
        }

        public static string GetAppId(IHeaderDictionary headers)
        {
            var value = headers[HeaderConstants.AppId];
            return value.Count > 0 ? value[0]?.Split(',')[0].Trim() : null;
        }

        public static string GetLoginId(HttpContext context, IHeaderDictionary headers)
        {
            var userName = context.User?.Identity?.Name;
            return userName ?? GetLoginId(headers);
        }

        public static string GetLoginId(IHeaderDictionary headers)
        {
            var value = headers[HeaderConstants.LoginId];
            return value.Count > 0 ? value[0] : null;
        }

        //public static string GetUserAgent(HttpContext httpContext, IHeaderDictionary headers)
        //{
        //    if (httpContext == null) throw new ArgumentNullException(nameof(httpContext));
        //    var request = httpContext.Request;
        //    var userAgent = string.Empty;
        //    if (request.Headers.ContainsKey("User-Agent"))
        //    {
        //        userAgent = request.Headers["User-Agent"][0];
        //    }
        //    else
        //    {
        //        userAgent = request.Headers["UserAgent"].ToString();
        //    }
        //    if (userAgent.Contains("MOAMC/Android"))
        //    {
        //        userAgent = "MOAMCAPP/Android";
        //    }
        //    else if (userAgent.Contains("MOAMC") && userAgent.Contains("iOS"))
        //    {
        //        userAgent = "MOAMCAPP/iOS";
        //    }
        //    else if (userAgent.Contains("WEB/MultipleCampaign"))
        //    {
        //        userAgent = "WEB/MultipleCampaign";
        //    }
        //    else if (userAgent.Contains("WEB/WhatsApp"))
        //    {
        //        userAgent = "WEB/WhatsApp";
        //    }
        //    else if (userAgent.Contains("WhatsApp"))
        //    {
        //        userAgent = "MOBILE/WhatsApp";
        //    }
        //    return userAgent ;
        //}

        public static string GetUserAgent(IHeaderDictionary headers)
        {
            var value = headers[HeaderConstants.UserAgent];
            return value.Count > 0 ? value[0]?.Split(',')[0].Trim() : null;
        }
    }
}