﻿using System;

namespace ApiCore.Auth
{
    public class UserRoles
    {
        public const string Distributor = "D";
        public const string MF_Investor = "MF";
        public const string PMS_Investor = "PMS";
        public const string Both = "B";
        public const string Guest = "G";

        public static string GetRole(string userType)
        {
            userType = userType.ToUpper();
            switch (userType)
            {
                case Distributor:
                    return Distributor;
                case MF_Investor:
                    return MF_Investor;
                case PMS_Investor:
                    return PMS_Investor;
                case Both:
                    return Both;
                case Guest:
                    return Guest;
                default:
                    throw new ArgumentException("invalid user type" + userType);
            }
        }
    }
}