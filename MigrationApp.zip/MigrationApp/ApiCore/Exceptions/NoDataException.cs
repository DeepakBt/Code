﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiCore.Exceptions
{
    public class NoDataException : Exception
    {
        public NoDataException(bool isList,string errorCode = "No Data Available.")
        {
            this.isList = isList;
            this.errorCode = errorCode;
        }

        public bool isList { get; }
        public string errorCode { get; }
    }
}
