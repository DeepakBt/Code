﻿using System.Collections.Generic;
using System.Linq;

namespace ApiCore.DTOs
{
    public class ResponseDataArrayModel<T>
    {
        public bool success { get; set; }
        public IEnumerable<T> data { get; set; }
        public string message { get; set; }


        /// <summary>
        /// Result details
        /// </summary>
        /// <param name="data">result data</param>
        /// <param name="errorCode">Respective error code to show message</param>
        public ResponseDataArrayModel(IEnumerable<T> data, string errorCode)
            : this(data, "Successful", errorCode)
        {
        }

        /// <summary>
        /// Result details
        /// </summary>
        /// <param name="data">result data</param>
        /// <param name="successCode"></param>
        /// <param name="errorCode">Respective error code to show message</param>
        public ResponseDataArrayModel(IEnumerable<T> data, string successCode = "Successful",
            string errorCode = "No Data Available.")
        {
            if (data != null && data.Any())
            {
                success = true;
                message = successCode;
            }
            else
            {
                success = false;
                message = errorCode;
            }
            this.data = data;
        }
    }
}