﻿namespace ApiCore.Model
{
    public class JwtSettings
    {
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string UseRsa { get; set; }
        public string AccessTokenPublicKey { get; set; }
        public string AccessTokenPrivateKey { get; set; }
        public int AccessTokenValidityMinutes { get; set; }
        public string RefreshTokenPublicKey { get; set; }
        public string RefreshTokenPrivateKey { get; set; }
        public int RefreshTokenValidityMinutes { get; set; }
        public int RefreshTokenRenewalMinutes { get; set; }
    }
}