﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiCore.Model
{
    public class Message
    {
        public string MsgCode { get; set; }
        public string MsgMessage { get; set; }
    }
}
