﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiCore.Model
{
    public class KYC_DETAILS
    {
        public string KYCId { get; set; } = "";
        public string LineIdentifier { get; set; } = "";
        public string UPDATE_FLAG { get; set; } = "";
        public string POS_CODE { get; set; } = "";
        public string ENTITY_TYPE { get; set; } = "";
        public string APPLICATION_NO { get; set; } = "";
        public string APPLICATION_DATE { get; set; } = "";
        public string PAN_GIR_NO { get; set; } = "";
        public string PAN_COPY_FLAG { get; set; } = "";
        public string EXEMPT { get; set; } = "";
        public string EXEMPTION_CATEGORY { get; set; } = "";
        public string PROOF_OF_ID { get; set; } = "";
        public string IN_PERSON_VERIFICATION { get; set; } = "";
        public string IN_PERSON_VERIFICATION_DATE { get; set; } = "";
        public string GENDER { get; set; } = "";
        public string APPLICANT_NAME { get; set; } = "";
        public string FATHERS_NAME { get; set; } = "";
        public string ENTITY_REGSITRATION_NUMBER { get; set; } = "";
        public string DATE_OF_BIRTH { get; set; } = "";
        public string COMMENCEMENT_DATE { get; set; } = "";
        public string NATIONALITY { get; set; } = "";
        public string NATIONALITY_OTHERS { get; set; } = "";
        public string COMPANY_STATUS { get; set; } = "";
        public string COMPANY_STATUS_OTHERS { get; set; } = "";
        public string RESIDENTIAL_STATUS_INDIVIDUALS { get; set; } = "";
        public string RESIDENTIAL_STATUS_NON_RESIDENT_INDIAN { get; set; } = "";
        public string AADHAR_NO { get; set; } = "";
        public string CORR_ADD_1 { get; set; } = "";
        public string CORR_ADD_2 { get; set; } = "";
        public string CORR_ADD_3 { get; set; } = "";
        public string CORR_CITY { get; set; } = "";
        public string CORR_PIN_CODE { get; set; } = "";
        public string CORR_STATE { get; set; } = "";
        public string CORR_COUNTRY { get; set; } = "";
        public string OFF_TEL_ISD { get; set; } = "";
        public string OFF_TEL_STD { get; set; } = "";
        public string OFF_TEL_NO { get; set; } = "";
        public string RES_TEL_ISD { get; set; } = "";
        public string RES_TEL_STD { get; set; } = "";
        public string RES_TEL_NO { get; set; } = "";
        public string MOBILE_TEL_ISD { get; set; } = "";
        public string MOBILE_TEL_NO { get; set; } = "";
        public string FAX_TEL_ISD { get; set; } = "";
        public string FAX_TEL_STD { get; set; } = "";
        public string FAX_TEL_NO { get; set; } = "";
        public string EMAIL_ID { get; set; } = "";
        public string COR_ADDRESS_PROOF { get; set; } = "";
        public string COR_ADDRESS_PROOF_REF_ID { get; set; } = "";
        public string COR_ADDRESS_PROOF_REF_DATE { get; set; } = "";
        public string PERMANENT_FOREIGN_REGISTERED_ADDRESS_FLAG { get; set; } = "";
        public string PERM_FOREIGN_REGD_ADD_1 { get; set; } = "";
        public string PERM_FOREIGN_REGD_ADD_2 { get; set; } = "";
        public string PERM_FOREIGN_REGD_ADD_3 { get; set; } = "";
        public string PERM_FOREIGN_REGD_CITY { get; set; } = "";
        public string PERM_FOREIGN_REGD_ZIP_CODE { get; set; } = "";
        public string PERM_FOREIGN_REGD_STATE { get; set; } = "";
        public string PERM_FOREIGN_REGD_COUNTRY { get; set; } = "";
        public string PERM_FOREIGN_REGD_ADD_PROOF { get; set; } = "";
        public string PERM_FOREIGN_REGD_ADD_PROOF_REF_ID { get; set; } = "";
        public string PERM_FOREIGN_ADD_PROOF_REF_DATE { get; set; } = "";
        public string GROSS_ANNUAL_INCOME { get; set; } = "";
        public string OCCUPATION_DETAILS { get; set; } = "";
        public string OCCUPATION_DETAILS_OTHERS { get; set; } = "";
        public string POLITICAL_CONNECTION { get; set; } = "";
        public string DOCUMENT_SUBMISSION_DETAILS { get; set; } = "";
        public string INTERMEDIARY_INTERNAL_REF_NO { get; set; } = "";
        public string BRANCH_CODE { get; set; } = "";
        public string MARITAL_STATUS { get; set; } = "";
        public string NETWORTH { get; set; } = "";
        public string NETWORTH_DATE { get; set; } = "";
        public string PLACE_OF_INCORPORATION { get; set; } = "";
        public string ANY_OTHER_INFORMATION { get; set; } = "";
        public string ACCOUNT_OPENING_DATE { get; set; } = "";
        public string ACCOUNT_ACTIVATION_DATE { get; set; } = "";
        public string ACCOUNT_LAST_UPDATE_DATE { get; set; } = "";
        public string PARENT_PAN { get; set; } = "";
        public string FILLER_1 { get; set; } = "";
        public string FILLER_2 { get; set; } = "";
        public string FILLER_3 { get; set; } = "";
        public string CVL_REFERENCE_NO { get; set; } = "";
        public string KYC_STATUS { get; set; } = "";
        public string KYC_STATUS_DATE { get; set; } = "";
        public string REJECTION_REASON { get; set; } = "";
        public string DUMP_TYPE { get; set; } = "";
        public string DOWNLOAD_DATE { get; set; } = "";
        public string Hold_REMARK { get; set; } = "";
        public string KYC_MODE { get; set; } = "";
        public string CVLKRA_Vault_Ref_Number { get; set; } = "";
        public string Aadhaar_Ref_Number { get; set; } = "";
        public string Version_Number { get; set; } = "";
        public string CreatedOn { get; set; } = "";
        public string ModifiedOn { get; set; } = "";
        public string KRA_Name { get; set; } = "";
    }

    public class RequestPANKYC
    {
        public string panNo { get; set; }
    }
}
