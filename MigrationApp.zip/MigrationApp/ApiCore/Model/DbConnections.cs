﻿namespace ApiCore.Model
{
    public class DbConnections
    {
        public string ConAMCMobileDB { get; set; }
        public string ConCMSDB { get; set; }
        public string CorporateDB { get; set; }
        public string ConAMCPORTAL { get; set; }
        public string ConAMCWhatsappDB { get; set; }
        public string ConMOSLGBIS { get; set; }
    }
}