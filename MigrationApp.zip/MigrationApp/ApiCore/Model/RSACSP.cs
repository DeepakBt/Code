﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System.IO;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Crypto.Encodings;
using Org.BouncyCastle.Crypto.Engines;

namespace ApiCore.Models
{
    public class RSACSP
    {

        public static string Decrypt(string encryptedData)
        {
            try
            {
                //lets take a new CSP with a new 2048 bit rsa key pair
                //var csp = new RSACryptoServiceProvider(2048);
                var csp = new RSACryptoServiceProvider(1024);

                AsymmetricCipherKeyPair keyPair;

                using (var reader = File.OpenText("myprivatekey.pem")) // file containing RSA PKCS1 private key
                    keyPair = (AsymmetricCipherKeyPair)new PemReader(reader).ReadObject();

                var bytesToDecrypt = Convert.FromBase64String(encryptedData); // string to decrypt, base64 encoded

                //using (var reader = File.OpenText(@"c:\myprivatekey.pem")) // file containing RSA PKCS1 private key
                //    keyPair = (AsymmetricCipherKeyPair)new PemReader(reader).ReadObject();

                var decryptEngine = new Pkcs1Encoding(new RsaEngine());
                decryptEngine.Init(false, keyPair.Private);

                var decrypted = Encoding.UTF8.GetString(decryptEngine.ProcessBlock(bytesToDecrypt, 0, bytesToDecrypt.Length));
                return decrypted;//plainTextData;
            }
            catch (Exception ex)
            {
                return "0";
            }
        }

        public static string RSAEncrypt(string plainText)
        {
            try
            {
                byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

                PemReader pr = new PemReader(
                    (StreamReader)File.OpenText("mypublickeyServer.pem")
                );
                RsaKeyParameters keys = (RsaKeyParameters)pr.ReadObject();

                // Pure mathematical RSA implementation
                // RsaEngine eng = new RsaEngine();

                // PKCS1 v1.5 paddings
                Pkcs1Encoding eng = new Pkcs1Encoding(new RsaEngine());

                // PKCS1 OAEP paddings
                //    OaepEncoding eng = new OaepEncoding(new RsaEngine());
                eng.Init(true, keys);

                int length = plainTextBytes.Length;
                int blockSize = eng.GetInputBlockSize();
                List<byte> cipherTextBytes = new List<byte>();
                for (int chunkPosition = 0;
                    chunkPosition < length;
                    chunkPosition += blockSize)
                {
                    int chunkSize = Math.Min(blockSize, length - chunkPosition);
                    cipherTextBytes.AddRange(eng.ProcessBlock(
                        plainTextBytes, chunkPosition, chunkSize
                    ));
                }
                return Convert.ToBase64String(cipherTextBytes.ToArray());
            }
            catch (Exception)
            {

                return "0";
            }
        }


        public static string AES_Encryption(string Plaintext)
        {
            string randomKey = RandomPassword();
            byte[] Key = Encoding.UTF8.GetBytes(randomKey);
            byte[] IV = Encoding.UTF8.GetBytes(randomKey);
            string Encryptedtext = EncryptStringToBytes_Aes(Plaintext, Key, IV);
            string PassRSAEncryKey = RSAEncrypt(randomKey);
            return PassRSAEncryKey + "|" + Encryptedtext;
        }

        public static string RandomPassword()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(RandomString(8, true));
            builder.Append(RandomNumber(1000, 10000));
            builder.Append(RandomString(4, false));
            return builder.ToString();
        }

        public static string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }

        public static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public static string EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV)
        {
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");
            string encrypted;

            // Create an Aes object
            // with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;
                // Create an encryptor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = Convert.ToBase64String(msEncrypt.ToArray());
                    }
                }
            }
            // Return the encrypted bytes from the memory stream.
            return encrypted;
        }
    }

}
