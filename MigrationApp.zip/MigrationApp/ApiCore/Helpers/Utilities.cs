﻿using ApiCore.Exceptions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace ApiCore.Helpers
{
    public static class Utilities
    {
        public static string ObjectToXMLString<T>(T objT)
        {
            string strXML = string.Empty;
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlSerializer xmlSerializer = new XmlSerializer(objT.GetType());
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, objT);
                    xmlStream.Position = 0;
                    xmlDoc.Load(xmlStream);
                    strXML = Convert.ToString(xmlDoc.InnerXml);
                }
            }
            catch (Exception ex)
            {
                throw new NoDataException(false);
            }
            return strXML;
        }
        public static string CreateHTTPPOSTRequest(string serviceUrl, string inputJson)
        {
            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(serviceUrl));
            httpRequest.Accept = "application/json";
            httpRequest.ContentType = "application/json";
            httpRequest.Method = "POST";

            byte[] bytes = Encoding.UTF8.GetBytes(inputJson);

            using (Stream stream = httpRequest.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Close();
            }
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string result = "";
            try
            {

                using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
                {
                    using (Stream stream = httpResponse.GetResponseStream())
                    {
                        string s = (new StreamReader(stream)).ReadToEnd();
                        result = JsonConvert.DeserializeObject(s).ToString();
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\UtilitiesCreateHTTPPOSTRequest.txt", "\r\n" + DateTime.Now.ToString() + " " + serviceUrl + " Error : " + ex.Message);
                return "";
            }
        }
        public static string CreateHTTPGETRequest(string serviceUrl)
        {
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(serviceUrl);
                request.Method = "GET";
                request.Accept = "application/json";
                request.ContentType = "application/json";

                var content = string.Empty;

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    using (var stream = response.GetResponseStream())
                    {
                        using (var sr = new StreamReader(stream))
                        {
                            content = sr.ReadToEnd();
                        }
                    }
                }
                return content;
            }
            catch (Exception ex)
            {
                File.AppendAllText("D:\\UtilitiesCreateHTTPGETRequest.txt", "\r\n" + DateTime.Now.ToString() + " " + serviceUrl + " Error : " + ex.Message);
                return "";
            }
        }
    }
}
