﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ApiCore.Auth;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using Serilog.Events;

namespace APICore.Helpers
{
    public class ApiLoggingMiddleware
    {
        private const string MessageTemplate =
                "{Scheme} {RequestMethod} {RequestPath} {RequestQuery} {AppId} {UserId} {StatusCode} {Elapsed} [{UserAgent}]"
            ;

        private static readonly ILogger Log = Serilog.Log.ForContext<ApiLoggingMiddleware>();

        private readonly RequestDelegate _next;

        public ApiLoggingMiddleware(RequestDelegate next)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
        }

        public async Task Invoke(HttpContext httpContext)
        {
            if (httpContext == null) throw new ArgumentNullException(nameof(httpContext));
            var sw = Stopwatch.StartNew();
            await _next(httpContext);
            sw.Stop();

            var request = httpContext.Request;
            var appId = HeaderAccessors.GetAppId(httpContext, request.Headers);
            var userId = HeaderAccessors.GetLoginId(httpContext, request.Headers);
            var userAgent = string.Empty;
            if (request.Headers.ContainsKey("User-Agent"))
            {
                 userAgent = request.Headers["User-Agent"][0];
            }
            else
            {
                userAgent = request.Headers["UserAgent"].ToString();
            }
            var statusCode = httpContext.Response?.StatusCode;
            var level = statusCode > 499 ? LogEventLevel.Error : LogEventLevel.Information;

            Log.Write(level, MessageTemplate, request.Scheme, request.Method, request.Path,
                request.QueryString, appId, userId, statusCode,
                sw.ElapsedMilliseconds, userAgent);
        }
    }
}