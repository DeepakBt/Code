﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Data;
using System.Configuration;

namespace ApiCore.Helpers
{
    public class ErrorHandlingDB
    {
        public static SqlConnection Conn;
        public static void Data_SQL()
        {
            Conn = new SqlConnection(Convert.ToString(ConfigurationManager.ConnectionStrings["APIDBConnection"]));
        }
        public static string ExMessage = "";

        public static async void LogExceptionDB(string ErrorMessage, string StackTrace, string ExceptionType, string ExceptionURL, string IPaddress)
        {
            Data_SQL();
            string ProjectTracker_AppID = ConfigurationManager.AppSettings["ProjectTracker_AppID"];
            ExMessage = ErrorMessage;
            Conn.Open();
            SqlCommand cmd = new SqlCommand("ExceptionLoggingToDataBase", Conn);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@ExceptionMsg", SqlDbType.VarChar, -1).Value = ExMessage;
            cmd.Parameters.Add("@ExceptionType", SqlDbType.VarChar, -1).Value = ExceptionType;
            cmd.Parameters.Add("@ExceptionSource", SqlDbType.VarChar, -1).Value = StackTrace;
            cmd.Parameters.Add("@ExceptionURL", SqlDbType.VarChar, -1).Value = ExceptionURL;
            cmd.Parameters.Add("@Userid", SqlDbType.VarChar, 1000).Value = IPaddress;
            cmd.Parameters.Add("@ProjectTracker_AppID", SqlDbType.VarChar, 10).Value = ProjectTracker_AppID;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar, 1000).Value = "";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 0;
            cmd.ExecuteNonQuery();
            Conn.Close();
        }
    }
}
