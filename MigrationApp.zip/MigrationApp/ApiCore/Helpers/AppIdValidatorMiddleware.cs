﻿using ApiCore.Auth;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ApiCore.Helpers
{
    public class AppIdValidatorMiddleware
    {
        const string _init = "/api/Init";
        const string _initWeb = "/api/Init/WebInit";
        const string _master = "/api/MFMaster";
        const string _MFNewInvestor = "/api/MFNewInvestor";
        const string _DigitalClientInfo = "/api/Init/DigitalClientInfo";
        const string _SaveApplicationForm = "/api/Init/SaveApplicationForm";
        const string _SaveData = "/api/Init/saveData";
        //public static string UserAgent = string.Empty; Suryakant
        private readonly RequestDelegate _next;
        public AppIdValidatorMiddleware(RequestDelegate next)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
        }

        public async Task Invoke(HttpContext httpContext)
        {
            if (httpContext == null) throw new ArgumentNullException(nameof(httpContext));
            var request = httpContext.Request;
            bool isValid = true;
            //UserAgent = HeaderAccessors.GetUserAgent(httpContext, request.Headers); Suryakant
            var appId = HeaderAccessors.GetAppId(request.Headers);
           
             if (request.Path.StartsWithSegments("/api") )
            {
                if (request.Path.Equals(_init))
                {
                    isValid = true;
                }
                else if (request.Path.Equals(_initWeb))
                {
                    isValid = true;
                }
                else if (request.Path.StartsWithSegments(_master))
                {
                    isValid = true;
                }
                else if (request.Path.StartsWithSegments(_DigitalClientInfo))
                {
                    isValid = true;
                }
                else if (request.Path.StartsWithSegments(_SaveApplicationForm))
                {
                    isValid = true;
                }
                else if (request.Path.StartsWithSegments(_SaveData))
                {
                    isValid = true;
                }
                else if (isAppIdValid(appId))
                {
                    isValid = true;
                }
                else if(request.Path.ToString().Substring(0,19)== "/api/SchemeDetails/")
                {
                    isValid = true;
                }
                else if(Convert.ToString(request.Path) == "/api/Init/CVLKYCCheck")
                {
                    isValid = true;
                }
                else if (Convert.ToString(request.Path) == "/api/PGRazorPay/SaveOrderResponse")
                {
                    isValid = true;
                }
                else
                {
                    isValid = false;
                }
            }

            if (isValid)
            {
                await _next(httpContext);
            }
            else
            {
                await HandleAppIdNotFoundAsync(httpContext);
            }
        }

        private static Task HandleAppIdNotFoundAsync(HttpContext context)
        {
            var code = HttpStatusCode.NotFound; // 404
            context.Response.StatusCode = (int)code;
            return context.Response.WriteAsync(code.ToString());
        }

        //public static string getUserAgent() Suryakant
        //{
        //    return UserAgent;
        //}
        private static bool isAppIdValid(string appId)
        {
            //TODO write code to valdate AppId.
            if (appId == null || appId.Length < 24)
            {
                return false;
            }
            else if (appId[8].Equals('M') && appId[13].Equals('A') && appId[18].Equals('M') && appId[23].Equals('C'))
            {
                return true;
            }
            else return false;
        }
    }
}
