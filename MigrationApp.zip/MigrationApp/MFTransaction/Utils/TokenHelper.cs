﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using ApiCore.Auth;
using ApiCore.Model;
using APICore.Auth;
using APICore.Constants;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
namespace MFTransaction.Utils
{

    public class TokenHelper
    {
        private readonly JwtSettings _jwtOptions;
        private readonly JwtSecurityTokenHandler _tokenHandler;
        public TokenHelper(IOptionsSnapshot<JwtSettings> jwtOptions)
        {
            _jwtOptions = jwtOptions.Value;
            _tokenHandler = new JwtSecurityTokenHandler();
        }

        public int GetAccessTokenValiditySeconds()
        {
            return _jwtOptions.AccessTokenValidityMinutes * 60;
        }

        public string CreateAccessToken(string panNumber, string role, string appId, string userId = "")
        {
            if (userId.Trim() != "")
            {
                var claimsIdentity = new ClaimsIdentity(new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, panNumber.ToUpper()),
                    new Claim(ClaimTypes.Role, UserRoles.GetRole(role)),
                    new Claim(TokenConstants.ClaimAppId, appId),
                    new Claim(TokenConstants.ClaimUserId,userId)
                });
                return CreateAccessToken(claimsIdentity);
            }
            else
            {
                var claimsIdentity = new ClaimsIdentity(new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, panNumber.ToUpper()),
                    new Claim(ClaimTypes.Role, UserRoles.GetRole(role)),
                    new Claim(TokenConstants.ClaimAppId, appId),
                });
                return CreateAccessToken(claimsIdentity);
            }
        }

        public string CreateAccessToken(ClaimsPrincipal principal)
        {
            List<Claim> filtered = principal.Claims.ToList();
            filtered.RemoveAll(c =>
                c.Type.Equals(TokenConstants.ClaimTokenType) || c.Type.Equals(TokenConstants.ClaimUserSecret) ||
                c.Type.Equals("aud") ||
                c.Type.Equals("iss"));
            return CreateAccessToken(new ClaimsIdentity(filtered));
        }

        public string CreateAccessToken(ClaimsIdentity claimsIdentity)
        {
            var securityTokenDescriptor = new SecurityTokenDescriptor()
            {
                Audience = _jwtOptions.Audience,
                Issuer = _jwtOptions.Issuer,
                Subject = claimsIdentity,
                SigningCredentials = RSAProvider.AccessTokenSigningCredentials,
                NotBefore = DateTime.Now.AddMinutes(-15),
                IssuedAt = DateTime.Now,
                Expires = DateTime.Now.AddSeconds(GetAccessTokenValiditySeconds())
            };

            return CreateToken(securityTokenDescriptor);
        }

        public string CreateRefreshToken(string clientCode, string role, string appId)
        {

            var claimsIdentity = new ClaimsIdentity(new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, clientCode.ToUpper()),
                    new Claim(ClaimTypes.Role, UserRoles.GetRole(role)),
                    new Claim(RefreshTokenConstants.ClaimAppId, appId),
                    new Claim(RefreshTokenConstants.ClaimTokenType, RefreshTokenConstants.TokenTypeRefresh)
                });
            var securityTokenDescriptor = new SecurityTokenDescriptor()
            {
                Audience = _jwtOptions.Audience,
                Issuer = _jwtOptions.Issuer,
                Subject = claimsIdentity,
                SigningCredentials = RSAProvider.RefreshTokenSigningCredentials,
                NotBefore = DateTime.Now.AddMinutes(-15),
                IssuedAt = DateTime.Now,
                Expires = DateTime.Now.AddHours(_jwtOptions.RefreshTokenValidityMinutes)
            };

            return CreateToken(securityTokenDescriptor);
        }


        public string CreateToken(SecurityTokenDescriptor tokenDescriptor)
        {
            var plainToken = _tokenHandler.CreateToken(tokenDescriptor);
            var signedAndEncodedToken = _tokenHandler.WriteToken(plainToken);

            return signedAndEncodedToken;
        }

        public JwtSecurityToken ReadToken(string token)
        {
            try
            {
                return _tokenHandler.ReadJwtToken(token);
            }
            catch
            {
                return null;
            }
        }


        public bool IsValidButMaybeExpired(string token, string tokenType, IHeaderDictionary headers)
        {
            var tokenData = ReadToken(token);

            if (tokenData == null) return false;
            //tokenData not null, means token is in valid format
            var tokenValidationParameters = RSAProvider.RefreshTokenValidationParameters;

            try
            {
                _tokenHandler.ValidateToken(token, tokenValidationParameters, out _);

                return true;
            }
            catch (Exception e)
            {
                return e.Message.Contains("Lifetime validation failed") && IsValidRequestor(tokenData, headers);
            }
        }

        public ClaimsPrincipal ValidateAccessToken(string token)
        {
            try
            {
                var claims = _tokenHandler.ValidateToken(token, RSAProvider.AccessTokenValidationParameters, out _);

                return claims;
            }
            catch
            {
                return null;
            }
        }

        public ClaimsPrincipal ValidateRefreshToken(string token)
        {
            try
            {
                var claims = _tokenHandler.ValidateToken(token,
                    RSAProvider.RefreshTokenValidationParameters, out _);

                return claims;
            }
            catch
            {
                return null;
            }
        }

        public static bool IsValidRequestor(JwtSecurityToken tokenData, IHeaderDictionary headers)
        {
            var claims = tokenData.Payload.Claims;
            var appId = HeaderAccessors.GetAppId(headers);


            return appId.Equals(IdentityHelper.GetAppId(claims));
        }
    }
}
