﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ApiCore.Model;

namespace MFTransaction.Models
{
    public class OrderRequest
    {
        //public string Records { get; set; }
        [Required]
        public string MainOrderId { get; set; }
        [Required]
        public string Amount { get; set; }
        [Required]
        public string TimeStamp { get; set; }
        public List<OrderRecord> itemDetails { get; set; }

        //Billdesk Fields
        public string PG_REQID { get; set; }
        public string PG_PGMERCID { get; set; }
        public string PG_MERCHANTID { get; set; }
        public string PG_CHECKSUMKEY { get; set; }
        public string PG_ADDITIONALINFO1 { get; set; }
        public string PG_ADDITIONALINFO2 { get; set; }
        public string PG_ADDITIONALINFO3 { get; set; }
        public string PG_ADDITIONALINFO4 { get; set; }
        public string PG_ADDITIONALINFO5 { get; set; }
        public string PG_ADDITIONALINFO6 { get; set; }
        public string PG_ADDITIONALINFO7 { get; set; }
        public string PG_FILLER1 { get; set; }
        public string PG_FILLER2 { get; set; }
        public string PG_FILLER3 { get; set; }
    }

    public class OrderRecord
    {
        //public string ID { get; set; }
        [Required]
        public string ChildOrderId { get; set; }
        //public string BankCode { get; set; }
        //public string BankAccNo { get; set; }
        [Required]
        public string Amount { get; set; }
    }

    #region Request XML classes
    public class REQUEST
    {
        private REQUESTTXNDATA tXNDATAField;
        private string cHECKSUMField;
        public REQUESTTXNDATA TXNDATA
        {
            get
            {
                return this.tXNDATAField;
            }
            set
            {
                this.tXNDATAField = value;
            }
        }
        public string CHECKSUM
        {
            get
            {
                return this.cHECKSUMField;
            }
            set
            {
                this.cHECKSUMField = value;
            }
        }
    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public class REQUESTTXNDATA
    {
        private REQUESTTXNDATATXNSUMMARY tXNSUMMARYField;
        private REQUESTTXNDATARECORD[] rECORDField;
        public REQUESTTXNDATATXNSUMMARY TXNSUMMARY
        {
            get
            {
                return this.tXNSUMMARYField;
            }
            set
            {
                this.tXNSUMMARYField = value;
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("RECORD")]
        public REQUESTTXNDATARECORD[] RECORD
        {
            get
            {
                return this.rECORDField;
            }
            set
            {
                this.rECORDField = value;
            }
        }
    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class REQUESTTXNDATATXNSUMMARY
    {
        private string rEQIDField;
        private string pGMERCIDField;
        private int rECORDSField;
        private string pGCUSTOMERIDField;
        private decimal aMOUNTField;
        private ulong tXNDATEField;

        /// <remarks/>
        public string REQID
        {
            get
            {
                return this.rEQIDField;
            }
            set
            {
                this.rEQIDField = value;
            }
        }
        /// <remarks/>
        public string PGMERCID
        {
            get
            {
                return this.pGMERCIDField;
            }
            set
            {
                this.pGMERCIDField = value;
            }
        }
        /// <remarks/>
        public int RECORDS
        {
            get
            {
                return this.rECORDSField;
            }
            set
            {
                this.rECORDSField = value;
            }
        }
        /// <remarks/>
        public string PGCUSTOMERID
        {
            get
            {
                return this.pGCUSTOMERIDField;
            }
            set
            {
                this.pGCUSTOMERIDField = value;
            }
        }
        /// <remarks/>
        public decimal AMOUNT
        {
            get
            {
                return this.aMOUNTField;
            }
            set
            {
                this.aMOUNTField = value;
            }
        }
        /// <remarks/>
        public ulong TXNDATE
        {
            get
            {
                return this.tXNDATEField;
            }
            set
            {
                this.tXNDATEField = value;
            }
        }
    }

    public partial class REQUESTTXNDATARECORD
    {
        private string mERCIDField;
        private decimal aMOUNTField;
        private string cUSTOMERIDField;
        private string aDDITIONALINFO1Field;
        private string aDDITIONALINFO2Field;
        private string aDDITIONALINFO3Field;
        private string aDDITIONALINFO4Field;
        private string aDDITIONALINFO5Field;
        private string aDDITIONALINFO6Field;
        private string aDDITIONALINFO7Field;
        private string fILLER1Field;
        private string fILLER2Field;
        private string fILLER3Field;
        private string idField;

        /// <remarks/>
        public string MERCID
        {
            get
            {
                return this.mERCIDField;
            }
            set
            {
                this.mERCIDField = value;
            }
        }
        /// <remarks/>
        public decimal AMOUNT
        {
            get
            {
                return this.aMOUNTField;
            }
            set
            {
                this.aMOUNTField = value;
            }
        }
        /// <remarks/>
        public string CUSTOMERID
        {
            get
            {
                return this.cUSTOMERIDField;
            }
            set
            {
                this.cUSTOMERIDField = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO1
        {
            get
            {
                return this.aDDITIONALINFO1Field;
            }
            set
            {
                this.aDDITIONALINFO1Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO2
        {
            get
            {
                return this.aDDITIONALINFO2Field;
            }
            set
            {
                this.aDDITIONALINFO2Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO3
        {
            get
            {
                return this.aDDITIONALINFO3Field;
            }
            set
            {
                this.aDDITIONALINFO3Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO4
        {
            get
            {
                return this.aDDITIONALINFO4Field;
            }
            set
            {
                this.aDDITIONALINFO4Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO5
        {
            get
            {
                return this.aDDITIONALINFO5Field;
            }
            set
            {
                this.aDDITIONALINFO5Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO6
        {
            get
            {
                return this.aDDITIONALINFO6Field;
            }
            set
            {
                this.aDDITIONALINFO6Field = value;
            }
        }
        /// <remarks/>
        public string ADDITIONALINFO7
        {
            get
            {
                return this.aDDITIONALINFO7Field;
            }
            set
            {
                this.aDDITIONALINFO7Field = value;
            }
        }
        /// <remarks/>
        public string FILLER1
        {
            get
            {
                return this.fILLER1Field;
            }
            set
            {
                this.fILLER1Field = value;
            }
        }
        /// <remarks/>
        public string FILLER2
        {
            get
            {
                return this.fILLER2Field;
            }
            set
            {
                this.fILLER2Field = value;
            }
        }
        /// <remarks/>
        public string FILLER3
        {
            get
            {
                return this.fILLER3Field;
            }
            set
            {
                this.fILLER3Field = value;
            }
        }

        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }
    #endregion

    public class OrderResponse
    {
        public string PGMercID { get; set; }
        public string PGCustomerID { get; set; }
        public string Records { get; set; }
        public string Amount { get; set; }
        public string StatusCode { get; set; }
        public string StatusDesc { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public List<OrderRecordRes> resItemDetails { get; set; }
        public string Checksum { get; set; }
        public string ExceptionMsg { get; set; }
        public string ExceptionLineNo { get; set; }
    }

    public class OrderRecordRes
    {
        //public string ID { get; set; }
        public string CustomerID { get; set; }
        public string EComTxnID { get; set; }
    }

    #region Response XML classes
    public class RESPONSE
    {
        private RESPONSETXNDATA tXNDATAField;
        private string cHECKSUMField;
        public RESPONSETXNDATA TXNDATA
        {
            get
            {
                return this.tXNDATAField;
            }
            set
            {
                this.tXNDATAField = value;
            }
        }
        public string CHECKSUM
        {
            get
            {
                return this.cHECKSUMField;
            }
            set
            {
                this.cHECKSUMField = value;
            }
        }
    }

    public class RESPONSETXNDATA
    {
        private RESPONSETXNDATATXNSUMMARY tXNSUMMARYField;
        private RESPONSETXNDATARECORD[] rECORDField;
        public RESPONSETXNDATATXNSUMMARY TXNSUMMARY
        {
            get
            {
                return this.tXNSUMMARYField;
            }
            set
            {
                this.tXNSUMMARYField = value;
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("RECORD")]
        public RESPONSETXNDATARECORD[] RECORD
        {
            get
            {
                return this.rECORDField;
            }
            set
            {
                this.rECORDField = value;
            }
        }
    }

    public class RESPONSETXNDATATXNSUMMARY
    {

        private string pGMERCIDField;

        private string pGCUSTOMERIDField;

        private int rECORDSField;

        private decimal aMOUNTField;

        private byte sTATUSCODEField;

        private string sTATUSDESCField;

        private string fILLER1Field;

        private string fILLER2Field;

        private string fILLER3Field;

        /// <remarks/>
        public string PGMERCID
        {
            get
            {
                return this.pGMERCIDField;
            }
            set
            {
                this.pGMERCIDField = value;
            }
        }

        /// <remarks/>
        public string PGCUSTOMERID
        {
            get
            {
                return this.pGCUSTOMERIDField;
            }
            set
            {
                this.pGCUSTOMERIDField = value;
            }
        }

        /// <remarks/>
        public int RECORDS
        {
            get
            {
                return this.rECORDSField;
            }
            set
            {
                this.rECORDSField = value;
            }
        }

        /// <remarks/>
        public decimal AMOUNT
        {
            get
            {
                return this.aMOUNTField;
            }
            set
            {
                this.aMOUNTField = value;
            }
        }

        /// <remarks/>
        public byte STATUSCODE
        {
            get
            {
                return this.sTATUSCODEField;
            }
            set
            {
                this.sTATUSCODEField = value;
            }
        }

        /// <remarks/>
        public string STATUSDESC
        {
            get
            {
                return this.sTATUSDESCField;
            }
            set
            {
                this.sTATUSDESCField = value;
            }
        }

        /// <remarks/>
        public string FILLER1
        {
            get
            {
                return this.fILLER1Field;
            }
            set
            {
                this.fILLER1Field = value;
            }
        }

        /// <remarks/>
        public string FILLER2
        {
            get
            {
                return this.fILLER2Field;
            }
            set
            {
                this.fILLER2Field = value;
            }
        }

        /// <remarks/>
        public string FILLER3
        {
            get
            {
                return this.fILLER3Field;
            }
            set
            {
                this.fILLER3Field = value;
            }
        }
    }

    public class RESPONSETXNDATARECORD
    {
        private string cUSTOMERIDField;
        private string eCOMTXNIDField;
        private byte idField;
        public string CUSTOMERID
        {
            get
            {
                return this.cUSTOMERIDField;
            }
            set
            {
                this.cUSTOMERIDField = value;
            }
        }
        public string ECOMTXNID
        {
            get
            {
                return this.eCOMTXNIDField;
            }
            set
            {
                this.eCOMTXNIDField = value;
            }
        }
        public byte ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }
    #endregion

    public class PaymentRequest
    {
        /// <summary>This is CustomerID for Billdesk</summary>
        [Required]
        public string MainOrderId { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed in bankAccNo field.")]
        public string BankAccNo { get; set; }
        [Required]
        public string TxnAmount { get; set; }
        [Required]
        public string BankID { get; set; }
        [Required]
        public string PG_ReturnURL { get; set; }
        public string PG_AdditionalInfo1 { get; set; }
        public string PG_AdditionalInfo2 { get; set; }
        public string PG_AdditionalInfo3 { get; set; }
        public string PG_AdditionalInfo4 { get; set; }
        public string PG_AdditionalInfo5 { get; set; }
        public string PG_AdditionalInfo6 { get; set; }
        public string PG_AdditionalInfo7 { get; set; }

        public string PG_MerchantID { get; set; }
        public string PG_CurrencyType { get; set; }
        public string PG_ProductID { get; set; }
        public string PG_TypeField1 { get; set; }
        public string PG_TypeField2 { get; set; }
        public string PG_SecurityID { get; set; }
        public string PG_ChecksumKey { get; set; }
        public string Mode { get; set; }

        //public string Checksum { get; set; }
    }

    public class PaymentResponse
    {
        public string PaymentURL { get; set; }
        public string ExceptionMsg { get; set; }
        public string ExceptionLineNo { get; set; }

    }

    #region Related to Serialization
    public class Utf8StringWriter : StringWriter
    {
        public override Encoding Encoding => Encoding.UTF8;
    }

    public static class XmlExtension
    {
        public static string Serialize<T>(this T value)
        {
            if (value == null) return string.Empty;
            try
            {
                var xmlSerializer = new XmlSerializer(typeof(T));
                using (var stringWriter = new Utf8StringWriter())
                {
                    //using (var xmlWriter = XmlWriter.Create(stringWriter, new XmlWriterSettings { Indent = true }))
                    using (var xmlWriter = XmlWriter.Create(stringWriter))
                    {
                        var ns = new XmlSerializerNamespaces();  //add empty namespace
                        ns.Add("", "");
                        xmlSerializer.Serialize(xmlWriter, value, ns);
                        return stringWriter.ToString().Replace("utf-8", "UTF-8");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred", ex);
            }
        }
    }
    #endregion

    public class PaymentConfirmationRes
    {
        public string pmsCode { get; set; }
        public string strategyName { get; set; }
        public string transactionRefrenceNumber { get; set; }
        public double transactionAmount { get; set; }
    }

    public class PaymentConfirm
    {
        [Required]
        /// <summary> "transactionRefrenceNumber" </summary>
        public Int64 transactionNo { get; set; }
        /// <summary> "MOTILALOAM" </summary>
        [Required]
        [DefaultValue("")]
        public string merchantId { get; set; }
        /// <summary> "GHDF4558070213" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionReferenceNo { get; set; }
        [Required]
        [DefaultValue("")]
        public string bankRef { get; set; }
        /// <summary> "Minimum Amount 1 lakh" </summary>
        [Required]
        [DefaultValue(0)]
        public double transactionAmount { get; set; }
        /// <summary> "Bank Short name" </summary>
        [Required]
        [DefaultValue("")]
        public string bankId { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string bankMerchantId { get; set; }
        /// <summary> "01" </summary>
        [Required]
        [DefaultValue("")]
        public string transactionType { get; set; }
        /// <summary> "INR" </summary>
        [Required]
        [DefaultValue("")]
        public string currency { get; set; }
        [Required]
        [DefaultValue("")]
        public string itemCode { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityType { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string securityPassword { get; set; }
        [Required]
        [DefaultValue("")]
        public string transactionDate { get; set; }
        /// <summary> "0300: success" </summary>
        [DefaultValue("")]
        public string authStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string settlementType { get; set; }
        /// <summary> "PMSCODE" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info1 { get; set; }
        [Required]
        /// <summary> "Order no" </summary>
        [DefaultValue("")]
        public string additional_Info2 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info3 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info4 { get; set; }
        /// <summary> "NONLIQUID" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info5 { get; set; }
        /// <summary> "logic for generating Code-(RESIDENT-VAL-NA-L-NA-NA)" </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info6 { get; set; }
        /// <summary> "Date Time in String " </summary>
        [Required]
        [DefaultValue("")]
        public string additional_Info7 { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string erroStatus { get; set; }
        /// <summary> "NA" </summary>
        [Required]
        [DefaultValue("")]
        public string errorDescription { get; set; }
        [Required]
        [DefaultValue("")]
        public string checkSum { get; set; }
    }

    public class PaymentStatusResponse
    {
        public string _PaymentStatus { get; set; }
    }
    public class PaymentStatusRequest
    {
        public string CustomerID { get; set; }
        public string Checksum { get; set; }
    }
    public class ReqSIPPending
    {
        public OrderRequest _OrderRequest { get; set; }
        public string BankAccNo { get; set; }
        public string BankId { get; set; }
        public string FolioNo { get; set; }
    }

    public class RazorOrderRequest
    {
        [Required]
        public string amount { get; set; }
        [Required]
        public string method { get; set; }
        public string currency { get; set; }
        public string receipt { get; set; }
        public string payment_capture { get; set; }
        public List<OrderRecord> notes { get; set; }
        public string account_number { get; set; }
        public string name { get; set; }
        public string ifsc { get; set; }
    }

    public class RazorOrderResponse
    {
        public string orderid { get; set; }
    }

    public class ResponseOrderReq
    {
        public string razorpay_order_id { get; set; }
        public string razorpay_payment_id { get; set; }
        public string razorpay_signature { get; set; }
    }
    public class ResponseOrderRes
    {
        public string payment_status { get; set; }
    }
    }
