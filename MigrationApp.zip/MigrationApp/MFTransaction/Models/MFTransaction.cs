﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Model;
namespace MFTransaction.Models
{
    public class LumpsumInvestmentDetail
    {
        public string FolioNo { get; set; }
        public string Scheme { get; set; }
        public string Plan { get; set; }
        public string Option { get; set; }
        public string TrType { get; set; }
        public string Amount { get; set; }
        public string TransRefNo { get; set; }
        public string MandateLimit { get; set; }
        public string MandateStatus { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
        public string UMRNexpirydate { get; set; }
        public string BrokerCode { get; set; }
        public string SubBrokerCode { get; set; }
        public string EUINFlag { get; set; }
        public string EUINOpt { get; set; }
        public string EUINNo { get; set; }
        public string EUINSubARNCode { get; set; }
        public string BankName { get; set; }
        public string BankAccountNo { get; set; }
        public string IFSCCode { get; set; }
        public string MICRCode { get; set; }
        public string GoalId { get; set; }
        public string MOGPID { get; set; }
        public string MOGPFREEZE { get; set; }
        public string CompanyCode { get; set; }
        public string EmployeeCode { get; set; }
        public string accOpeningMode { get; set; }
        public string HoldingDematMode { get; set; }
        public string NSDLCDSL { get; set; }
        public string DPIdClientId { get; set; }
        public string Paymode { get; set; }
        public string PG { get; set; }
        public string OrderId { get; set; }
        public string ChequeType { get; set; }
    }

    public class SIPInvestmentDetail
    {
        public string FolioNo { get; set; }
        public string InvName { get; set; }
        public string Scheme { get; set; }
        public string Plan { get; set; }
        public string Option { get; set; }
        public string TrType { get; set; }
        public string Amount { get; set; }
        public string Frequency { get; set; }
        public string SIPStartDate { get; set; }
        public string SIPEndDate { get; set; }
        public string NoOfInstallment { get; set; }
        public string SIPmonth { get; set; }
        public string TransRefNo { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
        public string UMRNNo { get; set; }
        public string UMRNexpirydate { get; set; }
        public string Siptype { get; set; }
        public string GoalId { get; set; }
        public string SIPRefno { get; set; }
        public string BrokerCode { get; set; }
        public string SubBrokerCode { get; set; }
        public string EUINFlag { get; set; }
        public string EUINOpt { get; set; }
        public string EUINNo { get; set; }
        public string EUINSubARNCode { get; set; }
        public string BankName { get; set; }
        public string BankAccountNo { get; set; }
        public string IFSCCode { get; set; }
        public string MICRCode { get; set; }
        public string MOGPID { get; set; }
        public string MOGPFREEZE { get; set; }
        public string CompanyCode { get; set; }
        public string EmployeeCode { get; set; }
        public string accOpeningMode { get; set; }
        public string HoldingDematMode { get; set; }
        public string NSDLCDSL { get; set; }
        public string DPIdClientId { get; set; }
        public string OrderId { get; set; }
        public string ChequeType { get; set; }
    }
    public class TransactionRequest
    {
        public string PurchaseDate { get; set; }
        public string PaymentMode { get; set; }
        public string TotalInvestAMount { get; set; }
        public string Branch { get; set; }
        public string PG { get; set; }
        public string Campaign { get; set; }
        public string MORefNo { get; set; }
        public List<LumpsumInvestmentDetail> LumpsumInvestmentDetails { get; set; }
        public List<SIPInvestmentDetail> SIPInvestmentDetails { get; set; }
    }

    public class LumpsumInvResponseDtl
    {
        public string Amount { get; set; }
        public string FolioNo { get; set; }
        public string GoalId { get; set; }
        public string MOGPFREEZE { get; set; }
        public string MOGPID { get; set; }
        public string Message { get; set; }
        public string Option { get; set; }
        public string Plan { get; set; }
        public string Scheme { get; set; }
        public string Status_Code { get; set; }
        public string TIME_STAMP { get; set; }
        public string TrType { get; set; }
        public string TransRefNo { get; set; }
        public object UMRNNo { get; set; }
        public string UMRNexpirydate { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
        public string OrderId { get; set; }
    }

    public class SipInvResponseDtl
    {
        public string Amount { get; set; }
        public string FolioNo { get; set; }
        public string Frequency { get; set; }
        public string GoalId { get; set; }
        public string MOGPFREEZE { get; set; }
        public string MOGPID { get; set; }
        public string Message { get; set; }
        public string NoOfInstallment { get; set; }
        public string Option { get; set; }
        public string Plan { get; set; }
        public string SIPEndDate { get; set; }
        public string SIPStartDate { get; set; }
        public string Scheme { get; set; }
        public string Status_Code { get; set; }
        public string TIME_STAMP { get; set; }
        public string TrType { get; set; }
        public string TransRefNo { get; set; }
        public string UMRNNo { get; set; }
        public string UMRNexpirydate { get; set; }
        public string URNNO { get; set; }
        public string URNexpirydate { get; set; }
        public string OrderId { get; set; }
    }

    public class TransactionResponse
    {
        public long PurRefNo { get; set; }
        public string BucketId { get; set; }
        public string Campaign { get; set; }
        public List<LumpsumInvResponseDtl> LumpsumInvResponseDtls { get; set; }
        public string MORefNo { get; set; }
        public List<SipInvResponseDtl> SipInvResponseDtls { get; set; }
        public string TotalInvestAMount { get; set; }
        public string TimeStamp { get; set; }
        public string Status_Code { get; set; }
        public string Message { get; set; }
        public string BankId { get; set; }

    }
    public class TransactionReqResponse
    {
        public TransactionRequest _TransactionRequest { get; set; }
        public TransactionResponse _TransactionResponse { get; set; }
    }

    public class TransactionConfirmationReq
    {
        public string BucketId { get; set; }
        public string Acno { get; set; }
        public string Appno { get; set; }
        public string MerchantID { get; set; }
        public string CustomerId { get; set; }
        public string BankRefno { get; set; }
        public string BankRemarks { get; set; }
        public string TxnAmount { get; set; }
        public string TxnId { get; set; }
        public string BankID { get; set; }
        public string BankMerchantID { get; set; }
        public string CurrencyName { get; set; }
        public string ItemCode { get; set; }
        public string SecurityType { get; set; }
        public string SecurityID { get; set; }
        public string SecurityPassword { get; set; }
        public string SettlementType { get; set; }
        public string PaymentStatus { get; set; }
        public string ErrorDescription { get; set; }
    }
    public class TransactionConfirmationRes
    {
        public string Acno { get; set; }
        public string Appno { get; set; }
        public string Message { get; set; }
        public string Status_Code { get; set; }
        public string TxnAmount { get; set; }
    }

    public class EMandateRegReq : IValidatableObject
    {
        public string UMRN { get; set; }
        [Required]
        public string OTMDate { get; set; }
        [Required]
        public string SponsorBank { get; set; }
        [Required]
        public string Authorize { get; set; }
        [Required]
        public string Utilitycode { get; set; }
        [Required]
        public string Mode { get; set; }
        [Required]
        public string ToDebit { get; set; }
        [Required]
        public string BankName { get; set; }
        [Required]
        public string BankHolderName { get; set; }
        public string MICRCode { get; set; }
        [Required]
        public string IFSCCode { get; set; }
        [Required]
        public string BankAcno { get; set; }
        [Required]
        public string BranchCode { get; set; }
        [Required]
        public string Frequency { get; set; }
        [Required]
        public string Debittype { get; set; }
        [Required]
        public string ClientId { get; set; }
        public string AccountType { get; set; }
        public string ReferenceID { get; set; }
        public string EmailId { get; set; }
        [Required]
        public string FromDate { get; set; }
        [Required]
        public string Todate { get; set; }
        public string RefNo { get; set; }
        public string Image { get; set; }
        [Required]
        public string MobileNo { get; set; }
        [Required]
        public string Amount { get; set; }
        public string RegMode { get; set; }
        public string ReceiptNo { get; set; }
        public string ChequeCopy { get; set; }
        [Required]
        public string PANNO { get; set; }
        [Required]
        public string InvestorName { get; set; }
        public string ImageType { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            
            if (this.Image != null && this.Image.Trim() != "")
            {
                string OTMImageExtension = GetFileExtension(this.Image);
                if (OTMImageExtension != "png" && OTMImageExtension != "jpg")
                {
                    results.Add(new ValidationResult("Invalid OTM Image Format", new List<string> { nameof(Image) }));
                }
            }
            if (this.ChequeCopy != null && this.ChequeCopy.Trim() != "")
            {
                string ChequeImageExt = GetFileExtension(this.ChequeCopy);
                if (ChequeImageExt != "png" && ChequeImageExt != "jpg")
                {
                    results.Add(new ValidationResult("Invalid Cheque Image Format", new List<string> { nameof(ChequeCopy) }));
                }
            }
            if(this.OTMDate==null || this.OTMDate.Trim() == "")
            {
                results.Add(new ValidationResult("OTMDate is required.", new List<string> { nameof(OTMDate) }));
            }
            if (this.SponsorBank == null || this.SponsorBank.Trim() == "")
            {
                results.Add(new ValidationResult("SponsorBank is required.", new List<string> { nameof(SponsorBank) }));
            }
            if (this.Authorize == null || this.Authorize.Trim() == "")
            {
                results.Add(new ValidationResult("Authorize is required.", new List<string> { nameof(Authorize) }));
            }
            if (this.Utilitycode == null || this.Utilitycode.Trim() == "")
            {
                results.Add(new ValidationResult("Utilitycode is required.", new List<string> { nameof(Utilitycode) }));
            }
            if (this.Mode == null || this.Mode.Trim() == "")
            {
                results.Add(new ValidationResult("Mode is required.", new List<string> { nameof(Mode) }));
            }
            if (this.ToDebit == null || this.ToDebit.Trim() == "")
            {
                results.Add(new ValidationResult("ToDebit is required.", new List<string> { nameof(ToDebit) }));
            }
            if (this.BankName == null || this.BankName.Trim() == "")
            {
                results.Add(new ValidationResult("BankName is required.", new List<string> { nameof(BankName) }));
            }
            if (this.IFSCCode == null || this.IFSCCode.Trim() == "")
            {
                results.Add(new ValidationResult("IFSCCode is required.", new List<string> { nameof(IFSCCode) }));
            }
            if (this.BankAcno == null || this.BankAcno.Trim() == "")
            {
                results.Add(new ValidationResult("BankAcno is required.", new List<string> { nameof(BankAcno) }));
            }
            if (this.BranchCode == null || this.BranchCode.Trim() == "")
            {
                results.Add(new ValidationResult("BranchCode is required.", new List<string> { nameof(BranchCode) }));
            }
            if (this.Frequency == null || this.Frequency.Trim() == "")
            {
                results.Add(new ValidationResult("Frequency is required.", new List<string> { nameof(Frequency) }));
            }
            if (this.Debittype == null || this.Debittype.Trim() == "")
            {
                results.Add(new ValidationResult("Debittype is required.", new List<string> { nameof(Debittype) }));
            }
            if (this.ClientId == null || this.ClientId.Trim() == "")
            {
                results.Add(new ValidationResult("ClientId is required.", new List<string> { nameof(ClientId) }));
            }
            if (this.FromDate == null || this.FromDate.Trim() == "")
            {
                results.Add(new ValidationResult("FromDate is required.", new List<string> { nameof(FromDate) }));
            }
            if (this.Todate == null || this.Todate.Trim() == "")
            {
                results.Add(new ValidationResult("Todate is required.", new List<string> { nameof(Todate) }));
            }
            if (this.PANNO == null || this.PANNO.Trim() == "" || this.PANNO.Trim().Length!=10)
            {
                results.Add(new ValidationResult("PANNO is required and should be 10 character.", new List<string> { nameof(PANNO) }));
            }
            if (this.InvestorName == null || this.InvestorName.Trim() == "")
            {
                results.Add(new ValidationResult("InvestorName is required.", new List<string> { nameof(InvestorName) }));
            }
            if (this.MobileNo == null || this.MobileNo.Trim() == "" || this.MobileNo.Trim().Length<7)
            {
                results.Add(new ValidationResult("MobileNo is required.", new List<string> { nameof(MobileNo) }));
            }
            if (this.Amount == null || this.Amount.Trim() == "" || this.Amount.Trim() == "0" || IsNumeric(this.Amount)==false)
            {
                results.Add(new ValidationResult("Amount is required and should be greater then 0.", new List<string> { nameof(Amount) }));
            }
            return results;
        }
        public static bool IsNumeric(string Amt)
        {
            Int64 Amt64;
            bool isNumeric = Int64.TryParse(Amt, out Amt64);
            return isNumeric;
        }
        public static string GetFileExtension(string base64String)
        {
            var data = base64String.Substring(0, 5);

            switch (data.ToUpper())
            {
                case "IVBOR":
                    return "png";
                case "/9J/4":
                    return "jpg";
                default:
                    return string.Empty;
            }
        }
    }
    public class EMandateRegRes
    {
        public string Message { get; set; }
        public string RefNo { get; set; }
        public string ReferenceID { get; set; }
        public string Status_Code { get; set; }
    }
    public class EMandateReqResponse
    {
        public EMandateRegReq _EMandateRegReq { get; set; }
        public EMandateRegRes _EMandateRegRes { get; set; }
    }
    public class OTMDetails
    {
        public string RefNo { get; set; }
        public string RegistrationDate { get; set; }
        public string BankName { get; set; }
        public string BankAccNo { get; set; }
        public string UMRN_NO { get; set; }
        public decimal MinAmount { get; set; }
        public string Status { get; set; }

        public string OTMDate { get; set; }
        public string SponsorBank { get; set; }
        public string Authorize { get; set; }
        public string Utilitycode { get; set; }
        public string Mode { get; set; }
        public string ToDebit { get; set; }
        public string BankHolderName { get; set; }
        public string MICRCode { get; set; }
        public string IFSCCode { get; set; }
        public string BankAcno { get; set; }
        public string BranchCode { get; set; }
        public string Frequency { get; set; }
        public string Debittype { get; set; }
        public string ClientId { get; set; }
        public string AccountType { get; set; }
        public string ReferenceID { get; set; }
        public string EmailId { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string Image { get; set; }
        public string MobileNo { get; set; }
        public string ChequeImage { get; set; }
        public string PANNO { get; set; }
        public string InvestorName { get; set; }
        public string ImageType { get; set; }
    }
    public class OTMReq : IValidatableObject
    {
        [Required]
        public string ModeOfHolding { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            if (this.ModeOfHolding == null || this.ModeOfHolding.Trim() == "")
            {
                results.Add(new ValidationResult("ModeOfHolding is required.", new List<string> { nameof(ModeOfHolding) }));
            }
            return results;
        }
    }
    public class FinalSubmitEMandate
    {
        public int RefNo { get; set; }
    }

    public class SaveOTMConsolidateRes
    {
        public EMandateRegRes ObjEMandateRegRes { get; set; }
        public List<OTMDetails> ObjLstOTMDetails { get; set; }
    }

    public class EMandateRegReqConsolidate
    {
        public EMandateRegReq ObjEMandateRegReq { get; set; }
        public OTMReq ObjOTMReq { get; set; }
    }
}
