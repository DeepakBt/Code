﻿using ApiCore.DTOs;
using ApiCore.Exceptions;
using ApiCore.Model;
using ApiCore.Validation;
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Text.RegularExpressions;

namespace MFTransaction.Models
{
    //PanDetails
    public class validateUserRes
    {
        [DefaultValue(false)]
        public bool authorizeUser { get; set; }
        public string message { get; set; }
    }
    public class PanKYCReq : IValidatableObject
    {
        /// <summary>Enter valid pan no. e.g. "XXXXX1234X"</summary>
        [Required]
        public string panNo { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();
            // some other random test
            Regex regex = new Regex("^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$");
            Match match = regex.Match(panNo);
            if (!match.Success)
            {
                results.Add(new ValidationResult("PanNo must be in valid format", new List<string> { nameof(panNo) }));
            }
            return results;
        }
    }
    public class MFClientsPanDetailsRes
    {
        public string accessToken { get; set; }
        public int expiresIn { get; set; }
        public string screenNo { get; set; }
    }
    public class MFClientsPanDetails
    {
        [Required]
        public string panNo { get; set; }
        public string aadharNo { get; set; }
        [Required]
        public string name { get; set; }
        [DefaultValue(0)]
        public int otp { get; set; }
        [Required]
        public bool saveForlater { get; set; }
    }

    //BasicDetails
    public class MFClientsBasicDetailsRes
    {
        public Int64 userId { get; set; }
        public int modeOfHolding { get; set; }
        public int firstHolderTaxStatus { get; set; }
        public List<BasicDetails> HolderDetails { get; set; }
        public FirstHolderGurdian firstHolderGurdian { get; set; }
    }

    public class MFClientsBasicDetails : IValidatableObject
    {
        //[Required]
        ///// <summary> "Refer saveNewInvestorPanDetails API  "userId" Key " </summary>
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        [Required]
        /// <summary> "Refer holderBasicDetails API  "modeOfHolding:holdingmodeId" Key eg 1|2|3" </summary>
        [DefaultValue(0)]
        public int modeOfHolding { get; set; }
        [DefaultValue(0)]
        public int firstHolderTaxStatus { get; set; }
        public List<BasicDetails> holderDetails { get; set; }
        public FirstHolderGurdian firstHolderGurdian { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();

            var results = new List<ValidationResult>();
            //if (this.userId == 0)
            //{
            //    results.Add(new ValidationResult("Invalid userId.", new List<string> { nameof(userId) }));
            //}
            if (this.modeOfHolding != 1 && this.modeOfHolding != 2 && this.modeOfHolding != 3)
            {
                results.Add(new ValidationResult("Invalid mode of holding", new List<string> { nameof(modeOfHolding) }));
            }
            if (this.firstHolderTaxStatus != 1 && this.firstHolderTaxStatus != 2)
            {
                results.Add(new ValidationResult("Invalid Tax status selected.", new List<string> { nameof(firstHolderTaxStatus) }));
            }
            if (this.holderDetails[0].category != 11 && this.holderDetails[0].category != 21)
            {
                results.Add(new ValidationResult("Invalid category selected.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].ifNri != 1 && this.holderDetails[0].ifNri != 2)
            {
                results.Add(new ValidationResult("Invalid IfNRI selected.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].occupation <= 0)
            {
                results.Add(new ValidationResult("Invalid Occupation selected.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].name == null || this.holderDetails[0].name.Trim() == "")
            {
                results.Add(new ValidationResult("First Holder Name cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].dob == null || this.holderDetails[0].dob.Trim() == "")
            {
                results.Add(new ValidationResult("Date of birth cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            else
            {
                if (ParamValid.DateValidate(this.holderDetails[0].dob.Trim(), "yyyy-MM-dd") == false)
                {
                    results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "firstHolderDetails" }));
                }
                else
                {
                    if (this.firstHolderTaxStatus == 1 && ParamValid.GetAge(this.holderDetails[0].dob) < 18)
                    {
                        results.Add(new ValidationResult("Date of birth should be greater then 18 year incase of Tax status is Individual.", new List<string> { "firstHolderDetails" }));
                    }
                    else if (this.firstHolderTaxStatus == 2 && ParamValid.GetAge(this.holderDetails[0].dob) > 18)
                    {
                        results.Add(new ValidationResult("Date of birth should be less then 18 year  incase of Tax status is Minor.", new List<string> { "firstHolderDetails" }));
                    }
                    if (this.firstHolderTaxStatus == 2)
                    {
                        if (this.firstHolderGurdian != null)
                        {
                            if (this.firstHolderGurdian.name == null || this.firstHolderGurdian.name.Trim() == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian name cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            if (this.firstHolderGurdian.panNo == null || this.firstHolderGurdian.panNo.Trim() == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian Pan No cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            else
                            {
                                if (ParamValid.IsValidPanno(this.firstHolderGurdian.panNo) == false)
                                {
                                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { "gurdaianDetails" }));
                                }
                            }
                            if (this.firstHolderGurdian.kycStatus != true && this.firstHolderGurdian.kycStatus != false)
                            {
                                results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "gurdaianDetails" }));
                            }
                            if(this.firstHolderGurdian.mobileno==null || this.firstHolderGurdian.mobileno.Trim()== "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian mobileno cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            if(this.firstHolderGurdian.email==null || this.firstHolderGurdian.email.Trim() == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian email cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            if(this.firstHolderGurdian.dob==null || this.firstHolderGurdian.dob == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian dob cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                            if (ParamValid.DateValidate(this.firstHolderGurdian.dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "gurdaianDetails" }));
                            }
                            if (this.firstHolderGurdian.relation == null || this.firstHolderGurdian.relation == "")
                            {
                                results.Add(new ValidationResult("First holder Gurdian relation cannot be left blank.", new List<string> { "gurdaianDetails" }));
                            }
                        }
                        else
                        {
                            results.Add(new ValidationResult("FirstHolder gurdian details Compulsory incase of Minor Holder.", new List<string> { "firstHolderDetails" }));
                        }

                    }
                }

            }
            if (this.holderDetails[0].panNo == null || this.holderDetails[0].panNo.Trim() == "")
            {
                results.Add(new ValidationResult("Pan no cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            else
            {
                if (ParamValid.IsValidPanno(this.holderDetails[0].panNo) == false)
                {
                    results.Add(new ValidationResult("Invalid Panno.", new List<string> { "firstHolderDetails" }));
                }
            }
            if (this.holderDetails[0].email == null || this.holderDetails[0].email.Trim() == "")
            {
                results.Add(new ValidationResult("Email cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            else if (ParamValid.IsValidEmail(this.holderDetails[0].email) == false)
            {
                results.Add(new ValidationResult("Invalid Email id", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].mobileNo == null || this.holderDetails[0].mobileNo.Trim() == "")
            {
                results.Add(new ValidationResult("Mobile no cannot be left blank.", new List<string> { "firstHolderDetails" }));
            }
            if (this.holderDetails[0].kycStatus != true && this.holderDetails[0].kycStatus != false)
            {
                results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "firstHolderDetails" }));
            }


            if (this.modeOfHolding == 2)
            {
                if (this.holderDetails.Count > 1)
                {
                    if (this.holderDetails[1].category != 11 && this.holderDetails[1].category != 21)
                    {
                        results.Add(new ValidationResult("Invalid category selected.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].ifNri != 1 && this.holderDetails[1].ifNri != 2)
                    {
                        results.Add(new ValidationResult("Invalid IfNRI selected.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].occupation <= 0)
                    {
                        results.Add(new ValidationResult("Invalid Occupation selected.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].name == null || this.holderDetails[1].name.Trim() == "")
                    {
                        results.Add(new ValidationResult("First Holder Name cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].dob == null || this.holderDetails[1].dob.Trim() == "")
                    {
                        results.Add(new ValidationResult("Date of birth cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    else
                    {
                        if (ParamValid.DateValidate(this.holderDetails[1].dob.Trim(), "yyyy-MM-dd") == false)
                        {
                            results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "SecondHolderDetails" }));
                        }
                        else if (ParamValid.GetAge(this.holderDetails[1].dob) < 18)
                        {
                            results.Add(new ValidationResult("Date of birth should be greater then 18 year.", new List<string> { "SecondHolderDetails" }));
                        }
                    }
                    if (this.holderDetails[1].panNo == null || this.holderDetails[1].panNo.Trim() == "")
                    {
                        results.Add(new ValidationResult("Pan no cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    else
                    {
                        if (ParamValid.IsValidPanno(this.holderDetails[1].panNo) == false)
                        {
                            results.Add(new ValidationResult("Invalid Panno.", new List<string> { "SecondHolderDetails" }));
                        }
                    }
                    if (this.holderDetails[1].email == null || this.holderDetails[1].email.Trim() == "")
                    {
                        results.Add(new ValidationResult("Email cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    else if (ParamValid.IsValidEmail(this.holderDetails[1].email) == false)
                    {
                        results.Add(new ValidationResult("Invalid Email id", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].mobileNo == null || this.holderDetails[1].mobileNo.Trim() == "")
                    {
                        results.Add(new ValidationResult("Mobile no cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                    }
                    if (this.holderDetails[1].kycStatus != true && this.holderDetails[1].kycStatus != false)
                    {
                        results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "SecondHolderDetails" }));
                    }
                }
                else
                {
                    results.Add(new ValidationResult("Second holder Details Compulsory incase of mode of holding is Joint.", new List<string> { "SecondHolderDetails" }));
                }

            }

            if (this.modeOfHolding == 2)
            {
                if (this.holderDetails.Count > 2)
                {
                    if (this.holderDetails[2].panNo != null && this.holderDetails[2].panNo.Trim() != "")
                    {

                        if (this.holderDetails[2].category != 11 && this.holderDetails[2].category != 21)
                        {
                            results.Add(new ValidationResult("Invalid category selected.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].ifNri != 1 && this.holderDetails[2].ifNri != 2)
                        {
                            results.Add(new ValidationResult("Invalid IfNRI selected.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].occupation <= 0)
                        {
                            results.Add(new ValidationResult("Invalid Occupation selected.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].name == null || this.holderDetails[2].name.Trim() == "")
                        {
                            results.Add(new ValidationResult("First Holder Name cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].dob == null || this.holderDetails[2].dob.Trim() == "")
                        {
                            results.Add(new ValidationResult("Date of birth cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        else
                        {
                            if (ParamValid.DateValidate(this.holderDetails[2].dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd", new List<string> { "ThirdHolderDetails" }));
                            }
                            else if (ParamValid.GetAge(this.holderDetails[2].dob) < 18)
                            {
                                results.Add(new ValidationResult("Date of birth should be greater then 18 year.", new List<string> { "ThirdHolderDetails" }));
                            }
                        }
                        if (this.holderDetails[2].panNo == null || this.holderDetails[2].panNo.Trim() == "")
                        {
                            results.Add(new ValidationResult("Pan no cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        else
                        {
                            if (ParamValid.IsValidPanno(this.holderDetails[2].panNo) == false)
                            {
                                results.Add(new ValidationResult("Invalid Panno.", new List<string> { "ThirdHolderDetails" }));
                            }
                        }
                        if (this.holderDetails[2].email == null || this.holderDetails[2].email.Trim() == "")
                        {
                            results.Add(new ValidationResult("Email cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        else if (ParamValid.IsValidEmail(this.holderDetails[2].email) == false)
                        {
                            results.Add(new ValidationResult("Invalid Email id", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].mobileNo == null || this.holderDetails[2].mobileNo.Trim() == "")
                        {
                            results.Add(new ValidationResult("Mobile no cannot be left blank.", new List<string> { "ThirdHolderDetails" }));
                        }
                        if (this.holderDetails[2].kycStatus != true && this.holderDetails[2].kycStatus != false)
                        {
                            results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "ThirdHolderDetails" }));
                        }

                    }
                }
            }



            if (this.holderDetails.Count > 2)
            {
                if ((this.holderDetails[0].panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[0].panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("First and Second Holders Pan no cannot be Same."));
                    }
                }
                if ((this.holderDetails[0].panNo.Trim() != "" && this.holderDetails[2].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[0].panNo.Trim() == this.holderDetails[2].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("First and Third Holders Pan no cannot be Same."));
                    }
                }
                if ((this.holderDetails[1].panNo.Trim() != "" && this.holderDetails[2].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[1].panNo.Trim() == this.holderDetails[2].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("Second and Third Holders Pan no cannot be Same."));
                    }
                }
            }
            else if (this.holderDetails.Count > 1)
            {
                if ((this.holderDetails[0].panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                {
                    if ((this.holderDetails[0].panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                    {
                        results.Add(new ValidationResult("First and Second Holders Pan no cannot be Same."));
                    }
                }
            }

            if (this.firstHolderTaxStatus == 2)
            {
                if (this.holderDetails.Count > 2)
                {
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[0].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[0].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and First Holders Pan no cannot be Same."));
                        }
                    }
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and Second Holders Pan no cannot be Same."));
                        }
                    }
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[2].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[2].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and Third Holders Pan no cannot be Same."));
                        }
                    }
                }
                else if (this.holderDetails.Count > 1)
                {
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[0].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[0].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and First Holders Pan no cannot be Same."));
                        }
                    }
                    if ((this.firstHolderGurdian.panNo.Trim() != "" && this.holderDetails[1].panNo.Trim() != ""))
                    {
                        if ((this.firstHolderGurdian.panNo.Trim() == this.holderDetails[1].panNo.Trim()))
                        {
                            results.Add(new ValidationResult("Gurdian and Second Holders Pan no cannot be Same."));
                        }
                    }
                }
            }
            return results;
        }
    }
    public class BasicDetails
    {
        /// <summary> "Refer holderBasicDetails API  "category:categoryId" Key eg 11|21" </summary>
        [DefaultValue(0)]
        public int category { get; set; }
        /// <summary> "Refer holderBasicDetails API  "nri:nriId" Key eg 1|2" </summary>
        [DefaultValue(0)]
        public int ifNri { get; set; }
        /// <summary> "Refer holderBasicDetails API  "occupation:occupationId" Key eg 1|2" </summary>
        [DefaultValue(0)]
        public int occupation { get; set; }
        /// <summary> "Mr.|Master|Miss|Mrs." </summary>
        [DefaultValue("")]
        public string title { get; set; }
        [DefaultValue("")]
        public string name { get; set; }
        [DefaultValue("")]
        public string dob { get; set; }
        [DefaultValue("")]
        public string panNo { get; set; }
        [DefaultValue("")]
        public string aadharNo { get; set; }
        [DefaultValue("")]
        public string email { get; set; }
        [DefaultValue("")]
        public string mobileNo { get; set; }
        [DefaultValue("")]
        public string landlineNo { get; set; }
        /// <summary> 0(false)|1(true)</summary>
        [DefaultValue(true)]
        public bool kycStatus { get; set; }

    }
    public class FirstHolderGurdian
    {
        [DefaultValue("")]
        public string name { get; set; }
        [DefaultValue("")]
        public string panNo { get; set; }
        [DefaultValue("")]
        public string aadhar { get; set; }
        public string email { get; set; }
        public string mobileno { get; set; }
        public string dob { get; set; }
        public string relation { get; set; }
        /// <summary> 0(false)|1(true)</summary>
        [DefaultValue(true)]
        public bool kycStatus { get; set; }
    }

    //FatcaDetails
    public class MFClientsFatchDetailsRes
    {
        //public Int64 userId { get; set; }
        public List<FatcaDetails> FatcaDetails { get; set; }
    }
    public class MFClientsFatchDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        public List<FatcaDetails> fatcaDetails { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            //if (this.userId == 0)
            //{
            //    results.Add(new ValidationResult("Invalid userId.", new List<string> { nameof(userId) }));
            //}
            if (this.fatcaDetails[0].incomeSlab == 0 || this.fatcaDetails[0].incomeSlab > 6)
            {
                results.Add(new ValidationResult("Invalid incomeSlab.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].birthCountry == null || this.fatcaDetails[0].birthCountry.Trim() == "")
            {
                results.Add(new ValidationResult("Birth Country cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].nationality == null || this.fatcaDetails[0].nationality.Trim() == "")
            {
                results.Add(new ValidationResult("Nationality cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].taxResidentNonIndian == true)
            {
                if (this.fatcaDetails[0].taxResident == null || this.fatcaDetails[0].taxResident.Trim() == "")
                {
                    results.Add(new ValidationResult("Tax Resident cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
                }
                if (this.fatcaDetails[0].foreignTaxId == null || this.fatcaDetails[0].foreignTaxId.Trim() == "")
                {
                    results.Add(new ValidationResult("ForignTaxId cannot be left blank.", new List<string> { "FirstHolderFatcaDetails" }));
                }
            }
            if (this.fatcaDetails[0].pep != true && this.fatcaDetails[0].pep != false)
            {
                results.Add(new ValidationResult("Invalid pep.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            if (this.fatcaDetails[0].relationalPep != true && this.fatcaDetails[0].relationalPep != false)
            {
                results.Add(new ValidationResult("Invalid Relation pep.", new List<string> { "FirstHolderFatcaDetails" }));
            }
            return results;
        }

    }
    public class FatcaDetails
    {
        [DefaultValue(0)]
        public int incomeSlab { get; set; }
        [DefaultValue("")]
        public string birthCountry { get; set; }
        [DefaultValue("")]
        public string nationality { get; set; }
        [DefaultValue(true)]
        public bool taxResidentNonIndian { get; set; }
        [DefaultValue("")]
        public string taxResident { get; set; }
        [DefaultValue("")]
        public string foreignTaxId { get; set; }
        [DefaultValue(false)]
        public bool pep { get; set; }  // Pep: Politcal exposed person
        [DefaultValue(false)]
        public bool relationalPep { get; set; }
    }

    //ContactDetails
    public class MFClientsContactDetailsRes
    {
        //public Int64 userId { get; set; }
        public List<ContactDetails> contactDetails { get; set; }
        public NRIContactDetails nriContact { get; set; }
    }
    public class MFClientsContactDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        public List<ContactDetails> contactDetails { get; set; }
        public NRIContactDetails nriContact { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            //if (this.userId == 0)
            //{
            //    results.Add(new ValidationResult("Invalid userId.", new List<string> { nameof(userId) }));
            //}
            if (this.contactDetails[0].wing == null || this.contactDetails[0].wing.Trim() == "")
            {
                results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].area == null || this.contactDetails[0].area.Trim() == "")
            {
                results.Add(new ValidationResult("Area cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].state == null || this.contactDetails[0].state.Trim() == "")
            {
                results.Add(new ValidationResult("State cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].country == null || this.contactDetails[0].country.Trim() == "")
            {
                results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "FirstHolderContactDetails" }));
            }
            if (this.contactDetails[0].pincode == 0)
            {
                results.Add(new ValidationResult("Invalid Pincode.", new List<string> { "FirstHolderContactDetails" }));
            }
            return results;
        }
    }
    public class ContactDetails
    {
        [DefaultValue("")]
        public string wing { get; set; }
        [DefaultValue("")]
        public string area { get; set; }
        [DefaultValue("")]
        public string landmark { get; set; }
        [DefaultValue("")]
        public string state { get; set; }
        [DefaultValue("")]
        public string city { get; set; }
        [DefaultValue("")]
        public string country { get; set; }
        [DefaultValue(0)]
        public int pincode { get; set; }
    }
    public class NRIContactDetails
    {
        [DefaultValue("")]
        public string address1 { get; set; }
        [DefaultValue("")]
        public string address2 { get; set; }
        [DefaultValue("")]
        public string address3 { get; set; }
        [DefaultValue("")]
        public string city { get; set; }
        [DefaultValue("")]
        public string country { get; set; }
        [DefaultValue("")]
        public string zipcode { get; set; }
    }

    //NomineeDetails
    public class MFClientsNomineeDetailsRes
    {
        //public Int64 userId { get; set; }
        public bool wishToNominate { get; set; }
        public List<NomineeDetails> nomineeDetails { get; set; }

    }
    public class MFClientsNomineeDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool wishToNominate { get; set; }
        public List<NomineeDetails> nomineeDetails { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.wishToNominate == true)
            {
                if (this.nomineeDetails[0].name == null || this.nomineeDetails[0].name.Trim() == "")
                {
                    results.Add(new ValidationResult("Name cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                }
                if (this.nomineeDetails[0].dob == null || this.nomineeDetails[0].dob.Trim() == "")
                {
                    results.Add(new ValidationResult("Date of Birth cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                }
                else
                {
                    if (ParamValid.DateValidate(this.nomineeDetails[0].dob.Trim(), "yyyy-MM-dd") == false)
                    {
                        results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd.", new List<string> { "FirstNomineeDetails" }));
                    }
                    else if (ParamValid.GetAge(this.nomineeDetails[0].dob) < 18)
                    {
                        if (this.nomineeDetails[0].gurdianName == null || this.nomineeDetails[0].gurdianName.Trim() == "")
                        {
                            results.Add(new ValidationResult("First Nominee Gurdian name cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                        }
                        if (this.nomineeDetails[0].gurdianPanNo == null || this.nomineeDetails[0].gurdianPanNo.Trim() == "")
                        {
                            results.Add(new ValidationResult("First Nominee Gurdian Pan No cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                        }
                        else
                        {
                            if (ParamValid.IsValidPanno(this.nomineeDetails[0].gurdianPanNo) == false)
                            {
                                results.Add(new ValidationResult("Invalid Panno.", new List<string> { "FirstNomineeDetails" }));
                            }
                        }
                    }
                }
                if (this.nomineeDetails[0].percent == 0)
                {
                    results.Add(new ValidationResult("Percent should be greater then Zero.", new List<string> { "FirstNomineeDetails" }));
                }
                if (this.nomineeDetails[0].addresFlag != true && this.nomineeDetails[0].addresFlag != false)
                {
                    results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "SecondHolderDetails" }));
                }
                else
                {
                    if (this.nomineeDetails[0].addresFlag == false)
                    {
                        if (this.nomineeDetails[0].address1.Trim() == "" || this.nomineeDetails[0].address1 == null)
                        {
                            results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "SecondHolderDetails" }));
                        }
                    }
                }
                if (this.nomineeDetails[0].relationship == null || this.nomineeDetails[0].relationship.Trim() == "")
                {
                    results.Add(new ValidationResult("Relationship cannot be left blank.", new List<string> { "FirstNomineeDetails" }));
                }

                if (this.nomineeDetails.Count == 2)
                {
                    if (this.nomineeDetails[1].percent > 0)
                    {
                        if (this.nomineeDetails[1].name == null || this.nomineeDetails[1].name.Trim() == "")
                        {
                            results.Add(new ValidationResult("Name cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                        }
                        if (this.nomineeDetails[1].dob == null || this.nomineeDetails[1].dob.Trim() == "")
                        {
                            results.Add(new ValidationResult("Date of Birth cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                        }
                        else
                        {
                            if (ParamValid.DateValidate(this.nomineeDetails[1].dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd.", new List<string> { "SecondNomineeDetails" }));
                            }
                            else if (ParamValid.GetAge(this.nomineeDetails[1].dob) < 18)
                            {
                                if (this.nomineeDetails[1].gurdianName == null || this.nomineeDetails[1].gurdianName.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Second Nominee Gurdian name cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                                }
                                if (this.nomineeDetails[1].gurdianPanNo == null || this.nomineeDetails[1].gurdianPanNo.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Second Nominee Gurdian Pan No cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                                }
                                else
                                {
                                    if (ParamValid.IsValidPanno(this.nomineeDetails[1].gurdianPanNo) == false)
                                    {
                                        results.Add(new ValidationResult("Invalid Panno.", new List<string> { "SecondNomineeDetails" }));
                                    }
                                }
                            }
                        }
                        if (this.nomineeDetails[1].percent == 0)
                        {
                            results.Add(new ValidationResult("Percent should be greater then Zero.", new List<string> { "SecondNomineeDetails" }));
                        }
                        if (this.nomineeDetails[1].addresFlag != true && this.nomineeDetails[1].addresFlag != false)
                        {
                            results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "SecondNomineeDetails" }));
                        }
                        else
                        {
                            if (this.nomineeDetails[1].addresFlag == false)
                            {
                                if (this.nomineeDetails[1].address1.Trim() == "" || this.nomineeDetails[1].address1 == null)
                                {
                                    results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                                }
                            }
                        }
                        if (this.nomineeDetails[1].relationship == null || this.nomineeDetails[1].relationship.Trim() == "")
                        {
                            results.Add(new ValidationResult("Relationship cannot be left blank.", new List<string> { "SecondNomineeDetails" }));
                        }
                    }
                }


                if (this.nomineeDetails.Count == 3)
                {
                    if (this.nomineeDetails[2].percent > 0)
                    {
                        if (this.nomineeDetails[2].name == null || this.nomineeDetails[2].name.Trim() == "")
                        {
                            results.Add(new ValidationResult("Name cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        if (this.nomineeDetails[2].dob == null || this.nomineeDetails[2].dob.Trim() == "")
                        {
                            results.Add(new ValidationResult("Date of Birth cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        else
                        {
                            if (ParamValid.DateValidate(this.nomineeDetails[2].dob.Trim(), "yyyy-MM-dd") == false)
                            {
                                results.Add(new ValidationResult("Date must be in format : yyyy-MM-dd.", new List<string> { "ThirdNomineeDetails" }));
                            }
                            else if (ParamValid.GetAge(this.nomineeDetails[2].dob) < 18)
                            {
                                if (this.nomineeDetails[2].gurdianName == null || this.nomineeDetails[2].gurdianName.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Third Nominee Gurdian name cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                                }
                                if (this.nomineeDetails[1].gurdianPanNo == null || this.nomineeDetails[1].gurdianPanNo.Trim() == "")
                                {
                                    results.Add(new ValidationResult("Third Nominee Gurdian Pan No cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                                }
                                else
                                {
                                    if (ParamValid.IsValidPanno(this.nomineeDetails[2].gurdianPanNo) == false)
                                    {
                                        results.Add(new ValidationResult("Invalid Panno.", new List<string> { "ThirdNomineeDetails" }));
                                    }
                                }
                            }
                        }
                        if (this.nomineeDetails[2].percent == 0)
                        {
                            results.Add(new ValidationResult("Percent should be greater then Zero.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        if (this.nomineeDetails[2].addresFlag != true && this.nomineeDetails[2].addresFlag != false)
                        {
                            results.Add(new ValidationResult("Invalid KYC status.", new List<string> { "ThirdNomineeDetails" }));
                        }
                        else
                        {
                            if (this.nomineeDetails[2].addresFlag == false)
                            {
                                if (this.nomineeDetails[2].address1.Trim() == "" || this.nomineeDetails[2].address1 == null)
                                {
                                    results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                                }
                            }
                        }
                        if (this.nomineeDetails[2].relationship == null || this.nomineeDetails[2].relationship.Trim() == "")
                        {
                            results.Add(new ValidationResult("Relationship cannot be left blank.", new List<string> { "ThirdNomineeDetails" }));
                        }
                    }
                }





                if (this.nomineeDetails.Count > 2)
                {
                    if (this.nomineeDetails[0].percent + this.nomineeDetails[1].percent + this.nomineeDetails[2].percent != 100)
                    {
                        results.Add(new ValidationResult("Total  Percent should be 100%."));
                    }

                }
                else if (this.nomineeDetails.Count > 1)
                {
                    if (this.nomineeDetails[0].percent + this.nomineeDetails[1].percent != 100)
                    {
                        results.Add(new ValidationResult("Total  Percent should be 100%."));
                    }
                }
                else if (this.nomineeDetails.Count == 1)
                {
                    if (this.nomineeDetails[0].percent != 100)
                    {
                        results.Add(new ValidationResult("Total  Percent should be 100%."));
                    }
                }



            }
            return results;
        }
    }
    public class NomineeDetails
    {
        [DefaultValue("")]
        public string title { get; set; }
        [DefaultValue("")]
        public string name { get; set; }
        [DefaultValue("")]
        public string dob { get; set; }
        [DefaultValue(0)]
        public decimal percent { get; set; }
        [DefaultValue(1)]
        /// <summary> 0|1</summary>
        public bool addresFlag { get; set; }
        [DefaultValue("")]
        public string address1 { get; set; }
        [DefaultValue("")]
        public string address2 { get; set; }
        [DefaultValue("")]
        public string relationship { get; set; }
        [DefaultValue("")]
        public string gurdianTitle { get; set; }
        [DefaultValue("")]
        public string gurdianName { get; set; }
        [DefaultValue("")]
        public string gurdianPanNo { get; set; }
        /// <summary> 0(false)|1(true)</summary>
        [DefaultValue(false)]
        public bool gurdianKycStatus { get; set; }
    }

    //SchemeDetails
    public class MFClientsSchemeDetailsRes
    {
        //public Int64 userId { get; set; }
        public string transactionType { get; set; }
        public string schemeCode { get; set; }
        public string schemeName { get; set; }
        public string planCode { get; set; }
        public string optionCode { get; set; }
        public double investmentAmount { get; set; }
        public double schemeMinAmount { get; set; }
        public string planMode { get; set; }
        public string frequency { get; set; }
        public string deductionDate { get; set; }
        public string sipFromDate { get; set; }
        public string sipToDate { get; set; }
        public bool perpetual { get; set; }
        public int noOfInstalment { get; set; }
    }
    public class MFClientsSchemeDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        [Required]
        [DefaultValue("")]
        public string transactionType { get; set; }
        [Required]
        [DefaultValue("")]
        public string schemeCode { get; set; }
        [Required]
        [DefaultValue("")]
        public string schemeName { get; set; }
        [Required]
        [DefaultValue("")]
        public string planCode { get; set; }
        [Required]
        [DefaultValue("")]
        public string optionCode { get; set; }
        [Required]
        [DefaultValue("")]
        public double investmentAmount { get; set; }
        [Required]
        [DefaultValue("")]
        public double schemeMinAmount { get; set; }
        [Required]
        [DefaultValue("")]
        public string planMode { get; set; }

        [DefaultValue("")]
        public string frequency { get; set; }
        [DefaultValue("")]
        public string deductionDate { get; set; }
        [DefaultValue("")]
        public string sipFromDate { get; set; }
        [DefaultValue("")]
        public string sipToDate { get; set; }
        [DefaultValue(false)]
        public bool perpetual { get; set; }
        [DefaultValue(0)]
        public int noOfInstalment { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.transactionType.ToUpper().Trim() != "LUMPSUM" && this.transactionType.ToUpper().Trim() != "SIP")
            {
                results.Add(new ValidationResult("Invalid Transaction Type", new List<string> { "SchemeDetails" }));
            }
            if (this.schemeCode.ToUpper() == null && this.schemeCode.ToUpper().Trim() == "")
            {
                results.Add(new ValidationResult("Invalid scheme code", new List<string> { "SchemeDetails" }));
            }
            if (this.schemeName.ToUpper() == null && this.schemeName.ToUpper().Trim() == "")
            {
                results.Add(new ValidationResult("Invalid scheme Name", new List<string> { "SchemeDetails" }));
            }
            if (this.planCode.ToUpper() == null && this.planCode.ToUpper().Trim() == "")
            {
                results.Add(new ValidationResult("Invalid planCode", new List<string> { "SchemeDetails" }));
            }
            //if (this.investmentAmount < 500)
            //{
            //    results.Add(new ValidationResult("Investment amount should be greater min Amount", new List<string> { "SchemeDetails" }));
            //}
            if (this.planMode.ToUpper().Trim() != "DIRECT" && this.planMode.ToUpper().Trim() != "REGULAR")
            {
                results.Add(new ValidationResult("Invalid Plan mode", new List<string> { "SchemeDetails" }));
            }
            if (this.optionCode.ToUpper().Trim() != "G" && this.optionCode.ToUpper().Trim() != "D" && this.optionCode.ToUpper().Trim() != "R")
            {
                results.Add(new ValidationResult("Invalid Option code ", new List<string> { "SchemeDetails" }));
            }
            if (this.transactionType.ToUpper().Trim() == "SIP")
            {
                if (!string.IsNullOrEmpty(this.deductionDate))
                {
                    if (ParamValid.isNumeric(this.deductionDate) == false)
                    {
                        results.Add(new ValidationResult("Deduction Date should be numeric value", new List<string> { "SchemeDetails" }));
                    }
                    else if (Convert.ToInt32(this.deductionDate) < 1 && Convert.ToInt32(this.deductionDate) > 31)
                    {
                        results.Add(new ValidationResult("Deduction Date should be numeric value Range 1  to  28", new List<string> { "SchemeDetails" }));
                    }
                }
                else
                {
                    results.Add(new ValidationResult("Deduction Date Required", new List<string> { "SchemeDetails" }));
                }


                if (this.frequency.ToUpper().Trim() != "MONTHLY" && this.frequency.ToUpper().Trim() != "QUARTERLY" && this.frequency.ToUpper().Trim() != "YEARLY" && this.frequency.ToUpper().Trim() != "FORTNIGHTLY" && this.frequency.ToUpper().Trim() != "WEEKLY")
                {
                    results.Add(new ValidationResult("Invalid frequency", new List<string> { "SchemeDetails" }));
                }
                bool fromdate = true;
                bool toDate = true;
                // some other random test
                if (!string.IsNullOrEmpty(this.sipFromDate))
                {
                    if (ParamValid.DateValidate(this.sipFromDate.Trim(), "yyyy-MM-dd") == false)
                    {
                        results.Add(new ValidationResult("Fromdate must be in format : yyyy-MM-dd", new List<string> { "SchemeDetails" }));
                        fromdate = false;
                    }
                }
                else
                {
                    results.Add(new ValidationResult("Fromdate Required", new List<string> { "SchemeDetails" }));
                    fromdate = false;
                }

                if (!string.IsNullOrEmpty(this.sipToDate))
                {
                    if (ParamValid.DateValidate(this.sipToDate.Trim(), "yyyy-MM-dd") == false)
                    {
                        results.Add(new ValidationResult("Todate must be in format : yyyy-MM-dd", new List<string> { "SchemeDetails" }));
                        toDate = false;
                    }
                }
                else
                {
                    results.Add(new ValidationResult("ToDate Required", new List<string> { "SchemeDetails" }));
                    toDate = false;
                }

                if (fromdate == true && toDate == true)
                {
                    if (Convert.ToDateTime(this.sipFromDate) > Convert.ToDateTime(this.sipToDate))
                    {
                        results.Add(new ValidationResult("toDate must be larger than fromDate"));
                    }
                }
                if (this.perpetual != true && this.perpetual != false)
                {
                    results.Add(new ValidationResult("Invalid prepetual flag.", new List<string> { "SchemeDetails" }));
                }
                if (this.noOfInstalment == 0)
                {
                    results.Add(new ValidationResult("No of intallment should not be Zero.", new List<string> { "SchemeDetails" }));
                }
            }

            return results;
        }
    }
    //BrokerDetails
    public class MFClientsBrokerDetailsRes
    {
        //public Int64 userId { get; set; }
        public string brokerCode { get; set; }
        public string subBroker { get; set; }
        public string subBrokerCode { get; set; }
        public string declarationEUIN { get; set; }
        public string codeEUIN { get; set; }
    }
    public class MFClientsBrokerDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        [Required]
        [DefaultValue("")]
        public string brokerCode { get; set; }
        [DefaultValue("")]
        public string subBroker { get; set; }
        [DefaultValue("")]
        public string subBrokerCode { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool declarationEUIN { get; set; }
        [DefaultValue("")]
        public string codeEUIN { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.brokerCode.Trim() == "" && this.brokerCode == null)
            {
                results.Add(new ValidationResult("Broker Code cannot be blank.", new List<string> { "BrokerDetails" }));
            }
            if (this.declarationEUIN != true && this.declarationEUIN != false)
            {
                results.Add(new ValidationResult("Invalid EUIN Declaration flag.", new List<string> { "BrokerDetails" }));
            }
            if (this.declarationEUIN == false)
            {
                if (this.codeEUIN.Trim() == "" || this.codeEUIN == null)
                {
                    results.Add(new ValidationResult("Invalid EUIN code.", new List<string> { "BrokerDetails" }));
                }
            }
            return results;
        }

    }

    //BankDetails
    public class MFClientsBankDetailsRes
    {
        //public Int64 userId { get; set; }
        public string ifscCode { get; set; }
        public string micrCode { get; set; }
        public string accountType { get; set; }
        public string bankName { get; set; }
        public string accountNo { get; set; }
        public string branchName { get; set; }
        public string branchAdd1 { get; set; }
        public string branchAdd2 { get; set; }
        public string branchAdd3 { get; set; }
        public string branchCity { get; set; }
        public string branchPincode { get; set; }
        public string paymentMode { get; set; }
        public byte[] chequeImage { get; set; }
    }
    public class MFClientsBankDetails : IValidatableObject
    {
        //[Required]
        //[DefaultValue(0)]
        //public Int64 userId { get; set; }
        [Required]
        [DefaultValue("")]
        public string ifscCode { get; set; }
        [Required]
        [DefaultValue("")]
        public string micrCode { get; set; }
        [Required]
        [DefaultValue("")]
        public string accountType { get; set; }
        [Required]
        [DefaultValue("")]
        public string bankName { get; set; }
        [Required]
        [DefaultValue("")]
        public string accountNo { get; set; }
        [Required]
        [DefaultValue("")]
        public string branchName { get; set; }
        [Required]
        [DefaultValue("")]
        public string branchAdd1 { get; set; }
        [DefaultValue("")]
        public string branchAdd2 { get; set; }
        [DefaultValue("")]
        public string branchAdd3 { get; set; }
        [Required]
        [DefaultValue("")]
        public string branchCity { get; set; }
        [Required]
        [DefaultValue(0)]
        public int branchPincode { get; set; }
        ///<summary>DCB|DC|UPI</summary>
        public string paymentMode { get; set; }
        public string chequeImage { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool saveForlater { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            ParamValid ParamValid = new ParamValid();
            var results = new List<ValidationResult>();
            if (this.ifscCode.Trim() == "" && this.ifscCode == null)
            {
                results.Add(new ValidationResult("IFSC Code cannot be blank.", new List<string> { "BankDetails" }));
            }
            //if (this.micrCode.Trim() == "" && this.micrCode == null)
            //{
            //    results.Add(new ValidationResult("MICR Code cannot be blank.", new List<string> { "BankDetails" }));
            //}
            if (this.accountType.ToUpper().Trim() != "CUR" && this.accountType.ToUpper().Trim() != "SAV" && this.accountType.ToUpper().Trim() != "FCN" && this.accountType.ToUpper().Trim() != "NRE" && this.accountType.ToUpper().Trim() != "NRO")
            {
                results.Add(new ValidationResult("Invalid Account Type", new List<string> { "BankDetails" }));
            }
            if (this.bankName.Trim() == "" && this.bankName == null)
            {
                results.Add(new ValidationResult("Bank Name cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.accountNo.Trim() == "" && this.accountNo == null)
            {
                results.Add(new ValidationResult("Account No cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.branchName.Trim() == "" && this.branchName == null)
            {
                results.Add(new ValidationResult("Branch Name cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.branchAdd1.Trim() == "" && this.branchAdd1 == null)
            {
                results.Add(new ValidationResult("Branch Address cannot be blank.", new List<string> { "BankDetails" }));
            }
            if (this.branchCity.Trim() == "" && this.branchCity == null)
            {
                results.Add(new ValidationResult("Branch City cannot be blank.", new List<string> { "BankDetails" }));
            }
            //if (this.branchPincode == 0 && this.branchPincode == null)
            //{
            //    results.Add(new ValidationResult("Branch City cannot be blank.", new List<string> { "BankDetails" })); 
            //}
            return results;
        }
    }

    //Get Client Details
    public class MFClientDetails
    {
        public MFPanDetails PanDetails { get; set; }
        public MFInvBasicDetails InvBasicDetails { get; set; }
        public MFNomineeDetails NomineeDetails { get; set; }
        public List<MFFatcaDetails> FatcaDetails { get; set; }
        public MFContactDetails ContactDetails { get; set; }
        public MFClientBankDetail BankDetail { get; set; }
        public MFClientFolioDetails FolioDetails { get; set; }
    }
    public class MFPanDetails
    {
        public string UserId { get; set; }
        public string PanNo { get; set; }
        public string Name { get; set; }
        public string OTPSent { get; set; }
        public string BranchCode { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
    }
    public class MFInvBasicDetails
    {
        public string ModeOfHolding { get; set; }
        public string FirstHolderTaxStatus { get; set; }
        public MFFirstHolderGurdian FirstHolderGurdian { get; set; }
        public List<HolderDetails> HolderDetails { get; set; }
    }
    public class MFFirstHolderGurdian
    {
        public string Name { get; set; }
        public string PanNo { get; set; }
        public string AadharNo { get; set; }
        public string KycStatus { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string Relation { get; set; }
        public string ScreenId { get; set; }
        public string DOB { get; set; }
        public string CreateDate { get; set; }
        public Boolean SaveForLater { get; set; }
    }
    public class HolderDetails
    {
        public string Category { get; set; }
        public string IfNri { get; set; }
        public string Occupation { get; set; }
        public string Title { get; set; }
        public string Name { get; set; }
        public string Dob { get; set; }
        public string PanNo { get; set; }
        public string AadharNo { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string LandlineNo { get; set; }
        public string KycStatus { get; set; }
        public string HFalg { get; set; }
    }
    //Nominee
    public class MFNomineeDetails
    {
        public Boolean WishToNominate { get; set; }
        public List<_NomineeDetails> NomineeDetails { get; set; }
    }
    public class _NomineeDetails
    {
        public string Title { get; set; }
        public string Name { get; set; }
        public string Dob { get; set; }
        public string Percent { get; set; }
        public Boolean AddresFlag { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Relationship { get; set; }
        public string GurdianTitle { get; set; }
        public string GurdianName { get; set; }
        public string GurdianPanNo { get; set; }
        public Boolean GurdianKycStatus { get; set; }
        public string HFlag { get; set; }
    }
    //FATCA
    public class MFFatcaDetails
    {
        public string IncomeSlab { get; set; }
        public string BirthCountry { get; set; }
        public string Nationality { get; set; }
        public Boolean TaxResidentNonIndian { get; set; }
        public string TaxResident { get; set; }
        public string ForeignTaxId { get; set; }
        public Boolean Pep { get; set; }
        public Boolean RelationalPep { get; set; }
        public string HFlag { get; set; }
    }
    //Contact Details
    public class MFContactDetails
    {
        public MFNRIContact NRIContact { get; set; }
        public List<MFContact> ContactDetails { get; set; }
    }
    public class MFNRIContact
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Zipcode { get; set; }
    }
    public class MFContact
    {
        public string Wing { get; set; }
        public string Area { get; set; }
        public string Landmark { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Pincode { get; set; }
        public string HFlag { get; set; }
    }
    //BankDetails
    public class MFClientBankDetail
    {
        public string IFSCCode { get; set; }
        public string MICRCode { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string AccountNo { get; set; }
        public string BranchName { get; set; }
        public string BranchAdd1 { get; set; }
        public string BranchAdd2 { get; set; }
        public string BranchAdd3 { get; set; }
        public string BranchCity { get; set; }
        public string BranchPincode { get; set; }
        public string PaymentMode { get; set; }
        public string ChequeImage { get; set; }
    }
    //FolioDetails
    public class MFClientFolioDetails
    {
        public string TrType { get; set; }
        public string FatcaFlag { get; set; }
        public string NomineeFlag { get; set; }
        public string FCOB { get; set; }
        public string CompanyCode { get; set; }
        public string EmployeeCode { get; set; }
        public string AccOpeningMode { get; set; }
        public string HoldingDematMode { get; set; }
        public string NSDLCDSL { get; set; }
        public string DPIdClientId { get; set; }
        public string MOGSIPFlag { get; set; }
        public string Res_App_Ref_No { get; set; }
        public string Res_GoalId { get; set; }
        public string Res_DateTimeStamp { get; set; }
        public string Res_Folio { get; set; }
        public string Res_TransactionId { get; set; }
        public string Res_Message { get; set; }
        public string Res_StatusCode { get; set; }
    }
    public class GetClientReq
    {
        public string PanNo { get; set; }
    }
}
