﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using APICore.Helpers;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using Serilog.Filters;

namespace MFTransaction
{
    public class Program
    {
        public static void Main(string[] args)
        {

            BuildWebHost(args).Run();
        }


        public static IWebHost BuildWebHost(string[] args) =>
             WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
            .UseSerilog((hostingContext, loggerConfiguration) => loggerConfiguration.ReadFrom
                    .Configuration(hostingContext.Configuration)
                    .WriteTo.Logger(lc => lc
                        .Filter.ByIncludingOnly(Matching.FromSource<ApiLoggingMiddleware>())
                        .WriteTo.File("logs/api/api_log_.log", rollingInterval: RollingInterval.Day,
                            rollOnFileSizeLimit: true,
                            fileSizeLimitBytes: 209715200, shared: true))
                    .WriteTo.Logger(lc => lc
                        .Filter.ByIncludingOnly(Matching.FromSource<ErrorHandlingMiddleware>())
                        .WriteTo.File("logs/error/error_log_.log", rollingInterval: RollingInterval.Day,
                            rollOnFileSizeLimit: true,
                            fileSizeLimitBytes: 209715200, shared: true))
                    .MinimumLevel.Override("Microsoft", LogEventLevel.Information))
             .UseKestrel(opt => opt.AddServerHeader = false)
                .Build();
    }
}
