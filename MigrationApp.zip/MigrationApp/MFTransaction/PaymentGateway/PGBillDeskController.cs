﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using ApiCore.Exceptions;
using APICore.Auth;
using APICore.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MFTransaction.Models;
using MFTransaction.Utils;

namespace MFTransaction.PaymentGateway
{
    [Produces("application/json")]
    [Route("api/PaymentGateway")]
    [ValidateModel]
  //  [Authorize]
    public class PGBillDeskController : ControllerBase
    {
        private readonly IPaymentGatewayDataSource _TransactionDataSource;
        public PGBillDeskController(TokenHelper tokenHelper, IPaymentGatewayDataSource TransactionDataSource)
        {
            _TransactionDataSource = TransactionDataSource;         
        }

        [HttpPost("OrderGeneration")]
        [Produces("application/json")]        
        [ProducesResponseType(typeof(ResponseDataModel<OrderResponse>), 200)]
        public async Task<IActionResult> PaymentOrderGeneration([FromBody] OrderRequest request)
        {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.PaymentOrderGeneration(AppId, request);
                return Ok(response);
        }

        [HttpPost("PaymentRequest")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<PaymentResponse>), 200)]
        public async Task<IActionResult> PaymentRequest([FromBody] PaymentRequest request)
        {
                var AppId = IdentityHelper.GetAppId(User.Identity);
                var response = await _TransactionDataSource.PaymentRequest(AppId, request);
                return Ok(response);
        }

        [HttpPost("PaymentRequestConfirmation")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<PaymentConfirmationRes>), 200)]
        public async Task<IActionResult> PaymentRequestConfirmation([FromBody] PaymentConfirm request)
        {
            var AppId = IdentityHelper.GetAppId(User.Identity);
            var response = await _TransactionDataSource.PaymentRequestConfirmation(AppId, request);
            return Ok(response);
        }

        [HttpPost("GetPaymentStatus")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<PaymentStatusResponse>), 200)]
        public async Task<IActionResult> GetPaymentStatus([FromBody] PaymentStatusRequest request)
        {
            var response = await _TransactionDataSource.GetPaymentStatus (request);
            return Ok(response);
        }

        [HttpPost("GetOrderGeneration")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<ReqSIPPending>), 200)]
        [HttpPost]
        public async Task<IActionResult> GetPaymentOrderGeneration()
        {
            string panNo = User.Identity.Name;
            var response = await _TransactionDataSource.GetPaymentOrderGeneration(panNo);
            return Ok(response);
        }
    }
}
