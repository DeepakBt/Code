﻿using ApiCore.DTOs;
using ApiCore.Model;
using MFTransaction.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MFTransaction.PaymentGateway
{
    public class PGRazorPayRepository : IPGRazorPayDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        string key = string.Empty;
        string secret = string.Empty;
        string orderapi = string.Empty;
        string orderId = string.Empty;
        string ErrorLogFile = "";
        public PGRazorPayRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            key = _iconfiguration["RazorPay:key"];
            secret = _iconfiguration["RazorPay:secret"];
            orderapi = _iconfiguration["RazorPay:orderapi"];
        }

        public async Task<ResponseDataModel<RazorOrderResponse>> PaymentOrderGeneration(string AppId, RazorOrderRequest req)
        {
            RazorOrderResponse oResponse = null;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(orderapi);
                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://prod-api-static.razorpay.com/");
                request.Method = "POST";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                string authString = string.Format("{0}:{1}", key, secret);
                request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(authString));

                long amount = 0;
                amount = Convert.ToInt64(string.Format("{0:0}", Convert.ToDouble(req.amount)));
                if (!string.IsNullOrEmpty(req.amount) && amount > 0)
                {
                    amount = amount * 100; // Razorpay accepts money in paisa so need to convert to rupees
                }

                Dictionary<string, object> input = new Dictionary<string, object>();
                input.Add("amount", amount); // this amount should be same as transaction amount
                input.Add("currency", req.currency);
                input.Add("receipt", req.receipt);
                input.Add("payment_capture", req.payment_capture);
                input.Add("method", req.method);
                input.Add("bank", "HDFC");
                if (!string.IsNullOrEmpty(req.account_number))
                {
                    object bank_account = new { account_number = req.account_number, name = req.name, ifsc = req.ifsc };
                    input.Add("bank_account", bank_account);
                }
                if (req.notes != null && req.notes.ToList().Count > 0)
                {
                    // input.Add("notes", req.notes);
                }
                var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(input));
                request.ContentLength = data.Length;

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                var orderResponse = (HttpWebResponse)request.GetResponse();

                JObject orderData = ParseResponse(orderResponse);
                orderId = orderData["id"].ToString();
                oResponse = new RazorOrderResponse();
                oResponse.orderid = orderId;
                return new ResponseDataModel<RazorOrderResponse>(oResponse);
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "PaymentOrderGeneration \r ERROR:" + ex.Message);
                return new ResponseDataModel<RazorOrderResponse>(null);

            }
        }

        public async Task<ResponseDataModel<ResponseOrderRes>> SaveOrderResponse(ResponseOrderReq req)
        {
            ResponseOrderRes obj = null;
            try
            {
                RazorpayClient client = new RazorpayClient(key, secret);

                Dictionary<string, string> attributes = new Dictionary<string, string>();

                attributes.Add("razorpay_payment_id", req.razorpay_payment_id);
                attributes.Add("razorpay_order_id", req.razorpay_order_id);
                attributes.Add("razorpay_signature", req.razorpay_signature);

                Utility.verifyPaymentSignature(attributes);
                obj = new ResponseOrderRes();
                obj.payment_status = "success";
                return new ResponseDataModel<ResponseOrderRes>(obj);
            }
            catch (Exception ex)
            {
                return new ResponseDataModel<ResponseOrderRes>(null, "Invalid Signature");
            }
        }

        private JObject ParseResponse(HttpWebResponse response)
        {
            string responseValue = string.Empty;
            using (var responseStream = response.GetResponseStream())
            {
                if (responseStream != null)
                    using (var reader = new StreamReader(responseStream))
                    {
                        responseValue = reader.ReadToEnd();
                    }
            }

            JObject responseObject = JObject.Parse(responseValue);

            return responseObject;
        }
    }
}

