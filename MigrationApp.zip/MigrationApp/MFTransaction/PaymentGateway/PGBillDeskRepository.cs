﻿using ApiCore.DTOs;
using ApiCore.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using MFTransaction.Models;
using System.Diagnostics;
using Dapper;

namespace MFTransaction.PaymentGateway
{
    public class PGBillDeskRepository : IPaymentGatewayDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private IDbConnection MOAMCPORTAL => new SqlConnection(_connections.ConAMCPORTAL);
        string PGAPIErrorLogFile = "";
        string SP_PGLog = string.Empty;
        string ErrorLogFile = string.Empty;
        public PGBillDeskRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            PGAPIErrorLogFile = _iconfiguration["PaymentGateway:PGAPIErrorLogFile"];
            SP_PGLog = _iconfiguration["PaymentGateway:SP_PGLog"];
        }

        public async Task<ResponseDataModel<OrderResponse>> PaymentOrderGeneration(string AppId, OrderRequest request)
        {
            OrderResponse paymentOrderResponse = new OrderResponse();
            try
            {
                string requestXML = string.Empty;
                string responseXML = string.Empty;
                decimal totalAmount = 0;
                int totalcount = Convert.ToInt32(request.itemDetails.Count);
                #region Working with Request XML 

                REQUESTTXNDATATXNSUMMARY rEQUESTTXNDATATXNSUMMARY = new REQUESTTXNDATATXNSUMMARY();

                rEQUESTTXNDATATXNSUMMARY.REQID = !string.IsNullOrEmpty(request.PG_REQID) ? request.PG_REQID : _iconfiguration["PaymentGateway:REQID"];
                rEQUESTTXNDATATXNSUMMARY.PGMERCID = !string.IsNullOrEmpty(request.PG_PGMERCID) ? request.PG_PGMERCID : _iconfiguration["PaymentGateway:PGMERCID"];
                rEQUESTTXNDATATXNSUMMARY.RECORDS = Convert.ToInt32(totalcount);
                rEQUESTTXNDATATXNSUMMARY.PGCUSTOMERID = request.MainOrderId;
                if (_iconfiguration["PaymentGateway:DebitAmountDefault"] == "Y")
                {
                    // totalAmount = Convert.ToDecimal((string.Format("{0:0.00}", Convert.ToDouble(_iconfiguration["PaymentGateway:DebitAmount"]))));
                    if (Convert.ToDouble(request.Amount) <= Convert.ToDouble(_iconfiguration["PaymentGateway:DebitAmount"]))
                    {
                        totalAmount = Convert.ToDecimal(string.Format("{0:0.00}", Convert.ToDouble(request.Amount)));
                    }
                    else
                    {
                       return new ResponseDataModel<OrderResponse>(null, "Amount Missmatch");
                    }
                }
                else
                {
                    totalAmount = Convert.ToDecimal(string.Format("{0:0.00}", Convert.ToDouble(request.Amount)));
                }
                rEQUESTTXNDATATXNSUMMARY.AMOUNT = totalAmount; //Convert.ToDecimal(Convert.ToString(request.Amount));
                rEQUESTTXNDATATXNSUMMARY.TXNDATE = !string.IsNullOrEmpty(request.TimeStamp) ? Convert.ToUInt64(Convert.ToDateTime(request.TimeStamp).ToString("yyyyMMddHHmmss")) : Convert.ToUInt64(DateTime.Now.ToString("yyyyMMddHHmmss")); //server


                double suborderAmount = 0;
                if (totalcount > 0)  // for testing we have enable for 10 Rs total amt 
                {
                    suborderAmount = (double)rEQUESTTXNDATATXNSUMMARY.AMOUNT / totalcount;
                }
                //suborderAmount = (double)rEQUESTTXNDATATXNSUMMARY.AMOUNT;

                string FinalsuborderAmount = Convert.ToString(string.Format("{0:0.00}", suborderAmount)); //String.Format("{0:C}", suborderAmount);
                List<REQUESTTXNDATARECORD> rEQUESTTXNDATARECORDs = new List<REQUESTTXNDATARECORD>();
                if (request.itemDetails.Count > 0)
                {
                    int RecordId = 1;
                    for (int i = 0; i < request.itemDetails.Count; i++)
                    {
                        REQUESTTXNDATARECORD rEQUESTTXNDATARECORD = new REQUESTTXNDATARECORD();
                        rEQUESTTXNDATARECORD.ID = Convert.ToString(RecordId);
                        rEQUESTTXNDATARECORD.MERCID = !string.IsNullOrEmpty(request.PG_MERCHANTID) ? request.PG_MERCHANTID : _iconfiguration["PaymentGateway:MERCHANTID"]; //"MOSLSCHEME"; //appsetting
                        rEQUESTTXNDATARECORD.AMOUNT = _iconfiguration["PaymentGateway:DebitAmountDefault"] == "Y" ? Convert.ToDecimal(FinalsuborderAmount) : Convert.ToDecimal(string.Format("{0:0.00}", Convert.ToDouble(request.itemDetails[i].Amount)));
                        rEQUESTTXNDATARECORD.CUSTOMERID = request.itemDetails[i].ChildOrderId;
                        rEQUESTTXNDATARECORD.ADDITIONALINFO1 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO1) ? request.PG_ADDITIONALINFO1 : "NA";
                        rEQUESTTXNDATARECORD.ADDITIONALINFO2 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO2) ? request.PG_ADDITIONALINFO2 : "NA";
                        rEQUESTTXNDATARECORD.ADDITIONALINFO3 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO3) ? request.PG_ADDITIONALINFO3 : "NA";
                        rEQUESTTXNDATARECORD.ADDITIONALINFO4 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO4) ? request.PG_ADDITIONALINFO4 : "NA";
                        rEQUESTTXNDATARECORD.ADDITIONALINFO5 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO5) ? request.PG_ADDITIONALINFO5 : "NA";
                        rEQUESTTXNDATARECORD.ADDITIONALINFO6 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO6) ? request.PG_ADDITIONALINFO6 : "NA";
                        rEQUESTTXNDATARECORD.ADDITIONALINFO7 = !string.IsNullOrEmpty(request.PG_ADDITIONALINFO7) ? request.PG_ADDITIONALINFO7 : "NA";
                        rEQUESTTXNDATARECORD.FILLER1 = !string.IsNullOrEmpty(request.PG_FILLER1) ? request.PG_FILLER1 : "NA";
                        rEQUESTTXNDATARECORD.FILLER2 = !string.IsNullOrEmpty(request.PG_FILLER2) ? request.PG_FILLER2 : "NA";
                        rEQUESTTXNDATARECORD.FILLER3 = !string.IsNullOrEmpty(request.PG_FILLER3) ? request.PG_FILLER3 : "NA";

                        rEQUESTTXNDATARECORDs.Add(rEQUESTTXNDATARECORD);

                        RecordId++;
                    }
                }

                REQUESTTXNDATA rEQUESTTXNDATA = new REQUESTTXNDATA();
                rEQUESTTXNDATA.TXNSUMMARY = rEQUESTTXNDATATXNSUMMARY;
                rEQUESTTXNDATA.RECORD = rEQUESTTXNDATARECORDs.ToArray();

                REQUEST rEQUEST = new REQUEST();
                rEQUEST.TXNDATA = rEQUESTTXNDATA;

                #endregion

                #region Generating CheckSum of Request TXNDATA tag

                string request_TXNDATA = rEQUEST.Serialize();
                XmlDocument d = new XmlDocument();
                d.LoadXml(request_TXNDATA);
                request_TXNDATA = d.ChildNodes[1].InnerXml;

                UTF8Encoding encoder = new UTF8Encoding();
                string key = !string.IsNullOrEmpty(request.PG_CHECKSUMKEY) ? request.PG_CHECKSUMKEY : _iconfiguration["PaymentGateway:CHECKSUMKEY"]; //"OswOSeGHw7W9";
                byte[] hashValue;
                byte[] keybyt = encoder.GetBytes(key);
                byte[] message = encoder.GetBytes(request_TXNDATA);

                HMACSHA256 hashString = new HMACSHA256(keybyt);
                string hex = "";
                hashValue = hashString.ComputeHash(message);
                foreach (byte x in hashValue)
                {
                    hex += String.Format("{0:x2}", x);
                }
                hex = hex.ToUpper();

                rEQUEST.CHECKSUM = hex;

                #endregion

                #region Calling BillDesk API for Order generation

                requestXML = rEQUEST.Serialize();

                //File.AppendAllText(PGAPIErrorLogFile, "\n\n Request API:" + requestXML + DateTime.Now.ToString());
                string url = _iconfiguration["PaymentGateway:ORDERAPI"] + requestXML; //"https://payments.billdesk.com/ecom/ECOM2ReqHandler?msg=" + requestXML;
                using (var client = new WebClient())
                {
                    responseXML = client.DownloadString(url);
                }

                // File.AppendAllText(PGAPIErrorLogFile, "\n\n Response API:" + responseXML + DateTime.Now.ToString());

                await PGLog_Insert(request.MainOrderId, requestXML, responseXML, "", "");
                #endregion

                #region Working with Response XML

                RESPONSETXNDATATXNSUMMARY rESPONSETXNDATATXNSUMMARY = new RESPONSETXNDATATXNSUMMARY();
                //RESPONSETXNDATARECORD rESPONSETXNDATARECORD = new RESPONSETXNDATARECORD();
                RESPONSETXNDATA rESPONSETXNDATA = new RESPONSETXNDATA();
                List<RESPONSETXNDATARECORD> rESPONSETXNDATARECORDs = new List<RESPONSETXNDATARECORD>();
                RESPONSE rESPONSE = new RESPONSE();

                XmlDocument xmlDoc = new XmlDocument();
                if (!string.IsNullOrEmpty(responseXML))
                {
                    xmlDoc.LoadXml(responseXML);
                    rESPONSETXNDATATXNSUMMARY.PGMERCID = xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/PGMERCID").InnerText;
                    rESPONSETXNDATATXNSUMMARY.PGCUSTOMERID = xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/PGCUSTOMERID").InnerText;
                    rESPONSETXNDATATXNSUMMARY.RECORDS = Convert.ToByte(xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/RECORDS").InnerText);
                    rESPONSETXNDATATXNSUMMARY.AMOUNT = Convert.ToDecimal(xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/AMOUNT").InnerText);
                    rESPONSETXNDATATXNSUMMARY.STATUSCODE = Convert.ToByte(xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/STATUSCODE").InnerText);
                    rESPONSETXNDATATXNSUMMARY.STATUSDESC = xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/STATUSDESC").InnerText;
                    rESPONSETXNDATATXNSUMMARY.FILLER1 = xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/FILLER1").InnerText;
                    rESPONSETXNDATATXNSUMMARY.FILLER2 = xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/FILLER2").InnerText;
                    rESPONSETXNDATATXNSUMMARY.FILLER3 = xmlDoc.SelectSingleNode("RESPONSE/TXNDATA/TXNSUMMARY/FILLER3").InnerText;
                    rESPONSETXNDATA.TXNSUMMARY = rESPONSETXNDATATXNSUMMARY;

                    XmlNodeList nodes = xmlDoc.SelectNodes("RESPONSE/TXNDATA/RECORD");
                    if (nodes.Count > 0)
                    {
                        foreach (XmlNode node in nodes)
                        {
                            RESPONSETXNDATARECORD rESPONSETXNDATARECORD = new RESPONSETXNDATARECORD();
                            rESPONSETXNDATARECORD.ID = Convert.ToByte(node.Attributes["ID"].Value);
                            rESPONSETXNDATARECORD.CUSTOMERID = node.SelectSingleNode("CUSTOMERID").InnerText;
                            rESPONSETXNDATARECORD.ECOMTXNID = node.SelectSingleNode("ECOMTXNID").InnerText;
                            rESPONSETXNDATARECORDs.Add(rESPONSETXNDATARECORD);
                        }
                    }
                    rESPONSETXNDATA.RECORD = rESPONSETXNDATARECORDs.ToArray();

                    rESPONSE.TXNDATA = rESPONSETXNDATA;
                    rESPONSE.CHECKSUM = xmlDoc.SelectSingleNode("RESPONSE/CHECKSUM").InnerText;
                }

                #endregion

                #region Generating Output

                paymentOrderResponse.PGMercID = rESPONSETXNDATATXNSUMMARY.PGMERCID;
                paymentOrderResponse.PGCustomerID = rESPONSETXNDATATXNSUMMARY.PGCUSTOMERID;
                paymentOrderResponse.Records = Convert.ToString(rESPONSETXNDATATXNSUMMARY.RECORDS);
                paymentOrderResponse.Amount = Convert.ToString(rESPONSETXNDATATXNSUMMARY.AMOUNT);
                paymentOrderResponse.StatusCode = Convert.ToString(rESPONSETXNDATATXNSUMMARY.STATUSCODE);
                paymentOrderResponse.StatusDesc = rESPONSETXNDATATXNSUMMARY.STATUSDESC;
                paymentOrderResponse.Filler1 = rESPONSETXNDATATXNSUMMARY.FILLER1;
                paymentOrderResponse.Filler2 = rESPONSETXNDATATXNSUMMARY.FILLER2;
                paymentOrderResponse.Filler3 = rESPONSETXNDATATXNSUMMARY.FILLER3;

                List<OrderRecordRes> paymentOrderResRecords = new List<OrderRecordRes>();
                foreach (var item in rESPONSETXNDATARECORDs)
                {
                    OrderRecordRes paymentOrderResRecord = new OrderRecordRes();
                    paymentOrderResRecord.CustomerID = item.CUSTOMERID;
                    paymentOrderResRecord.EComTxnID = item.ECOMTXNID;
                    paymentOrderResRecords.Add(paymentOrderResRecord);
                }
                paymentOrderResponse.resItemDetails = paymentOrderResRecords;
                paymentOrderResponse.Checksum = rESPONSE.CHECKSUM;
                return new ResponseDataModel<OrderResponse>(paymentOrderResponse);
                #endregion

            }
            catch (Exception ex)
            {
                File.AppendAllText(PGAPIErrorLogFile, "\n\n Order API Exception API:" + ex.Message + " " + DateTime.Now.ToString());
                paymentOrderResponse.ExceptionMsg = ex.Message.ToString();
                var st = new StackTrace(ex, true);
                // Get the top stack frame
                var frame = st.GetFrame(1);
                // Get the line number from the stack frame
                string line = Convert.ToString(frame.GetFileLineNumber());
                paymentOrderResponse.ExceptionLineNo = line;
                return new ResponseDataModel<OrderResponse>(paymentOrderResponse);
            }
        }

        public async Task<ResponseDataModel<PaymentResponse>> PaymentRequest(string AppId, PaymentRequest request)
        {
            PaymentResponse paymentResponse = new PaymentResponse();
            try
            {
                string strRequest = string.Empty;
                string BilldeskAPI = string.Empty;
                string MerchantID = !string.IsNullOrEmpty(request.PG_MerchantID) ? request.PG_MerchantID : _iconfiguration["PaymentGateway:PGMERCID"];
                var CurrencyType = !string.IsNullOrEmpty(request.PG_CurrencyType) ? request.PG_CurrencyType : _iconfiguration["PaymentGateway:CurrencyType"];
                var ProductID = !string.IsNullOrEmpty(request.PG_ProductID) ? request.PG_ProductID : _iconfiguration["PaymentGateway:ProductID"];
                var TypeField1 = !string.IsNullOrEmpty(request.PG_TypeField1) ? request.PG_TypeField1 : _iconfiguration["PaymentGateway:TypeField1"];
                var TypeField2 = !string.IsNullOrEmpty(request.PG_TypeField2) ? request.PG_TypeField2 : _iconfiguration["PaymentGateway:TypeField2"];
                var SecurityID = !string.IsNullOrEmpty(request.PG_SecurityID) ? request.PG_SecurityID : _iconfiguration["PaymentGateway:SecurityID"];

                string AdditionalInfo1 = !string.IsNullOrEmpty(request.PG_AdditionalInfo1) ? request.PG_AdditionalInfo1 : "NA";
                string AdditionalInfo2 = !string.IsNullOrEmpty(request.PG_AdditionalInfo2) ? request.PG_AdditionalInfo2 : "NA";
                string AdditionalInfo3 = !string.IsNullOrEmpty(request.PG_AdditionalInfo3) ? request.PG_AdditionalInfo3 : "NA";
                string AdditionalInfo4 = !string.IsNullOrEmpty(request.PG_AdditionalInfo4) ? request.PG_AdditionalInfo4 : "NA";
                string AdditionalInfo5 = !string.IsNullOrEmpty(request.PG_AdditionalInfo5) ? request.PG_AdditionalInfo5 : "NA";
                string AdditionalInfo6 = !string.IsNullOrEmpty(request.PG_AdditionalInfo6) ? request.PG_AdditionalInfo6 : "NA";
                string AdditionalInfo7 = !string.IsNullOrEmpty(request.PG_AdditionalInfo7) ? request.PG_AdditionalInfo7 : "NA";
                //strRequest = MerchantID + "|" + Convert.ToString(request.MainOrderId).Trim() + "|" + Convert.ToString(request.BankAccNo).Trim() + "|" + string.Format("{0:0.00}", request.TxnAmount).Trim() + "|" + request.BankID + "|NA|NA|" + CurrencyType + "|" + ProductID + "|" + TypeField1 + "|" + Convert.ToString(SecurityID).ToLower().Trim() + "|NA|NA|" + TypeField2 + "|" + Convert.ToString(request.SchemeName).Trim() + "|" + Convert.ToString(request.LastRecordedNAV).Trim() + "|" + Convert.ToString(request.TransactionType).Trim() + "|" + Convert.ToString(request.StartDate).Trim() + "|" + Convert.ToString(request.EndDate).Trim() + "|NA|NA|" + request.ReturnURL;
                //if (!string.IsNullOrEmpty(request.Mode))
                //{
                if (string.IsNullOrEmpty(request.Mode))
                { request.Mode = "NETBANKING"; }
                if (request.Mode.ToUpper() == "NETBANKING")
                {
                    BilldeskAPI = _iconfiguration["PaymentGateway:PaymentAPI"];
                    // MerchantID|CustomerID|InvestorBankAccntNo|TxnAmount|BANKID|NA|NA|CurrencyType|PRODUCTID|TypeField1|SecurityID|NA|NA|TypeField2|AdditionalInfo1|AdditionalInfo2|AdditionalInfo3|AdditionalInfo4|AdditionalInfo5|AdditionalInfo6|AdditionalInfo7|RU|Checksum 
                    strRequest = MerchantID + "|" + Convert.ToString(request.MainOrderId).Trim() + "|" + Convert.ToString(request.BankAccNo).Trim() + "|" + string.Format("{0:0.00}", request.TxnAmount).Trim() + "|" + request.BankID + "|NA|NA|" + CurrencyType + "|" + ProductID + "|" + TypeField1 + "|" + Convert.ToString(SecurityID).ToLower().Trim() + "|NA|NA|" + TypeField2 + "|" + AdditionalInfo1 + "|" + AdditionalInfo2 + "|" + AdditionalInfo3 + "|" + AdditionalInfo4 + "|" + AdditionalInfo5 + "|" + AdditionalInfo6 + "|" + AdditionalInfo7 + "|" + request.PG_ReturnURL;
                }
                if (request.Mode.ToUpper() == "CARD")
                {
                    //https://www.billdesk.com/pgidsk/PGICommonGateway?hidRequestId=PGIME1000&hidOperation=ME100 
                    BilldeskAPI = _iconfiguration["PaymentGateway:BilldeskCardAPI"];

                    //MerchantID|CustomerID|NA|TxnAmount|NA|NA|NA|CurrencyType|DIRECT|TypeField1|SecurityID|NA|NA|TypeField2|AdditionalInfo1|AdditionalInfo2|AdditionalInfo3|AdditionalInfo4|AdditionalInfo5|AdditionalInfo6|AdditionalInfo7|RU|Checksum 
                    strRequest = MerchantID + "|" + Convert.ToString(request.MainOrderId).Trim() + "|NA|" + string.Format("{0:0.00}", request.TxnAmount).Trim() + "|NA|NA|NA|" + CurrencyType +"|DIRECT" + "|" + TypeField1 + "|" + Convert.ToString(SecurityID).ToLower().Trim() + "|NA|NA|" + TypeField2 + "|" + AdditionalInfo1 + "|" + AdditionalInfo2 + "|" + AdditionalInfo3 + "|" + AdditionalInfo4 + "|" + AdditionalInfo5 + "|" + AdditionalInfo6 + "|" + AdditionalInfo7 + "|" + request.PG_ReturnURL;
                }
                //}

                #region Start of CheckSum for XMLData tag
                UTF8Encoding encoder = new UTF8Encoding();
                string key = !string.IsNullOrEmpty(request.PG_ChecksumKey) ? request.PG_ChecksumKey : _iconfiguration["PaymentGateway:CHECKSUMKEY"]; ; //"OswOSeGHw7W9";
                byte[] hashValue;
                byte[] keybyt = encoder.GetBytes(key);
                byte[] message = encoder.GetBytes(strRequest);

                HMACSHA256 hashString = new HMACSHA256(keybyt);
                string hex = "";
                hashValue = hashString.ComputeHash(message);
                foreach (byte x in hashValue)
                {
                    hex += String.Format("{0:x2}", x);
                }
                hex = hex.ToUpper();
                #endregion

                strRequest = strRequest + "|" + hex;
                await PGLog_Insert(request.MainOrderId, "", "", strRequest, "");
                //   File.AppendAllText(PGAPIErrorLogFile, "\n\n Payment API Request:" + strRequest + DateTime.Now.ToString());
                paymentResponse.PaymentURL = BilldeskAPI + strRequest; // "https://www.billdesk.com/pgidsk/PGIMerchantRequestHandler?hidRequestId=PGIME1000&hidOperation=ME100&msg=" + strRequest;
                return new ResponseDataModel<PaymentResponse>(paymentResponse);
            }
            catch (Exception ex)
            {
                File.AppendAllText(PGAPIErrorLogFile, "\n\n Payment API Error:" + ex.Message.ToString() + " " + DateTime.Now.ToString());
                paymentResponse.ExceptionMsg = ex.Message.ToString();
                var st = new StackTrace(ex, true);
                // Get the top stack frame
                var frame = st.GetFrame(0);
                // Get the line number from the stack frame
                string line = Convert.ToString(frame.GetFileLineNumber());
                paymentResponse.ExceptionLineNo = line;
                return new ResponseDataModel<PaymentResponse>(paymentResponse);
            }
        }

        public async Task<ResponseDataModel<PaymentConfirmationRes>> PaymentRequestConfirmation(string AppId, PaymentConfirm request)
        {
            PaymentConfirmationRes PaymentConfirmationRes = new PaymentConfirmationRes();
            PaymentConfirmationRes.pmsCode = Convert.ToString(request.itemCode) ?? "";
            PaymentConfirmationRes.strategyName = Convert.ToString(request.transactionNo) ?? "";
            PaymentConfirmationRes.transactionRefrenceNumber = Convert.ToString(request.transactionReferenceNo) ?? "";
            PaymentConfirmationRes.transactionAmount = request.transactionAmount;
            return new ResponseDataModel<PaymentConfirmationRes>(PaymentConfirmationRes);

        }

        public async Task<ResponseDataModel<PaymentStatusResponse>> GetPaymentStatus(PaymentStatusRequest request)
        {
            PaymentStatusResponse ObjRes = new PaymentStatusResponse();
            try
            {
                string PayStatusAPI = _iconfiguration["PaymentGateway:PaymentStatusAPI"];
                string QueryStr = string.Empty;

                // strRequest = MerchantID + "|" + Convert.ToString(request.MainOrderId).Trim() + "|" + Convert.ToString(request.BankAccNo).Trim() + "|" + string.Format("{0:0.00}", request.TxnAmount).Trim() + "|" + request.BankID + "|NA|NA|" + CurrencyType + "|" + ProductID + "|" + TypeField1 + "|" + Convert.ToString(SecurityID).ToLower().Trim() + "|NA|NA|" + TypeField2 + "|" + AdditionalInfo1 + "|" + AdditionalInfo2 + "|" + AdditionalInfo3 + "|" + AdditionalInfo4 + "|" + AdditionalInfo5 + "|" + AdditionalInfo6 + "|" + AdditionalInfo7 + "|" + request.PG_ReturnURL;
                QueryStr = Convert.ToString(_iconfiguration["PaymentGateway:PaymentStatusReqType"]) + "|" + Convert.ToString(_iconfiguration["PaymentGateway:PGMERCID"]) + "|" + Convert.ToString(request.CustomerID) + "|" + Convert.ToString(DateTime.Now.ToString("yyyyMMddHHmmss"));


                UTF8Encoding encoder = new UTF8Encoding();
                string key = !string.IsNullOrEmpty(request.Checksum) ? request.Checksum : _iconfiguration["PaymentGateway:CHECKSUMKEY"];
                byte[] hashValue;
                byte[] keybyt = encoder.GetBytes(key);
                byte[] message = encoder.GetBytes(QueryStr);

                HMACSHA256 hashString = new HMACSHA256(keybyt);
                string hex = "";
                hashValue = hashString.ComputeHash(message);
                foreach (byte x in hashValue)
                {
                    hex += String.Format("{0:x2}", x);
                }
                hex = hex.ToUpper();

                if (request.Checksum == null || request.Checksum == "")
                {
                    QueryStr = QueryStr + "|" + hex;
                }
                else
                {
                    QueryStr = QueryStr + "|" + request.Checksum;
                }

                using (var client = new WebClient())
                {
                    ObjRes._PaymentStatus = client.DownloadString(PayStatusAPI + QueryStr);
                }
                return new ResponseDataModel<PaymentStatusResponse>(ObjRes);
            }
            catch (Exception ex)
            {
                PGAPIErrorLogFile = _iconfiguration["ErrorLogFile"];
                PGAPIErrorLogFile = PGAPIErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(PGAPIErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetPaymentStatus \r CustomerID :" + Convert.ToString(request.CustomerID) + " ERROR:" + ex.Message);
                return new ResponseDataModel<PaymentStatusResponse>(null, Convert.ToString(ex.Message));
            }
        }

        public async Task<string> PGLog_Insert(string MainOrderId, string Req_XML, string Res_XML, string Req_PGString, string Res_PGString)
        {
            using (var conn = MOAMCPORTAL)
            {
                var dataLog = await conn.QueryAsync(SP_PGLog, new
                {
                    BucketId = MainOrderId,
                    Req_XML,
                    Res_XML,
                    Req_PGString
                }, commandType: CommandType.StoredProcedure);
                {
                    var LogRes = dataLog.ToList();
                    return "";
                }
            }
        }

        public async Task<ResponseDataModel<ReqSIPPending>> GetPaymentOrderGeneration(string PanNo)
        {
            ReqSIPPending ObjResponse = new ReqSIPPending();
            List<OrderRecord> lstOrder = new List<OrderRecord>();
            ObjResponse._OrderRequest = new OrderRequest();
            ObjResponse._OrderRequest.itemDetails = new List<OrderRecord>();
            try
            {
                using (var conn = MOAMCPORTAL)
                {
                    var dataSave = await conn.QueryMultipleAsync("MF.GET_TRANSACTION_SIP_PENDING_DETAILS", new
                    {
                        PanNo = PanNo
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var MainOrder = dataSave.Read<OrderRequest>().First();
                        var ChildOrder = dataSave.Read<OrderRecord>().ToList();
                        var BankDetails = dataSave.Read<ReqSIPPending>().First();

                        ObjResponse._OrderRequest.MainOrderId = Convert.ToString(MainOrder.MainOrderId) ?? "";
                        ObjResponse._OrderRequest.Amount = Convert.ToString(MainOrder.Amount) ?? "";
                        ObjResponse._OrderRequest.TimeStamp = Convert.ToString(MainOrder.TimeStamp) ?? "";
                        ObjResponse.BankAccNo = Convert.ToString(BankDetails.BankAccNo) ?? "";
                        ObjResponse.BankId = Convert.ToString(BankDetails.BankId) ?? "";
                        ObjResponse.FolioNo = Convert.ToString(BankDetails.FolioNo) ?? "";

                        if (ChildOrder.Count() > 0)
                        {
                            for (int i = 0; i <= ChildOrder.Count() - 1; i++)
                            {
                                OrderRecord ObjOList = new OrderRecord();
                                ObjOList.Amount = Convert.ToString(ChildOrder[i].Amount) ?? "";
                                ObjOList.ChildOrderId = Convert.ToString(ChildOrder[i].ChildOrderId) ?? "";
                                lstOrder.Add(ObjOList);
                            }
                            ObjResponse._OrderRequest.itemDetails = lstOrder;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetPaymentOrderGeneration \r ERROR:" + ex.Message);
                return new ResponseDataModel<ReqSIPPending>(null, ex.Message);
            }
            return new ResponseDataModel<ReqSIPPending>(ObjResponse);
        }
    }
}
