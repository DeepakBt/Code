﻿using ApiCore.DTOs;
using MFTransaction.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MFTransaction.PaymentGateway
{
    public interface IPGRazorPayDataSource
    {
        Task<ResponseDataModel<RazorOrderResponse>> PaymentOrderGeneration(string AppId, RazorOrderRequest request);
        Task<ResponseDataModel<ResponseOrderRes>> SaveOrderResponse(ResponseOrderReq request);


    }
}
