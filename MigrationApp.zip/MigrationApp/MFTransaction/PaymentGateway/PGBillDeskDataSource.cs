﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using MFTransaction.Models;

namespace MFTransaction.PaymentGateway
{
    public interface IPaymentGatewayDataSource
    {
        Task<ResponseDataModel<OrderResponse>> PaymentOrderGeneration(string AppId, OrderRequest request);
        Task<ResponseDataModel<PaymentResponse>> PaymentRequest(string AppId, PaymentRequest request);
        Task<ResponseDataModel<PaymentConfirmationRes>> PaymentRequestConfirmation(string AppId, PaymentConfirm request);
        Task<ResponseDataModel<PaymentStatusResponse>> GetPaymentStatus(PaymentStatusRequest request);
        Task<ResponseDataModel<ReqSIPPending>> GetPaymentOrderGeneration(string PanNo);
    }
}
