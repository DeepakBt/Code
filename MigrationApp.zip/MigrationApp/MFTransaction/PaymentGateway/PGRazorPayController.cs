﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using APICore.Auth;
using APICore.Helpers;
using MFTransaction.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace MFTransaction.PaymentGateway
{
    [Route("api/PGRazorPay")]
    [ValidateModel]

    public class PGRazorPayController : ControllerBase
    {
        private readonly IPGRazorPayDataSource _PGRazorPayDataSource;
        public PGRazorPayController(IPGRazorPayDataSource PGRazorPayDataSource)
        {
            _PGRazorPayDataSource = PGRazorPayDataSource;
        }

        [HttpPost("OrderGeneration")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> PaymentOrderGeneration([FromBody] RazorOrderRequest request)
        {
            var AppId = IdentityHelper.GetAppId(User.Identity);
            var response = await _PGRazorPayDataSource.PaymentOrderGeneration(AppId, request);
            return Ok(response);
        }

        [EnableCors("MOSLPolicy")]
        [HttpPost("SaveOrderResponse")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> OrderResponse([FromBody] ResponseOrderReq request)
        {
           // var AppId = IdentityHelper.GetAppId(User.Identity);
            var response = await _PGRazorPayDataSource.SaveOrderResponse(request);
            return Ok(response);
        }
    }
}