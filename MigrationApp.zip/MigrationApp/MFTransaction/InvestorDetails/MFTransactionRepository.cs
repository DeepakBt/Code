﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using ApiCore.Model;
using karvyAPI;
using MFTransaction.Models;
using MFTransaction.Utils;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Configuration;
using Dapper;
using ApiCore.Exceptions;
using System.IO;
using System.Collections.Generic;
using ApiCore.Helpers;
namespace MFTransaction.InvestorDetails
{
    public class MFTransactionRepository : IMFTransactionDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly TokenHelper _tokenHelper;
        private string ErrorLogFile = string.Empty;
        string serviceUrl = string.Empty;
        string Adminusername = string.Empty;
        string Adminpassword = string.Empty;
        string KarvTrnAPIName = string.Empty;
        string KarvTrnConfAPI = string.Empty;
        string KarvyEMandateAPI = string.Empty;
        string ReqLog = string.Empty;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        public MFTransactionRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
            serviceUrl = _iconfiguration["StaticPath:URL:serviceUrl"];
            Adminusername = _iconfiguration["StaticPath:URL:Adminusername"];
            Adminpassword = _iconfiguration["StaticPath:URL:Adminpassword"];
            KarvTrnAPIName = _iconfiguration["StaticPath:URL:MFTransactionAPIName"];
            KarvTrnConfAPI = _iconfiguration["StaticPath:URL:MFTransactionConfAPIName"];
            KarvyEMandateAPI= _iconfiguration["StaticPath:URL:EMandateAPI"];
        }
        public async Task<ResponseDataModel<TransactionResponse>> saveMFClientTransactionSubmit(string AppID, long userId, TransactionRequest request,string PanNo,string UserAgent)
        {
            TransactionResponse finalSubmitRes = new TransactionResponse();
            TransactionReqResponse objTransactionReqResponse = new TransactionReqResponse();
            List<SipInvResponseDtl> LstsipInvResponseDtls = new List<SipInvResponseDtl>();
            List<LumpsumInvResponseDtl> LstLumpsumInvResponseDtls = new List<LumpsumInvResponseDtl>();
            string inputJson = string.Empty;
            string ReqResponseXML = string.Empty;
            try
            {
                for(int i = 0; i < request.LumpsumInvestmentDetails.Count(); i++)
                {
                    request.LumpsumInvestmentDetails[i].OrderId = "OrderId_" + Convert.ToString(i+1);
                }
                for(int i=0;i<request.SIPInvestmentDetails.Count();i++)
                {
                    request.SIPInvestmentDetails[i].OrderId= "OrderId_" + Convert.ToString(i+1);
                }
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_MFTnx_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                    File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId)+"\r PanNo :"+Convert.ToString(PanNo) + "\r Request :" + inputJson);
                }
                objTransactionReqResponse._TransactionRequest = request;
                var result = KarvyRequest.CreateHTTPRequest(KarvTrnAPIName, serviceUrl, inputJson);
                var _Jobj = JObject.Parse(result);

                finalSubmitRes.BucketId = Convert.ToString(_Jobj["BucketId"]);
                finalSubmitRes.Campaign= Convert.ToString(_Jobj["Campaign"]);
                finalSubmitRes.TotalInvestAMount = Convert.ToString(_Jobj["TotalInvestAMount"]);
                finalSubmitRes.MORefNo= Convert.ToString(_Jobj["MORefNo"]);
                finalSubmitRes.TimeStamp = Convert.ToString(_Jobj["TimeStamp"]);
                finalSubmitRes.Message = Convert.ToString(_Jobj["Message"]);
                finalSubmitRes.BankId = Convert.ToString(_Jobj["BankId"]);
                finalSubmitRes.Status_Code = Convert.ToString(_Jobj["Status_Code"]);
                if (_Jobj["SipInvResponseDtls"].Count()>0)
                {
                    for (int i =0; i< _Jobj["SipInvResponseDtls"].Count();i++)
                    {
                        SipInvResponseDtl objSipInvResponseDtl = new SipInvResponseDtl();
                        objSipInvResponseDtl.Amount = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Amount"]);
                        objSipInvResponseDtl.FolioNo= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["FolioNo"]);
                        objSipInvResponseDtl.Frequency= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Frequency"]);
                        objSipInvResponseDtl.GoalId= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["GoalId"]);
                        objSipInvResponseDtl.Message= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Message"]);
                        objSipInvResponseDtl.MOGPFREEZE= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["MOGPFREEZE"]);
                        objSipInvResponseDtl.MOGPID= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["MOGPID"]);
                        objSipInvResponseDtl.NoOfInstallment= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["NoOfInstallment"]);
                        objSipInvResponseDtl.Option= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Option"]);
                        objSipInvResponseDtl.Plan= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Plan"]);
                        objSipInvResponseDtl.Scheme= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Scheme"]);
                        objSipInvResponseDtl.SIPEndDate= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["SIPEndDate"]);
                        objSipInvResponseDtl.SIPStartDate= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["SIPStartDate"]);
                        objSipInvResponseDtl.Status_Code= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["Status_Code"]);
                        objSipInvResponseDtl.TIME_STAMP = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TIME_STAMP"]);
                        objSipInvResponseDtl.TransRefNo = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TransRefNo"]);
                        objSipInvResponseDtl.TrType= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["TrType"]);
                        objSipInvResponseDtl.UMRNexpirydate= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["UMRNexpirydate"]);
                        objSipInvResponseDtl.UMRNNo= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["UMRNNo"]);
                        objSipInvResponseDtl.URNexpirydate= Convert.ToString(_Jobj["SipInvResponseDtls"][i]["URNexpirydate"]);
                        objSipInvResponseDtl.URNNO = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["URNNO"]);
                        objSipInvResponseDtl.OrderId = Convert.ToString(_Jobj["SipInvResponseDtls"][i]["OrderId"]);
                        LstsipInvResponseDtls.Add(objSipInvResponseDtl);
                    }
                    finalSubmitRes.SipInvResponseDtls = LstsipInvResponseDtls;
                }
                if(_Jobj["LumpsumInvResponseDtls"].Count() > 0)
                {
                    for(int i=0;i< _Jobj["LumpsumInvResponseDtls"].Count();i++)
                    {
                        LumpsumInvResponseDtl objLumpsumInvResponseDtl = new LumpsumInvResponseDtl();
                        objLumpsumInvResponseDtl.Amount= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Amount"]);
                        objLumpsumInvResponseDtl.FolioNo= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["FolioNo"]);
                        objLumpsumInvResponseDtl.GoalId = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["GoalId"]);
                        objLumpsumInvResponseDtl.Message= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Message"]);
                        objLumpsumInvResponseDtl.MOGPFREEZE= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["MOGPFREEZE"]);
                        objLumpsumInvResponseDtl.MOGPID= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["MOGPID"]);
                        objLumpsumInvResponseDtl.Option = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Option"]);
                        objLumpsumInvResponseDtl.Plan = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Plan"]);
                        objLumpsumInvResponseDtl.Scheme= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Scheme"]);
                        objLumpsumInvResponseDtl.Status_Code= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["Status_Code"]);
                        objLumpsumInvResponseDtl.TIME_STAMP= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TIME_STAMP"]);
                        objLumpsumInvResponseDtl.TransRefNo= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TransRefNo"]);
                        objLumpsumInvResponseDtl.TrType= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["TrType"]);
                        objLumpsumInvResponseDtl.UMRNexpirydate= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["UMRNexpirydate"]);
                        objLumpsumInvResponseDtl.UMRNNo= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["UMRNNo"]);
                        objLumpsumInvResponseDtl.URNexpirydate= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["URNexpirydate"]);
                        objLumpsumInvResponseDtl.URNNO= Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["URNNO"]);
                        objLumpsumInvResponseDtl.OrderId = Convert.ToString(_Jobj["LumpsumInvResponseDtls"][i]["OrderId"]);
                        LstLumpsumInvResponseDtls.Add(objLumpsumInvResponseDtl);
                    }
                    finalSubmitRes.LumpsumInvResponseDtls = LstLumpsumInvResponseDtls;
                }
                objTransactionReqResponse._TransactionResponse = finalSubmitRes;
                ReqResponseXML = Utilities.ObjectToXMLString(objTransactionReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_CLIENT_TRANSACTION", new
                    {
                        ReqResponseData = ReqResponseXML,
                        PanNo = PanNo,
                        AppId=AppID,
                        ReqJson= inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<string>().FirstOrDefault();
                        finalSubmitRes.PurRefNo = Convert.ToInt64(Returnvalue);
                    }
                }
                if(finalSubmitRes.Status_Code=="200")
                {
                    return new ResponseDataModel<TransactionResponse>(finalSubmitRes);
                }else
                {
                    return new ResponseDataModel<TransactionResponse>(null,finalSubmitRes.Message.ToString());
                }
                
            }
            catch (Exception ex)
            {
                if (request.SIPInvestmentDetails.Count()>0)
                {
                    for (int i = 0; i < request.SIPInvestmentDetails.Count(); i++)
                    {
                        SipInvResponseDtl objSipInvResponseDtl = new SipInvResponseDtl();
                        objSipInvResponseDtl.Amount = Convert.ToString(request.SIPInvestmentDetails[i].Amount);
                        objSipInvResponseDtl.FolioNo = Convert.ToString(request.SIPInvestmentDetails[i].FolioNo);
                        objSipInvResponseDtl.Frequency = Convert.ToString(request.SIPInvestmentDetails[i].Frequency);
                        objSipInvResponseDtl.GoalId = Convert.ToString(request.SIPInvestmentDetails[i].GoalId);
                        objSipInvResponseDtl.Message = Convert.ToString(ex.Message);
                        objSipInvResponseDtl.MOGPFREEZE = Convert.ToString(request.SIPInvestmentDetails[i].MOGPFREEZE);
                        objSipInvResponseDtl.MOGPID = Convert.ToString(request.SIPInvestmentDetails[i].MOGPID);
                        objSipInvResponseDtl.NoOfInstallment = Convert.ToString(request.SIPInvestmentDetails[i].NoOfInstallment);
                        objSipInvResponseDtl.Option = Convert.ToString(request.SIPInvestmentDetails[i].Option);
                        objSipInvResponseDtl.Plan = Convert.ToString(request.SIPInvestmentDetails[i].Plan);
                        objSipInvResponseDtl.Scheme = Convert.ToString(request.SIPInvestmentDetails[i].Scheme);
                        objSipInvResponseDtl.SIPEndDate = Convert.ToString(request.SIPInvestmentDetails[i].SIPEndDate);
                        objSipInvResponseDtl.SIPStartDate = Convert.ToString(request.SIPInvestmentDetails[i].SIPStartDate);
                        objSipInvResponseDtl.Status_Code = Convert.ToString("0");
                        objSipInvResponseDtl.TIME_STAMP = Convert.ToString("");
                        objSipInvResponseDtl.TransRefNo = Convert.ToString(request.SIPInvestmentDetails[i].TransRefNo);
                        objSipInvResponseDtl.TrType = Convert.ToString(request.SIPInvestmentDetails[i].TrType);
                        objSipInvResponseDtl.UMRNexpirydate = Convert.ToString(request.SIPInvestmentDetails[i].URNexpirydate);
                        objSipInvResponseDtl.UMRNNo = Convert.ToString(request.SIPInvestmentDetails[i].UMRNNo);
                        objSipInvResponseDtl.OrderId = Convert.ToString(request.SIPInvestmentDetails[i].OrderId);
                        LstsipInvResponseDtls.Add(objSipInvResponseDtl);
                    }
                    finalSubmitRes.SipInvResponseDtls = LstsipInvResponseDtls;
                }
                if (request.LumpsumInvestmentDetails.Count() > 0)
                {
                    for (int i = 0; i < request.LumpsumInvestmentDetails.Count(); i++)
                    {
                        LumpsumInvResponseDtl objLumpsumInvResponseDtl = new LumpsumInvResponseDtl();
                        objLumpsumInvResponseDtl.Amount = Convert.ToString(request.LumpsumInvestmentDetails[i].Amount);
                        objLumpsumInvResponseDtl.FolioNo = Convert.ToString(request.LumpsumInvestmentDetails[i].FolioNo);
                        objLumpsumInvResponseDtl.GoalId = Convert.ToString(request.LumpsumInvestmentDetails[i].GoalId);
                        objLumpsumInvResponseDtl.Message = Convert.ToString(ex.Message);
                        objLumpsumInvResponseDtl.MOGPFREEZE = Convert.ToString(request.LumpsumInvestmentDetails[i].MOGPFREEZE);
                        objLumpsumInvResponseDtl.MOGPID = Convert.ToString(request.LumpsumInvestmentDetails[i].MOGPID);
                        objLumpsumInvResponseDtl.Option = Convert.ToString(request.LumpsumInvestmentDetails[i].Option);
                        objLumpsumInvResponseDtl.Plan = Convert.ToString(request.LumpsumInvestmentDetails[i].Plan);
                        objLumpsumInvResponseDtl.Scheme = Convert.ToString(request.LumpsumInvestmentDetails[i].Scheme);
                        objLumpsumInvResponseDtl.Status_Code = Convert.ToString("0");
                        objLumpsumInvResponseDtl.TIME_STAMP = Convert.ToString("");
                        objLumpsumInvResponseDtl.TransRefNo = Convert.ToString(request.LumpsumInvestmentDetails[i].TransRefNo);
                        objLumpsumInvResponseDtl.TrType = Convert.ToString(request.LumpsumInvestmentDetails[i].TrType);
                        objLumpsumInvResponseDtl.UMRNexpirydate = Convert.ToString(request.LumpsumInvestmentDetails[i].UMRNexpirydate);
                        objLumpsumInvResponseDtl.UMRNNo = Convert.ToString("");
                        objLumpsumInvResponseDtl.URNexpirydate = Convert.ToString(request.LumpsumInvestmentDetails[i].URNexpirydate);
                        objLumpsumInvResponseDtl.URNNO = Convert.ToString(request.LumpsumInvestmentDetails[i].URNNO);
                        objLumpsumInvResponseDtl.OrderId = Convert.ToString(request.LumpsumInvestmentDetails[i].OrderId);
                        LstLumpsumInvResponseDtls.Add(objLumpsumInvResponseDtl);
                    }
                    finalSubmitRes.LumpsumInvResponseDtls = LstLumpsumInvResponseDtls;
                }
                objTransactionReqResponse._TransactionResponse = finalSubmitRes;
                ReqResponseXML = Utilities.ObjectToXMLString(objTransactionReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_CLIENT_TRANSACTION", new
                    {
                        ReqResponseData = ReqResponseXML,
                        PanNo = PanNo,
                        AppId = AppID,
                        ReqJson = inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<string>().FirstOrDefault();
                        finalSubmitRes.PurRefNo = Convert.ToInt64(Returnvalue);
                    }
                }
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "saveMFClientTransactionSubmit \r ERROR:" + ex.Message);
                return new ResponseDataModel<TransactionResponse>(null, ex.Message);
            }
        }

        public async Task<ResponseDataModel<TransactionConfirmationRes>> TransactionConfirmation(string AppID, long userId, TransactionConfirmationReq request, string UserAgent)
        {
            try
            {
                TransactionConfirmationRes ObjResponse = new TransactionConfirmationRes();
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                string inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxConfLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_MFTnxConf_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".txt";
                    File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r Request :" + inputJson);
                }
                var result = KarvyRequest.CreateHTTPRequest(KarvTrnConfAPI, serviceUrl, inputJson);
                var _Jobj = JObject.Parse(result);

                if(_Jobj.Count>0)
                {
                    ObjResponse.Acno = Convert.ToString(_Jobj["Acno"]);
                    ObjResponse.Appno= Convert.ToString(_Jobj["Appno"]);
                    ObjResponse.Message= Convert.ToString(_Jobj["Message"]);
                    ObjResponse.Status_Code = Convert.ToString(_Jobj["Status_Code"]);
                    ObjResponse.TxnAmount = Convert.ToString(_Jobj["TxnAmount"]);
                }

                return new ResponseDataModel<TransactionConfirmationRes>(ObjResponse);
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "TransactionConfirmation \r ERROR:" + ex.Message);
                return new ResponseDataModel<TransactionConfirmationRes>(null, ex.Message);
            }
        }
        public async Task<ResponseDataModel<EMandateRegRes>> EMandateRegistration(string AppID, long userId,int RefNo, string UserAgent)
        {
            EMandateRegRes ObjResponse = new EMandateRegRes();
            EMandateRegReq request = new EMandateRegReq();
            string inputJson = string.Empty;
            EMandateReqResponse objEMandateReqResponse = new EMandateReqResponse();
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var dataSave = await conn.QueryAsync("MF.GET_OTM_DETAILS", new
                    {
                        RefNo = RefNo,
                        Flag=1
                    }, commandType: CommandType.StoredProcedure);
                    {
                        var EMandateReq = dataSave.ToList();
                        if (EMandateReq.Count > 0)
                        {
                            request.AccountType= EMandateReq[0].AccountType ?? "";
                            request.Amount = Convert.ToString(EMandateReq[0].Amount) ?? "0";
                            request.Authorize= EMandateReq[0].Authorize ?? "";
                            request.BankAcno= EMandateReq[0].BankAcno ?? "";
                            request.SponsorBank= EMandateReq[0].SponsorBank_Code ?? "";
                            request.BankName = EMandateReq[0].BankName ?? "";
                            request.BranchCode= EMandateReq[0].BranchCode ?? "";
                            request.BankHolderName = EMandateReq[0].BankHolderName ?? "";
                            request.ChequeCopy = EMandateReq[0].Cheque_Image ?? "";
                            request.ClientId= EMandateReq[0].ClientId ?? "";
                            request.Debittype= EMandateReq[0].Debittype ?? "";
                            request.EmailId= EMandateReq[0].EmailId ?? "";
                            request.Frequency = EMandateReq[0].Frequency ?? "";
                            request.FromDate = Convert.ToString(EMandateReq[0].FromDate.ToString("yyyy-MM-dd"));
                            if(string.IsNullOrEmpty(EMandateReq[0].ToDate))
                            {
                                request.Todate = "";
                            }
                            else
                            {
                                request.Todate = Convert.ToString(Convert.ToDateTime(EMandateReq[0].ToDate).ToString("yyyy-MM-dd"));
                            }
                            request.IFSCCode= EMandateReq[0].IFSCCode ?? "";
                            request.Image= EMandateReq[0].OTM_Image ?? "";
                            request.MICRCode = EMandateReq[0].MICRCode ?? "";
                            request.MobileNo= EMandateReq[0].MobileNo ?? "";
                            request.Mode= EMandateReq[0].OTM_MODE ?? "";
                            request.OTMDate= Convert.ToString(EMandateReq[0].OTM_DATE.ToString("yyyy-MM-dd"));
                            request.ReferenceID = EMandateReq[0].ReferenceID ?? "";
                            request.RefNo = Convert.ToString(EMandateReq[0].RefNo);
                            request.UMRN= EMandateReq[0].UMRN_NO ?? "";
                            request.Utilitycode = EMandateReq[0].Utility_Code ?? "";
                            request.RegMode = EMandateReq[0].RegMode ?? "";
                            request.ReceiptNo = Convert.ToString(EMandateReq[0].ReceiptNo) ?? "";
                            request.ToDebit = EMandateReq[0].ToDebit ?? "";
                            request.PANNO= EMandateReq[0].PANNO ?? "";
                            request.InvestorName = EMandateReq[0].InvestorName ?? "";
                            request.ImageType = EMandateReq[0].ImageType ?? "";
                        }
                    }
                }
                objEMandateReqResponse._EMandateRegReq = request;
                JObject input = JObject.FromObject(request);
                input.Add("Adminusername", Adminusername);
                input.Add("Adminpassword", Adminpassword);
                inputJson = JsonConvert.SerializeObject(input);
                if (_iconfiguration["MFTnxEMandateLog"] == "On")
                {
                    ReqLog = _iconfiguration["RequestLog"];
                    ReqLog = ReqLog + "_EMandate_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Date.ToString("dd") + ".txt";
                    File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r Request :" + inputJson);
                }
                var result = KarvyRequest.CreateHTTPRequest(KarvyEMandateAPI, serviceUrl, inputJson);
                if (Convert.ToString(result) != "" && Convert.ToString(result) != null)
                {
                    var _Jobj = JObject.Parse(result);
                    if (_Jobj.Count > 0)
                    {
                        ObjResponse.RefNo = Convert.ToString(_Jobj["RefNo"]);
                        ObjResponse.ReferenceID = Convert.ToString(_Jobj["ReferenceID"]);
                        ObjResponse.Message = Convert.ToString(_Jobj["Message"]);
                        ObjResponse.Status_Code = Convert.ToString(_Jobj["Status_Code"]);
                    }
                    objEMandateReqResponse._EMandateRegRes = ObjResponse;
                }else
                {
                    ObjResponse.RefNo = Convert.ToString(RefNo);
                    ObjResponse.Message = "Blank Response By Karvy";
                    ObjResponse.ReferenceID = "";
                    ObjResponse.Status_Code = "";
                    objEMandateReqResponse._EMandateRegRes = ObjResponse;
                }
                string ReqResponseXML = Utilities.ObjectToXMLString(objEMandateReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_OTM_EMANDATE", new
                    {
                        ReqResponseData = ReqResponseXML,
                        ReqJson= inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<int>().FirstOrDefault();
                    }
                }
                if (ObjResponse.Status_Code == "200")
                {
                    return new ResponseDataModel<EMandateRegRes>(ObjResponse);
                }else
                {
                    return new ResponseDataModel<EMandateRegRes>(null, Convert.ToString(ObjResponse.Message));
                }
            }
            catch (Exception ex)
            {
                objEMandateReqResponse._EMandateRegRes.Message = ex.Message.ToString();
                string ReqResponseXML = Utilities.ObjectToXMLString(objEMandateReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_OTM_EMANDATE", new
                    {
                        ReqResponseData = ReqResponseXML,
                        ReqJson = inputJson
                    }, commandType: CommandType.StoredProcedure))
                    {
                        var Returnvalue = SaveKarvyResp.Read<int>().FirstOrDefault();
                    }
                }
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "EMandateRegistration \r ERROR:" + ex.Message);
                return new ResponseDataModel<EMandateRegRes>(null, ex.Message);
            }
        }
        public async Task<ResponseDataArrayModel<OTMDetails>> GetOTMDetails(OTMReq request,string PanNo)
        {
            List<OTMDetails> objLstOTMDetails = new List<OTMDetails>();
            try
            {
                using (var conn = MOAMCMOBILEDB)
                {
                    var multi = await conn.QueryAsync("MF.GET_OTM_DETAILS", new
                    {
                        PanNo = PanNo,
                        HoldingType = request.ModeOfHolding,
                    }, commandTimeout: 0, commandType: CommandType.StoredProcedure);

                    var ObjOTMList = multi.ToList();
                    if (ObjOTMList.Count > 0)
                    {
                        for (int i = 0; i < ObjOTMList.Count; i++)
                        {
                            OTMDetails ObjOTMDetails = new OTMDetails();
                            ObjOTMDetails.RefNo = Convert.ToString(ObjOTMList[i].RefNo ?? 0);
                            ObjOTMDetails.BankName= ObjOTMList[i].BankName ?? "";
                            ObjOTMDetails.BankAccNo = ObjOTMList[i].BankAccNo ?? "";
                            ObjOTMDetails.MinAmount= ObjOTMList[i].MinAmount ?? 0;
                            ObjOTMDetails.RegistrationDate = ObjOTMList[i].RegistrationDate.ToString("yyyy-MM-dd");
                            ObjOTMDetails.Status = Convert.ToString(ObjOTMList[i].Status);
                            ObjOTMDetails.UMRN_NO = ObjOTMList[i].UMRN_NO ?? "";

                            ObjOTMDetails.AccountType = ObjOTMList[i].AccountType ?? "";
                            ObjOTMDetails.Authorize= ObjOTMList[i].Authorize ?? "";
                            ObjOTMDetails.BankAcno= ObjOTMList[i].BankAcno ?? "";
                            ObjOTMDetails.SponsorBank= ObjOTMList[i].SponsorBank_Code ?? "";
                            ObjOTMDetails.BankName = ObjOTMList[i].BankName ?? "";
                            ObjOTMDetails.BranchCode= ObjOTMList[i].BranchCode ?? "";
                            ObjOTMDetails.BankHolderName = ObjOTMList[i].BankHolderName ?? "";
                            ObjOTMDetails.ChequeImage = ObjOTMList[i].Cheque_Image ?? "";
                            ObjOTMDetails.ClientId= ObjOTMList[i].ClientId ?? "";
                            ObjOTMDetails.Debittype= ObjOTMList[i].Debittype ?? "";
                            ObjOTMDetails.EmailId= ObjOTMList[i].EmailId ?? "";
                            ObjOTMDetails.Frequency = ObjOTMList[i].Frequency ?? "";
                            if (ObjOTMList[i].FromDate == null)
                            {
                                ObjOTMDetails.FromDate = Convert.ToString(default(DateTime).ToString("yyyy-MM-dd"));
                            }else
                            {
                                ObjOTMDetails.FromDate = Convert.ToString(ObjOTMList[i].FromDate.ToString("yyyy-MM-dd"));
                            }
                            if(string.IsNullOrEmpty(ObjOTMList[i].ToDate))
                            {
                                ObjOTMDetails.Todate = ObjOTMList[i].ToDate ?? "";
                            }
                            else
                            {
                                ObjOTMDetails.Todate = Convert.ToString(Convert.ToDateTime(ObjOTMList[i].ToDate).ToString("yyyy-MM-dd"));
                            }
                            ObjOTMDetails.IFSCCode= ObjOTMList[i].IFSCCode ?? "";
                            ObjOTMDetails.Image= ObjOTMList[i].OTM_Image ?? "";
                            ObjOTMDetails.MICRCode = ObjOTMList[i].MICRCode ?? "";
                            ObjOTMDetails.MobileNo= ObjOTMList[i].MobileNo ?? "";
                            ObjOTMDetails.Mode= ObjOTMList[i].OTM_MODE ?? "";
                            if (ObjOTMList[i].OTM_DATE == null)
                            {
                                ObjOTMDetails.OTMDate = Convert.ToString(default(DateTime).ToString("yyyy-MM-dd"));
                            }else
                            {
                                ObjOTMDetails.OTMDate = Convert.ToString(ObjOTMList[i].OTM_DATE.ToString("yyyy-MM-dd"));
                            }
                            ObjOTMDetails.ReferenceID = ObjOTMList[i].ReferenceID ?? "";
                            ObjOTMDetails.Utilitycode = ObjOTMList[i].Utility_Code ?? "";
                            ObjOTMDetails.ToDebit = ObjOTMList[i].ToDebit ?? "";
                            ObjOTMDetails.PANNO = ObjOTMList[i].PANNO ?? "";
                            ObjOTMDetails.InvestorName = ObjOTMList[i].InvestorName ?? "";
                            ObjOTMDetails.ImageType= ObjOTMList[i].ImageType ?? "";
                            objLstOTMDetails.Add(ObjOTMDetails);
                        }
                    }
                    return new ResponseDataArrayModel<OTMDetails>(objLstOTMDetails);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "GetOTMDetails \r ERROR:" + ex.Message);
                return new ResponseDataArrayModel<OTMDetails>(null,ex.Message);
            }
        }

        public async Task<ResponseDataModel<FinalSubmitEMandate>> SaveOTMDetails(EMandateRegReq request)
        {
            EMandateReqResponse objEMandateReqResponse = new EMandateReqResponse();
            FinalSubmitEMandate objFinalSubmitEMandate = new FinalSubmitEMandate();
            objEMandateReqResponse._EMandateRegReq = request;
            objEMandateReqResponse._EMandateRegRes = null;
            try
            {
                string ReqResponseXML = Utilities.ObjectToXMLString(objEMandateReqResponse);
                using (var conn = MOAMCMOBILEDB)
                {
                    using (var SaveKarvyResp = await conn.QueryMultipleAsync("MF.USP_SAVE_OTM_EMANDATE", new
                    {
                        ReqResponseData = ReqResponseXML,
                    }, commandType: CommandType.StoredProcedure))
                    {
                        int RefNo = 0;
                        var Returnvalue = SaveKarvyResp.Read<int>().FirstOrDefault();
                        RefNo = Convert.ToInt32(Returnvalue);
                        objFinalSubmitEMandate.RefNo = RefNo;
                    }
                    return new ResponseDataModel<FinalSubmitEMandate>(objFinalSubmitEMandate);
                }
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveOTMDetails \r ERROR:" + ex.Message);
                return new ResponseDataModel<FinalSubmitEMandate>(null, Convert.ToString(ex.Message));
            }
        }

        public async Task<ResponseDataModel<SaveOTMConsolidateRes>> SaveOTMDetailsConsolidate(EMandateRegReqConsolidate request, string AppID, long userId, string PanNo,string UserAgent)
        {
            try
            {
                SaveOTMConsolidateRes ObjSaveOTMConsolidateRes = new SaveOTMConsolidateRes();
                ObjSaveOTMConsolidateRes.ObjEMandateRegRes = new EMandateRegRes();
                ObjSaveOTMConsolidateRes.ObjLstOTMDetails = new List<OTMDetails>();
                EMandateRegReq ObjEMandateRegReq = new EMandateRegReq();
                EMandateRegRes ObjEMandateRegResponse = new EMandateRegRes();
                ObjEMandateRegReq = request.ObjEMandateRegReq;
                var SaveOTMresponse = await SaveOTMDetails(ObjEMandateRegReq);
                if (SaveOTMresponse.message == "Successful")
                {
                    var EMandateRegistrationRes = await EMandateRegistration(AppID, userId, SaveOTMresponse.data.RefNo, UserAgent);
                    if (EMandateRegistrationRes.message == "Successful")
                    {
                        ObjEMandateRegResponse.Message = Convert.ToString(EMandateRegistrationRes.data.Message);
                        ObjEMandateRegResponse.ReferenceID = Convert.ToString(EMandateRegistrationRes.data.ReferenceID);
                        ObjEMandateRegResponse.RefNo = Convert.ToString(EMandateRegistrationRes.data.RefNo);
                        ObjEMandateRegResponse.Status_Code = Convert.ToString(EMandateRegistrationRes.data.Status_Code);
                        ObjSaveOTMConsolidateRes.ObjEMandateRegRes = ObjEMandateRegResponse;
                    }
                }
                var ListOfOTM = await GetOTMDetails(request.ObjOTMReq, PanNo);
                if (ListOfOTM.message == "Successful" && ListOfOTM.data.Count() > 0)
                {
                    ObjSaveOTMConsolidateRes.ObjLstOTMDetails = ListOfOTM.data.ToList();
                }
                return new ResponseDataModel<SaveOTMConsolidateRes>(ObjSaveOTMConsolidateRes);
            }
            catch (Exception ex)
            {
                ErrorLogFile = _iconfiguration["ErrorLogFile"];
                ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "SaveOTMDetailsConsolidate \r ERROR:" + ex.Message);
                return new ResponseDataModel<SaveOTMConsolidateRes>(null, Convert.ToString(ex.Message));
            }
        }
    }
}