﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.Auth;
using ApiCore.DTOs;
using ApiCore.Model;
using APICore.Auth;
using APICore.Helpers;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MFTransaction.Models;
using MFTransaction.Utils;

namespace MFTransaction.InvestorDetails
{
    [Produces("application/json")]
    [Route("api/InvestorDetails")]
    [ValidateModel]

    public class BasicDetailsController : ControllerBase
    {

        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly IBasicDetailsDataSource _BasicDetailsDataSource;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);
        public BasicDetailsController(TokenHelper tokenHelper, IBasicDetailsDataSource BasicDetailsDataSource, IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration)
        {
            _BasicDetailsDataSource = BasicDetailsDataSource;
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
        }

        [HttpPost("panDetail")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<MFClientsPanDetailsRes>), 200)]
        public async Task<IActionResult> saveMFClientPanDetails([FromBody] MFClientsPanDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var Role = IdentityHelper.GetRole(User.Identity);
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var response = await _BasicDetailsDataSource.saveMFClientPanDetails(AppId, string.IsNullOrEmpty(Role) ? "G" : Role, UserAgent, request);
            return Ok(response);
        }

        [HttpPost("basicDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveMFClientBasicDetails([FromBody] MFClientsBasicDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var response = await _BasicDetailsDataSource.saveMFClientBasicDetails(AppId, userid, UserAgent, request);
            return Ok(response);
        }

        [HttpPost("fatcaDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveMFClientFatcaDetails([FromBody] MFClientsFatchDetails request)
        {
            int modeOfHolding = 0;
            int firstHolderTaxStatus = 0;
            var secondHolderPanno = "";
            var thirdholderPanHolder = "";
            int category = 0;
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            long userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("MF.USP_GET_CLIENT_DETAILS", new
                {
                    USERID = userid,
                    SCREENNO = 2
                }, commandType: CommandType.StoredProcedure);
                var Data = multi.ToList();
                if (Data.Count > 0)
                {
                    modeOfHolding = Convert.ToInt32(Data[0].MODEOFHOLDING) ?? 0;
                    firstHolderTaxStatus = Convert.ToInt32(Data[0].INVESTORSTATUS) ?? 0;
                    category = Convert.ToInt32(Data[0].CATEGORY) ?? 0;
                    secondHolderPanno = Convert.ToString(Data[0].SHPANNO) ?? "";
                    thirdholderPanHolder = Convert.ToString(Data[0].THPANNO) ?? "";
                }
            }
            var results = new List<ValidationResult>();
            if (modeOfHolding == 2)
            {
                if (request.fatcaDetails.Count == 1)
                {
                    results.Add(new ValidationResult("SecondHolderFatcaDetails Required", new List<string> { "SecondHolderFatcaDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.fatcaDetails[1].incomeSlab == 0 || request.fatcaDetails[1].incomeSlab > 6)
                    {
                        results.Add(new ValidationResult("Invalid incomeSlab.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[1].birthCountry == null || request.fatcaDetails[1].birthCountry.Trim() == "")
                    {
                        results.Add(new ValidationResult("Birth Country cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[1].nationality == null || request.fatcaDetails[1].nationality.Trim() == "")
                    {
                        results.Add(new ValidationResult("Nationality cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                   
                    if (request.fatcaDetails[1].taxResidentNonIndian == true)
                    {
                        if (request.fatcaDetails[1].taxResident == null || request.fatcaDetails[1].taxResident.Trim() == "")
                        {
                            results.Add(new ValidationResult("Tax Resident cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                        }
                        if (request.fatcaDetails[1].foreignTaxId == null || request.fatcaDetails[1].foreignTaxId.Trim() == "")
                        {
                            results.Add(new ValidationResult("ForignTaxId cannot be left blank.", new List<string> { "SecondHolderFatcaDetails" }));
                        }
                    }
                    if (request.fatcaDetails[1].pep != true && request.fatcaDetails[1].pep != false)
                    {
                        results.Add(new ValidationResult("Invalid pep.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[1].relationalPep != true && request.fatcaDetails[1].relationalPep != false)
                    {
                        results.Add(new ValidationResult("Invalid Relation pep.", new List<string> { "SecondHolderFatcaDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }

                }
            }
            if (modeOfHolding == 2 && thirdholderPanHolder.Trim() != "")
            {
                if (request.fatcaDetails.Count == 2)
                {
                    results.Add(new ValidationResult("ThirdHolderFatcaDetails Required", new List<string> { "ThirdHolderFatcaDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.fatcaDetails[2].incomeSlab == 0 || request.fatcaDetails[2].incomeSlab > 6)
                    {
                        results.Add(new ValidationResult("Invalid incomeSlab.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[2].birthCountry == null || request.fatcaDetails[2].birthCountry.Trim() == "")
                    {
                        results.Add(new ValidationResult("Birth Country cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[2].nationality == null || request.fatcaDetails[2].nationality.Trim() == "")
                    {
                        results.Add(new ValidationResult("Nationality cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                
                    if (request.fatcaDetails[2].taxResidentNonIndian == true)
                    {
                        if (request.fatcaDetails[2].taxResident == null || request.fatcaDetails[2].taxResident.Trim() == "")
                        {
                            results.Add(new ValidationResult("Tax Resident cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                        }
                        if (request.fatcaDetails[2].foreignTaxId == null || request.fatcaDetails[2].foreignTaxId.Trim() == "")
                        {
                            results.Add(new ValidationResult("ForignTaxId cannot be left blank.", new List<string> { "ThirdHolderFatcaDetails" }));
                        }
                    }
                    if (request.fatcaDetails[2].pep != true && request.fatcaDetails[2].pep != false)
                    {
                        results.Add(new ValidationResult("Invalid pep.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (request.fatcaDetails[2].relationalPep != true && request.fatcaDetails[2].relationalPep != false)
                    {
                        results.Add(new ValidationResult("Invalid Relation pep.", new List<string> { "ThirdHolderFatcaDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }
                }

            }


            var response = await _BasicDetailsDataSource.saveMFClientFatcaDetails(AppId, userid, UserAgent, request);
            return Ok(response);
        }

        [HttpPost("contactDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveMFClientContactDetails([FromBody] MFClientsContactDetails request)
        {
            int modeOfHolding = 0;
            int firstHolderTaxStatus = 0;
            var secondHolderPanno = "";
            var thirdholderPanHolder = "";
            int category = 0;
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            using (var conn = MOAMCMOBILEDB)
            {
                var multi = await conn.QueryAsync("MF.USP_GET_CLIENT_DETAILS", new
                {
                    USERID = userid,
                    SCREENNO = 2
                }, commandType: CommandType.StoredProcedure);
                var Data = multi.ToList();
                if (Data.Count > 0)
                {
                    modeOfHolding = Convert.ToInt32(Data[0].MODEOFHOLDING) ?? 0;
                    firstHolderTaxStatus = Convert.ToInt32(Data[0].INVESTORSTATUS) ?? 0;
                    category = Convert.ToInt32(Data[0].CATEGORY) ?? 0;
                    secondHolderPanno = Convert.ToString(Data[0].SHPANNO) ?? "";
                    thirdholderPanHolder = Convert.ToString(Data[0].THPANNO) ?? "";
                }
            }
            var results = new List<ValidationResult>();
            if (category == 21)
            {
                if (request.nriContact == null)
                {
                    results.Add(new ValidationResult("NRI Contact Details Required.", new List<string> { "FirstHolderNRIContactDetails" }));
                }
                else
                {
                    if (request.nriContact.address1 == null || request.nriContact.address1.Trim() == "")
                    {
                        results.Add(new ValidationResult("Address1 cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                    if (request.nriContact.city == null || request.nriContact.city.Trim() == "")
                    {
                        results.Add(new ValidationResult("City cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                    if (request.nriContact.country == null || request.nriContact.country.Trim() == "")
                    {
                        results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                    if (request.nriContact.zipcode == null || request.nriContact.zipcode.Trim() == "")
                    {
                        results.Add(new ValidationResult("Zipcode cannot be left blank.", new List<string> { "FirstHolderNRIContactDetails" }));
                    }
                }
                if (results.Count > 0)
                {
                    return BadRequest(results);
                }
            }
            if (modeOfHolding == 2)
            {
                if (request.contactDetails.Count == 1)
                {
                    results.Add(new ValidationResult("SecondHolderContactDetails Required", new List<string> { "SecondHolderContactDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.contactDetails[1].wing == null || request.contactDetails[1].wing.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].area == null || request.contactDetails[1].area.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].state == null || request.contactDetails[1].state.Trim() == "")
                    {
                        results.Add(new ValidationResult("State cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].country == null || request.contactDetails[1].country.Trim() == "")
                    {
                        results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (request.contactDetails[1].pincode == 0)
                    {
                        results.Add(new ValidationResult("Invalid Pincode.", new List<string> { "SecondHolderContactDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }

                }
            }
            if (modeOfHolding == 2 && thirdholderPanHolder.Trim() != "")
            {
                if (request.contactDetails.Count == 2)
                {
                    results.Add(new ValidationResult("ThirdHolderContactDetails Required", new List<string> { "ThirdHolderContactDetails" }));
                    return BadRequest(results);
                }
                else
                {
                    if (request.contactDetails[2].wing == null || request.contactDetails[2].wing.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].area == null || request.contactDetails[2].area.Trim() == "")
                    {
                        results.Add(new ValidationResult("Wing cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].state == null || request.contactDetails[2].state.Trim() == "")
                    {
                        results.Add(new ValidationResult("State cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].country == null || request.contactDetails[2].country.Trim() == "")
                    {
                        results.Add(new ValidationResult("Country cannot be left blank.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (request.contactDetails[2].pincode == 0)
                    {
                        results.Add(new ValidationResult("Invalid Pincode.", new List<string> { "ThirdHolderContactDetails" }));
                    }
                    if (results.Count > 0)
                    {
                        return BadRequest(results);
                    }
                }
            }
            var response = await _BasicDetailsDataSource.saveMFClientContactDetails(AppId, userid, UserAgent, request);
            return Ok(response);
        }

        [HttpPost("nomineeDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveMFClientNomineeDetails([FromBody] MFClientsNomineeDetails request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var response = await _BasicDetailsDataSource.saveMFClientNomineeDetails(AppId, userid, UserAgent, request);
            return Ok(response);
        }


        [HttpPost("bankDetails")]
        [Produces("application/json")]
        [Authorize]
        [ProducesResponseType(typeof(ResponseDataModel<string>), 200)]
        public async Task<IActionResult> saveMFClientBankDetails([FromBody] MFClientsBankDetails request)
        {
            string transactionType = "";
            Int64 userid = Convert.ToInt64(IdentityHelper.GetUserId(User.Identity));
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var results = new List<ValidationResult>();
            //if (string.IsNullOrEmpty(request.chequeImage))
            //{
            //    {
            //        results.Add(new ValidationResult("Cancel Cheque image is required.", new List<string> { "BankDetails" }));
            //    }
            //}
            //else
            //{
                if (string.IsNullOrEmpty(request.paymentMode))
                {
                    {
                        results.Add(new ValidationResult("PaymentMode is required.", new List<string> { "BankDetails" }));
                    }
                }
                else if (request.paymentMode.ToUpper() != "DCB" && request.paymentMode.ToUpper() != "DC" && request.paymentMode.ToUpper() != "UPI")
                {
                    results.Add(new ValidationResult("Invalid PaymentMode.", new List<string> { "BankDetails" }));
                }
            //}
            if (results.Count > 0)
            {
                return BadRequest(results);
            }
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var response = await _BasicDetailsDataSource.saveMFClientBankDetails(AppId, userid, UserAgent, request);
            return Ok(response);
        }

        [HttpPost("ClientDetails")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<MFClientDetails>), 200)]
        public async Task<IActionResult> ClientDetails([FromBody]GetClientReq Req)
        {
            string PanNo = string.Empty;
            if(string.IsNullOrEmpty(Req.PanNo))
            {
                PanNo= Convert.ToString(User.Identity.Name);
            }
            else
            {
                PanNo = Convert.ToString(Req.PanNo);
            }
            var response = await _BasicDetailsDataSource.GetClientDetails(PanNo);
            return Ok(response);
        }

        [HttpPost("validateNewInvestorPan")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(ResponseDataModel<validateUserRes>), 200)]
        public async Task<IActionResult> validateNewInvestorPan([FromBody] PanKYCReq request)
        {
            var AppId = HeaderAccessors.GetAppId(Request.Headers);
            var UserAgent = HeaderAccessors.GetUserAgent(Request.Headers);
            var response = await _BasicDetailsDataSource.validateNewMFInvestorPan(AppId, UserAgent, request);
            return Ok(response);
        }
    }
}