﻿using ApiCore.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MFTransaction.Models;
namespace MFTransaction.InvestorDetails
{
    public interface IBasicDetailsDataSource
    {
        //Task<ResponseDataModel<string>> PaymentOrderGeneration(string panno, string AppId);
        Task<ResponseDataModel<MFClientsPanDetailsRes>> saveMFClientPanDetails(string AppID, string Role,string UserAgent, MFClientsPanDetails request);
        Task<ResponseDataModel<string>> saveMFClientBasicDetails(string AppID, Int64 userId, string UserAgent, MFClientsBasicDetails request);
        Task<ResponseDataModel<string>> saveMFClientFatcaDetails(string AppID, Int64 userId, string UserAgent, MFClientsFatchDetails request);
        Task<ResponseDataModel<string>> saveMFClientContactDetails(string AppID, Int64 userId, string UserAgent, MFClientsContactDetails request);
        Task<ResponseDataModel<string>> saveMFClientNomineeDetails(string AppID, Int64 userId, string UserAgent, MFClientsNomineeDetails request);
        Task<ResponseDataModel<string>> saveMFClientBankDetails(string AppID, Int64 userId, string UserAgent, MFClientsBankDetails request);
        Task<ResponseDataModel<MFClientDetails>> GetClientDetails(string PanNo);
        Task<ResponseDataModel<validateUserRes>> validateNewMFInvestorPan(string Appid, string UserAgent, PanKYCReq request);
    }
}
