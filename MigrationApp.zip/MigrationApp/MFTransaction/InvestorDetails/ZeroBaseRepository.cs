﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ApiCore.DTOs;
using ApiCore.Model;
using karvyAPI;
using MFTransaction.Models;
using MFTransaction.Utils;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Configuration;
using Dapper;
using ApiCore.Exceptions;
using System.IO;

namespace MFTransaction.InvestorDetails
{
    public class ZeroBaseRepository : IZeroBaseDataSource
    {
        private readonly DbConnections _connections;
        private readonly IConfiguration _iconfiguration;
        private readonly TokenHelper _tokenHelper;
        private string ErrorLogFile = string.Empty;
        string serviceUrl = string.Empty;
        string Adminusername = string.Empty;
        string Adminpassword = string.Empty;
        string KarvAPIName = string.Empty;
        string ReqLog = string.Empty;
        private IDbConnection MOAMCMOBILEDB => new SqlConnection(_connections.ConAMCMobileDB);

        public ZeroBaseRepository(IOptionsSnapshot<DbConnections> connectionsSnapshot, IConfiguration iconfiguration, TokenHelper tokenHelper)
        {
            _connections = connectionsSnapshot.Value;
            _iconfiguration = iconfiguration;
            _tokenHelper = tokenHelper;
            serviceUrl = _iconfiguration["StaticPath:URL:serviceUrl"];
            Adminusername = _iconfiguration["StaticPath:URL:Adminusername"];
            Adminpassword = _iconfiguration["StaticPath:URL:Adminpassword"];
            KarvAPIName = _iconfiguration["StaticPath:URL:ZBFAPIName"];
        }
        public async Task<ResponseDataModel<FinalSubmitRes>> saveMFClientSubmit(string AppID, long userId, FinalSubmit request)
        {
            FinalSubmitRes finalSubmitRes = new FinalSubmitRes();
            MFClientKarvy objMFClient = new MFClientKarvy();
            string inputJson = string.Empty;
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("MF.USP_GET_CLIENT_FINALDATA", new
                {
                    USERID = userId,
                    UNDERTAKING = request.undertaking
                }, commandType: CommandType.StoredProcedure);
                {
                    var ClientList = dataSave.ToList();
                    if (ClientList.Count > 0)
                    {
                        try
                        {
                            string InvStatus = string.Empty; ;
                            if (ClientList[0].investorstatus == "1")
                            {
                                InvStatus = "I";
                            }
                            else if (ClientList[0].investorstatus == "2")
                            {
                                InvStatus = "M";
                            }
                            objMFClient.trtype = ClientList[0].trtype ?? "";
                            objMFClient.fatca_flag = ClientList[0].fatcaflag ?? "";
                            objMFClient.nominee_flag = ClientList[0].nomineeflag ?? "";
                            objMFClient.KYC_flag = ClientList[0].fhkycstatus ?? "";
                            objMFClient.branch = ClientList[0].branchcode ?? "";
                            objMFClient.FPoliticallyExposed = Convert.ToString(ClientList[0].fhpep) == "True" ? "Y" : "N";
                            objMFClient.FRelatedToPoliticallyExposed = Convert.ToString(ClientList[0].fhrpep) == "True" ? "Y" : "N";
                            objMFClient.SPoliticallyExposed = Convert.ToString(ClientList[0].shpep) == "True" ? "Y" : "N";
                            objMFClient.SRelatedToPoliticallyExposed = Convert.ToString(ClientList[0].shrpep) == "True" ? "Y" : "N";
                            objMFClient.TPoliticallyExposed = Convert.ToString(ClientList[0].thpep) == "True" ? "Y" : "N";
                            objMFClient.TRelatedToPoliticallyExposed = Convert.ToString(ClientList[0].thrpep) == "True" ? "Y" : "N";
                            objMFClient.GPoliticallyExposed = ClientList[0].gpoliticallyexposed ?? "";
                            objMFClient.GRelatedToPoliticallyExposed = ClientList[0].grelatedtopoliticallyexposed ?? "";
                            objMFClient.FKRA = ClientList[0].fhkycstatus ?? "";
                            objMFClient.FCOB = ClientList[0].fhbirthcountry ?? "";
                            objMFClient.accountNumber = ClientList[0].accountno ?? "";
                            objMFClient.accountType = ClientList[0].accounttype ?? "";
                            objMFClient.bankName = ClientList[0].bankname ?? "";
                            objMFClient.branchCity = ClientList[0].branchcity ?? "";
                            objMFClient.branchName = ClientList[0].branchname ?? "";
                            objMFClient.ifscCode = ClientList[0].ifsccode ?? "";
                            objMFClient.micrCode = ClientList[0].micrcode ?? "";
                            objMFClient.branchPin = Convert.ToString(ClientList[0].branchpincode) ?? "";
                            objMFClient.schemeCategory = ClientList[0].schemecategory ?? "";
                            objMFClient.schemeName = ClientList[0].schemename ?? "";
                            objMFClient.schemePlan = ClientList[0].schemeplan ?? "";
                            objMFClient.schemeOption = ClientList[0].schemeoption ?? "";
                            objMFClient.investmentAmount = ClientList[0].investmentamount ?? 0;
                            objMFClient.brokerCode = ClientList[0].brokercode ?? "";
                            objMFClient.subBrokerCode = ClientList[0].subbrokercode ?? "";
                            objMFClient.subBrokerArn = ClientList[0].subbrokerarn ?? "";
                            objMFClient.euin = ClientList[0].euin ?? "";
                            objMFClient.euinDeclaration = ClientList[0].euindeclaration ?? "";
                            objMFClient.Nomname = ClientList[0].fnomineename ?? "";
                            objMFClient.relationship = ClientList[0].fnomrelationship ?? "";
                            objMFClient.percentageAllocation = ClientList[0].fnomineepercentage ?? "";
                            objMFClient.Nomaddress1 = ClientList[0].fnomaddress1 ?? "";
                            objMFClient.Nomaddress2 = ClientList[0].fnomaddress2 ?? "";
                            objMFClient.Nomaddress3 = ClientList[0].nomaddress3 ?? "";
                            objMFClient.Nomcountry = ClientList[0].nomcountry ?? "";
                            objMFClient.Nomcity = ClientList[0].nomcity ?? "";
                            objMFClient.NomzipCode = ClientList[0].nomzipcode ?? "";
                            objMFClient.Nomdob = ClientList[0].fnomineedob ?? "";
                            objMFClient.NomguardianName = ClientList[0].fnomgaurdianname ?? "";
                            objMFClient.nominee2 = ClientList[0].snomineename ?? "";
                            objMFClient.nom2Relation = ClientList[0].snomrelationship ?? "";
                            objMFClient.nominee2percentage = ClientList[0].snomineepercentage ?? "";
                            objMFClient.nom2add1 = ClientList[0].snomaddress1 ?? "";
                            objMFClient.nom2add2 = ClientList[0].snomaddress2 ?? "";
                            objMFClient.nom2add3 = ClientList[0].nom2add3 ?? "";
                            objMFClient.nom2country = ClientList[0].nom2country ?? "";
                            objMFClient.nom2city = ClientList[0].nom2city ?? "";
                            objMFClient.nom2pin = ClientList[0].nom2pin ?? "";
                            objMFClient.nom2DOB = ClientList[0].snomineedob ?? "";
                            objMFClient.nom2Gaurdian = ClientList[0].snomgaurdianname ?? "";
                            objMFClient.nominee3 = ClientList[0].tnomineename ?? "";
                            objMFClient.nom3Relation = ClientList[0].tnomrelationship ?? "";
                            objMFClient.nominee3percentage = ClientList[0].tnomineepercentage ?? "";
                            objMFClient.nom3add1 = ClientList[0].tnomaddress1 ?? "";
                            objMFClient.nom3add2 = ClientList[0].tnomaddress2 ?? "";
                            objMFClient.nom3add3 = ClientList[0].nom3add3 ?? "";
                            objMFClient.nom3country = ClientList[0].nom3country ?? "";
                            objMFClient.nom3city = ClientList[0].nom3city ?? "";
                            objMFClient.nom3pin = ClientList[0].nom3pin ?? "";
                            objMFClient.nom3DOB = ClientList[0].tnomineedob ?? "";
                            objMFClient.nom3Gaurdian = ClientList[0].tnomgaurdianname ?? "";
                            objMFClient.annualIncome = ClientList[0].fhincomeslab ?? "";
                            objMFClient.countryOfBirth = ClientList[0].fhbirthcountry ?? "";
                            objMFClient.nationality = ClientList[0].fhnationality ?? "";
                            objMFClient.countryOfTaxResident = ClientList[0].fhbirthcountry ?? "";
                            objMFClient.foreignTaxNumber = ClientList[0].fhforigntaxid ?? "";
                            objMFClient.pep = Convert.ToString(ClientList[0].fhpep) == "True" ? "Y" : "N";
                            objMFClient.relatedToPEP = Convert.ToString(ClientList[0].fhrpep) == "True" ? "Y" : "N";
                            objMFClient.Nriaddress1 = ClientList[0].nriaddress1 ?? "";
                            objMFClient.Nriaddress2 = ClientList[0].nriaddress2 ?? "";
                            objMFClient.Nriaddress3 = ClientList[0].nriaddress3 ?? "";
                            objMFClient.Nricountry = ClientList[0].nricountry ?? "";
                            objMFClient.Nricity = ClientList[0].nricity ?? "";
                            objMFClient.NrizipCode = ClientList[0].nrizipcode ?? "";
                            objMFClient.Invname = ClientList[0].fhname;
                            objMFClient.Invaddress1 = ClientList[0].fhwing ?? "" + " " + ClientList[0].fharea ?? "" + " " + ClientList[0].fhlandmark ?? "";
                            objMFClient.Invaddress2 = ClientList[0].fhstate ?? "" + " " + ClientList[0].fhstate ?? "" + " " + ClientList[0].fhcountry ?? "";
                            objMFClient.Invaddress3 = ClientList[0].fhcity ?? "" + " " + ClientList[0].fhpincode ?? "";
                            objMFClient.Invoccupation = ClientList[0].fhoccupation ?? "";
                            objMFClient.InvresidenceCategory = ClientList[0].category ?? "";
                            objMFClient.Invpan = ClientList[0].fhpanno ?? "";
                            objMFClient.InvmobileNumber = ClientList[0].fhmobileno ?? "";
                            objMFClient.Invemail = ClientList[0].fhemailid ?? "";
                            objMFClient.Invdob = ClientList[0].fhdob ?? "";
                            objMFClient.ModeOfHolding = ClientList[0].modeofholding ?? "";
                            objMFClient.CompanyCode = ClientList[0].companycode ?? "";
                            objMFClient.EmployeeCode = ClientList[0].employeecode ?? "";
                            objMFClient.accOpeningMode = ClientList[0].accopeningmode ?? "";
                            objMFClient.HoldingDematMode = ClientList[0].holdingdematmode ?? "";
                            objMFClient.NSDLCDSL = ClientList[0].nsdlcdsl ?? "";
                            objMFClient.DPIdClientId = ClientList[0].dpidclientid ?? "";
                            objMFClient.GoalId = ClientList[0].GoalId ?? "";
                            objMFClient.MOGSipflag = ClientList[0].mogsipflag ?? "";
                            objMFClient.Refno = Convert.ToString(ClientList[0].userid) ?? "";
                            objMFClient.GuardianName = ClientList[0].fhgaurdianname ?? "";
                            objMFClient.GMobileNo = ClientList[0].fhmobileno ?? "";
                            objMFClient.GPan = ClientList[0].fhgaurdianpan ?? "";
                            objMFClient.GGender = ClientList[0].ggender ?? "";
                            objMFClient.GDob = ClientList[0].gdob ?? "";
                            objMFClient.GRelation = ClientList[0].grelation ?? "";
                            objMFClient.GCOB = ClientList[0].gcob ?? "";
                            objMFClient.GAnnualIncome = ClientList[0].gannualincome ?? "";
                            objMFClient.GNationality = ClientList[0].gnationality ?? "";
                            objMFClient.GTaxResident = ClientList[0].gtaxresident ?? "";
                            objMFClient.GForeignTaxId = ClientList[0].gforeigntaxid ?? "";
                            objMFClient.GFather = ClientList[0].gfather ?? "";
                            objMFClient.GKRA = ClientList[0].fhgaurdiankycstatus ?? "";
                            objMFClient.SecondInvName = ClientList[0].shname ?? "";
                            objMFClient.ThirdInvName = ClientList[0].thname ?? "";
                            objMFClient.SecondInvOccupation = ClientList[0].shoccupation ?? "";
                            objMFClient.ThirdInvOccupation = ClientList[0].thoccupation ?? "";
                            objMFClient.SecondInvDOB = ClientList[0].shdob ?? "";
                            objMFClient.ThirdInvDOB = ClientList[0].thdob ?? "";
                            objMFClient.SecondInvEMail = ClientList[0].shemailid ?? "";
                            objMFClient.ThirdInvEMail = ClientList[0].themailid ?? "";
                            objMFClient.SecondInvMobile = ClientList[0].shmobileno ?? "";
                            objMFClient.ThirdInvMobile = ClientList[0].thmobileno ?? "";
                            objMFClient.SecondInvSalutation = ClientList[0].shsalutation ?? "";
                            objMFClient.ThirdInvSalutation = ClientList[0].thsalutation ?? "";
                            objMFClient.SAnnualIncome = ClientList[0].shincomeslab ?? "";
                            objMFClient.SNationality = ClientList[0].shnationality ?? "";
                            objMFClient.STaxResident = ClientList[0].shtaxresident ?? "";
                            objMFClient.SForeignTaxID = ClientList[0].shforigntaxid ?? "";
                            objMFClient.TAnnualIncome = ClientList[0].thincomeslab ?? "";
                            objMFClient.TNationality = ClientList[0].thnationality ?? "";
                            objMFClient.TTaxResident = ClientList[0].thtaxresident ?? "";
                            objMFClient.TForeignTaxID = ClientList[0].thforigntaxid ?? "";
                            objMFClient.SGender = ClientList[0].sgender ?? "";
                            objMFClient.TGender = ClientList[0].tgender ?? "";
                            objMFClient.SFather = ClientList[0].sfather ?? "";
                            objMFClient.TFather = ClientList[0].tfather ?? "";
                            objMFClient.SecondInvPAN = ClientList[0].shpanno ?? "";
                            objMFClient.ThirdInvPAN = ClientList[0].thpanno ?? "";
                            objMFClient.ckycrefno1 = ClientList[0].ckycrefno1 ?? "";
                            objMFClient.ckycrefno2 = ClientList[0].ckycrefno2 ?? "";
                            objMFClient.ckycrefno3 = ClientList[0].ckycrefno3 ?? "";
                            objMFClient.ckycrefnog = ClientList[0].ckycrefnog ?? "";
                            objMFClient.SCOB = ClientList[0].shbirthcountry ?? "";
                            objMFClient.TCOB = ClientList[0].thbirthcountry ?? "";
                            objMFClient.chequeCopy = ClientList[0].chequeimage ?? "";
                            objMFClient.Status = InvStatus;
                            JObject input = JObject.FromObject(objMFClient);
                            input.Add("Adminusername", Adminusername);
                            input.Add("Adminpassword", Adminpassword);
                            inputJson = JsonConvert.SerializeObject(input);
                            if (_iconfiguration["ZBFLog"] == "On")
                            {
                                ReqLog = _iconfiguration["RequestLog"];
                                ReqLog = ReqLog + "_ZBF_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Date.ToString("dd") + ".txt";
                                File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r Request :" + inputJson);
                            }
                            var result = KarvyRequest.CreateHTTPRequest(KarvAPIName, serviceUrl, inputJson);
                            var _Jobj = JObject.Parse(result);
                            finalSubmitRes.dateTimeStamp = Convert.ToString(_Jobj["dateTimeStamp"]);
                            finalSubmitRes.APP_REF_NO = Convert.ToString(_Jobj["APP_REF_NO"]);
                            finalSubmitRes.folio = Convert.ToString(_Jobj["folio"]);
                            finalSubmitRes.GoalId = Convert.ToString(_Jobj["GoalId"]);
                            finalSubmitRes.GroupId = Convert.ToString(_Jobj["GroupId"]);
                            finalSubmitRes.message = Convert.ToString(_Jobj["message"]);
                            finalSubmitRes.RefNo = Convert.ToString(_Jobj["RefNo"]);
                            finalSubmitRes.statusCode = Convert.ToString(_Jobj["statusCode"]);
                            finalSubmitRes.transactionId = Convert.ToString(_Jobj["transactionId"]);
                            //added by Suryakant 
                            finalSubmitRes.modeOfHolding = objMFClient.ModeOfHolding;
                            finalSubmitRes.bankName = objMFClient.bankName;
                            finalSubmitRes.accountNo = objMFClient.accountNumber;
                            finalSubmitRes.ifscCode = objMFClient.ifscCode;
                            finalSubmitRes.micrCode = objMFClient.micrCode;
                            var SavefinalSubmitRes = await conn.QueryAsync("MF.USP_SAVE_CLIENT_KARY_RESPONSE", new
                            {
                                APP_REF_NO = Convert.ToString(finalSubmitRes.APP_REF_NO),
                                DATETIMESTAMP = Convert.ToString(finalSubmitRes.dateTimeStamp),
                                FOLIO = Convert.ToString(finalSubmitRes.folio),
                                GOALID = Convert.ToString(finalSubmitRes.GoalId),
                                GROUPID = Convert.ToString(finalSubmitRes.GroupId),
                                MESSAGE = Convert.ToString(finalSubmitRes.message),
                                REFNO = Convert.ToString(finalSubmitRes.RefNo),
                                STATUSCODE = Convert.ToString(finalSubmitRes.statusCode),
                                TRANSACTIONID = Convert.ToString(finalSubmitRes.transactionId),
                                ReqJson = Convert.ToString(inputJson)
                            }, commandType: CommandType.StoredProcedure);
                            if (finalSubmitRes.statusCode == "200")
                            {
                                return new ResponseDataModel<FinalSubmitRes>(finalSubmitRes);
                            }
                            else
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, finalSubmitRes.message.ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            var SavefinalSubmitRes = await conn.QueryAsync("MF.USP_SAVE_CLIENT_KARY_RESPONSE", new
                            {
                                APP_REF_NO = Convert.ToString(finalSubmitRes.APP_REF_NO),
                                DATETIMESTAMP = Convert.ToString(finalSubmitRes.dateTimeStamp),
                                FOLIO = Convert.ToString(finalSubmitRes.folio),
                                GOALID = Convert.ToString(finalSubmitRes.GoalId),
                                GROUPID = Convert.ToString(finalSubmitRes.GroupId),
                                MESSAGE = Convert.ToString(ex.Message),
                                REFNO = Convert.ToString(objMFClient.Refno),
                                STATUSCODE = "0",
                                TRANSACTIONID = Convert.ToString(finalSubmitRes.transactionId),
                                ReqJson = inputJson
                            }, commandType: CommandType.StoredProcedure);
                            ErrorLogFile = _iconfiguration["ErrorLogFile"];
                            ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                            File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "saveMFClientSubmit \r UserId :" + Convert.ToString(objMFClient.Refno) + " ERROR:" + ex.Message);
                            return new ResponseDataModel<FinalSubmitRes>(null, ex.Message);
                        }
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        public async Task<ResponseDataModel<FinalSubmitRes>> MFZBFSubmit(string AppID, long userId, string PanNo, ZBFReq req)
        {
            FinalSubmitRes finalSubmitRes = new FinalSubmitRes();
            MFClientKarvy objMFClient = new MFClientKarvy();
            string inputJson = string.Empty;
            using (var conn = MOAMCMOBILEDB)
            {
                var dataSave = await conn.QueryAsync("USP_GET_ZBF_DETAILS_FOR_FOLIOCREATION", new
                {
                    PanNo,
                    TrType = req.trType,
                    FolioNo = req.folioNo,
                    AccountType = req.accounttype,
                    BankAccountNo = req.bankAccountNo,
                    BranchCode = req.branchCode,
                    IsDemat = req.isDemat
                }, commandType: CommandType.StoredProcedure);
                {
                    var ClientList = dataSave.ToList();
                    if (ClientList.Count > 0)
                    {
                        try
                        {
                            string InvStatus = string.Empty; ;
                            if (string.IsNullOrEmpty(ClientList[0].investorstatus))
                            {
                                InvStatus = "I";
                            }
                            else
                            {
                                InvStatus = Convert.ToString(ClientList[0].investorstatus);
                            }
                            objMFClient.trtype = ClientList[0].trtype ?? "";
                            objMFClient.fatca_flag = ClientList[0].fatcaflag ?? "";
                            objMFClient.nominee_flag = ClientList[0].nomineeflag ?? "";
                            objMFClient.KYC_flag = ClientList[0].fhkycstatus ?? "";
                            objMFClient.branch = ClientList[0].branchcode ?? "";
                            objMFClient.FPoliticallyExposed = Convert.ToString(ClientList[0].fhpep) == "True" ? "Y" : "N";
                            objMFClient.FRelatedToPoliticallyExposed = Convert.ToString(ClientList[0].fhrpep) == "True" ? "Y" : "N";
                            objMFClient.SPoliticallyExposed = Convert.ToString(ClientList[0].shpep) == "True" ? "Y" : "N";
                            objMFClient.SRelatedToPoliticallyExposed = Convert.ToString(ClientList[0].shrpep) == "True" ? "Y" : "N";
                            objMFClient.TPoliticallyExposed = Convert.ToString(ClientList[0].thpep) == "True" ? "Y" : "N";
                            objMFClient.TRelatedToPoliticallyExposed = Convert.ToString(ClientList[0].thrpep) == "True" ? "Y" : "N";
                            objMFClient.GPoliticallyExposed = ClientList[0].gpoliticallyexposed ?? "";
                            objMFClient.GRelatedToPoliticallyExposed = ClientList[0].grelatedtopoliticallyexposed ?? "";
                            objMFClient.FKRA = ClientList[0].fhkycstatus ?? "";
                            objMFClient.FCOB = ClientList[0].fhbirthcountry ?? "";
                            objMFClient.accountNumber = ClientList[0].accountno ?? "";
                            objMFClient.accountType = ClientList[0].accounttype ?? "";
                            objMFClient.bankName = ClientList[0].bankname ?? "";
                            objMFClient.branchCity = ClientList[0].branchcity ?? "";
                            objMFClient.branchName = ClientList[0].branchname ?? "";
                            objMFClient.ifscCode = ClientList[0].ifsccode ?? "";
                            objMFClient.micrCode = ClientList[0].micrcode ?? "";
                            objMFClient.branchPin = Convert.ToString(ClientList[0].branchpincode) ?? "";
                            objMFClient.schemeCategory = ClientList[0].schemecategory ?? "";
                            objMFClient.schemeName = ClientList[0].schemename ?? "";
                            objMFClient.schemePlan = ClientList[0].schemeplan ?? "";
                            objMFClient.schemeOption = ClientList[0].schemeoption ?? "";
                            objMFClient.investmentAmount = ClientList[0].investmentamount ?? 0;
                            objMFClient.brokerCode = ClientList[0].brokercode ?? "";
                            objMFClient.subBrokerCode = ClientList[0].subbrokercode ?? "";
                            objMFClient.subBrokerArn = ClientList[0].subbrokerarn ?? "";
                            objMFClient.euin = ClientList[0].euin ?? "";
                            objMFClient.euinDeclaration = ClientList[0].euindeclaration ?? "";
                            objMFClient.Nomname = ClientList[0].fnomineename ?? "";
                            objMFClient.relationship = ClientList[0].fnomrelationship ?? "";
                            objMFClient.percentageAllocation = ClientList[0].fnomineepercentage ?? "";
                            objMFClient.Nomaddress1 = ClientList[0].fnomaddress1 ?? "";
                            objMFClient.Nomaddress2 = ClientList[0].fnomaddress2 ?? "";
                            objMFClient.Nomaddress3 = ClientList[0].nomaddress3 ?? "";
                            objMFClient.Nomcountry = ClientList[0].nomcountry ?? "";
                            objMFClient.Nomcity = ClientList[0].nomcity ?? "";
                            objMFClient.NomzipCode = ClientList[0].nomzipcode ?? "";
                            objMFClient.Nomdob = KarvyRequest.DateConvert(ClientList[0].fnomineedob, "yyyy-MM-dd")  ?? "";
                            objMFClient.NomguardianName = ClientList[0].fnomgaurdianname ?? "";
                            objMFClient.nominee2 = ClientList[0].snomineename ?? "";
                            objMFClient.nom2Relation = ClientList[0].snomrelationship ?? "";
                            objMFClient.nominee2percentage = ClientList[0].snomineepercentage ?? "";
                            objMFClient.nom2add1 = ClientList[0].snomaddress1 ?? "";
                            objMFClient.nom2add2 = ClientList[0].snomaddress2 ?? "";
                            objMFClient.nom2add3 = ClientList[0].nom2add3 ?? "";
                            objMFClient.nom2country = ClientList[0].nom2country ?? "";
                            objMFClient.nom2city = ClientList[0].nom2city ?? "";
                            objMFClient.nom2pin = ClientList[0].nom2pin ?? "";
                            objMFClient.nom2DOB = ClientList[0].snomineedob ?? "";
                            objMFClient.nom2Gaurdian = ClientList[0].snomgaurdianname ?? "";
                            objMFClient.nominee3 = ClientList[0].tnomineename ?? "";
                            objMFClient.nom3Relation = ClientList[0].tnomrelationship ?? "";
                            objMFClient.nominee3percentage = ClientList[0].tnomineepercentage ?? "";
                            objMFClient.nom3add1 = ClientList[0].tnomaddress1 ?? "";
                            objMFClient.nom3add2 = ClientList[0].tnomaddress2 ?? "";
                            objMFClient.nom3add3 = ClientList[0].nom3add3 ?? "";
                            objMFClient.nom3country = ClientList[0].nom3country ?? "";
                            objMFClient.nom3city = ClientList[0].nom3city ?? "";
                            objMFClient.nom3pin = ClientList[0].nom3pin ?? "";
                            objMFClient.nom3DOB = ClientList[0].tnomineedob ?? "";
                            objMFClient.nom3Gaurdian = ClientList[0].tnomgaurdianname ?? "";
                            objMFClient.annualIncome = ClientList[0].fhincomeslab ?? "";
                            objMFClient.countryOfBirth = ClientList[0].fhbirthcountry ?? "";
                            objMFClient.nationality = ClientList[0].fhnationality ?? "";
                            objMFClient.countryOfTaxResident = ClientList[0].fhbirthcountry ?? "";
                            objMFClient.foreignTaxNumber = ClientList[0].fhforigntaxid ?? "";
                            objMFClient.pep = Convert.ToString(ClientList[0].fhpep) == "True" ? "Y" : "N";
                            objMFClient.relatedToPEP = Convert.ToString(ClientList[0].fhrpep) == "True" ? "Y" : "N";
                            objMFClient.Nriaddress1 = ClientList[0].nriaddress1 ?? "";
                            objMFClient.Nriaddress2 = ClientList[0].nriaddress2 ?? "";
                            objMFClient.Nriaddress3 = ClientList[0].nriaddress3 ?? "";
                            objMFClient.Nricountry = ClientList[0].nricountry ?? "";
                            objMFClient.Nricity = ClientList[0].nricity ?? "";
                            objMFClient.NrizipCode = ClientList[0].nrizipcode ?? "";
                            objMFClient.Invname = ClientList[0].fhname;
                            objMFClient.Invaddress1 = ClientList[0].fhwing ?? "" + " " + ClientList[0].fharea ?? "" + " " + ClientList[0].fhlandmark ?? "";
                            objMFClient.Invaddress2 = ClientList[0].fhstate ?? "" + " " + ClientList[0].fhstate ?? "" + " " + ClientList[0].fhcountry ?? "";
                            objMFClient.Invaddress3 = ClientList[0].fhcity ?? "" + " " + ClientList[0].fhpincode ?? "";
                            objMFClient.Invoccupation = ClientList[0].fhoccupation ?? "";
                            objMFClient.InvresidenceCategory = ClientList[0].category ?? "";
                            objMFClient.Invpan = ClientList[0].fhpanno ?? "";
                            objMFClient.InvmobileNumber = ClientList[0].fhmobileno ?? "";
                            objMFClient.Invemail = ClientList[0].fhemailid ?? "";
                            objMFClient.Invdob = KarvyRequest.DateConvert(ClientList[0].fhdob, "yyyy-MM-dd") ?? "";
                            objMFClient.ModeOfHolding = ClientList[0].modeofholding ?? "";
                            objMFClient.CompanyCode = ClientList[0].companycode ?? "";
                            objMFClient.EmployeeCode = ClientList[0].employeecode ?? "";
                            objMFClient.accOpeningMode = ClientList[0].accopeningmode ?? "";
                            objMFClient.HoldingDematMode = ClientList[0].holdingdematmode ?? "";
                            objMFClient.NSDLCDSL = ClientList[0].nsdlcdsl ?? "";
                            objMFClient.DPIdClientId = ClientList[0].dpidclientid ?? "";
                            objMFClient.GoalId = ClientList[0].GoalId ?? "";
                            objMFClient.MOGSipflag = ClientList[0].mogsipflag ?? "";
                            objMFClient.Refno = Convert.ToString(ClientList[0].userid) ?? "";
                            objMFClient.GuardianName = ClientList[0].fhgaurdianname ?? "";
                            objMFClient.GMobileNo = ClientList[0].fhmobileno ?? "";
                            objMFClient.GPan = ClientList[0].fhgaurdianpan ?? "";
                            objMFClient.GGender = ClientList[0].ggender ?? "";
                            objMFClient.GDob = KarvyRequest.DateConvert(ClientList[0].gdob, "yyyy-MM-dd") ?? "";
                            objMFClient.GRelation = ClientList[0].grelation ?? "";
                            objMFClient.GCOB = ClientList[0].gcob ?? "";
                            objMFClient.GAnnualIncome = ClientList[0].gannualincome ?? "";
                            objMFClient.GNationality = ClientList[0].gnationality ?? "";
                            objMFClient.GTaxResident = ClientList[0].gtaxresident ?? "";
                            objMFClient.GForeignTaxId = ClientList[0].gforeigntaxid ?? "";
                            objMFClient.GFather = ClientList[0].gfather ?? "";
                            objMFClient.GKRA = ClientList[0].fhgaurdiankycstatus ?? "";
                            objMFClient.SecondInvName = ClientList[0].shname ?? "";
                            objMFClient.ThirdInvName = ClientList[0].thname ?? "";
                            objMFClient.SecondInvOccupation = ClientList[0].shoccupation ?? "";
                            objMFClient.ThirdInvOccupation = ClientList[0].thoccupation ?? "";
                            objMFClient.SecondInvDOB = KarvyRequest.DateConvert(ClientList[0].shdob, "yyyy-MM-dd")  ?? "";
                            objMFClient.ThirdInvDOB = KarvyRequest.DateConvert(ClientList[0].thdob, "yyyy-MM-dd") ?? "";
                            objMFClient.SecondInvEMail = ClientList[0].shemailid ?? "";
                            objMFClient.ThirdInvEMail = ClientList[0].themailid ?? "";
                            objMFClient.SecondInvMobile = ClientList[0].shmobileno ?? "";
                            objMFClient.ThirdInvMobile = ClientList[0].thmobileno ?? "";
                            objMFClient.SecondInvSalutation = ClientList[0].shsalutation ?? "";
                            objMFClient.ThirdInvSalutation = ClientList[0].thsalutation ?? "";
                            objMFClient.SAnnualIncome = ClientList[0].shincomeslab ?? "";
                            objMFClient.SNationality = ClientList[0].shnationality ?? "";
                            objMFClient.STaxResident = ClientList[0].shtaxresident ?? "";
                            objMFClient.SForeignTaxID = ClientList[0].shforigntaxid ?? "";
                            objMFClient.TAnnualIncome = ClientList[0].thincomeslab ?? "";
                            objMFClient.TNationality = ClientList[0].thnationality ?? "";
                            objMFClient.TTaxResident = ClientList[0].thtaxresident ?? "";
                            objMFClient.TForeignTaxID = ClientList[0].thforigntaxid ?? "";
                            objMFClient.SGender = ClientList[0].sgender ?? "";
                            objMFClient.TGender = ClientList[0].tgender ?? "";
                            objMFClient.SFather = ClientList[0].sfather ?? "";
                            objMFClient.TFather = ClientList[0].tfather ?? "";
                            objMFClient.SecondInvPAN = ClientList[0].shpanno ?? "";
                            objMFClient.ThirdInvPAN = ClientList[0].thpanno ?? "";
                            objMFClient.ckycrefno1 = ClientList[0].ckycrefno1 ?? "";
                            objMFClient.ckycrefno2 = ClientList[0].ckycrefno2 ?? "";
                            objMFClient.ckycrefno3 = ClientList[0].ckycrefno3 ?? "";
                            objMFClient.ckycrefnog = ClientList[0].ckycrefnog ?? "";
                            objMFClient.SCOB = ClientList[0].shbirthcountry ?? "";
                            objMFClient.TCOB = ClientList[0].thbirthcountry ?? "";
                            objMFClient.chequeCopy = ClientList[0].chequeimage ?? "";
                            objMFClient.Status = InvStatus;
                            JObject input = JObject.FromObject(objMFClient);
                            input.Add("Adminusername", Adminusername);
                            input.Add("Adminpassword", Adminpassword);
                            inputJson = JsonConvert.SerializeObject(input);
                            if (_iconfiguration["ZBFLog"] == "On")
                            {
                                ReqLog = _iconfiguration["RequestLog"];
                                ReqLog = ReqLog + "_ZBF_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Date.ToString("dd") + ".txt";
                                File.AppendAllText(ReqLog, "\r\n" + DateTime.Now.ToString() + "\r AppID :" + AppID + "\r UserId :" + Convert.ToString(userId) + "\r Request :" + inputJson);
                            }
                            var result = KarvyRequest.CreateHTTPRequest(KarvAPIName, serviceUrl, inputJson);
                            var _Jobj = JObject.Parse(result);
                            finalSubmitRes.dateTimeStamp = Convert.ToString(_Jobj["dateTimeStamp"]);
                            finalSubmitRes.APP_REF_NO = Convert.ToString(_Jobj["APP_REF_NO"]);
                            finalSubmitRes.folio = Convert.ToString(_Jobj["folio"]);
                            finalSubmitRes.GoalId = Convert.ToString(_Jobj["GoalId"]);
                            finalSubmitRes.GroupId = Convert.ToString(_Jobj["GroupId"]);
                            finalSubmitRes.message = Convert.ToString(_Jobj["message"]);
                            finalSubmitRes.RefNo = Convert.ToString(_Jobj["RefNo"]);
                            finalSubmitRes.statusCode = Convert.ToString(_Jobj["statusCode"]);
                            finalSubmitRes.transactionId = Convert.ToString(_Jobj["transactionId"]);
                            //added by Suryakant 
                            finalSubmitRes.modeOfHolding = objMFClient.ModeOfHolding;
                            finalSubmitRes.bankName = objMFClient.bankName;
                            finalSubmitRes.accountNo = objMFClient.accountNumber;
                            finalSubmitRes.ifscCode = objMFClient.ifscCode;
                            finalSubmitRes.micrCode = objMFClient.micrCode;
                            var SavefinalSubmitRes = await conn.QueryAsync("MF.USP_SAVE_CLIENT_KARY_RESPONSE", new
                            {
                                APP_REF_NO = Convert.ToString(finalSubmitRes.APP_REF_NO),
                                DATETIMESTAMP = Convert.ToString(finalSubmitRes.dateTimeStamp),
                                FOLIO = Convert.ToString(finalSubmitRes.folio),
                                GOALID = Convert.ToString(finalSubmitRes.GoalId),
                                GROUPID = Convert.ToString(finalSubmitRes.GroupId),
                                MESSAGE = Convert.ToString(finalSubmitRes.message),
                                REFNO = Convert.ToString(finalSubmitRes.RefNo),
                                STATUSCODE = Convert.ToString(finalSubmitRes.statusCode),
                                TRANSACTIONID = Convert.ToString(finalSubmitRes.transactionId),
                                ReqJson = Convert.ToString(inputJson)
                            }, commandType: CommandType.StoredProcedure);
                            if (finalSubmitRes.statusCode == "200")
                            {
                                return new ResponseDataModel<FinalSubmitRes>(finalSubmitRes);
                            }
                            else
                            {
                                return new ResponseDataModel<FinalSubmitRes>(null, finalSubmitRes.message.ToString());
                            }
                        }
                        catch (Exception ex)
                        {
                            //    var SavefinalSubmitRes = await conn.QueryAsync("MF.USP_SAVE_CLIENT_KARY_RESPONSE", new
                            //    {
                            //        APP_REF_NO = Convert.ToString(finalSubmitRes.APP_REF_NO),
                            //        DATETIMESTAMP = Convert.ToString(finalSubmitRes.dateTimeStamp),
                            //        FOLIO = Convert.ToString(finalSubmitRes.folio),
                            //        GOALID = Convert.ToString(finalSubmitRes.GoalId),
                            //        GROUPID = Convert.ToString(finalSubmitRes.GroupId),
                            //        MESSAGE = Convert.ToString(ex.Message),
                            //        REFNO = Convert.ToString(objMFClient.Refno),
                            //        STATUSCODE = "0",
                            //        TRANSACTIONID = Convert.ToString(finalSubmitRes.transactionId),
                            //        ReqJson = inputJson
                            //    }, commandType: CommandType.StoredProcedure);
                            //    ErrorLogFile = _iconfiguration["ErrorLogFile"];
                            //    ErrorLogFile = ErrorLogFile + "_" + DateTime.Now.Year.ToString() + DateTime.Now.Date.ToString("MM") + DateTime.Now.Date.ToString("dd") + ".log";
                            //    File.AppendAllText(ErrorLogFile, "\r\n" + DateTime.Now.ToString() + "\r Method :" + "saveMFClientSubmit \r UserId :" + Convert.ToString(objMFClient.Refno) + " ERROR:" + ex.Message);
                            //    return new ResponseDataModel<FinalSubmitRes>(null, ex.Message);
                            //}
                            return new ResponseDataModel<FinalSubmitRes>(null, ex.Message);
                        }
                    }
                    else
                    {
                        throw new NoDataException(false);
                    }
                }
            }
        }

        
    }
}

