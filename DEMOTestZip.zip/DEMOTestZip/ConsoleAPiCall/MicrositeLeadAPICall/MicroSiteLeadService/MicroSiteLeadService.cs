﻿using MicroSiteLeadService.BAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Threading;

namespace MicroSiteLeadService
{
    public partial class MicroSiteLeadService : ServiceBase
    {
        System.Threading.Timer timer1;
        private static ATLoggerClass.ATFileLogger log = new ATLoggerClass.ATFileLogger();
        public MicroSiteLeadService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            log = new ATLoggerClass.ATFileLogger();
            log.Path = ApplicationPath() + "\\Log";
            log.Log("Service Start at"+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            int timeSecond = Convert.ToInt32(ConfigurationManager.AppSettings["timeSecond"].ToString());
            timer1 = new System.Threading.Timer(new TimerCallback(GetMicrositeLeadData), null, 1000, timeSecond);
            
        }
        public void GetMicrositeLeadData(object obj)
        {
            log = new ATLoggerClass.ATFileLogger();
            log.Path = ApplicationPath() + "\\Log";
            log.Log("GetMicrositeLeadData Started at :"+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            //GetMicrositeData();
            //GetMicrositeDataTb();
            int MaxLead;
            MaxLead = getMaxLeadId();
            SaveMissCallLead();
            SaveMicrositeLead(MaxLead);
            log.Log("GetMicrositeLeadData Executed Successfully at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
        }
        public void SaveMissCallLead()
        {
            try
            {
                int Result = 0;
                MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                Result = objMicrositeLeadBAL.SaveMissCallLeadData();
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "SaveMissCallLead");
            }
        }

        public int getMaxLeadId()
        {
            try
            {
                log = new ATLoggerClass.ATFileLogger();
                log.Path = ApplicationPath() + "\\Log";
                log.Log("getMaxLeadId Started at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                int MarketingLeadId = 0;
                MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                MarketingLeadId = objMicrositeLeadBAL.GetMaxMarketingLead();
                log.Log("getMaxLeadId End at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                return MarketingLeadId;
        
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "getMaxLeadId");
                log = new ATLoggerClass.ATFileLogger();
                log.Path = ApplicationPath() + "\\Log";
                log.Log("getMaxLeadId Throws Exception " + ex.Message + " " + ex.StackTrace + " " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                return 0;
            }
        }

        public void SaveMicrositeLead(int maxLeadId)
        {
            try
            {
                log = new ATLoggerClass.ATFileLogger();
                log.Path = ApplicationPath() + "\\Log";
                log.Log("SaveMicrositeLead Started at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                string MicrositeLeadAPI;
                MicrositeLeadAPI = ConfigurationManager.AppSettings.Get("CentrumMicrositeLeadAPI").ToString();
                MicrositeLeadAPI = MicrositeLeadAPI + Convert.ToString(maxLeadId);
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(MicrositeLeadAPI);
                    List<MicroSiteLead> objLeadData = new JavaScriptSerializer().Deserialize<List<MicroSiteLead>>(result);
                    MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                    string Result = objMicrositeLeadBAL.SaveMicrositeLeadData(Utilities.ObjectToXMLString(objLeadData));
                    log.Log("SaveMicrositeLead End at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss")+" Result:"+Convert.ToString(Result));
                }
            }
            catch (Exception ex)
            {
                log = new ATLoggerClass.ATFileLogger();
                log.Path = ApplicationPath() + "\\Log";
                log.Log("SaveMicrositeLead Throws Exception " + ex.Message + " " + ex.StackTrace + " " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "SaveMicrositeLead");
            }
        }
        public void GetMicrositeData()
        {
            log = new ATLoggerClass.ATFileLogger();
            log.Path = ApplicationPath() + "\\Log";
            log.Log("GetMicrositeData Started at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            try
            {
                string MicrositeLeadAPI;
                MicrositeLeadAPI = ConfigurationManager.AppSettings.Get("MicrositeLeadAPI").ToString();
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(MicrositeLeadAPI);
                    List<Lead> objLeadData = new JavaScriptSerializer().Deserialize<List<Lead>>(result);
                    objLeadData = objLeadData.FindAll(Lead => Lead.date_created.ToString("dd-MM-yyyy") == DateTime.Now.ToString("dd-MM-yyyy"));
                    MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                    string Result = objMicrositeLeadBAL.SaveLeadData(Utilities.ObjectToXMLString(objLeadData));
                }
                log.Log("GetMicrositeData Finished at "+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            }
            catch (Exception ex)
            {
                //Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "GetMicrositeData");
                log = new ATLoggerClass.ATFileLogger();
                log.Path = ApplicationPath() + "\\Log";
                log.Log("GetMicrositeData Throws Exception " + ex.Message +" "+ ex.StackTrace +" "+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            }
        }
        public void GetMicrositeDataTb()
        {
            log = new ATLoggerClass.ATFileLogger();
            log.Path = ApplicationPath() + "\\Log";
            log.Log("GetMicrositeDataTb Started at :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            try
            {
                string MicrositeLeadTbAPI;
                MicrositeLeadTbAPI = ConfigurationManager.AppSettings.Get("MicrositeLeadDownloadAPI").ToString();
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(MicrositeLeadTbAPI);
                    List<Lead> objLeadData = new JavaScriptSerializer().Deserialize<List<Lead>>(result);
                    objLeadData = objLeadData.FindAll(Lead => Lead.date_created.ToString("dd-MM-yyyy") == DateTime.Now.ToString("dd-MM-yyyy"));
                    MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                    string Result = objMicrositeLeadBAL.SaveLeadData(Utilities.ObjectToXMLString(objLeadData));
                }
                log.Log("GetMicrositeDataTb Finished at " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            }
            catch (Exception ex)
            {
                //Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "GetMicrositeDataTb");
                log = new ATLoggerClass.ATFileLogger();
                log.Path = ApplicationPath() + "\\Log";
                log.Log("GetMicrositeDataTb Throws Exception " + ex.Message + " " + ex.StackTrace + " " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
            }
        }
        static string ApplicationPath()
        {
            try
            {
                string lAppName = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string lExecutionPath = System.IO.Path.GetDirectoryName(lAppName);
                return lExecutionPath;
            }
            catch (System.Exception ex)
            {
                return string.Empty;
            }
        }
        protected override void OnStop()
        {
            log = new ATLoggerClass.ATFileLogger();
            log.Path = ApplicationPath() + "\\Log";
            log.Log("Service Stop at "+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
        }
    }
}
