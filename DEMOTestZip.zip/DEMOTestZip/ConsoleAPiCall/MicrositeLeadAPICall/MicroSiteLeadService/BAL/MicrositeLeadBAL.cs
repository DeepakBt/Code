﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicroSiteLeadService.DAL;
using System.Data;
using System.Data.SqlClient;

namespace MicroSiteLeadService.BAL
{
    public class MicrositeLeadBAL
    {
        SqlCommand cmd;
        public string SaveLeadData(string XMLData)
        {
            try
            {
                string Result = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_LEAD_DETAILS");
                Result = Convert.ToString(dt.Rows[0][1]);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int GetMaxMarketingLead()
        {
            try
            {
                int MaxLeadId;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_MARKETING_LEAD");
                MaxLeadId = Convert.ToInt32(dt.Rows[0]["MaxMarketingLeadID"] == DBNull.Value ? 0 : dt.Rows[0]["MaxMarketingLeadID"]);
                return MaxLeadId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int SaveMissCallLeadData()
        {
            try
            {
                int Result = 0;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CTI_TELECALLER_MISSED_LEAD");
                Result = Convert.ToInt32(dt.Rows[0]["Result"]);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveMicrositeLeadData(string XMLData)
        {
            try
            {
                string Result = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_MARKETING_LEAD");
                Result = Convert.ToString(dt.Rows[0]["Result"]);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    public class Lead
    {
        public string id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string budget { get; set; }
        public string FlatConfig { get; set; }
        public string text { get; set; }
        public DateTime date_created { get; set; }
        public string ip { get; set; }
    }
    public class MicroSiteLead
    {
        public int id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email { get; set; }
        public string contact { get; set; }
        public int configuration { get; set; }
        public int source { get; set; }
        public int project { get; set; }
    }
}
