﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using MicrositeLeadAPICall.BAL;
namespace MicrositeLeadAPICall
{
    class Program
    {
        static void Main(string[] args)
        {
            Program pro = new Program();
            int MaxLead;
            MaxLead = pro.getMaxLeadId();
            pro.SaveMissCallLead();
            pro.SaveMicrositeLead(MaxLead);
            //pro.GetMicrositeData();
            //pro.GetMicrositeDataTb();
        }
        public void GetMicrositeData()
        {
            try
            {
                string MicrositeLeadAPI;
                MicrositeLeadAPI = ConfigurationManager.AppSettings.Get("MicrositeLeadAPI").ToString();
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(MicrositeLeadAPI);
                    List<Lead> objLeadData = new JavaScriptSerializer().Deserialize<List<Lead>>(result);
                    objLeadData= objLeadData.FindAll(Lead => Lead.date_created.ToString("dd-MM-yyyy") == DateTime.Now.ToString("dd-MM-yyyy"));
                    MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                    string Result = objMicrositeLeadBAL.SaveLeadData(Utilities.ObjectToXMLString(objLeadData));
                    Console.WriteLine(Result);
                }
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "GetMicrositeData");
                throw ex;
            }
        }
        public void GetMicrositeDataTb()
        {
            try
            {
                string MicrositeLeadTbAPI;
                MicrositeLeadTbAPI = ConfigurationManager.AppSettings.Get("MicrositeLeadDownloadAPI").ToString();
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(MicrositeLeadTbAPI);
                    List<Lead> objLeadData = new JavaScriptSerializer().Deserialize<List<Lead>>(result);
                    objLeadData = objLeadData.FindAll(Lead => Lead.date_created.ToString("dd-MM-yyyy") == DateTime.Now.ToString("dd-MM-yyyy"));
                    MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                    string Result = objMicrositeLeadBAL.SaveLeadData(Utilities.ObjectToXMLString(objLeadData));
                    Console.WriteLine(Result);
                }
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "GetMicrositeDataTb");
                throw ex;
            }
        }

        public void SaveMissCallLead()
        {
            try
            {
                int Result = 0;
                MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                Result=objMicrositeLeadBAL.SaveMissCallLeadData();
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "SaveMissCallLead");
            }
        }

        public int getMaxLeadId()
        {
            try
            {
                int MarketingLeadId = 0;
                MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                MarketingLeadId = objMicrositeLeadBAL.GetMaxMarketingLead();
                return MarketingLeadId;
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "getMaxLeadId");
                return 0;
            }
        }

        public void SaveMicrositeLead(int maxLeadId)
        {
            try
            {
                string MicrositeLeadAPI;
                MicrositeLeadAPI = ConfigurationManager.AppSettings.Get("CentrumMicrositeLeadAPI").ToString();
                MicrositeLeadAPI = MicrositeLeadAPI + Convert.ToString(maxLeadId);
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(MicrositeLeadAPI);
                    List<MicroSiteLead> objLeadData = new JavaScriptSerializer().Deserialize<List<MicroSiteLead>>(result);
                    MicrositeLeadBAL objMicrositeLeadBAL = new MicrositeLeadBAL();
                    string Result = objMicrositeLeadBAL.SaveMicrositeLeadData(Utilities.ObjectToXMLString(objLeadData));
                }
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "MicrositeLeadAPICall", "SaveMicrositeLead");
                throw ex;
            }
        }
    }
}
