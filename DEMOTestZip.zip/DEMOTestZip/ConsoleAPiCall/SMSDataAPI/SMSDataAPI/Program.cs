﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace SMSDataAPI
{
    class Program
    {
        string UserName, Password, CCode,GetDate;
        int LoopCount = 0;
        List<int> CountList;
        int DivideBy = Convert.ToInt32(ConfigurationManager.AppSettings.Get("SMSCountLimit").ToString());
        static void Main(string[] args)
        {
            Program objProgram = new Program();
            objProgram.UserName = ConfigurationManager.AppSettings.Get("user").ToString();
            objProgram.Password = ConfigurationManager.AppSettings.Get("password").ToString();
            objProgram.CCode = ConfigurationManager.AppSettings.Get("ccode").ToString();
            objProgram.LoopCount = objProgram.GetSMSLoopLimit();
            objProgram.GetSMSAPIData(objProgram.LoopCount);
            Console.WriteLine(objProgram.LoopCount);
            Console.ReadKey();
        }
        public int GetSMSLoopLimit()
        {
            try
            {
                decimal LimitDiv;
                string CountAPILink = string.Empty;
                GetDate = DateTime.Now.ToString("dd-MM-yyyy");
                CountAPILink = ConfigurationManager.AppSettings.Get("SMSCountAPI").ToString();
                CountAPILink = CountAPILink + "?user=" + UserName + "&password=" + Password + "&ccode=" + CCode + "&fromDate=" + GetDate;
                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(CountAPILink);
                    CountList = result.Split(',').Select(int.Parse).ToList();
                    LimitDiv = Convert.ToDecimal(CountList[0]) / Convert.ToDecimal(DivideBy);
                    if(LimitDiv>0 && LimitDiv<1)
                    {
                        LoopCount = 1;
                    }else
                    {
                        LoopCount = Convert.ToInt32(LimitDiv)+1; 
                    }
                }
                return LoopCount;
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "GetSMSLoopLimit", "SMSDataAPI");
                throw ex;
            }
        }
        public void GetSMSAPIData(int Count)
        {
            try
            {
                string SMSDataAPILink = string.Empty;
                int APIStartCount, APIEndCount,LoopStartCount;
                LoopStartCount = 1;
                APIStartCount = 0;
                APIEndCount = DivideBy;
                GetDate = DateTime.Now.ToString("yyyy-MM-dd");
                while (LoopStartCount <= Count)
                {
                    SMSDataAPILink = ConfigurationManager.AppSettings.Get("SMSDataAPI").ToString();
                    SMSDataAPILink = SMSDataAPILink + "?user=" + UserName + "&password=" + Password + "&sentdate=" + GetDate + "&limit="+APIStartCount+","+APIEndCount;
                    using (var client = new WebClient())
                    {
                        client.Headers.Add("Content-Type:application/json");
                        client.Headers.Add("Accept:application/json");
                        var result = client.DownloadString(SMSDataAPILink);
                        SMSData objSMSData = new JavaScriptSerializer().Deserialize<SMSData>(result);
                        SMSBAL objSMSBAL = new SMSBAL();
                        string Result=objSMSBAL.SaveSMSData(Utilities.ObjectToXMLString(objSMSData));
                        Console.WriteLine(Result);
                    }
                    APIStartCount = APIEndCount+1;
                    APIEndCount = APIEndCount + DivideBy;
                    LoopStartCount = LoopStartCount + 1;
                }
            }
            catch (Exception ex)
            {
                Utilities.ErrorLog(ex.Message, "GetSMSAPIData", "SMSDataAPI");
                throw ex;
            }
        }
    }
}
