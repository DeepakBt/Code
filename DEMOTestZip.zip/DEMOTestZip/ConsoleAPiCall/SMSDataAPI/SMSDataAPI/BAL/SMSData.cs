﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SMSDataAPI
{
    public class SMSBAL
    {
        SqlCommand cmd;
        public string SaveSMSData(string XMLData)
        {
            try
            {
                string Result = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_SMS_LOG");
                Result = Convert.ToString(dt.Rows[0][1]);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    public class SMSData
    {
       public List<SMSList> smslist { get; set; }
    } 
    public class SMSList
    {
        public string senderid { get; set; }
        public DateTime senttime { get; set; }
        public string deliverystatus { get; set; }
        public string status { get; set; }
        public DateTime deliverytime { get; set; }
        public string mobileno { get; set; }
    }

}
