﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace SMSDataAPI
{
    public static class Utilities
    {
        static SqlCommand cmd;
        public static void ErrorLog(string ErrorMsg, string ErrorMethod, string ErrorSource)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@ErrMsg", ErrorMsg);
                cmd.Parameters.AddWithValue("@ActionMethod", ErrorMethod);
                cmd.Parameters.AddWithValue("@ErrorSource", ErrorSource);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_LOG_API_ERROR");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string ObjectToXMLString<T>(T objT)
        {
            string strXML = string.Empty;
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlSerializer xmlSerializer = new XmlSerializer(objT.GetType());
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, objT);
                    xmlStream.Position = 0;
                    xmlDoc.Load(xmlStream);
                    strXML = Convert.ToString(xmlDoc.InnerXml);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strXML;
        }
    }
}
