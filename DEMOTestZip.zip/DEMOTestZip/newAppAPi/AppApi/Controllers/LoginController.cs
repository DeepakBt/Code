﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BAL;
using AppApi.Filters;

namespace AppApi.Controllers
{
    public class LoginController : ApiController
    {
        LoginBAL empObj = new LoginBAL();
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult PostEmployeeLogin(Login e)
        {
            string JsonResponse = string.Empty;
            try
            {
                UserSession oUser = empObj.LogIn(Utilities.ObjectToXMLString(e));
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(oUser == null ? "" : serializer.Serialize(oUser));
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\PostEmployeeLogin", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        [GenericAuthenticationFilter]
        public IHttpActionResult GetEmployee(Login e)
        {
            try
            {
                string JsonResponse = string.Empty;
                JsonResponse = empObj.GetEmp();
                return Ok(JsonResponse);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\GetEmployee", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostGenerateOTP(Login e)
        {
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = empObj.GenerateOTP(Utilities.ObjectToXMLString(e));
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\PostGenerateOTP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostValidateOTP(Login e)
        {
            string JsonResponse = string.Empty;
            try
            {
                User oUser = empObj.ValidateOTP(Utilities.ObjectToXMLString(e));
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(oUser == null ? "" : serializer.Serialize(oUser));
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\PostValidateOTP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostLogOut(Login e)
        {
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = empObj.LogOut(Utilities.ObjectToXMLString(e));
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\PostLogOut", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        [GenericAuthenticationFilter]
        public IHttpActionResult PostChangePassword(Login e)
        {
            string JsonResponse = string.Empty;
            try
            {
                long EMPID = GetEmpID();
                int RoleId = GetRoleID();
                JsonResponse = empObj.ChangePassword(Utilities.ObjectToXMLString(e), EMPID, RoleId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\PostChangePassword", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostForgetPassword(ForgetPassword objForgetPassword)
        {
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = empObj.ForgetPassword(objForgetPassword);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\PostForgetPassword", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Login\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }
        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }
        #endregion

    }
}
