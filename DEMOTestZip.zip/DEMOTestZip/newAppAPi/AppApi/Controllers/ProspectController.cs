﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Web.Script.Serialization;
using BAL.Prop;
using Newtonsoft.Json;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class ProspectController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);

        [HttpGet]
        public IHttpActionResult GetPropertyMaster()
        {
            try
            {
                PropertyBAL objPropBAL = new PropertyBAL();
                string JSONResult = objPropBAL.GetPropertyMaster();
                return Ok(JSONResult);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\GetPropertyMaster", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetDataForProspectRMAssign(int PropertyId)
        {
            try
            {
                ProspectBAL objProspectBAL = new ProspectBAL();
                RMAssignMasterData oRMAssignMasterData = objProspectBAL.GetDataForProspectRMAssign(PropertyId);
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                return Ok(oRMAssignMasterData == null ? "" : serializer.Serialize(oRMAssignMasterData));
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\GetDataForProspectRMAssign", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpGet]
        public IHttpActionResult GetProspectMeeting(int MeetingId)
        {
            try
            {
                ProspectBAL objProspectBAL = new ProspectBAL();
                ProspectMeeting objProspectMeeting = objProspectBAL.GetMeetingDetails(MeetingId);
                return Ok(objProspectMeeting);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\GetProspectMeeting", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult AssignRMToProspect(Prospect oProspect)
        {
            var EMPID = GetEmpID();
            
            string JsonResponse = string.Empty;
            try
            {
                if (oProspect != null)
                {
                    ProspectBAL oProspectBAL = new ProspectBAL();
                    JsonResponse = oProspectBAL.AssignRMToProspect(oProspect, Convert.ToInt32(EMPID));
                }
                else
                {
                    throw new Exception("Select RM to assign");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\AssignRMToProspect", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetSalesRmList()
        {
            try
            {
                ProspectBAL oProspectBAL = new ProspectBAL();
                string JSONResult = oProspectBAL.GetSalesRmList();
                return Ok(JSONResult);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\GetSalesRmList", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetMOMQuestions()
        {
            try
            {
                ProspectBAL oProspectBAL = new ProspectBAL();
                List<ProspectMOMQuestions> lstProspectMOMQuestions = new List<ProspectMOMQuestions>();
                lstProspectMOMQuestions = oProspectBAL.GetProspectMOMQuestion();
                return Ok(lstProspectMOMQuestions);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\GetMOMQuestions", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostMeetingMOMDetails(Meeting objMeeting)
        {
            try
            {
                var EMPID = GetEmpID();
                var ROLEID = GetRoleID();
                int Flag = 1; //for Update Meeting Details with MOM Question Answer
                string JsonResponse = string.Empty;
                ProspectBAL objProspectBAL = new ProspectBAL();
                JsonResponse = objProspectBAL.UpdateMeetingDetails(Utilities.ObjectToXMLString(objMeeting),Convert.ToInt32(EMPID), Convert.ToInt32(ROLEID), Flag);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\PostMOMAnswer", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult PostMeetingReschedule(Meeting objMeeting)
        {
            try
            {
                var EMPID = GetEmpID();
                var ROLEID = GetRoleID();
                int Flag = 2; //for Update Reschedule Meeting
                string JsonResponse = string.Empty;
                ProspectBAL objProspectBAL = new ProspectBAL();
                JsonResponse = objProspectBAL.UpdateMeetingDetails(Utilities.ObjectToXMLString(objMeeting), Convert.ToInt32(EMPID), Convert.ToInt32(ROLEID), Flag);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\PostMeetingReschedule", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult PostMeeting(Meeting objMeeting)
        {
            try
            {
                var EMPID = GetEmpID();
                var ROLEID = GetRoleID();
                int Flag = 3; //for Inserting New Meeting
                string JsonResponse = string.Empty;
                ProspectBAL objProspectBAL = new ProspectBAL();
                JsonResponse = objProspectBAL.UpdateMeetingDetails(Utilities.ObjectToXMLString(objMeeting), Convert.ToInt32(EMPID), Convert.ToInt32(ROLEID), Flag);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\PostMeeting", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpGet]
        public IHttpActionResult GetMOMMasterData()
        {
            try
            {
                ProspectBAL objProspectBAL = new ProspectBAL();
                MOMMasters objMOMMaster = objProspectBAL.GetMOMMasterData();
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(objMOMMaster == null ? "" : serializer.Serialize(objMOMMaster));
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Prospect\GetMOMMasterData", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetProspect360DegreeView(Filters360degree objDashboard)
        {
            try
            {
                int RoleId = GetRoleID();
                long EmpId = GetEmpID();
                ProspectBAL objProspectBAL = new ProspectBAL();
                Prospects360View objProspects360View = new Prospects360View();
                objProspects360View = objProspectBAL.GetProspect360DegreeView(objDashboard, RoleId, EmpId);
                return Ok(objProspects360View);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetProspect360DegreeView", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetProspect360Summary(Filters360degree objDashboard)
        {
            try
            {
                int RoleId = GetRoleID();
                long EmpId = GetEmpID();
                ProspectBAL objProspectBAL = new ProspectBAL();
                Lead360Summary objLead360Summary = new Lead360Summary();
                objLead360Summary = objProspectBAL.GetLead360Summary(objDashboard,RoleId,EmpId);
                return Ok(objLead360Summary);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetProspect360Summary", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods
        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
        #endregion
    }
}
