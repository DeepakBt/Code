﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BAL;
using BAL.Prop;
namespace AppApi.Controllers
{
    public class GeneralController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult InsertGeneralLeadDetails(LeadProp oLead)
        {
            LeadBAL objLeadBAL = new LeadBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (oLead != null)
                {
                    JsonResponse = objLeadBAL.InsertGeneralLeadDetails(Utilities.ObjectToXMLString(oLead));
                }
                else
                {
                    throw new Exception("Fill Lead Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\InsertGeneralLeadDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult InsertSubscriberDetails(Subscriber oSubscriber)
        {
            CommonBAL objCommonBal = new CommonBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (oSubscriber != null)
                {
                    JsonResponse = objCommonBal.InsertSubscriber(Utilities.ObjectToXMLString(oSubscriber));
                }
                else
                {
                    throw new Exception("Fill Subscriber Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\InsertSubscriberDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertGeneralLeadMeeting(GeneralLeadMeeting objGeneralLeadMeeting)
        {
            CommonBAL objCommonBal = new CommonBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (objGeneralLeadMeeting != null)
                {
                    JsonResponse = objCommonBal.InsertGeneralLeadMeeting(Utilities.ObjectToXMLString(objGeneralLeadMeeting));
                }
                else
                {
                    throw new Exception("Fill Lead Meeting Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\InsertGeneralLeadMeeting", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertUnregisterCPDeveloper(UnregisterCPDeveloper objUnregisterCPDeveloper)
        {
            CommonBAL objCommonBal = new CommonBAL();
            int Flag;
            string JsonResponse = string.Empty;
            try
            {
                if (objUnregisterCPDeveloper != null)
                {
                    Flag = objUnregisterCPDeveloper.Flag;
                    JsonResponse = objCommonBal.InsertUnregisterCPDeveloper(Utilities.ObjectToXMLString(objUnregisterCPDeveloper), Flag);
                }
                else
                {
                    throw new Exception("Fill Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\InsertUnregisterCPDeveloper", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertTest(TestInsert objIns)
        {
            CommonBAL objCommonBal = new CommonBAL();
            int Flag;
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = objCommonBal.InsertIntoTest(objIns);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\InsertTest", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostContactUs(ContactUs objContactUs)
        {
            CommonBAL objCommonBal = new CommonBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (objContactUs != null)
                {
                    JsonResponse = objCommonBal.InsertContactUs(Utilities.ObjectToXMLString(objContactUs));
                }
                else
                {
                    throw new Exception("Fill Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\PostContactUs", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetKnowledgeCenterArticle(Filters360degree objFilter)
        {
            try
            {
                CommonBAL objCommonBal = new CommonBAL();
                List<KnowledgeCenterArticle> objLstKnowledgeCenterArticle = new List<KnowledgeCenterArticle>();
                objLstKnowledgeCenterArticle = objCommonBal.GetArticle(objFilter);
                return Ok(objLstKnowledgeCenterArticle);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\GetKnowledgeCenterArticle", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpGet]
        public IHttpActionResult UnSubscribe(string EmailId)
        {
            CommonBAL objCommonBal = new CommonBAL();
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = objCommonBal.InsertUnSubscribe(EmailId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"General\UnSubscribe", "API");
                throw new HttpResponseException(badRequest);
            }
        }


        [HttpGet]
        public IHttpActionResult GetPropertyDetails(int PropertyId)
        {
            try
            {
                PropertyBAL objPropBAL = new PropertyBAL();
                Property objProperty = objPropBAL.GetPropertyDetails(PropertyId);
                return Ok(objProperty);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetPropertyDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }
    }
}
