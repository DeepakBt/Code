﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using Newtonsoft.Json;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class CustomerController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetCustomer360DegreeView(Filters360degree objDashboard)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                Customer objCustomer = objCustomerBAL.GetCustomer360DegreeView(objDashboard);
                return Ok(objCustomer);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetCustomer360DegreeView", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetCustomer360Summary(Filters360degree objDashboard)
        {
            try
            {
                int RoleId = GetRoleID();
                long EmpId = GetEmpID();
                CustomerBAL objCustomerBAL = new CustomerBAL();
                Customer360Summary objCustomer360Summary = objCustomerBAL.GetCustomer360Summary(objDashboard,RoleId,EmpId);
                return Ok(objCustomer360Summary);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetCustomer360Summary", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetProjectUpdate(Filters360degree objDashboard)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                ProjectUpdateWrapper objProjectUpdateWrapper = objCustomerBAL.GetProjectUpdate(objDashboard);
                return Ok(objProjectUpdateWrapper);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetProjectUpdate", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetSlabWisePaymentDetails(Filters360degree objDashboard)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                List<SlabPaymentDetails> objLstSlabPaymentDetails = objCustomerBAL.GetSlabPaymentDetails(objDashboard);
                return Ok(objLstSlabPaymentDetails);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetSlabWisePaymentDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetBankLoadDetails(Filters360degree objDashboard)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                List<BankLoanProcess> objBankLoanProcess = objCustomerBAL.GetLoanProcess(objDashboard);
                return Ok(objBankLoanProcess);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetBankLoadDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetQueryRequestDDL(Filters360degree objDashboard)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                List<Dropdown> objDropdown = objCustomerBAL.GetQueryReqDDL(objDashboard);
                return Ok(objDropdown);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetQueryRequestDDL", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetLoanProcessDetails(int BankId)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                BankLoanProcess oBankLoanProcess = objCustomerBAL.GetLoanProcessDetails(BankId);
                return Ok(oBankLoanProcess);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetQueryRequestDDL", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetProspectDetails(Filters360degree objDashboard)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                CustomerBooking objCustomer = objCustomerBAL.GetProspectDetails(objDashboard,Convert.ToInt32(GetEmpID()));
                return Ok(objCustomer);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\GetProspectDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult SaveCustomer(List<CustomerBooking> LstobjCustomer)
        {
            try
            {
                CustomerBAL objCustomerBAL = new CustomerBAL();
                string JResponse;
                JResponse = objCustomerBAL.SaveCustomer(Utilities.ObjectToXMLString(LstobjCustomer),Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()));
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Customer\SaveCustomer", "API");
                throw new HttpResponseException(badRequest);
            }
        }


        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
    }
}
