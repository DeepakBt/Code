﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using System.Web;
using System.IO;
using System.Configuration;
using System.Data;
using BAL.Prop;
using Newtonsoft.Json;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class CPController : ApiController
    {
        string TempFolder = System.Web.HttpContext.Current.Server.MapPath(Convert.ToString(ConfigurationSettings.AppSettings["FolderName"])) + "\\";
        string PdfTemplate = System.Web.HttpContext.Current.Server.MapPath(Convert.ToString(ConfigurationSettings.AppSettings["Template"])) + "\\";

        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        CpBAL objCP = new CpBAL();
        FtpSave ftp = new FtpSave();

        [HttpPost]
        public IHttpActionResult PostCPDetails(CP cp)
        {
            var EMPID = GetEmpID();

            string JsonResponse = string.Empty;
            try
            {
                if (cp != null)
                {
                    Boolean Result = true;
                    JsonResponse = objCP.InsertCP(Utilities.ObjectToXMLString(cp), Convert.ToInt32(EMPID), 5);
                    if (JsonResponse == "2")
                    {
                        Result = SaveImage(cp.ImageData, cp.ImagePath, cp.ImageName);
                    }
                    if (Result)
                    {
                        JsonResponse = objCP.InsertCP(Utilities.ObjectToXMLString(cp), Convert.ToInt32(EMPID), 1);
                    }
                    else
                    {
                        throw new Exception("Fill CP Data");
                    }
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\PostCPDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetCPDetails([FromUri] int CPId)
        {

            var EMPID = GetEmpID();

            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = objCP.GetCP(Convert.ToInt32(EMPID), CPId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetSearchedCity(string SearchCity)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                string JsonResponse = "";
                JsonResponse = objCpBAL.GetCityListOnSearch(SearchCity);
                return Ok(JsonResponse);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetSearchedCity", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetCityFromPin(string SearchedPin)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                string JsonResponse = "";
                JsonResponse = objCpBAL.GetCityFromPin(SearchedPin);
                return Ok(JsonResponse);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCityFromPin", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetMasterDataForNewCP()
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                CPMasterData oCPMasterData = objCpBAL.GetMasterDataForNewCP();
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(oCPMasterData == null ? "" : serializer.Serialize(oCPMasterData));
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetMasterDataForNewCP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetCpDashboardData(int filter)
        {
            try
            {
                long EMPID = GetEmpID();
                int RoleId = GetRoleID();
                CpBAL objCpBAL = new CpBAL();
                string result = objCpBAL.GetCpDashboardData(EMPID, RoleId, filter);
                return Ok(result);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCpDashboardData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]

        public IHttpActionResult UpdateCPBasicData(CP cp)
        {  
            var EMPID = GetEmpID();

            string JsonResponse = string.Empty;
            try
            {
                if (cp != null)
                {

                    JsonResponse = objCP.UpdateCPBasicData(Utilities.ObjectToXMLString(cp), Convert.ToInt32(EMPID));

                    DataTable dt = objCP.GetPDF_EditValue(cp.CPId);

                    string templateName = PdfTemplate + dt.Rows[0]["parametervalue"].ToString();
                    string FTPFilePath = dt.Rows[1]["parametervalue"].ToString();
                    string fileName = dt.Rows[2]["parametervalue"].ToString();


                    //deleting ftp file path and template name and file name;
                    dt.Rows.RemoveAt(0);
                    dt.Rows.RemoveAt(0);
                    dt.Rows.RemoveAt(0);

                    int iResult = ftp.GeneratePDF_Edit(dt, templateName, TempFolder, FTPFilePath, fileName);
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\UpdateCPBasicData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateCPAgreementStatus(CP cp)
        {

            var EMPID = GetEmpID();

            string JsonResponse = string.Empty;
            try
            {
                if (cp != null)
                {
                    JsonResponse = objCP.UpdateCPAgreementStatus(Utilities.ObjectToXMLString(cp), Convert.ToInt32(EMPID));
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\UpdateCPAgreementStatus", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetCPAllDetails([FromUri] int CPId)
        {
            string JsonResponse = string.Empty;
            try
            {
                CP oCP = objCP.GetCPAllDetails(CPId);
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(oCP == null ? "" : serializer.Serialize(oCP));
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPAllDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateCPPersonalData(CP oCP)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();

            string JsonResponse = string.Empty;
            try
            {
                if (oCP != null)
                {
                    JsonResponse = objCP.UpdateCPDetailedForm(Utilities.ObjectToXMLString(oCP)
                        , Convert.ToInt32(EMPID), 1, Convert.ToInt32(RoleId));
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\UpdateCPPersonalData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateCPBankData(CP oCP)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();

            string JsonResponse = string.Empty;
            try
            {
                if (oCP != null)
                {
                    JsonResponse = objCP.UpdateCPDetailedForm(Utilities.ObjectToXMLString(oCP)
                        , Convert.ToInt32(EMPID), 2, Convert.ToInt32(RoleId));
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\UpdateCPBankData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateCPDetailedForm(CP oCP)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();

            string JsonResponse = string.Empty;
            try
            {
                if (oCP != null)
                {
                    JsonResponse = objCP.UpdateCPDetailedForm(Utilities.ObjectToXMLString(oCP)
                        , Convert.ToInt32(EMPID), 3, Convert.ToInt32(RoleId));

                    //DataTable dt = objCP.GetPDF_Empanelform_Html(oCP.CPId);

                    //string FTPFilePath = dt.Rows[0]["FTPFilePath"].ToString();
                    //string fileName = dt.Rows[0]["fileName"].ToString();

                    //int iResult = ftp.GeneratePDFFromHTML(dt, TempFolder, fileName, FTPFilePath);
                    if (RoleId == 3) //generate pdf only when Checker submits the data
                    {

                        DataTable dt = objCP.GetPDF_EmpanelFormEditValue(Convert.ToInt32(oCP.CPId));

                        string templateName = PdfTemplate + dt.Rows[0]["parametervalue"].ToString();
                        string FTPFilePath = dt.Rows[1]["parametervalue"].ToString();
                        string fileName = dt.Rows[2]["parametervalue"].ToString();


                        //deleting ftp file path and template name and file name;
                        dt.Rows.RemoveAt(0);
                        dt.Rows.RemoveAt(0);
                        dt.Rows.RemoveAt(0);

                        int iResult = ftp.GeneratePDF_Edit(dt, templateName, TempFolder, FTPFilePath, fileName);

                        if (iResult == 0)
                        {

                        }

                        //Regenerate Agreement
                        dt = null;
                        dt = objCP.GetPDF_EditValue(oCP.CPId);

                        templateName = PdfTemplate + dt.Rows[0]["parametervalue"].ToString();
                        FTPFilePath = dt.Rows[1]["parametervalue"].ToString();
                        fileName = dt.Rows[2]["parametervalue"].ToString();


                        //deleting ftp file path and template name and file name;
                        dt.Rows.RemoveAt(0);
                        dt.Rows.RemoveAt(0);
                        dt.Rows.RemoveAt(0);

                       iResult = ftp.GeneratePDF_Edit(dt, templateName, TempFolder, FTPFilePath, fileName);
                    }
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\UpdateCPDetailedForm", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPDocumentList(DocListFilters objDocListFilters)
        {
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = objCP.GetCPDocumentList(objDocListFilters);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPDocumentList", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostCPDocumentList(CP oCP)
        {
            //
            IEnumerable<string> headerValues;
            var EMPID = string.Empty;
            if (Request.Headers.TryGetValues("EmpId", out headerValues))
            {
                EMPID = headerValues.FirstOrDefault();
            }
            //
            string JsonResponse = string.Empty;
            try
            {
                if (oCP != null)
                {
                    JsonResponse = objCP.SaveCPDocumentList(Utilities.ObjectToXMLString(oCP), Convert.ToInt32(EMPID));
                }
                else
                {
                    throw new Exception("Please select at least one document");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\PostCPDocumentList", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPElockerDetails(DocListFilters objDocListFilters)
        {
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = objCP.GetCPElockerDetails(objDocListFilters);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPElockerDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetAgreementPdf([FromUri] int CPID)
        {
            string JsonResponse = string.Empty;
            try
            {
                JsonResponse = objCP.GetAgreementPdf(CPID);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetAgreementPdf", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult SendDocsEmail(User oUser)
        {
            string JsonResponse = string.Empty;
            try
            {
                if (oUser != null)
                {
                    JsonResponse = objCP.SendDocsEmail(Utilities.ObjectToXMLString(oUser));
                }
                else
                {
                    throw new Exception("Please select at least one document");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\SendDocsEmail", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult SearchBankFromIFSC(string IFSC)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                string JsonResponse = "";
                JsonResponse = objCpBAL.SearchBankFromIFSC(IFSC);
                return Ok(JsonResponse);
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\SearchBankFromIFSC", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPPropertStatus(Filters360degree objDashboard)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                CPPropertyStatus objCPPropertyStatus = new CPPropertyStatus();
                objCPPropertyStatus = objCpBAL.GetCPPropertyStatusDashBoard(objDashboard);
                return Ok(objCPPropertyStatus);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPPropertStatus", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCP360DegreeView(Filters360degree objDashboard)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                CP360View objCP360 = new CP360View();
                objCP360 = objCpBAL.GetCP360DegreeView(objDashboard);
                return Ok(objCP360);
             
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCP360DegreeView", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetCPPropertyDashBoard(Filters360degree objDashboard)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                CPPropertyDashboard objCPPropertyDashboard = new CPPropertyDashboard();
                objCPPropertyDashboard = objCpBAL.GetCPPropertyDashboard(objDashboard);
                return Ok(objCPPropertyDashboard);

            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPPropertyDashBoard", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPCustomerPaymentSummary(Filters360degree objDashboard)
        {
            try
            {
                var RoleId = GetRoleID();

                CpBAL objCpBAL = new CpBAL();
                PaymentSummary objPaymentSummary = new PaymentSummary();
                objPaymentSummary = objCpBAL.GetPaymentSummary(objDashboard, RoleId);
                return Ok(objPaymentSummary);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPCustomerPayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult PostBankDetails(BankDetails objBankDetails)
        {
            CommonBAL objCommonBal = new CommonBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (objBankDetails != null)
                {
                    long UserId = GetEmpID();
                    JsonResponse = objCommonBal.InsertBankDetails(Utilities.ObjectToXMLString(objBankDetails),1, UserId);
                }
                else
                {
                    throw new Exception("Fill Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\PostBankDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult ProcessClientwisePayment(Customer oClient)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                string JsonResponse = string.Empty;
                long EmpId = GetEmpID();

                JsonResponse = objCpBAL.ProcessClientwisePayment(oClient, EmpId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\ProcessClientwisePayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GenerateInvoiceForClientPayment(Customer oClient)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                string JsonResponse = string.Empty;
                long EmpId = GetEmpID();

                DataTable dt = objCpBAL.GenerateInvoiceForClientPayment(oClient, EmpId);

                if(dt != null && dt.Rows.Count > 0)
                {
                    DataTable dtResult = new DataTable();
                    DataColumn dc = new DataColumn("HTML", typeof(String));
                    dtResult.Columns.Add(dc);

                    DataRow dr = dtResult.NewRow();
                    dr[0] = Convert.ToString(dt.Rows[0]["InvoiceHTML"]);

                    dtResult.Rows.Add(dr);

                    int iResult = ftp.GeneratePDFFromHTML(dtResult, TempFolder,
                        Convert.ToString(dt.Rows[0]["FileName"]), Convert.ToString(dt.Rows[0]["SAVEPATH"]));

                    if(iResult == 1) //success
                    {
                        string Result = objCpBAL.SaveInvoicePathInDB(oClient, EmpId);
                    }

                }
                JsonResponse = Utilities.dtToJson(dt);

                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GenerateInvoiceForClientPayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPSupportCost(ReportParam objParam)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                List<CPSupportCost> lstObjCPSC = new List<CPSupportCost>();
                lstObjCPSC = objCpBAL.GetCPSupportCost(objParam);
                return Ok(lstObjCPSC);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPSupportCost", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertUpdateCPSupportCost(CPSupportCost objParam)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                string JString = string.Empty;
                JString = objCpBAL.SaveUpdateCPSupportCost(Utilities.ObjectToXMLString(objParam), Convert.ToInt32(GetEmpID()), objParam.Flag);
                return Ok(JString);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\InsertUpdateCPSupportCost", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetSelectedCPCostDetails(CPSupportCost objParam)
        {
            try
            {
                CpBAL objCpBAL = new CpBAL();
                CPSupportCost objCPCost = new CPSupportCost();
                objCPCost = objCpBAL.GetSelectedCPCost(objParam);
                return Ok(objCPCost);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetSelectedCPCostDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GenerateOTPForCP(CP cp)
        {
            var EMPID = GetEmpID();

            string JsonResponse = string.Empty;
            try
            {
                if (cp != null)
                {
                    JsonResponse = objCP.UpdateCPDetails(Utilities.ObjectToXMLString(cp), Convert.ToInt32(EMPID), Convert.ToInt32(GetRoleID()),2);
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GenerateOTPForCP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateCPDetails(CP cp)
        {
            var EMPID = GetEmpID();

            string JsonResponse = string.Empty;
            try
            {
                if (cp != null)
                {
                    JsonResponse = objCP.UpdateCPDetails(Utilities.ObjectToXMLString(cp), Convert.ToInt32(EMPID), Convert.ToInt32(GetRoleID()), 1);
                }
                else
                {
                    throw new Exception("Fill CP Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\UpdateCPDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult SaveCPAttendance(CPAttendance objCP)
        {
            try
            {
                CpBAL objCPBAL = new CpBAL();
                string JResponse;
                JResponse = objCPBAL.SaveCPAttendance(Utilities.ObjectToXMLString(objCP), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\SaveCPAttendance", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPAttendance(CPAttendance objCP)
        {
            try
            {
                CpBAL objCPBAL = new CpBAL();
                List<_CPAttendance> lstCPA = new List<_CPAttendance>();
                lstCPA = objCPBAL.GetCPAttendance(Utilities.ObjectToXMLString(objCP), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(lstCPA);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetCPAttendance", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }

        private Boolean SaveImage(string ImageData, string ImagePath, string ImageName)
        {
            Boolean Result = false;
            try
            {
                string TempPath = TempFolder + ImageName;

                if (ImageData != "" && ImageData != null && ImageData != "undefined")
                {
                    byte[] imageBytes = Convert.FromBase64String(ImageData);

                    //Guid picid = Guid.NewGuid();
                    MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
                    ms.Write(imageBytes, 0, imageBytes.Length);
                    System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);

                    //Save on local 
                    image.Save(TempPath, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //Save on FTP                    
                    int iResult = ftp.TransferFileToFTP(TempPath, ImagePath, ImageName);

                    //Delete from temp file path
                    if (iResult == 1)
                    {
                        File.Delete(TempPath);
                        Result = true;
                    }
                }

            }
            catch (Exception oEx)
            {
                Utilities.ApiErrorLog(oEx.Message.ToString(), @"CP\SaveImage", "API");
                Result = false;
                throw oEx;
            }
            return Result;
        }        

        #endregion

    }
}
