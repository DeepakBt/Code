﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using System.Data;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class MarketingController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetMarketingDocDetails(MarketingFilter objParam)
        {
            try
            {
                DataSet objDs = new DataSet();
                MarketingBAL objBAL = new MarketingBAL();
                objDs = objBAL.GetMarketingDocDetails(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objDs.Tables.Count > 0)
                {
                    objDs.Tables[0].TableName = "MarketingDocDetails";
                }
                return Ok(objDs);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Marketing\GetMarketingDocDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Marketing\GetEmpID", "API");
                EMPID = 0;
            }
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Marketing\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }
    }
}
