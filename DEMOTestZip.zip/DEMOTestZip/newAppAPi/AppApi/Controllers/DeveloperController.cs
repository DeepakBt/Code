﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AppApi.Controllers
{
   [GenericAuthenticationFilter]
    public class DeveloperController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetDeveloperDashboardLiveLeads(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                DeveloperLiveLeads objDeveloperLiveLeads = objDeveloperBAL.GetPropertyDeveloperLiveLeads(objParam);
                return Ok(objDeveloperLiveLeads);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperDashboardLiveLeads", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetDeveloperDashboardLiveInventory(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                DeveloperLiveInventory objDeveloperLiveInventory = objDeveloperBAL.GetPropertyDeveloperLiveInventory(objParam);
                return Ok(objDeveloperLiveInventory);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperDashboardLiveInventory", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperDashboardPaymentStatus(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                DeveloperPaymentStatus objDeveloperPaymentStatus = objDeveloperBAL.GetPropertyDeveloperPaymentStatus(objParam);
                return Ok(objDeveloperPaymentStatus);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperDashboardPaymentStatus", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperInventory(Filters360degree objParam)
        {
            try
            {
                int RoleId = GetRoleID();
                if(RoleId==10)
                {
                    objParam.DeveloperId = GetEmpID();
                }
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                string objInventoryPlot = objDeveloperBAL.GetDeveloperInventory(objParam);
                JObject Invjson = JObject.Parse(objInventoryPlot);
                return Ok(Invjson);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperInventory", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperCashFlow(Filters360degree objParam)
        {
            try
            {
                int RoleId = GetRoleID();
                if (RoleId == 10)
                {
                    objParam.DeveloperId = GetEmpID();
                }
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                string JString = objDeveloperBAL.GetDeveloperCashFLowDetails(objParam);
                return Ok(JString);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperCashFlow", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperCashFlowPaymentDetails(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                DeveloperPaymentDetailsSummary objDeveloperPaymentDetailsSummary = new DeveloperPaymentDetailsSummary();
                objDeveloperPaymentDetailsSummary = objDeveloperBAL.GetDeveloperPaymentDetails(objParam);
                return Ok(objDeveloperPaymentDetailsSummary);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperCashFlowPaymentDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperPaymentModuleDetails(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                DeveloperPaymentModuleDetails objDeveloperPaymentModuleDetails = new DeveloperPaymentModuleDetails();
                objDeveloperPaymentModuleDetails = objDeveloperBAL.GetDeveloperPaymentModuleDetails(objParam);
                return Ok(objDeveloperPaymentModuleDetails);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperPaymentModuleDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperInventoryDrill(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                InventoryDrillDown objInventoryDrillDown = new InventoryDrillDown();
                objInventoryDrillDown = objDeveloperBAL.GetInventoryDrillDown(objParam);
                return Ok(objInventoryDrillDown);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperInventoryDrill", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetCPFunnelForDeveloperDashboard(int PropertyId)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                string JsonResponse = "";
                JsonResponse = objDeveloperBAL.GetCPFunnelForDeveloperDashboard(PropertyId,Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()));
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetCPFunnelForDeveloperDashboard", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCommunicationFunnel(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                CommunicationFunnel objCommunicationFunnel = new CommunicationFunnel();
                objCommunicationFunnel = objDeveloperBAL.GetCommunicationFunnel(objParam,Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()));
                return Ok(objCommunicationFunnel);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetCommunicationFunnel", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDeveloperOtherChargesDetails(Filters360degree objParam)
        {
            try
            {
                DeveloperBAL objDeveloperBAL = new DeveloperBAL();
                DeveloperOtherCharges objDeveloperOtherCharges = new DeveloperOtherCharges();
                objDeveloperOtherCharges = objDeveloperBAL.GetDeveloperOtherCharges(objParam);
                return Ok(objDeveloperOtherCharges);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetDeveloperOtherChargesDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetEmpID", "API");
                EMPID = 0;
            }
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Developer\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }
    }
}
