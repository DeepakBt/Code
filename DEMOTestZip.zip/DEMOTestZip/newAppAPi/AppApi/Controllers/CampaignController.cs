﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class CampaignController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult AddCampaign(Campaign objCampaign)
        {
            try
            {
                CampaignBAL objCampaignBAL = new CampaignBAL();
                string Result = objCampaignBAL.SaveCampaign(Utilities.ObjectToXMLString(objCampaign),Convert.ToInt32(GetEmpID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Campaign\AddCampaign", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCampaign(Campaign objCampaign)
        {
            try
            {
                CampaignBAL objCampaignBAL = new CampaignBAL();
                objCampaign = objCampaignBAL.GetCampaign(Utilities.ObjectToXMLString(objCampaign), Convert.ToInt32(GetEmpID()));
                return Ok(objCampaign);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Campaign\GetCampaign", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Campaign\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Campaign\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
    }
}
