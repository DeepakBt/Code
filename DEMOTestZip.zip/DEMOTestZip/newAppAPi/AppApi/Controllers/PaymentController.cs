﻿using BAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AppApi.Controllers
{
    public class PaymentController : ApiController
    {
        string TempFolder = System.Web.HttpContext.Current.Server.MapPath(Convert.ToString(ConfigurationSettings.AppSettings["FolderName"])) + "\\";
        FtpSave ftp = new FtpSave();

        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);

        [HttpGet]
        public IHttpActionResult GetPaymentPendingClients(int PropertyId,int FlagId)
        {
            try
            {
                PaymentBAL oPaymentBAL = new PaymentBAL();
                var EmpId = GetEmpID();
                string JSONResponse = oPaymentBAL.GetPaymentPendingClients(EmpId, PropertyId, FlagId);
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\GetPaymentPendingClients", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpGet]
        public IHttpActionResult GetCostSheetMasterData(int ClientId)
        {
            try
            {
                PaymentBAL oPaymentBAL = new PaymentBAL();
                CostSheetMasterData oCostSheetMasterData = oPaymentBAL.GetCostSheetMasterData(ClientId);
                return Ok(oCostSheetMasterData);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\GetCostSheetMasterData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostClientCostSheet(Customer oCustomer )
        {
            try
            {
                var EMPID = GetEmpID();
                var RoleId = GetRoleID();
                PaymentBAL oPaymentBAL = new PaymentBAL();
                string JSONResponse = oPaymentBAL.InsertClientCostSheet(Utilities.ObjectToXMLString(oCustomer),EMPID,RoleId);
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\PostClientCostSheet", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetPaymentMaster(PaymentPageInputParam oParam)
        {
            try
            {
                PaymentBAL oPaymentBAL = new PaymentBAL();
                PaymentMasterData oPaymentMasterData = oPaymentBAL.GetPaymentMaster(oParam);
                return Ok(oPaymentMasterData);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\GetPaymentMaster", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostClientOtherChargesPayment(Customer oCustomer)
        {
            try
            {
                var EMPID = GetEmpID();
                var RoleId = GetRoleID();

                string JSONResponse = String.Empty;
                PaymentBAL oPaymentBAL = new PaymentBAL();
                JSONResponse = oPaymentBAL.InsertClientOtherChargesPayment(Utilities.ObjectToXMLString(oCustomer), EMPID, RoleId);
                
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\PostClientPayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetClientPaymentsDetail(long ClientId)
        {
            try
            {
                PaymentBAL oPaymentBAL = new PaymentBAL();
                var EmpId = GetEmpID();
                string JSONResponse = oPaymentBAL.GetClientPaymentsDetail(ClientId, 1);
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\GetClientPaymentsDetail", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostClientRegFeesPayment(Customer oCustomer)
        {
            try
            {
                var EMPID = GetEmpID();
                var RoleId = GetRoleID();
                string JSONResponse = String.Empty;
                int Result = 1;
                PaymentBAL oPaymentBAL = new PaymentBAL();

                //Save Stamp Duty Challan if uploaded
                if (oCustomer.ClientRegistrationFees.ChallanImgData.Length > 0)
                {
                    DataTable dt = oPaymentBAL.GetDocDetails(1);

                    int DocTypeId = Convert.ToInt32(dt.Rows[0]["DOCID"]);
                    string ImagePath = Convert.ToString(dt.Rows[0]["SAVEPATH"]);
                    string ImageData = oCustomer.ClientRegistrationFees.ChallanImgData;
                    string ImageName = Convert.ToString(DocTypeId) + "_" + Convert.ToString(oCustomer.Customer_Id) + "_"
                        + oCustomer.ClientRegistrationFees.ChallanImgName;
                    string DBPath = Convert.ToString(dt.Rows[0]["RETRIVALPATH"]);

                    oCustomer.ClientRegistrationFees.ChallanImgPath = DBPath + ImageName;
                    oCustomer.ClientRegistrationFees.ChallanImgName = ImageName;

                    Result = SaveUploadDocData(ImagePath, ImageData, ImageName);
                }
               
                if (Result == 1)
                {
                   JSONResponse = oPaymentBAL.PostClientRegFeesPayment(Utilities.ObjectToXMLString(oCustomer), EMPID, RoleId);
                }
                else
                {
                    throw new Exception("Error while saving Stamp Duty Challan Data");
                }
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\PostClientRegFeesPayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetClientPaymentParticulars(PaymentPageInputParam oParam)
        {
            try
            {
                PaymentBAL oPaymentBAL = new PaymentBAL();
                PaymentMasterData oPaymentMasterData = oPaymentBAL.GetClientPaymentParticulars(oParam);
                return Ok(oPaymentMasterData);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\GetPaymentMaster", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetClientRegCharges(long ClientId)
        {
            try
            {
                PaymentBAL oPaymentBAL = new PaymentBAL();
                var EmpId = GetEmpID();
                var RoleId = GetRoleID();

                Customer oCustomer = new Customer();
                oCustomer.Customer_Id = ClientId;
                string JSONResponse = oPaymentBAL.GetClientRegCharges(Utilities.ObjectToXMLString(oCustomer), EmpId, RoleId);

                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\GetClientRegCharges", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostCPBrokerage(Customer oCustomer)
        {
            try
            {
                var EMPID = GetEmpID();
                var RoleId = GetRoleID();
                string JSONResponse = String.Empty;
                PaymentBAL oPaymentBAL = new PaymentBAL();
                JSONResponse = oPaymentBAL.PostCPBrokerage(Utilities.ObjectToXMLString(oCustomer), EMPID, RoleId);
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\PostClientRegFeesPayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostClientPaymentTranches(Customer oCustomer)
        {
            try
            {
                var EMPID = GetEmpID();
                var RoleId = GetRoleID();

                string JSONResponse = String.Empty;
                int Result = 1;
                PaymentBAL oPaymentBAL = new PaymentBAL();
                foreach(PaymentTranches oTranch in oCustomer.PaymentTranchesList)
                {
                    if (oTranch.PaymentTypeId == 3 && oTranch.IsOtherCharges == false)
                    {
                        //Save TDS Challan
                        DataTable dt = oPaymentBAL.GetDocDetails(2);

                        int DocTypeId = Convert.ToInt32(dt.Rows[0]["DOCID"]);
                        string ImagePath = Convert.ToString(dt.Rows[0]["SAVEPATH"]);
                        string ImageData = oTranch.ChallanImgData;
                        string ImageName = Convert.ToString(DocTypeId) + "_" + Convert.ToString(oCustomer.Customer_Id) + "_"
                            + oTranch.ChallanImgName;
                        string DBPath = Convert.ToString(dt.Rows[0]["RETRIVALPATH"]);

                        oTranch.ChallanImgPath = DBPath + ImageName;
                        oTranch.ChallanImgName = ImageName;

                        if (Path.GetExtension(oTranch.ChallanImgName.ToLower()) == ".pdf")
                        {
                            FtpSave oFTP = new FtpSave();
                            string tempPath = TempFolder + ImageName;
                            File.WriteAllBytes(@"" + tempPath + "", Convert.FromBase64String(ImageData));
                            Result = oFTP.TransferFileToFTP(tempPath, ImagePath, ImageName);
                        }
                        else
                        {
                            Result = SaveUploadDocData(ImagePath, ImageData, ImageName);
                        }

                        if(Result == 1)
                        {
                            oTranch.ChallanImgData = "";
                        }
                    }
                }
               
                if (Result == 1)
                {
                    JSONResponse = oPaymentBAL.InsertClientPayment(Utilities.ObjectToXMLString(oCustomer), EMPID, RoleId);
                }
                else
                {
                    throw new Exception("Error while saving Stamp Duty Challan Data");
                }
                return Ok(JSONResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Payment\PostClientPayment", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        #region Methods

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CP\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }

        private int SaveUploadDocData(string ImagePath, string ImageData, string ImageName)
        {
            int Result = 1;

            try
            {
                string TempPath = TempFolder + ImageName;

                if (ImageData != "" && ImageData != null && ImageData != "undefined")
                {
                    byte[] imageBytes = Convert.FromBase64String(ImageData);

                    //Guid picid = Guid.NewGuid();
                    MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
                    ms.Write(imageBytes, 0, imageBytes.Length);
                    System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);

                    //Save on local 
                    image.Save(TempPath, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //Save on FTP                    
                    int iResult = ftp.TransferFileToFTP(TempPath, ImagePath, ImageName);

                    //Delete from temp file path
                    if (iResult == 1)
                    {
                        File.Delete(TempPath);
                        Result = 1;
                    }
                }

            }
            catch (Exception oEx)
            {
                Utilities.ApiErrorLog(oEx.Message.ToString(), @"Payment\SaveUploadDocData", "API");
                Result = 0;
                throw oEx;
            }
            return Result;
        }

        #endregion
    }
}
