﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Web.Script.Serialization;
using BAL.Prop;
using System.Data;
using Newtonsoft.Json;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class ReportsController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpGet]
        public IHttpActionResult GetReportList()
        {
            try
            {
                List<ReportCategory> objLstReport = new List<ReportCategory>();
                ReportsBAL objReportsBal = new ReportsBAL();
                objLstReport = objReportsBal.GetListOfReports(Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()));
                return Ok(objLstReport);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Reports\GetReportList", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetReportData(ReportParam objParam)
        {
            try
            {
                ReportsBAL objReportsBAL = new ReportsBAL();
                //if (objParam.ReportId == 1)
                //{
                //    DataSet objSalesData = new DataSet();
                //    objSalesData = objReportsBAL.GetSalesRMWiseDataDs(Convert.ToInt32(GetEmpID()), objParam);
                //    return Ok(objSalesData);
                //}
                //else if (objParam.ReportId == 2)
                //{
                //    DataSet objSalesData = new DataSet();
                //    objSalesData = objReportsBAL.GetSalesRMFollowUpDataDs(Convert.ToInt32(GetEmpID()), objParam);
                //    return Ok(objSalesData);
                //}
                //else if (objParam.ReportId == 3)
                //{
                //    DataSet objSalesData = new DataSet();
                //    objSalesData = objReportsBAL.GetSalesMeetingCountDs(Convert.ToInt32(GetEmpID()), objParam);
                //    return Ok(objSalesData);
                //}
                //else if(objParam.ReportId==4)
                //{
                //    DataSet objCPLogin = new DataSet();
                //    objCPLogin = objReportsBAL.GetCPLoginActivitySummaryDs(Convert.ToInt32(GetEmpID()), objParam);
                //    return Ok(objCPLogin);
                //}
                //else if(objParam.ReportId==5)
                //{
                //    DataSet objSV = new DataSet();
                //    objSV = objReportsBAL.GetStatusWiseRevisitDs(Convert.ToInt32(GetEmpID()), objParam);
                //    return Ok(objSV); 
                //}
                //else if(objParam.ReportId==6)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetTeleCallerDetailsDs(Convert.ToInt32(GetEmpID()), objParam);
                //    return Ok(objds);
                //}
                //else if (objParam.ReportId == 7)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetTeleCallerLeadDetailsDs(Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objParam);
                //    return Ok(objds);
                //}
                //else if (objParam.ReportId == 8)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetDatewiseSourcingRatingDs(Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objParam);
                //    return Ok(objds);
                //}
                //else if (objParam.ReportId == 9)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetRMWiseUnregCPCountDs(Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objParam);
                //    return Ok(objds);
                //}
                //else if (objParam.ReportId==10)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetProspectCritriaSummaryDs(Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objParam);
                //    return Ok(objds);
                //}
                //else if (objParam.ReportId == 11)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetLeadSummaryDs(Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objParam);
                //    return Ok(objds);
                //}
                //else if (objParam.ReportId == 12)
                //{
                //    DataSet objds = new DataSet();
                //    objds = objReportsBAL.GetRegUNRegCPDetailsDs(Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objParam);
                //    return Ok(objds);
                //}
                objParam.EmpId = GetEmpID();
                objParam.EmpTypeId = GetRoleID();
                DataSet objds = new DataSet();
                objds = objReportsBAL.GetReportData(Utilities.ObjectToXMLString(objParam));
                return Ok(objds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Reports\GetReportData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods
        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Prospect\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
        #endregion
    }
}
