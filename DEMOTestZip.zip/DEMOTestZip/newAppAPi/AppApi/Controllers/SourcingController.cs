﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using System.Data;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class SourcingController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetSourcingDB(SourcingParam objParam)
        {
            try
            {
                SourcingBAL objBAL = new SourcingBAL();
                SourcingDashboard objDB = objBAL.GetSourcingDashboard(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objDB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetSourcingDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostSourcingTarget(List<SourcingTarget> lstObjST)
        {
            try
            {
                string JResponse = string.Empty;
                SourcingBAL objBAL = new SourcingBAL();
                JResponse = objBAL.SaveSourcingTarget(Utilities.ObjectToXMLString(lstObjST), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\PostSourcingTarget", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetSourcingTarget(SourcingTarget objSourcingParam)
        {
            try
            {
                string JResponse = string.Empty;
                SourcingBAL objBAL = new SourcingBAL();
                List<SourcingTarget> lstObj = new List<SourcingTarget>();
                lstObj = objBAL.GetSourcingTarget(objSourcingParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(lstObj);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetSourcingTarget", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateSourcingTarget(List<SourcingTarget> lstObjST)
        {
            try
            {
                string JResponse = string.Empty;
                SourcingBAL objBAL = new SourcingBAL();
                JResponse = objBAL.UpdateSourcingTarget(Utilities.ObjectToXMLString(lstObjST), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\UpdateSourcingTarget", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult DeleteSourcingTarget(List<SourcingTarget> lstObjST)
        {
            try
            {
                string JResponse = string.Empty;
                SourcingBAL objBAL = new SourcingBAL();
                JResponse = objBAL.DeleteSourcingTarget(Utilities.ObjectToXMLString(lstObjST), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\DeleteSourcingTarget", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetOverAllSourcingSummary(SourcingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                SourcingBAL objBAL = new SourcingBAL();
                objSourcingds = objBAL.GetOverAllSourcingSummary(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetOverAllSourcingSummary", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCPTargetSummaryDB(SourcingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                SourcingBAL objBAL = new SourcingBAL();
                objSourcingds = objBAL.GetCPTargetSummary(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "TargetSummary";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetCPTargetSummaryDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetSourcingMarketingDB(SourcingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                SourcingBAL objBAL = new SourcingBAL();
                objSourcingds = objBAL.GetSourcingMarketing(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetSourcingMarketingDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetSourcingWeekWiseWalkinDB(SourcingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                SourcingBAL objBAL = new SourcingBAL();
                objSourcingds = objBAL.GetWeekWiseWalkinDB(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "WeekWiseWalkin";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetSourcingWeekWiseWalkinDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTopTenSourcingCPWalkin(SourcingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                SourcingBAL objBAL = new SourcingBAL();
                objSourcingds = objBAL.GetTopTenSourcingCPWalkin(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "SourcingCPWalkin";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetTopTenSourcingCPWalkin", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetEmpID", "API");
                EMPID = 0;
            }
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Sourcing\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }
    }
}
