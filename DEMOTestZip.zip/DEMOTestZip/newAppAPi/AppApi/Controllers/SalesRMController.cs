﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using System.Web.Script.Serialization;
using System.Data;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class SalesRMController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        
        [HttpGet]
        public IHttpActionResult GetSalesRMMeetingDashboardMasterData()
        {
            try
            {
                long EmpId = GetEmpID();
                int RoleId = GetRoleID();

                SalesRmBAL oSalesRMBAL = new SalesRmBAL();
                SalesRMMasterData oSalesRM = oSalesRMBAL.GetSalesRMMeetingDashboardMasterData(EmpId, RoleId);
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(oSalesRM == null ? "" : serializer.Serialize(oSalesRM));
            }
            catch
            {
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetSalesRmDashboardDetails(string strSelectedParams)
        {
            try
            {
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                DashboardSelectedParams oSelectedParams = serializer.Deserialize<DashboardSelectedParams>(strSelectedParams);
                long EmpId = GetEmpID();
                int RoleId = GetRoleID();
                SalesRmBAL objSalesRmBAL = new SalesRmBAL();
                SalesRMDashboard oSalesRMDashboard = objSalesRmBAL.GetSalesRmDashboard(EmpId,oSelectedParams, RoleId);
                return Ok(oSalesRMDashboard == null ? "" : serializer.Serialize(oSalesRMDashboard));
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Sales\GetSalesRmDashboardDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }       

        [HttpPost]
        public IHttpActionResult GetInventoryBookingStatus(Filters360degree objFilters)
        {
            try
            {
                List<InventoryStatus> objlstInventoryStatus = new List<InventoryStatus>();
                SalesRmBAL objSalesRmBAL = new SalesRmBAL();
                objlstInventoryStatus = objSalesRmBAL.GetInventoryBookingStatus(objFilters);
                return Ok(objlstInventoryStatus);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"SalesRM\GetInventoryBookingStatus", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostInventoryBookingStatus(List<InventoryStatus> objListInventoryStatus)
        {
            try
            {
                var EMPID = GetEmpID();
                var ROLEID = GetRoleID();
                int Flag = 2; //for Updating the Inventory Status
                string JsonResponse = string.Empty;
                SalesRmBAL objSalesRmBAL = new SalesRmBAL();
                JsonResponse = objSalesRmBAL.UpdateInventoryBookingStatus(Utilities.ObjectToXMLString(objListInventoryStatus), Convert.ToInt32(EMPID), Flag);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"SalesRM\PostInventoryBookingStatus", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetAllProspectData(string strSelectedParams)
        {
            try
            {
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                DashboardSelectedParams oSelectedParams = serializer.Deserialize<DashboardSelectedParams>(strSelectedParams);
                long EmpId = GetEmpID();
                int RoleId = GetRoleID();
                SalesRmBAL objSalesRmBAL = new SalesRmBAL();
                string Result = objSalesRmBAL.GetSalesAllProspectData(EmpId, oSelectedParams, RoleId);
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Sales\GetSalesRmDashboardDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetSalesRMAnalyticDB(ReportParam objParam)
        {
            try
            {
                SalesRmBAL objSalesRmBAL = new SalesRmBAL();
                SalesAnalyticDashboard objSADb = new SalesAnalyticDashboard();
                objSADb = objSalesRmBAL.GetSalesRMAnalyticDB(Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()), objParam);
                return Ok(objSADb);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"SalesRM\GetSalesRMAnalyticDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetSearchedProspects(string strSelectedParams)
        {
            try
            {
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                DashboardSelectedParams oSelectedParams = serializer.Deserialize<DashboardSelectedParams>(strSelectedParams);
                long EmpId = GetEmpID();
                int RoleId = GetRoleID();
                SalesRmBAL objSalesRmBAL = new SalesRmBAL();
                SalesRMDashboard oSalesRMDashboard = objSalesRmBAL.GetSearchedProspects(EmpId, oSelectedParams, RoleId);
                return Ok(oSalesRMDashboard == null ? "" : serializer.Serialize(oSalesRMDashboard));
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Sales\GetSalesRmDashboardDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods
        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Sales\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Sales\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
        #endregion
    }
}
