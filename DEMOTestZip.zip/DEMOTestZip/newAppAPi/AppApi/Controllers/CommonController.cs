﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
namespace AppApi.Controllers
{
   //[GenericAuthenticationFilter]
    public class CommonController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpGet]
        public IHttpActionResult GetSearchDllFill()
        {
            try
            {
                int RoleId = GetRoleID();
                UniversalSearchBAL objUniversalSearchBAL = new UniversalSearchBAL();
                UniversalSearch objUniversalSearch = objUniversalSearchBAL.GetUniversalSearchMst(RoleId);
                return Ok(objUniversalSearch);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetSearchDllFill", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetSearchResult(CommonSearchFilters objFilters)
        {
            try
            {
                objFilters.EmpId = GetEmpID();
                objFilters.RoleId = GetRoleID();
                UniversalSearchBAL objUniversalSearchBAL = new UniversalSearchBAL();
                List<UniversalSearch> objUniversalSearch = objUniversalSearchBAL.GetUniversalSearchResult(objFilters);
                return Ok(objUniversalSearch);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetSearchResult", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetSubMenuOn360degree(string ComponentName)
        {
            try
            {
                var RoleId = GetRoleID();
                var EmpId = GetEmpID();
                UniversalSearchBAL oUniversalSearchBAL = new UniversalSearchBAL();
                string JsonResponse = "";
                JsonResponse = oUniversalSearchBAL.GetSubMenu(ComponentName, RoleId, EmpId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetSubMenuOn360degree", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetPropertyDDLFill(Filters360degree objFilter)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                PropertyDDL objPropertyDDL = new PropertyDDL();
                if (objFilter.Flag == 2)
                {
                    objFilter.RoleId = GetRoleID();
                }
                objPropertyDDL = objCommonBAL.GetPropertyMasterDDL(objFilter);
                return Ok(objPropertyDDL);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetPropertyDDLFill", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetFYDDLFill(Filters360degree objFilter)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                List<Dropdown> objDropdown = new List<Dropdown>();
                objDropdown = objCommonBAL.GetFYDDL(objFilter);
                return Ok(objDropdown);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetFYDDLFill", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostMOM(MOM objMOM)
        {
            CommonBAL objCommonBal = new CommonBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (objMOM != null)
                {
                    int RoleId = GetRoleID();
                    long EMPId = GetEmpID();
                    JsonResponse = objCommonBal.InsertMOM(Utilities.ObjectToXMLString(objMOM),EMPId,RoleId);
                }
                else
                {
                    throw new Exception("Fill PostMOM Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\PostMOM", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetDownloadURL(Filters360degree objFilter)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                DownloadURL objDownloadURL = new DownloadURL();
                objDownloadURL = objCommonBAL.GetDownloadURL(objFilter);
                return Ok(objDownloadURL);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetDownloadURL", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateIsAcceptUserFlag()
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                int RoleId = GetRoleID();
                var EmpId = GetEmpID();
                string Result = objCommonBAL.UpdateIsAcceptUserFlag(EmpId,RoleId);
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UpdateIsAcceptUserFlag", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UserCPMapping(UserCPMapping objCPMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.SaveUserCPMapping(Utilities.ObjectToXMLString(objCPMapping),Convert.ToInt32(GetEmpID()),Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UserCPMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        
        [HttpPost]
        public IHttpActionResult GetUserCPMapping(Users objUsers)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                UserCPMapping objCPM = new BAL.UserCPMapping();
                objCPM = objCommonBAL.GetUserCPMapping(Utilities.ObjectToXMLString(objUsers), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objCPM);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetUserCPMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult RMCPMOMInsert(RMCPMOM objRMCPMOM)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.SaveRMCPMOM(Utilities.ObjectToXMLString(objRMCPMOM), Convert.ToInt32(GetEmpID()), Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\RMCPMOMInsert", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetRequestedDDL(Filters360degree objDashboard)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                if (objDashboard.Flag == 7)
                {
                    List<UserCPDropDown> objUserCPDropDown = objCommonBAL.RequestedUserCPDDL(objDashboard);
                    return Ok(objUserCPDropDown);
                }
                else if(objDashboard.Flag==9)
                {
                    List<CPSupportDDL> objCPDropDown = objCommonBAL.RequestedCPDDL(objDashboard);
                    return Ok(objCPDropDown);
                }
                else
                {
                    List<Dropdown> objDropdown = objCommonBAL.RequestedDDL(objDashboard);
                    return Ok(objDropdown);
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetRequestedDDL", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult VerifyUnRegisterCP(UnregisterCPDeveloper objUnRegCP)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                if(objUnRegCP.Flag==1)
                {
                    List<UnregisterCPDeveloper> objList = new List<UnregisterCPDeveloper>();
                    objList = objCommonBAL.GetAllUnCP(objUnRegCP,Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                    return Ok(objList);
                }else if(objUnRegCP.Flag==2 || objUnRegCP.Flag == 4)
                {
                    UnregisterCPDeveloper objUnCP = new UnregisterCPDeveloper();
                    objUnCP = objCommonBAL.GetSelectUnCP(objUnRegCP, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                    return Ok(objUnCP);
                }
                else if(objUnRegCP.Flag==3)
                {
                    string Result = objCommonBAL.UpdateUNCP(Utilities.ObjectToXMLString(objUnRegCP), 
                        Convert.ToInt32(GetEmpID()), objUnRegCP.RegistrationId,objUnRegCP.UnRegFlag, Convert.ToInt32(GetRoleID()));
                    return Ok(Result);
                }else
                {
                    return Ok("InValid Flag");
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\VerifyUnRegisterCP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UserLanguageMapping(UserLanguageMapping objLangMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.SaveUserLanguageMapping(Utilities.ObjectToXMLString(objLangMapping), Convert.ToInt32(GetEmpID()), Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UserLanguageMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetUserLanguageMapping(Users objUsers)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                UserLanguageMapping objULM = new UserLanguageMapping();
                objULM = objCommonBAL.GetUserLanguageMapping(Utilities.ObjectToXMLString(objUsers), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objULM);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetUserLanguageMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UserPropertyMapping(UserPropertyMapping objPropMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.SaveUserPropertyMapping(Utilities.ObjectToXMLString(objPropMapping), Convert.ToInt32(GetEmpID()), Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UserPropertyMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetUserPropertyMapping(Users objUsers)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                UserPropertyMapping objPM = new UserPropertyMapping();
                objPM = objCommonBAL.GetUserPropertyMapping(Utilities.ObjectToXMLString(objUsers), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objPM);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetUserPropertyMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UserCampaignMapping(UserCampaignMapping objCampaignMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.SaveUserCampaignMapping(Utilities.ObjectToXMLString(objCampaignMapping), Convert.ToInt32(GetEmpID()), Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UserCampaignMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetUserCampaignMapping(Users objUsers)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                UserCampaignMapping objCM = new UserCampaignMapping();
                objCM = objCommonBAL.GetUserCampaignMapping(Utilities.ObjectToXMLString(objUsers), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objCM);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetUserCampaignMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult EditUserCampaignMapping(UserCampaignMapping objCampaignMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.EditUserCampaignMapping(Utilities.ObjectToXMLString(objCampaignMapping), Convert.ToInt32(GetEmpID()), Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UserCampaignMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateGeoLocationDetails(GeoLocation ObjGeoLocation)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                if(ObjGeoLocation.Flag==1)
                {
                    if (!string.IsNullOrEmpty(ObjGeoLocation.LoginLatitude) || !string.IsNullOrEmpty(ObjGeoLocation.LoginLongitude))
                    {
                        ObjGeoLocation.LoginAddress = objCommonBAL.GetGeoLocation(ObjGeoLocation.LoginLatitude, ObjGeoLocation.LoginLongitude);
                    }else
                    {
                        ObjGeoLocation.LoginLatitude = "";
                        ObjGeoLocation.LoginLongitude = "";
                        ObjGeoLocation.LoginAddress = "";
                    }
                }else if(ObjGeoLocation.Flag==2)
                {
                    if (!string.IsNullOrEmpty(ObjGeoLocation.LogoutLatitude) || !string.IsNullOrEmpty(ObjGeoLocation.LogoutLongitude))
                    {
                        ObjGeoLocation.LogoutAddress = objCommonBAL.GetGeoLocation(ObjGeoLocation.LogoutLatitude, ObjGeoLocation.LogoutLongitude);
                    }
                    else
                    {
                        ObjGeoLocation.LogoutLatitude = "";
                        ObjGeoLocation.LogoutLongitude = "";
                        ObjGeoLocation.LogoutAddress = "";
                    }
                }
                string Result = objCommonBAL.UpdateGeoLocationDetails(Utilities.ObjectToXMLString(ObjGeoLocation),ObjGeoLocation.Flag,Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UpdateGeoLocationDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult SaveUnRegisterCP(UnregisterCPDeveloper objUnRegCP)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string JResponse = string.Empty;
                JResponse = objCommonBAL.InsertUnRegCP(Utilities.ObjectToXMLString(objUnRegCP), Convert.ToInt32(GetEmpID())
                    ,Convert.ToInt32(GetRoleID()),objUnRegCP.Flag);
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\SaveUnRegisterCP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult EditUserCPMapping(UserCPMapping objCPMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.EditUserCPMapping(Utilities.ObjectToXMLString(objCPMapping)
                    , Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\DeleteUserCPMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetMasterValues(int Flag)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string JResponse = string.Empty;
                JResponse = objCommonBAL.GetMasterValues(Flag);
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetMasterValues", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetUserAttendanceDetails(AttendanceParam oAttendanceParam)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string JResponse = string.Empty;
                JResponse = objCommonBAL.GetUserAttendanceDetails(oAttendanceParam);
                return Ok(JResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetUserAttendanceDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult DeleteUserCPMapping(UserCPMapping objCPMapping)
        {
            try
            {
                CommonBAL objCommonBAL = new CommonBAL();
                string Result = objCommonBAL.DeleteUserCPMapping(Utilities.ObjectToXMLString(objCPMapping), Convert.ToInt32(GetEmpID()), Convert.ToInt16(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\UserCPMapping", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        
        #region Method

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetEmpID", "API");
                EMPID = 0;
            }
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Common\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }

        #endregion 
    }
}
