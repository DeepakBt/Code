﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;

namespace AppApi.Controllers
{

    //[GenericAuthenticationFilter]
    public class TeleCallerController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);

        [HttpPost]
        public IHttpActionResult AddUpdateTeleCaller(TeleCaller objTeleCaller)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                string Result = objTeleCallerBAL.SaveUpdateTeleCaller(Utilities.ObjectToXMLString(objTeleCaller), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objTeleCaller.Flag, objTeleCaller.TeleCallerId);
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\AddUpdateTeleCaller", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTeleCaller(TeleCaller objTeleCaller)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                objTeleCaller = objTeleCallerBAL.GetTeleCaller(objTeleCaller.TeleCallerId, objTeleCaller.Flag);
                return Ok(objTeleCaller);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\GetTeleCaller", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult AddUpdateTCVendor(TeleCallerVendor objTCVendor)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                string Result = objTeleCallerBAL.SaveUpdateTeleCallerVendor(Utilities.ObjectToXMLString(objTCVendor), Convert.ToInt32(GetEmpID()), objTCVendor.Flag, objTCVendor.VendorId);
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\AddUpdateTCVendor", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTCVendor(TeleCallerVendor objTCVendor)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                objTCVendor = objTeleCallerBAL.GetTeleCallerVendor(objTCVendor.VendorId, objTCVendor.Flag);
                return Ok(objTCVendor);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\GetTCVendor", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTeleCallerDB(DashboardSelectedParams objDBParam)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                TeleCallerDashBoard objDB = new TeleCallerDashBoard();
                objDB = objTeleCallerBAL.GetTCDashBoard(objDBParam.Flag, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objDBParam.FTD);
                return Ok(objDB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\GetTeleCallerDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTeleCallerLead(DashboardSelectedParams objDBParam)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                List<TeleCallerSVFollowUp> objTCLead = new List<TeleCallerSVFollowUp>();
                objTCLead = objTeleCallerBAL.GetTCLeadDetails(objDBParam.Flag, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objDBParam.FTD);
                return Ok(objTCLead);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\GetTeleCallerFollowUp", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateTelecallerLeaves(TelecallerLeaves oTelecallerLeaves)
        {
            try
            {
                TeleCallerBAL objTeleCallerBAL = new TeleCallerBAL();
                string Result = objTeleCallerBAL.UpdateTelecallerLeaves(Utilities.ObjectToXMLString(oTelecallerLeaves), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(Result);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\UpdateTelecallerLeaves", "API");
                throw new HttpResponseException(badRequest);
            }
        }
      
        #region Method

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"TeleCaller\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }

        #endregion
    }
}
