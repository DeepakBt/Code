﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using System.Data;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class CallingController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult SendBrochure(Brochure objBrochure)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                string JString = string.Empty;
                JString = objCallingBAL.SendBrochure(objBrochure.Flag, objBrochure.LeadId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()),objBrochure.PropertyId);
                return Ok(JString);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\SendBrochure", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetCallingAPI()
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                List<CallingAPI> lstCallingObj = new List<CallingAPI>();
                lstCallingObj = objCallingBAL.GetCallingAPI(Convert.ToInt32(GetEmpID()));
                return Ok(lstCallingObj);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\GetCallingAPI", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetGlobalLeadBucket(TCDBParam objParam)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                GlobalLeadBucket objGL = new GlobalLeadBucket();
                objGL = objCallingBAL.GetGlobalLead(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objGL);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\GetGlobalLeadBucket", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult AssignedLeadToTC(TCDBParam objParam)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                ResponseMessage ObjResponse = new BAL.ResponseMessage();
                ObjResponse = objCallingBAL.AssignedLeadTC(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(ObjResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\AssignedLeadToTC", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTeleCallerLead(TCDBParam objParam)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                List<TCAssignedLead> objLstTCLead = new List<TCAssignedLead>();
                objLstTCLead = objCallingBAL.GetTCLead(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                return Ok(objLstTCLead);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\GetTeleCallerLead", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertUpdateTeleCallerLead(TCAssignedLead objLTc)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                ResponseMessage ObjResponse = new BAL.ResponseMessage();
                ObjResponse = objCallingBAL.InsertUpdateTeleCallerLead(Utilities.ObjectToXMLString(objLTc), Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), objLTc.Flag);
                return Ok(ObjResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\InsertUpdateTeleCallerLead", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTeleCallerLeadMobile(TCAssignedLead objLTc)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                TCAssignedLead objTCLead = new TCAssignedLead();
                objTCLead = objCallingBAL.GetTCLeadMobile(Utilities.ObjectToXMLString(objLTc),Convert.ToInt32(GetEmpID()),Convert.ToInt32(GetRoleID()));
                if (objTCLead.LeadId == 0)
                {
                    ResponseMessage ObjResponse = new BAL.ResponseMessage();
                    ObjResponse.Result = 2;
                    ObjResponse.Message = "New Mobile No";
                    return Ok(ObjResponse);
                }
                else
                {
                    return Ok(objTCLead);
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\GetTeleCallerLead", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult WhatsAppBrochure(Brochure objBrochure)
        {
            try
            {
                string JString = Utilities.dtToJson(FnWhatsAppBrochure(objBrochure));
                return Ok(JString);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\WhatsAppBrochure", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        private DataTable FnWhatsAppBrochure(Brochure objBrochure)
        {
            CallingBAL objCallingBAL = new CallingBAL();
            CommonBAL oCommonBAL = new CommonBAL();
            string Result = string.Empty;
            List<WhatsAppMsg> oWhatsAppMsgList = new List<WhatsAppMsg>();
            DataTable dtResult = objCallingBAL.WhatsAppBrochure(objBrochure, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), out oWhatsAppMsgList);
            if (oWhatsAppMsgList.Count > 0)
            {
                foreach (WhatsAppMsg oMsg in oWhatsAppMsgList)
                {
                    if (oMsg.IsPdfLinkMsg)
                    {
                        Result = oCommonBAL.SendWhatssAppFileMessage(oMsg.WhatsAppNumber, oMsg.MessageTxt, oMsg.BrochureReadLink,
                            oMsg.BrochureWriteLink, oMsg.BrochureName);
                    }
                    else
                    {
                        Result = oCommonBAL.SendWhatssAppTextMessage(oMsg.WhatsAppNumber, oMsg.MessageTxt);
                    }

                    oMsg.Response = Result;
                    dtResult = objCallingBAL.UpdateWhatsAppMsgStatus(oMsg, GetEmpID(), GetRoleID());
                }
            }
            return dtResult;
        }

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\GetEmpID", "API");
                EMPID = 0;
            }
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Calling\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }
    }
}
