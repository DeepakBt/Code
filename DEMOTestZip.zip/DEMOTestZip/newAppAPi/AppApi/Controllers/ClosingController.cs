﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using System.Data;
namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class ClosingController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetClosingProsepctSourceDB(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetClosingSourceDB(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ClosingProspectSource";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetClosingProsepctSourceDB", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetClosingProspectRevisit(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetClosingRevisitStatusWise(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ClosingProspectRevisit";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetClosingProspectRevisit", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetClosingNoOfTimeRevisit(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetClosingNoOfTimeRevisit(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ClosingProspectRevisit";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetClosingNoOfTimeRevisit", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetClosingRevisitAgeing(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetClosingRevisitAgeing(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ClosingProspectRevisit";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetClosingRevisitAgeing", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetClosingActiveProspectRevisit(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetClosingActiveRevisit(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ClosingProspectRevisit";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetClosingActiveProspectRevisit", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetProspectCriteriaStatusSummary(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetProspectCriteriaStatusSummary(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ProspectCriteriaStatus";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetProspectCriteriaStatusSummary", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetProspectFTWRevisitSummary(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetProspectFTW_RevisitSummary(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ProspectRevisit";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetProspectFTWRevisitSummary", "API");
                throw new HttpResponseException(badRequest);
            }
        }


        [HttpPost]
        public IHttpActionResult GetProspectDecisionMakerSummary(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetProspectDecisionMakerSummary(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ProspectDecisionSummary";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetProspectDecisionMakerSummary", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetTopTenClosingCPWalkin(ClosingParam objParam)
        {
            try
            {
                DataSet objSourcingds = new DataSet();
                ClosingBAL objBAL = new ClosingBAL();
                objSourcingds = objBAL.GetTopTenClosingCPWalkin(objParam, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objSourcingds.Tables.Count > 0)
                {
                    objSourcingds.Tables[0].TableName = "ClosingCPWalkin";
                }
                return Ok(objSourcingds);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Closing\GetTopTenClosingCPWalkin", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods
        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Closing\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"Closing\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
        #endregion
    }
}
