﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Web.Script.Serialization;
using BAL.Prop;
using System.Data;

namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class LeadController : ApiController
    {
        Lead objLead = new Lead();
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        LeadBAL objLeadBAL = new LeadBAL();

        public IHttpActionResult PostInsertLead(LeadProp lp)
        {
            try
            {
                string JsonResponse = "";
                XmlDocument xmlDoc = new XmlDocument();
                XmlSerializer xmlSerializer = new XmlSerializer(lp.GetType());
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, lp);
                    xmlStream.Position = 0;
                    xmlDoc.Load(xmlStream);
                    JsonResponse = objLead.InsertLead(xmlDoc.InnerXml);
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\PostInsertLead", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpGet]
        public IHttpActionResult GetMasterDataForSiteEnquiryForm()
        {
            try
            {
                LeadBAL objLeadBAL = new LeadBAL();
                LeadMasterData oLeadMasterData = objLeadBAL.GetMasterDataForSiteEnquiryForm();
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                return Ok(oLeadMasterData == null ? "" : serializer.Serialize(oLeadMasterData));
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetMasterDataForSiteEnquiryForm", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetPropertyDetails(int PropertyId)
        {
            try
            {
                long EMPID = GetEmpID();
                int RoleId = GetRoleID();
                PropertyBAL objPropBAL = new PropertyBAL();
                Property objProperty = objPropBAL.GetPropertyDetails(PropertyId);
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                return Ok(objProperty == null ? "" : serializer.Serialize(objProperty));
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetPropertyDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult SearchProperties(string SearchProp)
        {
            try
            {
                PropertyBAL objPropertyBAL = new PropertyBAL();
                string JsonResponse = "";
                JsonResponse = objPropertyBAL.GetProppertiesOnSearch(SearchProp);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\SearchProperties", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetDetailsOnSearch(string SearchedText)
        {
            try
            {
                IEnumerable<string> headerValues;
                int FlagId = 0;

                if (Request.Headers.TryGetValues("FlagId", out headerValues))
                {
                    FlagId = Convert.ToInt32(headerValues.FirstOrDefault());
                }

                LeadBAL objLeadBAL = new LeadBAL();
                string JsonResponse = "";
                JsonResponse = objLeadBAL.GetDetailsOnSearch(SearchedText, FlagId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetDetailsOnSearch", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertSiteEnquiryForm(Prospect oLead)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();
            LeadBAL objLeadBAL = new LeadBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (oLead != null)
                {
                    JsonResponse = objLeadBAL.InsertSiteEnquiryForm(Utilities.ObjectToXMLString(oLead)
                        , Convert.ToInt32(EMPID), 2, Convert.ToInt32(RoleId));
                }
                else
                {
                    throw new Exception("Fill Lead Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\InsertSiteEnquiryForm", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertBasicSiteEnquiryForm(LeadProp oLead)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();
            LeadBAL objLeadBAL = new LeadBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (oLead != null)
                {
                    JsonResponse = objLeadBAL.InsertBasicSiteEnquiryForm(Utilities.ObjectToXMLString(oLead)
                        , Convert.ToInt32(EMPID), 1, Convert.ToInt32(RoleId));
                }
                else
                {
                    throw new Exception("Fill Lead Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\InsertBasicSiteEnquiryForm", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetUserDataById(string TokenId)
        {
            try
            {
                UserBAL objUserBAL = new UserBAL();
                string JsonResponse = "";
                JsonResponse = objUserBAL.GetUserDataById(TokenId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetUserDataById", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult VerifyProspectOTP(LeadProp oLead)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();
            LeadBAL objLeadBAL = new LeadBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (oLead != null)
                {
                    JsonResponse = objLeadBAL.VerifyProspectOTP(Utilities.ObjectToXMLString(oLead)
                        , Convert.ToInt32(EMPID), 3, Convert.ToInt32(RoleId));
                }
                else
                {
                    throw new Exception("Fill Lead Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\VerifyProspectOTP", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpGet]
        public IHttpActionResult GetProspectDetailsById(long ProspectId)
        {
            try
            {
                LeadBAL objLeadBAL = new LeadBAL();
                string JsonResponse = "";
                JsonResponse = objLeadBAL.GetProspectDetailsById(ProspectId);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetProspectDetailsById", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostProspectDetails(Prospect oProspect)
        {
            try
            {
                LeadBAL objLeadBAL = new LeadBAL();
                string JsonResponse = "";
                JsonResponse = objLeadBAL.PostProspectDetails(oProspect);
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetProspectDetailsById", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult UpdateProspectDetails(Prospect oLead)
        {
            var EMPID = GetEmpID();

            var RoleId = GetRoleID();
            LeadBAL objLeadBAL = new LeadBAL();
            string JsonResponse = string.Empty;
            try
            {
                if (oLead != null)
                {
                    JsonResponse = objLeadBAL.InsertSiteEnquiryForm(Utilities.ObjectToXMLString(oLead)
                        , Convert.ToInt32(EMPID), 4, Convert.ToInt32(RoleId));
                }
                else
                {
                    throw new Exception("Fill Lead Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\InsertSiteEnquiryForm", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult InsertTeleCallerLead(TeleCallerLead ObjTeleCallerLead)
        {

            LeadBAL objLeadBAL = new LeadBAL();
            bool WhatsAppBrochureFlag = ObjTeleCallerLead.WhatsAppBrochureFlag;
            string JsonResponse = string.Empty;
            try
            {
                if (ObjTeleCallerLead != null)
                {
                    JsonResponse = objLeadBAL.InsertTeleCallerLeadDetails(Utilities.ObjectToXMLString(ObjTeleCallerLead)
                        , Convert.ToInt32(GetEmpID()), ObjTeleCallerLead.BrochureFlag, Convert.ToInt32(GetRoleID()),
                        out ObjTeleCallerLead);

                    if (WhatsAppBrochureFlag && ObjTeleCallerLead.WhatsAppNo != "")
                    {
                        Brochure oBrochure = new Brochure();
                        oBrochure.LeadId = ObjTeleCallerLead.LeadId;
                        oBrochure.WhatsAppNo = ObjTeleCallerLead.WhatsAppNo;
                        oBrochure.Flag = 3;

                        DataTable dtResult = FnWhatsAppBrochure(oBrochure);
                        if (dtResult != null && dtResult.Rows.Count > 0)
                        {
                            if (Convert.ToInt32(dtResult.Rows[0]["Results"]) == 0)
                            {
                                JsonResponse = Utilities.dtToJson(dtResult);
                            }
                        }
                    }
                }
                else
                {
                    throw new Exception("Fill Lead Data");
                }
                return Ok(JsonResponse);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\InsertTeleCallerLead", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetSiteVistLead(DashboardSelectedParams objParam)
        {
            try
            {
                List<SiteVisitLead> objLstSV = new List<SiteVisitLead>();
                LeadBAL objBAl = new LeadBAL();
                objLstSV = objBAl.GetSiteVisitLead(objParam);
                return Ok(objLstSV);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetSiteVistLead", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetLead360(Lead360Param objParam)
        {
            try
            {
                List<Lead360> objLstLd = new List<Lead360>();
                LeadBAL objBAl = new LeadBAL();
                objLstLd = objBAl.GetLeadList(objParam);
                return Ok(objLstLd);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetLead360", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetLead360Details(Lead360Param objParam)
        {
            try
            {
                _Lead360Details objLead = new _Lead360Details();
                LeadBAL objBAl = new LeadBAL();
                objLead = objBAl.GetLead360Details(objParam, GetEmpID(), GetRoleID());
                return Ok(objLead);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetLead360Details", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        private DataTable FnWhatsAppBrochure(Brochure objBrochure)
        {
            try
            {
                CallingBAL objCallingBAL = new CallingBAL();
                CommonBAL oCommonBAL = new CommonBAL();
                string Result = string.Empty;
                List<WhatsAppMsg> oWhatsAppMsgList = new List<WhatsAppMsg>();
                DataTable dtResult = objCallingBAL.WhatsAppBrochure(objBrochure, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()), out oWhatsAppMsgList);
                if (oWhatsAppMsgList.Count > 0)
                {
                    foreach (WhatsAppMsg oMsg in oWhatsAppMsgList)
                    {
                        if (oMsg.IsPdfLinkMsg)
                        {
                            Result = oCommonBAL.SendWhatssAppFileMessage(oMsg.WhatsAppNumber, oMsg.MessageTxt, oMsg.BrochureReadLink,
                                oMsg.BrochureWriteLink, oMsg.BrochureName);
                        }
                        else
                        {
                            Result = oCommonBAL.SendWhatssAppTextMessage(oMsg.WhatsAppNumber, oMsg.MessageTxt);
                        }

                        oMsg.Response = Result;
                        dtResult = objCallingBAL.UpdateWhatsAppMsgStatus(oMsg, GetEmpID(), GetRoleID());
                    }
                }
                return dtResult;
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\FnWhatsAppBrochure", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        #region Methods
        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetEmpID", "API");
                EMPID = 0;
            }
            //
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"Lead\GetRoleID", "API");
                RoleID = 0;
            }
            //
            return RoleID;
        }
        #endregion
    }
}
