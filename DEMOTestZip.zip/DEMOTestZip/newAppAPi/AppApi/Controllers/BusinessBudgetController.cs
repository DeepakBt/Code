﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppApi.Filters;
using BAL;
using BAL.Prop;
using System.Data;
namespace AppApi.Controllers
{
    [GenericAuthenticationFilter]
    public class BusinessBudgetController : ApiController
    {
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);
        [HttpPost]
        public IHttpActionResult GetBusinessBudgetDDL(BusinessBudgetFilters objParam)
        {
            try
            {
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                List<Dropdown> objDropdown = objBAL.BusinessBudgetDDL(objParam);
                return Ok(objDropdown);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\GetBusinessBudgetDDL", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult GetBudgetValue(BusinessBudget objBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.GetBusinessBudgetDetails(objBBParam.PropertyId,Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "BudgetedValue";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\GetBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }


        [HttpPost]
        public IHttpActionResult PostBudgetValue(BusinessBudget objBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.SaveBusinessBudgetDetails(Utilities.ObjectToXMLString(objBBParam),objBBParam.PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "BudgetedValue";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\PostBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PutBudgetValue(BusinessBudget objBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.UpdateBusinessBudgetDetails(Utilities.ObjectToXMLString(objBBParam), objBBParam.PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "BudgetedValue";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\PutBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult DeleteBudgetValue(BusinessBudget objBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.DeleteBusinessBudgetDetails(Utilities.ObjectToXMLString(objBBParam), objBBParam.PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "BudgetedValue";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\DeleteBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetSpentBudgetValue(BusinessBudgetSpent objBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.GetSpentBusinessBudget(objBBParam.PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "SpentBudgetedValue";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\GetSpentBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }
        [HttpPost]
        public IHttpActionResult GetSpentBudgetValueDetails(BusinessBudgetSpent objBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.GetSpentBusinessBudgetDetails(objBBParam.PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "SpentBudgetedValueDetails";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\GetSpentBudgetValueDetails", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PostSpentBudgetValue(List<BusinessBudgetSpent> objLstBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.SaveSpentBusinessBudgetDetails(Utilities.ObjectToXMLString(objLstBBParam), objLstBBParam[0].PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "SpentBudgetedValueDetails";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\PostSpentBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult PutSpentBudgetValue(List<BusinessBudgetSpent> objLstBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.UpdateSpentBusinessBudgetDetails(Utilities.ObjectToXMLString(objLstBBParam), objLstBBParam[0].PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "SpentBudgetedValueDetails";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\PutSpentBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public IHttpActionResult DeleteSpentBudgetValue(List<BusinessBudgetSpent> objLstBBParam)
        {
            try
            {
                DataSet objBB = new DataSet();
                BusinessBudgetBAL objBAL = new BusinessBudgetBAL();
                objBB = objBAL.DeleteSpentBusinessBudgetDetails(Utilities.ObjectToXMLString(objLstBBParam), objLstBBParam[0].PropertyId, Convert.ToInt32(GetEmpID()), Convert.ToInt32(GetRoleID()));
                if (objBB.Tables.Count > 0)
                {
                    objBB.Tables[0].TableName = "SpentBudgetedValueDetails";
                }
                return Ok(objBB);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\DeleteSpentBudgetValue", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        private long GetEmpID()
        {
            IEnumerable<string> headerValues;
            long EMPID = 0;
            try
            {

                if (Request.Headers.TryGetValues("EmpId", out headerValues))
                {
                    EMPID = Convert.ToInt64(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\GetEmpID", "API");
                EMPID = 0;
            }
            return EMPID;
        }

        private int GetRoleID()
        {
            IEnumerable<string> headerValues;
            int RoleID = 0;
            try
            {
                if (Request.Headers.TryGetValues("RoleId", out headerValues))
                {
                    RoleID = Convert.ToInt32(headerValues.FirstOrDefault());
                }
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"BusinessBudget\GetRoleID", "API");
                RoleID = 0;
            }
            return RoleID;
        }
    }
}
