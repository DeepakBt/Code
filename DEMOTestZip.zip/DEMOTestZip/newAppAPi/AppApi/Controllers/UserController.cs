﻿using AppApi.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BAL;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Web;

namespace AppApi.Controllers
{
    public class UserController : ApiController
    {
        UserBAL objUserBAL = new UserBAL();
        HttpResponseMessage badRequest = new HttpResponseMessage(HttpStatusCode.BadRequest);

        [GenericAuthenticationFilter]        
        public IHttpActionResult GetNewUserMstData()
        {
            try
            {
                UserMasterData objUserMstData = objUserBAL.GetMasterDataForNewUser();
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(objUserMstData == null ? "" : serializer.Serialize(objUserMstData));
            }
            catch(Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"User\GetNewUserMstData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [GenericAuthenticationFilter]
        [HttpPost]
        public IHttpActionResult PostInsertUpdateNewUserData(User objUser)
        {
            try
            {
                string oUserXML = CreateXML(objUser);

                User oUser = new User();
                string Result = objUserBAL.InsertUpdateNewUserData(oUserXML.ToString());
                return Ok(Result);
            }
            catch(Exception oEx)
            {
                Utilities.ApiErrorLog(oEx.ToString(), @"User\PostInsertUpdateNewUserData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        public string CreateXML(Object AnyObj)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();   //Represents an XML document, 
                                                          // Initializes a new instance of the XmlDocument class.          
                XmlSerializer xmlSerializer = new XmlSerializer(AnyObj.GetType());
                // Creates a stream whose backing store is memory. 
                using (MemoryStream xmlStream = new MemoryStream())
                {
                    xmlSerializer.Serialize(xmlStream, AnyObj);
                    xmlStream.Position = 0;
                    //Loads the XML document from the specified string.
                    xmlDoc.Load(xmlStream);
                    return xmlDoc.InnerXml;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        [GenericAuthenticationFilter]
        [HttpGet]
        public IHttpActionResult GetUserAccessData(int UserId)
        {
            try
            {
                UserBAL objUserBAL = new UserBAL();
                User objUser = objUserBAL.GetUserAccessData(UserId);
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Ok(objUser == null ? "" : serializer.Serialize(objUser));
            }
            catch (Exception oEx)
            {
                Utilities.ApiErrorLog(oEx.ToString(), @"User\GetUserAccessData", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [GenericAuthenticationFilter]
        [HttpGet]
        public IHttpActionResult GetUsersListOnSeach(string SearchText)
        {
            try
            {
                string JsonResponse = "";
                JsonResponse = objUserBAL.GetUsersListOnSeach(SearchText);
                return Ok(JsonResponse);
            }
            catch(Exception oEx)
            {
                Utilities.ApiErrorLog(oEx.ToString(), @"User\GetUsersListOnSeach", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        [HttpPost]
        public HttpResponseMessage SaveImage()
        {
            try
            {
                HttpResponseMessage response = new HttpResponseMessage();
                string base64ImgeDp = string.Empty;
                string imgName = string.Empty;
                string IP = string.Empty;
                var httpRequest = HttpContext.Current.Request;
                if (httpRequest.Form["dpData"].Length > 0)
                {
                    base64ImgeDp = Convert.ToString(httpRequest.Form["dpData"]);
                    imgName = Convert.ToString(httpRequest.Form["imgName"]);
                    IP = Convert.ToString(httpRequest.Form["IP"]);
                    if (base64ImgeDp != "" && base64ImgeDp != null && base64ImgeDp != "undefined")
                    {
                        base64ImgeDp = base64ImgeDp.Replace("data:image/jpeg;base64,", "");
                        Base64ToImage(base64ImgeDp, imgName);
                    }
                }
                return response;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        private void Base64ToImage(string base64String, string imgName)
        {
            try
            {
                byte[] imageBytes = Convert.FromBase64String(base64String);

                Guid picid = Guid.NewGuid();
                MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
                ms.Write(imageBytes, 0, imageBytes.Length);
                System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
                string spath = System.Web.HttpContext.Current.Server.MapPath("~/UploadFile");
                string path = spath + "\\" + imgName + picid + ".jpg";
                image.Save(path, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        [GenericAuthenticationFilter]
        [HttpPost]
        public IHttpActionResult GetUserActivity(UserParam objUserParam)
        {
            try
            {
                UserBAL objUserBAL = new UserBAL();
                List<UserActivity> LstobjUA = new List<UserActivity>();
                LstobjUA = objUserBAL.GetUserActivity(objUserParam);
                return Ok(LstobjUA);
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.ToString(), @"User\GetUserActivity", "API");
                throw new HttpResponseException(badRequest);
            }
        }

        //public IHttpActionResult GetUsers()
        //{
        //    try
        //    {
        //        string JsonResponse = "";
        //        JsonResponse = objUser.GetUsers();
        //        return Ok(JsonResponse);
        //    }
        //    catch
        //    {
        //        throw new HttpResponseException(badRequest);
        //    }
        //}
    }
}
