﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using BAL;
using System.Web.Http;
using System.Net;

namespace AppApi.Filters
{
    public class GenericAuthenticationFilter : ActionFilterAttribute
    {

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            try
            {
                if (actionContext.Request.Headers.Contains("TokenId") && actionContext.Request.Headers.Contains("EmpId"))
                {
                    string TokenId = Convert.ToString(actionContext.Request.Headers.GetValues("TokenId").FirstOrDefault());
                    long EmpId = Convert.ToInt64(actionContext.Request.Headers.GetValues("EmpId").FirstOrDefault());
                    bool isAuth = false;
                    LoginBAL objEmp = new LoginBAL();
                    isAuth = objEmp.CheckSession(EmpId, TokenId);
                    if (isAuth == false)
                    {
                        Utilities.ApiErrorLog("isAuth is false. TokenId : "+ TokenId+",EmpId : "+Convert.ToString(EmpId)+""
                            , @"GenericAuthenticationFilter\OnActionExecuting", "API");
                        throw new HttpResponseException(HttpStatusCode.Unauthorized);
                    }
                }
                else
                {
                    Utilities.ApiErrorLog("Missing TokenId Or EmpId", @"GenericAuthenticationFilter\OnActionExecuting", "API");
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);                    
                }
            }
            catch (Exception oEX)
            {
                Utilities.ApiErrorLog(oEX.Message, @"GenericAuthenticationFilter\OnActionExecuting", "API");
                throw oEX;
            }
        }
    }

}