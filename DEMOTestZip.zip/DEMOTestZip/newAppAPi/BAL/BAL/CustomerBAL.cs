﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BAL;
using BAL.Prop;
using DAL;
using Newtonsoft.Json;
namespace BAL
{
    public class CustomerBAL
    {
        public SqlCommand cmd;
        public Customer GetCustomer360DegreeView(Filters360degree objDashBoard)
        {
            try
            {
                Customer objCustomer = new Customer();
                Applicant objApplicant;

                string Result = string.Empty;
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@Customer_ID", objDashBoard.Customer_ID);
                cmd.Parameters.AddWithValue("@Type", objDashBoard.Type);
                cmd.Parameters.AddWithValue("@CommunicationId", objDashBoard.CommunicationId);
                cmd.Parameters.AddWithValue("@Currency",objDashBoard.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CUSTOMER_360_DEGREE_VIEW");
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    if (objDashBoard.Flag == 1)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objCustomer.Applicant = new List<Applicant>();
                            objCustomer.Customer_Id = Convert.ToInt64(dsResult.Tables[0].Rows[0]["Customer_ID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["Customer_ID"]);
                            objCustomer.ApplicantTypeID = Convert.ToInt32(dsResult.Tables[0].Rows[0]["ApplicantTypeID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["ApplicantTypeID"]);
                            objCustomer.Name = Convert.ToString(dsResult.Tables[0].Rows[0]["Name"]);
                            objCustomer.Address = Convert.ToString(dsResult.Tables[0].Rows[0]["Address"]);
                            objCustomer.DOB = Convert.ToString(dsResult.Tables[0].Rows[0]["DOB"]);
                            objCustomer.MobileNo = Convert.ToString(dsResult.Tables[0].Rows[0]["MobileNo"]);
                            objCustomer.EmailId = Convert.ToString(dsResult.Tables[0].Rows[0]["EmailId"]);
                            objCustomer.Occupation = Convert.ToString(dsResult.Tables[0].Rows[0]["Occupation"]);
                            objCustomer.Gender = Convert.ToString(dsResult.Tables[0].Rows[0]["Gender"]);
                            objCustomer.Entity = Convert.ToString(dsResult.Tables[0].Rows[0]["Entity"]);
                            objCustomer.Language= Convert.ToString(dsResult.Tables[0].Rows[0]["Language"]);
                            objCustomer.Religion = Convert.ToString(dsResult.Tables[0].Rows[0]["Religion"]);
                        }
                        foreach (DataRow dr in dsResult.Tables[1].Rows)
                        {
                            objApplicant = new Applicant();
                            objApplicant.Customer_Id = Convert.ToInt64(dr["Customer_ID"] == DBNull.Value ? 0 : dr["Customer_ID"]);
                            objApplicant.ApplicantTypeID = Convert.ToInt32(dr["ApplicantTypeID"] == DBNull.Value ? 0 : dr["ApplicantTypeID"]);
                            objApplicant.Name = Convert.ToString(dr["Name"]);
                            objApplicant.Address = Convert.ToString(dr["Address"]);
                            objApplicant.DOB = Convert.ToString(dr["DOB"]);
                            objApplicant.MobileNo = Convert.ToString(dr["MobileNo"]);
                            objApplicant.EmailId = Convert.ToString(dr["EmailId"]);
                            objApplicant.Occupation = Convert.ToString(dr["Occupation"]);
                            objApplicant.Gender = Convert.ToString(dr["Gender"]);
                            objApplicant.Entity = Convert.ToString(dr["Entity"]);

                            objCustomer.Applicant.Add(objApplicant);
                        }
                        if (dsResult.Tables[2].Rows.Count > 0)
                        {
                            objCustomer.BookingDetails = new BookingDetails();
                            objCustomer.BookingDetails.Customer_ID = Convert.ToInt64(dsResult.Tables[2].Rows[0]["Customer_ID"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["Customer_ID"]);
                            objCustomer.BookingDetails.BookingId = Convert.ToInt64(dsResult.Tables[2].Rows[0]["BookingId"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["BookingId"]);
                            objCustomer.BookingDetails.PropertyName = Convert.ToString(dsResult.Tables[2].Rows[0]["PropertyName"]);
                            objCustomer.BookingDetails.PerSqFeetRate = Convert.ToString(dsResult.Tables[2].Rows[0]["PerSqFeetRate"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["PerSqFeetRate"]);
                            objCustomer.BookingDetails.BookingDate = Convert.ToString(dsResult.Tables[2].Rows[0]["BookingDate"]);
                            objCustomer.BookingDetails.UnitType = Convert.ToString(dsResult.Tables[2].Rows[0]["UnitType"]);
                            objCustomer.BookingDetails.Floor = Convert.ToInt32(dsResult.Tables[2].Rows[0]["Floor"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["Floor"]);
                            objCustomer.BookingDetails.BuildingWing = Convert.ToString(dsResult.Tables[2].Rows[0]["BuildingWing"]);
                            objCustomer.BookingDetails.ParkingAllocated = Convert.ToString(dsResult.Tables[2].Rows[0]["ParkingAllocated"]);
                            objCustomer.BookingDetails.ApartmentNo = Convert.ToInt32(dsResult.Tables[2].Rows[0]["ApartmentNo"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["ApartmentNo"]);
                            objCustomer.BookingDetails.CarpetArea = Convert.ToString(dsResult.Tables[2].Rows[0]["CarpetArea"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["CarpetArea"]);
                            objCustomer.BookingDetails.ParkingAllocated = Convert.ToString(dsResult.Tables[2].Rows[0]["ParkingAllocated"]);
                            objCustomer.BookingDetails.AgreementValue = Convert.ToString(dsResult.Tables[2].Rows[0]["AgreementValue"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["AgreementValue"]);
                            objCustomer.BookingDetails.Source = Convert.ToString(dsResult.Tables[2].Rows[0]["Source"]);
                            objCustomer.BookingDetails.PayedAmount = Convert.ToString(dsResult.Tables[2].Rows[0]["PayedAmount"]);
                        }
                    }
                    else if (objDashBoard.Flag == 4)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objCustomer.CustMileStone = new List<MileStone>();
                            foreach (DataRow dr in dsResult.Tables[0].Rows)
                            {
                                MileStone objMileStone = new MileStone();
                                objMileStone.MileStoneId = Convert.ToInt32(dr["MileStoneId"] == DBNull.Value ? 0 : dr["MileStoneId"]);
                                objMileStone.MileStoneName = Convert.ToString(dr["MileStoneName"]);
                                objMileStone.Date = Convert.ToString(dr["Date"]);
                                objMileStone.CSSClass = Convert.ToString(dr["CSSClass"]);
                                objCustomer.CustMileStone.Add(objMileStone);
                            }
                        }
                    }
                    else if (objDashBoard.Flag == 2)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objCustomer.lstCommunication = new List<Communication>();
                            foreach (DataRow dr in dsResult.Tables[0].Rows)
                            {
                                Communication objCommunication = new Communication();
                                objCommunication.CommunicationId = Convert.ToInt64(dr["CommunicationId"] == DBNull.Value ? 0 : dr["CommunicationId"]);
                                objCommunication.Type = Convert.ToInt32(dr["Type"] == DBNull.Value ? 0 : dr["Type"]);
                                objCommunication.Date = Convert.ToString(dr["Date"]);
                                objCommunication.ModeOfContact = Convert.ToString(dr["ModeOfContact"]);
                                objCommunication.Agenda = Convert.ToString(dr["Agenda"]);
                                objCommunication.ContactPerson = Convert.ToString(dr["ContactPerson"]);
                                objCommunication.LeadStatus = Convert.ToString(dr["LeadStatus"]);
                                objCustomer.lstCommunication.Add(objCommunication);
                            }
                        }
                    }
                    else if (objDashBoard.Flag == 3)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objCustomer.SelectedCommunication = new Communication();
                            objCustomer.SelectedCommunication.CommunicationId = Convert.ToInt64(dsResult.Tables[0].Rows[0]["CommunicationId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CommunicationId"]);
                            objCustomer.SelectedCommunication.Type = Convert.ToInt32(dsResult.Tables[0].Rows[0]["Type"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["Type"]);
                            objCustomer.SelectedCommunication.Date = Convert.ToString(dsResult.Tables[0].Rows[0]["Date"]);
                            objCustomer.SelectedCommunication.ModeOfContact = Convert.ToString(dsResult.Tables[0].Rows[0]["ModeOfContact"]);
                            objCustomer.SelectedCommunication.Agenda = Convert.ToString(dsResult.Tables[0].Rows[0]["Agenda"]);
                            objCustomer.SelectedCommunication.ContactPerson = Convert.ToString(dsResult.Tables[0].Rows[0]["ContactPerson"]);
                            objCustomer.SelectedCommunication.MOM = Convert.ToString(dsResult.Tables[0].Rows[0]["MOM"]);
                            objCustomer.SelectedCommunication.LeadStatus = Convert.ToString(dsResult.Tables[0].Rows[0]["LeadStatus"]);
                        }
                    }
                    else if (objDashBoard.Flag == 5)
                    {
                        if (dsResult.Tables.Count > 0)
                        {
                            objCustomer.Customer360PaymentOverView = new Customer360PaymentOverView();
                            objCustomer.Customer360PaymentOverView.PaymentOverView = new PaymentOverView();
                            if (dsResult.Tables[0].Rows.Count > 0)
                            {
                                objCustomer.Customer360PaymentOverView.PaymentOverView = new PaymentOverView();
                                objCustomer.Customer360PaymentOverView.PaymentOverView.PlanName = Convert.ToString(dsResult.Tables[0].Rows[0]["PlanName"]);
                                objCustomer.Customer360PaymentOverView.PaymentOverView.SourceName = Convert.ToString(dsResult.Tables[0].Rows[0]["SourceName"]);
                                objCustomer.Customer360PaymentOverView.PaymentOverView.AgreementValue = Convert.ToString(dsResult.Tables[0].Rows[0]["AgreementValue"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["AgreementValue"]);
                            }
                            if(dsResult.Tables[1].Rows.Count>0)
                            {
                                objCustomer.Customer360PaymentOverView.CustomerProperty = new CustomerProperty();
                                objCustomer.Customer360PaymentOverView.CustomerProperty.BookedDate = Convert.ToString(dsResult.Tables[1].Rows[0]["BookedDate"]);
                                objCustomer.Customer360PaymentOverView.CustomerProperty.PropertyName = Convert.ToString(dsResult.Tables[1].Rows[0]["PropertyName"]);
                                objCustomer.Customer360PaymentOverView.CustomerProperty.ApartmentNo = Convert.ToString(dsResult.Tables[1].Rows[0]["ApartmentNo"]);
                                objCustomer.Customer360PaymentOverView.CustomerProperty.Floor = Convert.ToString(dsResult.Tables[1].Rows[0]["Floor"]);
                                objCustomer.Customer360PaymentOverView.CustomerProperty.CarpetArea = Convert.ToString(dsResult.Tables[1].Rows[0]["CarpetArea"]);
                                objCustomer.Customer360PaymentOverView.CustomerProperty.PropertyConfig = Convert.ToString(dsResult.Tables[1].Rows[0]["Name"]);
                            }
                            if(dsResult.Tables[2].Rows.Count>0)
                            {
                                objCustomer.Customer360PaymentOverView.CostAcquisition = new CostAcquisition();
                                objCustomer.Customer360PaymentOverView.CostAcquisition.CostOfAcquisition= Convert.ToString(dsResult.Tables[2].Rows[0]["CostOfAcquisition"]);
                                objCustomer.Customer360PaymentOverView.CostAcquisition.AgreementValue = Convert.ToString(dsResult.Tables[2].Rows[0]["AgreementValue"]);
                                objCustomer.Customer360PaymentOverView.CostAcquisition.GSTonAgreementValue = Convert.ToString(dsResult.Tables[2].Rows[0]["GSTonAgreementValue"]);
                            }
                            if(dsResult.Tables[3].Rows.Count>0)
                            {
                                objCustomer.Customer360PaymentOverView.StampDuty = new StampDuty();
                                objCustomer.Customer360PaymentOverView.StampDuty.Stamp_Duty= Convert.ToString(dsResult.Tables[3].Rows[0]["StampDuty(5%)"]);
                                objCustomer.Customer360PaymentOverView.StampDuty.RegistrationCharges = Convert.ToString(dsResult.Tables[3].Rows[0]["RegistrationCharges"]);
                                objCustomer.Customer360PaymentOverView.StampDuty.RegistrationAppPay= Convert.ToString(dsResult.Tables[3].Rows[0]["RegistrationAppPay"]);
                                objCustomer.Customer360PaymentOverView.StampDuty.EstimatedCostOfAcquisition = Convert.ToString(dsResult.Tables[3].Rows[0]["EstimatedCostOfAquisition"]);
                                objCustomer.Customer360PaymentOverView.StampDuty.ScanningCharges = Convert.ToString(dsResult.Tables[3].Rows[0]["ScanningCharges"]);
                            }
                            if(dsResult.Tables[4].Rows.Count>0)
                            {
                                objCustomer.Customer360PaymentOverView.OtherCharges = new List<OtherChargesOverView>();
                                foreach(DataRow dr in dsResult.Tables[4].Rows)
                                {
                                    OtherChargesOverView objOtherCharges = new OtherChargesOverView();
                                    objOtherCharges.Name = Convert.ToString(dr["Name"]);
                                    objOtherCharges.Amount = Convert.ToString(dr["Amount"]);
                                    objCustomer.Customer360PaymentOverView.OtherCharges.Add(objOtherCharges);
                                }
                            }
                            if (dsResult.Tables[5].Rows.Count > 0)
                            {
                                objCustomer.Customer360PaymentOverView.PaymentPlanView = new List<PaymentPlanView>();
                                foreach (DataRow dr in dsResult.Tables[5].Rows)
                                {
                                    PaymentPlanView objPaymentPlanView = new PaymentPlanView();
                                    objPaymentPlanView.ScheduleName = Convert.ToString(dr["ScheduleName"]);
                                    objPaymentPlanView.PaymentPerc = Convert.ToString(dr["PaymentPerc"] == DBNull.Value ? 0 : dr["PaymentPerc"]) + " %";
                                    objPaymentPlanView.AgreementValue = Convert.ToString(dr["AgreementValue"] == DBNull.Value ? 0 : dr["AgreementValue"]);
                                    objPaymentPlanView.PrincipalAmt = Convert.ToString(dr["PrincipalAmt"] == DBNull.Value ? 0 : dr["PrincipalAmt"]);
                                    objPaymentPlanView.GSTAmt = Convert.ToString(dr["GSTAmt"] == DBNull.Value ? 0 : dr["GSTAmt"]);
                                    objPaymentPlanView.TDSAmt = Convert.ToString(dr["TDSAmt"] == DBNull.Value ? 0 : dr["TDSAmt"]);
                                    objCustomer.Customer360PaymentOverView.PaymentPlanView.Add(objPaymentPlanView);
                                }
                            }
                            if (dsResult.Tables[6].Rows.Count > 0)
                            {
                                objCustomer.Customer360PaymentOverView.PaymentPlot = new List<PaymentPlot>();
                                foreach (DataRow dr in dsResult.Tables[6].Rows)
                                {
                                    PaymentPlot objPaymentPlot = new PaymentPlot();
                                    objPaymentPlot.Amount = Convert.ToString(dr["Amount"] == DBNull.Value ? 0 : dr["Amount"]);
                                    objPaymentPlot.PaymentDate = Convert.ToString(dr["PaymentDate"]);
                                    objCustomer.Customer360PaymentOverView.PaymentPlot.Add(objPaymentPlot);
                                }
                            }
                            if (dsResult.Tables[7].Rows.Count > 0)
                            {
                                objCustomer.Customer360PaymentOverView.TotalPaymentPlot = Convert.ToString(dsResult.Tables[7].Rows[0]["TotalAmount"] == DBNull.Value ? 0 : dsResult.Tables[7].Rows[0]["TotalAmount"]);
                            }
                            if (dsResult.Tables[8].Rows.Count > 0)
                            {
                                objCustomer.Customer360PaymentOverView.PaymentDetails = new List<PaymentDetails>();
                                foreach (DataRow dr in dsResult.Tables[8].Rows)
                                {
                                    PaymentDetails objPaymentDetails = new PaymentDetails();
                                    objPaymentDetails.MappingScheduleId = Convert.ToInt64(dr["MappingScheduleId"] == DBNull.Value ? 0 : dr["MappingScheduleId"]);
                                    objPaymentDetails.DetailShowFlag = Convert.ToBoolean(dr["DetailShowFlag"]==DBNull.Value?false: dr["DetailShowFlag"]);
                                    objPaymentDetails.ScheduleName = Convert.ToString(dr["ScheduleName"]);
                                    objPaymentDetails.AgreementValue = Convert.ToString(dr["AgreementValue"] == DBNull.Value ? 0 : dr["AgreementValue"]);
                                    objPaymentDetails.Amount = Convert.ToString(dr["Amount"] == DBNull.Value ? 0 : dr["Amount"]);
                                    objPaymentDetails.PaymentDate = Convert.ToString(dr["PaymentDate"]);
                                    objPaymentDetails.PaymentDueDate = Convert.ToString(dr["PaymentDueDate"]);
                                    objPaymentDetails.PendingAmount = Convert.ToString(dr["PendingAmount"] == DBNull.Value ? 0 : dr["PendingAmount"]);
                                    objPaymentDetails.DelayedDays = Convert.ToString(dr["DelayedDays"] == DBNull.Value ? 0 : dr["DelayedDays"]);
                                    objPaymentDetails.DelayedInterest = Convert.ToString(dr["DelayedInterest"] == DBNull.Value ? 0 : dr["DelayedInterest"]);
                                    objPaymentDetails.TotalPendingDue = Convert.ToString(dr["TotalPendingDue"] == DBNull.Value ? 0 : dr["TotalPendingDue"]);
                                    objCustomer.Customer360PaymentOverView.PaymentDetails.Add(objPaymentDetails);
                                }
                            }
                            if(dsResult.Tables[9].Rows.Count>0)
                            {
                                objCustomer.Customer360PaymentOverView.CustomerPaymentSummary = new CustomerPaymentSummary();
                                objCustomer.Customer360PaymentOverView.CustomerPaymentSummary.TotalAmount= Convert.ToString(dsResult.Tables[9].Rows[0]["TotalAmount"]);
                                objCustomer.Customer360PaymentOverView.CustomerPaymentSummary.PayedAmount = Convert.ToString(dsResult.Tables[9].Rows[0]["PayedAmount"]);
                                objCustomer.Customer360PaymentOverView.CustomerPaymentSummary.PendingAmount = Convert.ToString(dsResult.Tables[9].Rows[0]["PendingAmount"]);
                            }
                        }
                    }
                    else if(objDashBoard.Flag==6)
                    {
                        if(dsResult.Tables.Count>0)
                        {
                            objCustomer.Customer360OtherCharges = new Customer360OtherCharges();
                            objCustomer.Customer360OtherCharges.PaymentSchedule = new List<PaymentSchedule>();
                            objCustomer.Customer360OtherCharges.OtherCharges = new List<OtherCharges>();
                            if(dsResult.Tables[0].Rows.Count>0)
                            {
                                foreach(DataRow dr in dsResult.Tables[0].Rows)
                                {
                                    PaymentSchedule objPaymentSchedule = new PaymentSchedule();
                                    objPaymentSchedule.ScheduleName = Convert.ToString(dr["ScheduleName"]);
                                    objPaymentSchedule.GSTAmount =Convert.ToString(dr["GSTAmt"]);
                                    objPaymentSchedule.GSTPaid = Convert.ToString(dr["GSTPaid"]);
                                    objPaymentSchedule.TDSAmount = Convert.ToString(dr["TDSAmt"]);
                                    objPaymentSchedule.TDSPaid = Convert.ToString(dr["TDSPaid"]);
                                    objPaymentSchedule.GSTFlag = Convert.ToBoolean(dr["GSTFlag"] == DBNull.Value ? 0 : dr["GSTFlag"]);
                                    objPaymentSchedule.TDSFlag = Convert.ToBoolean(dr["TDSFlag"] == DBNull.Value ? 0 : dr["TDSFlag"]);
                                    objCustomer.Customer360OtherCharges.PaymentSchedule.Add(objPaymentSchedule);
                                }
                            }
                            if(dsResult.Tables[1].Rows.Count>0)
                            {
                                foreach(DataRow dr in dsResult.Tables[1].Rows)
                                {
                                    OtherCharges objOtherCharges = new OtherCharges();
                                    objOtherCharges.OtherCharge= Convert.ToString(dr["Name"]);
                                    objOtherCharges.Amount = Convert.ToString(dr["Amount"]);
                                    objOtherCharges.PaidAmount =Convert.ToString(dr["PaidAmount"]);
                                    objOtherCharges.Flag = Convert.ToString(dr["Flag"]);
                                    objCustomer.Customer360OtherCharges.OtherCharges.Add(objOtherCharges);
                                }
                            }
                        }
                    }
                }
                return objCustomer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Customer360Summary GetCustomer360Summary(Filters360degree objDashBoard, int RoleId, long EmpId)
        {
            try
            {
                Customer360Summary objCustomer360Summary = new Customer360Summary();
                string Result = string.Empty;
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@UserId", EmpId);
                cmd.Parameters.AddWithValue("@UserTypeId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CUSTOMER_360_SUMMARY");
                if(dsResult.Tables.Count>0)
                {
                    if(objDashBoard.Flag==1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objCustomer360Summary.CustomerCount = new CustomerCount();
                            objCustomer360Summary.CustomerCount.NoOfFlatBooked = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfFlatBooked"]);
                            objCustomer360Summary.CustomerCount.NoOfRegistrationDone= Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfRegistrationDone"]);
                            objCustomer360Summary.CustomerCount.NoOfBookingDone = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfBookingDonein15Days"]);
                            objCustomer360Summary.CustomerCount.NoOfMeetingCallDone = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfMeetingCallDone"]);
                        }if(dsResult.Tables[1].Rows.Count>0)
                        {
                            objCustomer360Summary.CustomerDetails = new List<CustomerDetails>();
                            foreach(DataRow dr in dsResult.Tables[1].Rows)
                            {
                                CustomerDetails objCustomerDetails = new CustomerDetails();
                                objCustomerDetails.Customer_ID = Convert.ToInt64(dr["Customer_ID"] ==DBNull.Value?0: dr["Customer_ID"]);
                                objCustomerDetails.CustomerName = Convert.ToString(dr["CustomerName"]);
                                objCustomerDetails.Typology = Convert.ToString(dr["Typology"]);
                                objCustomerDetails.RegistrationDone = Convert.ToString(dr["RegistrationDone"]);
                                objCustomerDetails.PropertyName = Convert.ToString(dr["PropertyName"]);
                                objCustomerDetails.Received = Convert.ToString(dr["Received"]);
                                objCustomerDetails.Wing= Convert.ToString(dr["Wing"]);
                                objCustomer360Summary.CustomerDetails.Add(objCustomerDetails);
                            }
                        }
                    }
                }
                return objCustomer360Summary;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ProjectUpdateWrapper GetProjectUpdate(Filters360degree objDashBoard)
        {
            try
            {
                ProjectUpdateWrapper objProjectUpdateWrapper = new ProjectUpdateWrapper();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@Customer_Id", objDashBoard.Customer_ID);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PROJECT_UPDATE");
                if(dsResult.Tables.Count>0)
                {
                    if(objDashBoard.Flag==1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objProjectUpdateWrapper.ProjectUpdate = new List<ProjectUpdate>();
                            foreach(DataRow dr in dsResult.Tables[0].Rows)
                            {
                                ProjectUpdate objProjectUpdate = new ProjectUpdate();
                                objProjectUpdate.Date = Convert.ToString(dr["Date"]);
                                objProjectUpdate.Title = Convert.ToString(dr["Title"]);
                                objProjectUpdate.DocName= Convert.ToString(dr["DocName"]);
                                if (dsResult.Tables[1].Rows.Count > 0)
                                {
                                    objProjectUpdate.Files = new List<Files>();
                                    objProjectUpdate.Images = new List<Images>();
                                    foreach (DataRow drInner in dsResult.Tables[1].Rows)
                                    {
                                        if (
                                            Convert.ToString(dr["PropertyID"]) == Convert.ToString(drInner["PropertyID"]) &&
                                            Convert.ToString(dr["WingId"]) == Convert.ToString(drInner["WingId"]) &&
                                            Convert.ToString(dr["FloorNo"]) == Convert.ToString(drInner["FloorNo"]) &&
                                            Convert.ToString(dr["DocTypeId"]) == Convert.ToString(drInner["DocTypeId"])
                                            )
                                        {
                                            if(Convert.ToInt32(drInner["ContentTypeId"]==DBNull.Value?0: drInner["ContentTypeId"]) ==1)
                                            {
                                                Files objFiles = new Files();
                                                objFiles.File = Convert.ToString(drInner["Content"]);
                                                objProjectUpdate.Files.Add(objFiles);
                                            }
                                            if(Convert.ToInt32(drInner["ContentTypeId"] == DBNull.Value ? 0 : drInner["ContentTypeId"]) == 2)
                                            {
                                                Images objImages = new Images();
                                                objImages.ImgPath = Convert.ToString(drInner["Content"]);
                                                objProjectUpdate.Images.Add(objImages);
                                            }
                                        }
                                    }
                                }
                                objProjectUpdateWrapper.ProjectUpdate.Add(objProjectUpdate);
                            }
                        }
                    }
                }
                return objProjectUpdateWrapper;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<SlabPaymentDetails> GetSlabPaymentDetails(Filters360degree objDashBoard)
        {
            try
            {
                List<SlabPaymentDetails> objListSlabPaymentDetails = new List<SlabPaymentDetails>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@Customer_Id", objDashBoard.Customer_ID);
                cmd.Parameters.AddWithValue("@MappingScheduledId", objDashBoard.MappingScheduledId);
                cmd.Parameters.AddWithValue("@Currency", objDashBoard.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_CUSTOMER_SLABWISE_PAYMENT_DETAILS");
                if(objDashBoard.Flag==1)
                {
                    if(dsResult.Tables.Count>0)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            foreach(DataRow dr in dsResult.Tables[0].Rows)
                            {
                                SlabPaymentDetails objSlabPaymentDetails = new SlabPaymentDetails();
                                objSlabPaymentDetails.SlabName = Convert.ToString(dr["SlabName"]);
                                objSlabPaymentDetails.PaymentDate = Convert.ToString(dr["PaymentDate"]);
                                objSlabPaymentDetails.Amount= Convert.ToString(dr["Amount"]);
                                objSlabPaymentDetails.PaymentType= Convert.ToString(dr["PaymentType"]);
                                objSlabPaymentDetails.PaymentMode = Convert.ToString(dr["PaymentMode"]);
                                objSlabPaymentDetails.ChequeDate= Convert.ToString(dr["ChequeDate"]);
                                objSlabPaymentDetails.ChequeNo = Convert.ToString(dr["ChequeNo"]==DBNull.Value?0: dr["ChequeNo"]);
                                objListSlabPaymentDetails.Add(objSlabPaymentDetails);
                            }
                        }
                    }
                }
                return objListSlabPaymentDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<BankLoanProcess> GetLoanProcess(Filters360degree objDashBoard)
        {
            try
            {
                List<BankLoanProcess> ObjLoanProcess = new List<BankLoanProcess>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_BANK_LOAN_DETAILS");
                if (objDashBoard.Flag == 1)
                {
                    if(dsResult.Tables.Count>0)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            foreach(DataRow dr in dsResult.Tables[0].Rows)
                            {
                                BankLoanProcess _ObjLoanProcess = new BankLoanProcess();
                                _ObjLoanProcess.BankId = Convert.ToInt32(dr["BankId"] == DBNull.Value ? 0 : dr["BankId"]);
                                _ObjLoanProcess.BankLogo = Convert.ToString(dr["BankLogo"]);
                                _ObjLoanProcess.BankName = Convert.ToString(dr["BankName"]);
                                _ObjLoanProcess.InterestRange = Convert.ToString(dr["InterestRange"]);
                                _ObjLoanProcess.LoanAmount = Convert.ToString(dr["LoanAmount"]);
                                _ObjLoanProcess.ProcessingFeeRange = Convert.ToString(dr["ProcessingFeeRange"]);
                                _ObjLoanProcess.TenureRange = Convert.ToString(dr["TenureRange"]);
                                ObjLoanProcess.Add(_ObjLoanProcess);
                            }
                        }
                    }
                }
                return ObjLoanProcess;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Dropdown> GetQueryReqDDL(Filters360degree objDashBoard)
        {
            try
            {
                List<Dropdown> objListDropdown = new List<Dropdown>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetMaster");
                if(dsResult.Tables.Count>0)
                {
                    if(dsResult.Tables[0].Rows.Count>0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            Dropdown objDropdown = new Dropdown();
                            objDropdown.Id = Convert.ToInt32(dr["Id"] == DBNull.Value ? 0 : dr["Id"]);
                            objDropdown.Value = Convert.ToString(dr["Value"]);
                            objListDropdown.Add(objDropdown);
                        }
                    }
                }
                return objListDropdown;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BankLoanProcess GetLoanProcessDetails(int BankId)
        {
            try
            {
                BankLoanProcess ObjLoanProcess = new BankLoanProcess();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@BankId", BankId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_BANK_LOAN_DETAILS");
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0] != null && dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow oRow in dsResult.Tables[0].Rows)
                        {
                            string Benefits = Convert.ToString(oRow["Benefits"]);
                            string ContactPerson = Convert.ToString(oRow["ContactPerson"]);
                            string LoanProcess = Convert.ToString(oRow["LoanProcess"]);
                            string[] ArrBenefits = Benefits.Split(new string[] { "|$|" }, StringSplitOptions.None);
                            string[] ArrContactPerson = ContactPerson.Split(new string[] { "|$|" }, StringSplitOptions.None);
                            string[] ArrLoanProcess = LoanProcess.Split(new string[] { "|$|" }, StringSplitOptions.None);

                            if (ArrBenefits != null && ArrBenefits.Length > 0)
                            {
                                ObjLoanProcess.BenefitsList = new List<Dropdown>();
                                for (int i = 0; i < ArrBenefits.Length; i++)
                                {
                                    Dropdown dd = new Dropdown();
                                    dd.Value = Convert.ToString(ArrBenefits[i]);
                                    ObjLoanProcess.BenefitsList.Add(dd);
                                }
                            }

                            if (ArrContactPerson != null && ArrContactPerson.Length > 0)
                            {
                                ObjLoanProcess.ContactDetailsList = new List<Dropdown>();
                                for (int i = 0; i < ArrContactPerson.Length; i++)
                                {
                                    Dropdown dd = new Dropdown();
                                    dd.Value = Convert.ToString(ArrContactPerson[i]);
                                    ObjLoanProcess.ContactDetailsList.Add(dd);
                                }
                            }

                            if (ArrLoanProcess != null && ArrLoanProcess.Length > 0)
                            {
                                ObjLoanProcess.LoanProcessList = new List<Dropdown>();
                                for (int i = 0; i < ArrLoanProcess.Length; i++)
                                {
                                    Dropdown dd = new Dropdown();
                                    dd.Value = Convert.ToString(ArrLoanProcess[i]);
                                    ObjLoanProcess.LoanProcessList.Add(dd);
                                }
                            }
                        }
                    }
                }
                return ObjLoanProcess;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CustomerBooking GetProspectDetails(Filters360degree objParam,int EmpId)
        {
            try
            {
                CustomerBooking objCustomerBooking = new CustomerBooking();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@ProspectId", objParam.ProspectId);
                cmd.Parameters.AddWithValue("@EmpId",EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_CUSTOMER_BOOKING_FORM");
                if(dt.Rows.Count>0)
                {
                    objCustomerBooking.ProspectId = Convert.ToInt32(dt.Rows[0]["PROSPECTID"] == DBNull.Value ? 0 : dt.Rows[0]["PROSPECTID"]);
                    objCustomerBooking.FirstName = Convert.ToString(dt.Rows[0]["FirstName"]);
                    objCustomerBooking.LastName = Convert.ToString(dt.Rows[0]["LastName"]);
                    objCustomerBooking.MobileNo = Convert.ToString(dt.Rows[0]["Mobile"]);
                    objCustomerBooking.EmailId = Convert.ToString(dt.Rows[0]["Email"]);
                    objCustomerBooking.Gender = Convert.ToInt32(dt.Rows[0]["Gender"]);
                    objCustomerBooking.GenderName = Convert.ToString(dt.Rows[0]["GenderName"]);
                    if (!DBNull.Value.Equals(dt.Rows[0]["DOB"]))
                    {
                        objCustomerBooking.DOB =  Convert.ToDateTime(dt.Rows[0]["DOB"]);
                    }
                    objCustomerBooking.DateOfBirth = Convert.ToString(dt.Rows[0]["DateOfBirth"]);
                    objCustomerBooking.Address = Convert.ToString(dt.Rows[0]["Address"]);
                    objCustomerBooking.Country = Convert.ToInt32(dt.Rows[0]["Country"]==DBNull.Value?0: dt.Rows[0]["Country"]);
                    objCustomerBooking.CountryName = Convert.ToString(dt.Rows[0]["CountryName"]);
                    objCustomerBooking.PinId = Convert.ToInt32(dt.Rows[0]["PincodeId"]==DBNull.Value?0:dt.Rows[0]["PincodeId"]);
                    objCustomerBooking.PinCode = Convert.ToString(dt.Rows[0]["PinCode"]);
                    objCustomerBooking.IsNRI = Convert.ToBoolean(dt.Rows[0]["IsNRI"] == DBNull.Value ? false : dt.Rows[0]["IsNRI"]);
                    objCustomerBooking.PropertyId = Convert.ToInt32(dt.Rows[0]["PropertyId"] == DBNull.Value ? 0 : dt.Rows[0]["PropertyId"]);
                    objCustomerBooking.PropertyName = Convert.ToString(dt.Rows[0]["PropertyName"]);
                }
                return objCustomerBooking;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveCustomer(string CustomerXML, int UserId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XmlData", CustomerXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", UserId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_CUSTOMER_BOOKING_FORM");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
