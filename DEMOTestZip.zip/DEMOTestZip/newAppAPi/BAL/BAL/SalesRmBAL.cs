﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;

namespace BAL
{
    public class SalesRmBAL
    {
        SqlCommand cmd;
        public string GetSalesRmHierarchy(long EmpID)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpID);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SalesRM_Lead_Dashboard");
                JString = Utilities.dtToJson(oDT);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SalesRMMasterData GetSalesRMMeetingDashboardMasterData(long EmpID,int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EMPID", EmpID);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet oDS = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetMaster");

                SalesRMMasterData oSalesRM = new SalesRMMasterData();
                oSalesRM.PropertyList = new List<Dropdown>();
                oSalesRM.LeadStatusList = new List<Dropdown>();
                oSalesRM.LeadQualificationList = new List<Dropdown>();
                oSalesRM.SalesRMList = new List<Dropdown>();
                oSalesRM.CPList = new List<Dropdown>();
                oSalesRM.SessionParams = new List<Entity>();
                Dropdown odd = new Dropdown();
                Entity en = new Entity();

                if(oDS!= null  && oDS.Tables.Count > 0)
                {
                    foreach(DataRow oRow in oDS.Tables[0].Rows)
                    {
                        odd = new Dropdown();
                        odd.Id = Convert.ToInt32(oRow["Empid"]);
                        odd.Value = Convert.ToString(oRow["EmpName"]);
                        oSalesRM.SalesRMList.Add(odd);
                    }

                    foreach (DataRow oRow in oDS.Tables[1].Rows)
                    {
                        odd = new Dropdown();
                        odd.Id = Convert.ToInt32(oRow["PropertyId"]);
                        odd.Value = Convert.ToString(oRow["PropertyName"]);
                        oSalesRM.PropertyList.Add(odd);
                    }

                    foreach (DataRow oRow in oDS.Tables[2].Rows)
                    {
                        odd = new Dropdown();
                        odd.Id = Convert.ToInt32(oRow["StatusID"]);
                        odd.Value = Convert.ToString(oRow["StatusName"]);
                        oSalesRM.LeadStatusList.Add(odd);
                    }

                    foreach (DataRow oRow in oDS.Tables[3].Rows)
                    {
                        odd = new Dropdown();
                        odd.Id = Convert.ToInt32(oRow["QualifyID"]);
                        odd.Value = Convert.ToString(oRow["QualifyName"]);
                        oSalesRM.LeadQualificationList.Add(odd);
                    }

                    foreach (DataRow oRow in oDS.Tables[4].Rows)
                    {
                        odd = new Dropdown();
                        odd.Id = Convert.ToInt32(oRow["CPID"]);
                        odd.Value = Convert.ToString(oRow["Name"]);
                        oSalesRM.CPList.Add(odd);
                    }

                    if (oDS.Tables.Count > 5)
                    {
                        foreach (DataRow oRow in oDS.Tables[5].Rows)
                        {
                            en = new Entity();
                            en.Id = Convert.ToInt32(oRow["ParamId"]);
                            en.Value = Convert.ToString(oRow["Value"]);
                            en.Name = Convert.ToString(oRow["ParamName"]);
                            oSalesRM.SessionParams.Add(en);
                        }
                    }
                }

                return oSalesRM;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public SalesRMDashboard GetSalesRmDashboard(long EmpID, DashboardSelectedParams oSelectedParams,int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", oSelectedParams.Flag);
                cmd.Parameters.AddWithValue("@EMPID", EmpID);
                cmd.Parameters.AddWithValue("@PropertyID", oSelectedParams.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", oSelectedParams.RMId);
                cmd.Parameters.AddWithValue("@CPId", oSelectedParams.CPId);
                cmd.Parameters.AddWithValue("@StatusId", oSelectedParams.LeadStatusId);
                cmd.Parameters.AddWithValue("@QualificationId", oSelectedParams.LeadQualiId);
                cmd.Parameters.AddWithValue("@FTD", oSelectedParams.FTD);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet oDs = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_LEAD_SALESRM_DASHBOARD");
                SalesRMDashboard oSalesRMDashboard = new SalesRMDashboard();
                if(oDs != null && oDs.Tables.Count > 0)
                {
                    oSalesRMDashboard.DisplayBlocks = Utilities.dtToJson(oDs.Tables[0]);
                    oSalesRMDashboard.RMProspectDataList = oDs.Tables.Count > 1 ? Utilities.dtToJson(oDs.Tables[1]) : "";
                    oSalesRMDashboard.RMTodaysCallList = oDs.Tables.Count > 2 ? Utilities.dtToJson(oDs.Tables[2]) : "";
                }

                return oSalesRMDashboard;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<InventoryStatus> GetInventoryBookingStatus(Filters360degree objParam)
        {
            try
            {
                List<InventoryStatus> objLstInventoryStatus = new List<InventoryStatus>();
                cmd = new SqlCommand();
                DataSet dsResult;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@WingId",objParam.WingId);
                cmd.Parameters.AddWithValue("@FloorNo", objParam.FloorNo);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_UPDATE_INVENTORY_STATUS");
                if(dsResult.Tables.Count>0)
                {
                    if(dsResult.Tables[0].Rows.Count>0)
                    {
                        foreach(DataRow dr in dsResult.Tables[0].Rows)
                        {
                            InventoryStatus objInventoryStatus = new InventoryStatus();
                            objInventoryStatus.InventoryId = Convert.ToInt64(dr["InventoryId"] == DBNull.Value ? 0 : dr["InventoryId"]);
                            objInventoryStatus.FlatNo = Convert.ToString(dr["FlatNo"]==DBNull.Value?0:dr["FlatNo"]);
                            objInventoryStatus.Wing = Convert.ToString(dr["Wing"]);
                            objInventoryStatus.Facing = Convert.ToString(dr["Facing"]);
                            objInventoryStatus.Name = Convert.ToString(dr["Name"]);
                            objInventoryStatus.BookedStatus = Convert.ToString(dr["BookedStatus"]);
                            objInventoryStatus.StatusId = Convert.ToInt32(dr["StatusId"]);
                            objLstInventoryStatus.Add(objInventoryStatus);
                        }
                    }
                }
                return objLstInventoryStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateInventoryBookingStatus(string XMLData,long EmpId,int Flag)
        {
            try
            {
                string JString = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_UPDATE_INVENTORY_STATUS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetSalesAllProspectData(long EmpID, DashboardSelectedParams oSelectedParams,int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EMPID", EmpID);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@Flag", oSelectedParams.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", oSelectedParams.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", oSelectedParams.RMId);
                cmd.Parameters.AddWithValue("@StatusId", oSelectedParams.LeadStatusId);
                cmd.Parameters.AddWithValue("@QualificationId", oSelectedParams.LeadQualiId);
                cmd.Parameters.AddWithValue("@FTD", oSelectedParams.FTD);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_ALL_PROSPECTS_DATA");
                JString = Utilities.dtToJson(oDT);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SalesAnalyticDashboard GetSalesRMAnalyticDB(int EmpId,int RoleId, ReportParam objParam)
        {
            try
            {
                SalesAnalyticDashboard objSDb = new SalesAnalyticDashboard();
                objSDb.LeadTypeBreakUp = new LeadTypeBreakUp();
                objSDb.LeadSourceBreakUp = new LeadSourceBreakUp();
                objSDb.LeadStatusBreakUp = new LeadStatusBreakUp();
                objSDb.LeadStatusColor = new LeadStatusColor();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@FromDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@Period",objParam.Period);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_SALES_ANALYTICS_DASHBOARD");
                if(ds.Tables.Count>3)
                {
                    if(ds.Tables[0].Rows.Count>0)
                    {
                        objSDb.LeadTypeBreakUp.Hot = Convert.ToInt32(ds.Tables[0].Rows[0]["Hot"]==DBNull.Value?0: ds.Tables[0].Rows[0]["Hot"]);
                        objSDb.LeadTypeBreakUp.Warm= Convert.ToInt32(ds.Tables[0].Rows[0]["Warm"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["Warm"]);
                        objSDb.LeadTypeBreakUp.Cold= Convert.ToInt32(ds.Tables[0].Rows[0]["Cold"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["Cold"]);
                        objSDb.LeadTypeBreakUp.DataDisplayFlag = Convert.ToBoolean(ds.Tables[0].Rows[0]["DataDisplayFlag"] == DBNull.Value ? false : ds.Tables[0].Rows[0]["DataDisplayFlag"]);
                    }
                    if(ds.Tables[1].Rows.Count>0)
                    {
                        objSDb.LeadSourceBreakUp.CP = Convert.ToInt32(ds.Tables[1].Rows[0]["CP"]==DBNull.Value?0: ds.Tables[1].Rows[0]["CP"]);
                        objSDb.LeadSourceBreakUp.Offline= Convert.ToInt32(ds.Tables[1].Rows[0]["Offline"] == DBNull.Value ? 0 : ds.Tables[1].Rows[0]["Offline"]);
                        objSDb.LeadSourceBreakUp.Online = Convert.ToInt32(ds.Tables[1].Rows[0]["Online"] == DBNull.Value ? 0 : ds.Tables[1].Rows[0]["Online"]);
                        objSDb.LeadSourceBreakUp.Others = Convert.ToInt32(ds.Tables[1].Rows[0]["Others"] == DBNull.Value ? 0 : ds.Tables[1].Rows[0]["Others"]);
                        objSDb.LeadSourceBreakUp.DataDisplayFlag = Convert.ToBoolean(ds.Tables[1].Rows[0]["DataDisplayFlag"] == DBNull.Value ? false : ds.Tables[1].Rows[0]["DataDisplayFlag"]);
                    }
                    if(ds.Tables[2].Rows.Count>0)
                    {
                        objSDb.LeadStatusBreakUp.BookedEOI = Convert.ToInt32(ds.Tables[2].Rows[0]["BookedEOI"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["BookedEOI"]);
                        objSDb.LeadStatusBreakUp.Closure = Convert.ToInt32(ds.Tables[2].Rows[0]["Closure"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["Closure"]);
                        objSDb.LeadStatusBreakUp.FollowUp = Convert.ToInt32(ds.Tables[2].Rows[0]["FollowUp"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["FollowUp"]);
                        objSDb.LeadStatusBreakUp.InDiscussion = Convert.ToInt32(ds.Tables[2].Rows[0]["InDiscussion"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["InDiscussion"]);
                        objSDb.LeadStatusBreakUp.NotInterested = Convert.ToInt32(ds.Tables[2].Rows[0]["NotInterested"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["NotInterested"]);
                        objSDb.LeadStatusBreakUp.Positive = Convert.ToInt32(ds.Tables[2].Rows[0]["Positive"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["Positive"]);
                        objSDb.LeadStatusBreakUp.Rejected = Convert.ToInt32(ds.Tables[2].Rows[0]["Rejected"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["Rejected"]);
                        objSDb.LeadStatusBreakUp.DataDisplayFlag = Convert.ToBoolean(ds.Tables[2].Rows[0]["DataDisplayFlag"] == DBNull.Value ? false : ds.Tables[2].Rows[0]["DataDisplayFlag"]);
                    }
                    if(ds.Tables[3].Rows.Count>0)
                    {
                        objSDb.LeadStatusColor.BookedEOI = Convert.ToString(ds.Tables[3].Rows[0]["BookedEOI"]);
                        objSDb.LeadStatusColor.Closure = Convert.ToString(ds.Tables[3].Rows[0]["Closure"]);
                        objSDb.LeadStatusColor.FollowUp = Convert.ToString(ds.Tables[3].Rows[0]["FollowUp"]);
                        objSDb.LeadStatusColor.InDiscussion = Convert.ToString(ds.Tables[3].Rows[0]["InDiscussion"]);
                        objSDb.LeadStatusColor.NotInterested = Convert.ToString(ds.Tables[3].Rows[0]["NotInterested"]);
                        objSDb.LeadStatusColor.Positive = Convert.ToString(ds.Tables[3].Rows[0]["Positive"]);
                        objSDb.LeadStatusColor.Rejected = Convert.ToString(ds.Tables[3].Rows[0]["Rejected"]);
                        objSDb.LeadStatusColor.DataDisplayFlag = Convert.ToBoolean(ds.Tables[3].Rows[0]["DataDisplayFlag"]==DBNull.Value?false: ds.Tables[3].Rows[0]["DataDisplayFlag"]);
                    }
                }
                return objSDb;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public SalesRMDashboard GetSearchedProspects(long EmpID, DashboardSelectedParams oSelectedParams, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", oSelectedParams.Flag);
                cmd.Parameters.AddWithValue("@EMPID", EmpID);
                cmd.Parameters.AddWithValue("@PropertyID", oSelectedParams.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", oSelectedParams.RMId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@ProspectSearch", oSelectedParams.ProspectSearch);
                DataSet oDs = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_PROSPECT_SEARCH");
                SalesRMDashboard oSalesRMDashboard = new SalesRMDashboard();
                if (oDs != null && oDs.Tables.Count > 0)
                {
                    oSalesRMDashboard.RMProspectDataList = Utilities.dtToJson(oDs.Tables[0]);
                }

                return oSalesRMDashboard;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
