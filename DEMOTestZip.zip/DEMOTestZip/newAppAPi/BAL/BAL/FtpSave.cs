﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class FtpSave
    {
        #region variable

        public const int LOGON32_LOGON_INTERACTIVE = 9;
        public const int LOGON32_PROVIDER_DEFAULT = 0;
        public static WindowsImpersonationContext impersonationContext;

        [DllImport("advapi32.dll")]
        public static extern int LogonUserA(String lpszUserName, String lpszDomain, String lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int DuplicateToken(IntPtr hToken, int impersonationLevel, ref IntPtr hNewToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool RevertToSelf();

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]

        public static extern bool CloseHandle(IntPtr handle);

        string UserName = Convert.ToString(ConfigurationSettings.AppSettings["UserName"]);

        string Password = Convert.ToString(ConfigurationSettings.AppSettings["Password"]);

        string Domain = Convert.ToString(ConfigurationSettings.AppSettings["Domain"]);

        #endregion

        private bool impersonateValidUser(String userName, String password, String domain)
        {
            try
            {
                WindowsIdentity tempWindowsIdentity;
                IntPtr token = IntPtr.Zero;
                IntPtr tokenDuplicate = IntPtr.Zero;

                if (RevertToSelf())
                {
                    if (LogonUserA(userName, domain, password, LOGON32_LOGON_INTERACTIVE,
                        LOGON32_PROVIDER_DEFAULT, ref token) != 0)
                    {
                        if (DuplicateToken(token, 2, ref tokenDuplicate) != 0)
                        {
                            tempWindowsIdentity = new WindowsIdentity(tokenDuplicate);
                            impersonationContext = tempWindowsIdentity.Impersonate();
                            if (impersonationContext != null)
                            {
                                CloseHandle(token);
                                CloseHandle(tokenDuplicate);
                                return true;
                            }
                        }
                    }
                }
                if (token != IntPtr.Zero)
                    CloseHandle(token);

                if (tokenDuplicate != IntPtr.Zero)
                    CloseHandle(tokenDuplicate);

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public int GeneratePDFFromHTML(DataTable dtResult, string TempFilePath, string AttachmentName
                   , string AttachmentPATH)
        {
            int iResult = 0; StringReader sr = null;
            string tempPath = TempFilePath + AttachmentName;
            try
            {
                if (impersonateValidUser(UserName, Password, Domain))
                {

                    sr = new StringReader(Convert.ToString(dtResult.Rows[0][0]));

                    using (FileStream _fileStream = new FileStream(@"" + tempPath + "", FileMode.OpenOrCreate))
                    {
                        Document document = new Document(PageSize.A4, 10f, 10f, 10f, 20f);
                        PdfWriter writer = PdfWriter.GetInstance(document, _fileStream);
                        document.Open();
                        //Style
                        iTextSharp.text.Font tableBodyfont = iTextSharp.text.FontFactory.GetFont(FontFactory.HELVETICA, 6);//body font

                        XMLWorkerHelper.GetInstance().ParseXHtml(writer, document, sr);

                        document.Close();
                        writer.Close();
                        iResult = 1;

                        //Transfer Created file to FTP folder

                        iResult = TransferFileToFTP(tempPath, AttachmentPATH, AttachmentName);

                        //Delete temporary created file
                        if (iResult == 1)
                        {
                            File.Delete(tempPath);
                        }
                    }
                }//Impersonation valid
            }

            catch (Exception oEX)
            {
                iResult = 0;
                Utilities.ApiErrorLog(oEX.Message.ToString(), @"FtpSave\GeneratePDFFromHTML", "API");
            }
            return iResult;
        }

        public int GeneratePDF_Edit(DataTable dtResult, string templatePath, string TempFilePath, string FTPFilePath
            , string fileName)
        {
            string tempPath = TempFilePath + fileName;
            int iResult = 0;
            try
            {
                if (impersonateValidUser(UserName, Password, Domain))
                {
                    bool exists = System.IO.File.Exists(templatePath);

                    if (exists)
                    {
                        using (PdfReader pdfReader = new PdfReader(templatePath))
                        {
                            using (PdfStamper pdfStamper = new PdfStamper(pdfReader, new FileStream(tempPath, FileMode.Create)))
                            {
                                AcroFields pdfFormFields = pdfStamper.AcroFields;

                                BindPDF_Edit(pdfFormFields, dtResult);

                                //pdfStamper.SetFullCompression();
                                pdfStamper.Writer.CompressionLevel = PdfStream.BEST_COMPRESSION;
                                pdfStamper.FormFlattening = true;

                                pdfStamper.Close();
                                pdfReader.Close();
                                iResult = 1;
                                //Transfer Created file to FTP folder

                                iResult = TransferFileToFTP(tempPath, FTPFilePath, fileName);

                                //Delete temporary created file
                                if (iResult == 1)
                                {
                                    File.Delete(tempPath);
                                }
                            }
                        }
                    }
                }//Impersonation valid
            }
            catch (Exception oEX)
            {
                iResult = 0;
                throw oEX;
            }
            return iResult;
        }

        public void BindPDF_Edit(AcroFields pdfFormFields, DataTable dtResult)
        {
            try
            {
                for (int i = 0; i < dtResult.Rows.Count; i++)
                {
                    if (Convert.ToString(dtResult.Rows[i]["parametername"]) != "DOCPATH")
                    {
                        pdfFormFields.SetField(Convert.ToString(dtResult.Rows[i]["parametername"]), Convert.ToString(dtResult.Rows[i]["parametervalue"]));
                    }
                    else if (Convert.ToString(dtResult.Rows[i]["parametername"]) == "DOCPATH")
                    {
                        PushbuttonField ad = pdfFormFields.GetNewPushbuttonFromField("DOCPATH");
                        ad.Layout = PushbuttonField.LAYOUT_ICON_ONLY;
                        ad.ProportionalIcon = true;
                        ad.Image = Image.GetInstance(Convert.ToString(dtResult.Rows[i]["parametervalue"]));
                        pdfFormFields.ReplacePushbuttonField("DOCPATH", ad.Field);
                    }
                    //else if (Convert.ToInt32(dtResult.Rows[i]["ischeckbox"]) == 1)
                    //{
                    //    pdfFormFields.SetField(Convert.ToString(dtResult.Rows[i]["parametername"]), Convert.ToString(dtResult.Rows[i]["parametervalue"]), true);
                    //}
                }
            }
            catch (Exception oEX)
            {
                throw oEX;
            }
        }

        private string DeleteFTPFile(string fileName,string FTPFilePath, string UserName,string Password)
        {
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(FTPFilePath + fileName);
           //request.Proxy = new WebProxy();
            request.Method = WebRequestMethods.Ftp.DeleteFile;
            request.Credentials = new NetworkCredential(UserName, Password);

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            {
                return response.StatusDescription;
            }
        }

        private bool CheckIfFileExistsOnServer(string fileName, string FTPFilePath, string UserName, string Password)
        {
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(FTPFilePath + fileName);
           // request.Proxy = new WebProxy();
            request.Credentials = new NetworkCredential(UserName, Password);
            request.Method = WebRequestMethods.Ftp.GetFileSize;

            try
            {
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                return true;
            }
            catch (WebException ex)
            {
                FtpWebResponse response = (FtpWebResponse)ex.Response;
                if (response.StatusCode == FtpStatusCode.ActionNotTakenFileUnavailable)
                    return false;
            }
            return false;
        }

        public int TransferFileToFTP(string TempFilePath, string FTPFilePath, string fileName)
        {
            int iResult = 0;
            try
            {
                //bool exists = System.IO.File.Exists(TempFilePath);
                //if (exists)
                //{ }

                if (impersonateValidUser(UserName, Password, Domain))
                {
                    ///////////////////////////////
                    int bufferSize = 2048;
                    //Delete If Exist
                    if (CheckIfFileExistsOnServer(fileName, FTPFilePath, UserName, Password))
                    {
                        DeleteFTPFile(fileName, FTPFilePath, UserName, Password);
                    }
                    //if (FTPFilePath != "")
                    //{
                    //    createDirectory(FTPFilePath, UserName, Password);
                    //}
                    FtpWebRequest ftpRequest = null;
                    /* Create an FTP Request */
                    ftpRequest = (FtpWebRequest)FtpWebRequest.Create(FTPFilePath + fileName);
                    //ftpRequest.Proxy = new WebProxy();
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(UserName, Password);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
                    /* Establish Return Communication with the FTP Server */
                    Stream ftpStream = ftpRequest.GetRequestStream();
                    /* Open a File Stream to Read the File for Upload */
                    if (impersonateValidUser(UserName, Password, Domain))
                    {
                        FileStream localFileStream = new FileStream(TempFilePath, FileMode.Open);
                        /* Buffer for the Downloaded Data */
                        byte[] byteBuffer = new byte[bufferSize];
                        int bytesSent = localFileStream.Read(byteBuffer, 0, bufferSize);
                        /* Upload the File by Sending the Buffered Data Until the Transfer is Complete */
                        try
                        {
                            while (bytesSent != 0)
                            {
                                ftpStream.Write(byteBuffer, 0, bytesSent);
                                bytesSent = localFileStream.Read(byteBuffer, 0, bufferSize);
                            }
                            iResult = 1;
                        }
                        catch (Exception ex)
                        {
                            iResult = 0;
                            throw ex;
                        }
                        finally
                        {
                            /* Resource Cleanup */
                            localFileStream.Close();
                            ftpStream.Close();
                            ftpRequest = null;
                        }
                    }
                    /////////////////////////////////////////////////////////
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return iResult;
        }

        public int Download_Upload_OnFTP(string readFTPFilePath, string createFTPFilePath, string fileName)
        {
            int iResult = 0;
            try
            {                
                if (impersonateValidUser(UserName, Password, Domain))
                {                   
                    int bufferSize = 2048;
                    //Delete If Exist
                    if (CheckIfFileExistsOnServer(fileName, createFTPFilePath, UserName, Password))
                    {
                        DeleteFTPFile(fileName, createFTPFilePath, UserName, Password);
                    }               
                     
                    /* Create an FTP Request */
                    FtpWebRequest ftpRequest = (FtpWebRequest)FtpWebRequest.Create(createFTPFilePath);
                    //ftpRequest.Proxy = new WebProxy();
                    /* Log in to the FTP Server with the User Name and Password Provided */
                    ftpRequest.Credentials = new NetworkCredential(UserName, Password);
                    /* When in doubt, use these options */
                    ftpRequest.UseBinary = true;
                    ftpRequest.UsePassive = true;
                    ftpRequest.KeepAlive = true;
                    /* Specify the Type of FTP Request */
                    ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
                    /* Establish Return Communication with the FTP Server */
                    Stream ftpStream = ftpRequest.GetRequestStream();
                    /* Open a File Stream to Read the File for Upload */
                    if (impersonateValidUser(UserName, Password, Domain))
                    {
                        ////////////////////////fffff///////////////////
                        FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(readFTPFilePath));
                        reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                        reqFTP.UseBinary = true;
                        reqFTP.Credentials = new NetworkCredential(UserName, Password);
                        FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                        Stream ftpStreamRead = response.GetResponseStream();

                        /* Buffer for the Downloaded Data */
                        byte[] byteBuffer = new byte[bufferSize];
                        int bytesSent = ftpStreamRead.Read(byteBuffer, 0, bufferSize);
                        /* Upload the File by Sending the Buffered Data Until the Transfer is Complete */
                        try
                        {
                            while (bytesSent != 0)
                            {
                                ftpStream.Write(byteBuffer, 0, bytesSent);
                                bytesSent = ftpStreamRead.Read(byteBuffer, 0, bufferSize);
                            }
                            iResult = 1;
                        }
                        catch (Exception ex)
                        {
                            iResult = 0;
                            throw ex;
                        }
                        finally
                        {
                            /* Resource Cleanup */
                            ftpStreamRead.Close();
                            reqFTP = null;
                            ftpStream.Close();
                            ftpRequest = null;
                        }
                    }
                    /////////////////////////////////////////////////////////
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return iResult;
        }     

        /* Create a New Directory on the FTP Server */
        private bool createDirectory(string newDirectory, string user, string pass)
        {
            try
            {
                FtpWebRequest ftpRequest = null;
                FtpWebResponse ftpResponse = null;
                /* Create an FTP Request */
                ftpRequest = (FtpWebRequest)WebRequest.Create(newDirectory);
                /* Log in to the FTP Server with the User Name and Password Provided */
                ftpRequest.Credentials = new NetworkCredential(user, pass);
                /* When in doubt, use these options */
                ftpRequest.UseBinary = true;
                ftpRequest.UsePassive = true;
                ftpRequest.KeepAlive = true;
                /* Specify the Type of FTP Request */
                ftpRequest.Method = WebRequestMethods.Ftp.MakeDirectory;
                /* Establish Return Communication with the FTP Server */
                ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                /* Resource Cleanup */
                ftpResponse.Close();
                ftpRequest = null;
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
