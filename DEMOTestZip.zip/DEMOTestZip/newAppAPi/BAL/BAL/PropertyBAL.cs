﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using DAL;

namespace BAL
{
    public class PropertyBAL
    {
        SqlCommand cmd;
        public string GetPropertyMaster()
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_Prospect_RMAssign");
                JString = Utilities.dtToJson(oDT);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetProppertiesOnSearch(string SearchText)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@SearchValue", SearchText);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_PROPERTY_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Property GetPropertyDetails(int PropertyId)
        {
            Property objProperty = null;
            try
            {
                DataSet ds;
                Dropdown dd;
                LeadSource oLeadSource;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@PropertyId", PropertyId);
                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PROPERTY_DETAILS");
                if (ds != null && ds.Tables.Count > 0)
                {
                    objProperty = new Property();
                    objProperty.BudgetList = new List<Dropdown>();
                    objProperty.ConfigList = new List<Dropdown>();
                    objProperty.InventoryTypeList = new List<Dropdown>();
                    objProperty.PurposeList = new List<Dropdown>();
                    objProperty.VisitorTypeList = new List<Dropdown>();
                    objProperty.OccupationList = new List<Dropdown>();
                    objProperty.ReligionList = new List<Dropdown>();
                    objProperty.LeadSourceList = new List<LeadSource>();
                    objProperty.PosessionTimeList = new List<Dropdown>();
                    objProperty.GenderList = new List<Dropdown>();

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objProperty.PurposeList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["ConfigId"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objProperty.ConfigList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["InventoryId"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objProperty.InventoryTypeList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[3].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["BudgetId"]);
                        dd.Value = Convert.ToString(dr["DisplayName"]);
                        objProperty.BudgetList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[4].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["VISITORTYPEID"]);
                        dd.Value = Convert.ToString(dr["VISITORTYPENAME"]);
                        objProperty.VisitorTypeList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[5].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["OccupationId"]);
                        dd.Value = Convert.ToString(dr["Occupation"]);
                        objProperty.OccupationList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[6].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["ReligionName"]);
                        objProperty.ReligionList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[7].Rows)
                    {
                        oLeadSource = new LeadSource();
                        oLeadSource.SourceId = Convert.ToInt32(dr["SourceId"]);
                        oLeadSource.IsInput = Convert.ToBoolean(dr["IsInput"]);
                        oLeadSource.SourceName = Convert.ToString(dr["SourceName"]);
                        oLeadSource.StrSubSourceList = Convert.ToString(dr["SubSourceList"]);
                        objProperty.LeadSourceList.Add(oLeadSource);
                    }
                    foreach (DataRow dr in ds.Tables[8].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objProperty.PosessionTimeList.Add(dd);
                    }
                    foreach (DataRow dr in ds.Tables[9].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objProperty.GenderList.Add(dd);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objProperty;
        }
    }
}
