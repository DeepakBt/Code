﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BAL;
using BAL.Prop;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BAL
{
    public class BusinessBudgetBAL
    {
        SqlCommand cmd;
        public List<Dropdown> BusinessBudgetDDL(BusinessBudgetFilters objParam)
        {
            try
            {
                List<Dropdown> objListDropdown = new List<Dropdown>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@CategoryID",objParam.CategoryId);
                cmd.Parameters.AddWithValue("@SubCategory", objParam.SubCategoryId);
                cmd.Parameters.AddWithValue("@SubCategory2", objParam.SubCategoryId2);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Get_Budget_Category_SubCategory_Mst");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            Dropdown objDropdown = new Dropdown();
                            objDropdown.Id = Convert.ToInt32(dr["Id"] == DBNull.Value ? 0 : dr["Id"]);
                            objDropdown.Value = Convert.ToString(dr["Value"]);
                            objListDropdown.Add(objDropdown);
                        }
                    }
                }
                return objListDropdown;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetBusinessBudgetDetails(int PropertyId,int EmpId,int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@propertyId",PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BusinessBudget_Value");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet SaveBusinessBudgetDetails(string XMLData,int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BusinessBudget_Value");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet UpdateBusinessBudgetDetails(string XMLData, int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BusinessBudget_Value");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet DeleteBusinessBudgetDetails(string XMLData, int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BusinessBudget_Value");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetSpentBusinessBudget(int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BUSINESSBUDGET_SPEND_VALUE");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetSpentBusinessBudgetDetails(int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 5);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BUSINESSBUDGET_SPEND_VALUE");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet SaveSpentBusinessBudgetDetails(string XMLData, int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BUSINESSBUDGET_SPEND_VALUE");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet UpdateSpentBusinessBudgetDetails(string XMLData, int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BUSINESSBUDGET_SPEND_VALUE");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet DeleteSpentBusinessBudgetDetails(string XMLData, int PropertyId, int EmpId, int RoleId)
        {
            try
            {
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@propertyId", PropertyId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_BUSINESSBUDGET_SPEND_VALUE");
                return dsResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
