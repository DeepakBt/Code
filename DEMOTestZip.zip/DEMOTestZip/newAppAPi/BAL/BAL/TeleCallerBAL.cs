﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;

namespace BAL
{
    public class TeleCallerBAL
    {
        SqlCommand cmd;
        public string SaveUpdateTeleCaller(string XMLData, int EmpId,int RoleId,int Flag,int TeleCallerId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@TeleCallerId", TeleCallerId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_TELECALLER_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public TeleCaller GetTeleCaller(int TeleCallerId,int Flag)
        {
            try
            {
                TeleCaller objTeleCaller = new TeleCaller();
                objTeleCaller.ListOfLanguage = new List<Language>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@TeleCallerId", TeleCallerId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_UPDATE_TELECALLER_DETAILS");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objTeleCaller.TeleCallerId = Convert.ToInt32(ds.Tables[0].Rows[0]["TeleCallerId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["TeleCallerId"]);
                        objTeleCaller.TeleCallerName = Convert.ToString(ds.Tables[0].Rows[0]["TeleCallerName"]);
                        objTeleCaller.MobileNo = Convert.ToString(ds.Tables[0].Rows[0]["MobileNo"]);
                        objTeleCaller.VendorId = Convert.ToInt32(ds.Tables[0].Rows[0]["VendorId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["VendorId"]);
                        objTeleCaller.TeleCallerCode = Convert.ToString(ds.Tables[0].Rows[0]["TeleCallerCode"]);
                        objTeleCaller.VendorName = Convert.ToString(ds.Tables[0].Rows[0]["VendorName"]);
                        objTeleCaller.WhatsAppNo = Convert.ToString(ds.Tables[0].Rows[0]["WhatsAppNo"]);
                        objTeleCaller.YearOfExperience = Convert.ToDecimal(ds.Tables[0].Rows[0]["YearOfExperience"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["YearOfExperience"]);
                        objTeleCaller.Email = Convert.ToString(ds.Tables[0].Rows[0]["Email"]);
                        objTeleCaller.Address = Convert.ToString(ds.Tables[0].Rows[0]["Address"]);
                        objTeleCaller.MotherTongueId = Convert.ToInt32(ds.Tables[0].Rows[0]["MotherTongueId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["MotherTongueId"]);
                        objTeleCaller.MotherTongue = Convert.ToString(ds.Tables[0].Rows[0]["MotherTongue"]);
                        objTeleCaller.DateOfJoining = Convert.ToString(ds.Tables[0].Rows[0]["DOJ"]);
                        objTeleCaller.DOJ = Convert.ToDateTime(ds.Tables[0].Rows[0]["DateOfJoining"]==DBNull.Value?default(DateTime): ds.Tables[0].Rows[0]["DateOfJoining"]);
                        objTeleCaller.PANCARD = Convert.ToString(ds.Tables[0].Rows[0]["PANCARD"]);
                        objTeleCaller.AADHARNO = Convert.ToString(ds.Tables[0].Rows[0]["AADHARNO"]);
                        objTeleCaller.Cost = Convert.ToDecimal(ds.Tables[0].Rows[0]["Cost"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["Cost"]);
                        objTeleCaller.Comments = Convert.ToString(ds.Tables[0].Rows[0]["Comments"]);
                        objTeleCaller.IsActive = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsActive"]);
                        objTeleCaller.UserTypeId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserTypeId"]);
                        objTeleCaller.Location = Convert.ToString(ds.Tables[0].Rows[0]["Location"]);
                        objTeleCaller.LocationId = Convert.ToInt32(ds.Tables[0].Rows[0]["LocationId"]==DBNull.Value?0:ds.Tables[0].Rows[0]["LocationId"]);
                        objTeleCaller.PropertyMappedFlag = Convert.ToBoolean(ds.Tables[0].Rows[0]["PropertyMappedFlag"]==DBNull.Value?false: ds.Tables[0].Rows[0]["PropertyMappedFlag"]);
                    }
                    if(ds.Tables[1].Rows.Count>0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            Language objLanguage = new Language();
                            objLanguage.LanguageId = Convert.ToInt32(dr["LanguageId"] == DBNull.Value ? 0 : dr["LanguageId"]);
                            objLanguage.LanguageName = Convert.ToString(dr["LanguageName"]);
                            objTeleCaller.ListOfLanguage.Add(objLanguage);
                        }
                    }
                }
                return objTeleCaller;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string SaveUpdateTeleCallerVendor(string XMLData,int EmpId,int Flag,int VendorId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@VendorId", VendorId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_TELECALLER_VENDOR_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {   
                throw ex;
            }
        }
        public TeleCallerVendor GetTeleCallerVendor(int VendorId,int Flag)
        {
            try
            {
                TeleCallerVendor objTCVendor = new TeleCallerVendor();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@VendorId", VendorId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_TELECALLER_VENDOR_DETAILS");
                if(dt.Rows.Count>0)
                {
                    objTCVendor.VendorId = Convert.ToInt32(dt.Rows[0]["VendorId"]==DBNull.Value?0: dt.Rows[0]["VendorId"]);
                    objTCVendor.VendorCode = Convert.ToString(dt.Rows[0]["VendorCode"]);
                    objTCVendor.Name = Convert.ToString(dt.Rows[0]["Name"]);
                    objTCVendor.Remark = Convert.ToString(dt.Rows[0]["Remark"]);
                    objTCVendor.IsActive = Convert.ToBoolean(dt.Rows[0]["IsActive"]);
                    objTCVendor.MobileNo = Convert.ToString(dt.Rows[0]["MobileNo"]);
                    objTCVendor.EmailId = Convert.ToString(dt.Rows[0]["EmailId"]);
                    objTCVendor.Location = Convert.ToString(dt.Rows[0]["Location"]);
                    objTCVendor.LocationId = Convert.ToInt32(dt.Rows[0]["LocationId"]);
                }
                return objTCVendor;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public TeleCallerDashBoard GetTCDashBoard(int Flag,int EmpId,int RoleId,int FTD)
        {
            try
            {
                TeleCallerDashBoard objTCDB = new TeleCallerDashBoard();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId",RoleId);
                cmd.Parameters.AddWithValue("@FTD",FTD);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_TELECALLER_DASHBOARD");
                if(dt.Rows.Count>0)
                {
                    objTCDB.TotalLead = Convert.ToInt32(dt.Rows[0]["TotalLead"] == DBNull.Value ? 0 : dt.Rows[0]["TotalLead"]);
                    objTCDB.TotalFollowUp = Convert.ToInt32(dt.Rows[0]["TotalFollowUp"] == DBNull.Value ? 0 : dt.Rows[0]["TotalFollowUp"]);
                    objTCDB.TotalSiteVisit = Convert.ToInt32(dt.Rows[0]["TotalSiteVisit"]==DBNull.Value?0: dt.Rows[0]["TotalSiteVisit"]);
                    objTCDB.TotalRejected = Convert.ToInt32(dt.Rows[0]["TotalRejected"] ==DBNull.Value?0: dt.Rows[0]["TotalRejected"]);
                    objTCDB.isLoginToday = Convert.ToBoolean(dt.Rows[0]["IsLoginToday"]==DBNull.Value?false: dt.Rows[0]["IsLoginToday"]);
                }
                return objTCDB;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<TeleCallerSVFollowUp> GetTCLeadDetails(int Flag, int EmpId, int RoleId, int FTD)
        {
            try
            {
                List<TeleCallerSVFollowUp> LstobjFollowUp = new List<TeleCallerSVFollowUp>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@FTD", FTD);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_TELECALLER_DASHBOARD");
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        TeleCallerSVFollowUp objTCF = new TeleCallerSVFollowUp();
                        objTCF.LeadId = Convert.ToInt32(dr["LeadId"] == DBNull.Value ? 0 : dr["LeadId"]);
                        objTCF.BrochureFlag = Convert.ToBoolean(dr["BrochureFlag"]);
                        objTCF.CampaignId = Convert.ToBoolean(dr["CampaignId"]);
                        objTCF.Comments = Convert.ToString(dr["Comments"]);
                        objTCF.CPName = Convert.ToString(dr["CPName"]);
                        objTCF.CPID = Convert.ToInt32(dr["CPID"]==DBNull.Value?0: dr["CPID"]);
                        objTCF.Email = Convert.ToString(dr["Email"]);
                        objTCF.IsCPRegister = Convert.ToBoolean(dr["IsRegisteredCPFlag"]);
                        objTCF.LeadName = Convert.ToString(dr["LeadName"]);
                        objTCF.Mobile = Convert.ToString(dr["Mobile"]);
                        objTCF.PropertyId = Convert.ToInt32(dr["PropertyId"]);
                        objTCF.Date = Convert.ToString(dr["Date"]);
                        objTCF.SiteVisitFlag = Convert.ToBoolean(dr["SiteVisitFlag"]);
                        objTCF.LeadStatusId = Convert.ToInt32(dr["LeadStatus"]);
                        objTCF.WhatsAppNo = Convert.ToString(dr["WhatsAppNo"]);
                        objTCF.WhatsAppBrochureFlag = Convert.ToBoolean(dr["WhatsAppBrochureFlag"]);
                        LstobjFollowUp.Add(objTCF);
                    }
                }
                return LstobjFollowUp;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public string UpdateTelecallerLeaves(string XMLData, int EmpId,int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@XmlData", XMLData);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_TELECALLER_LEAVES");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
