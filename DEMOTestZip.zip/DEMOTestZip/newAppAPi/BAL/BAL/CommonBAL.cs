﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;
using System.Xml.Linq;
using System.Configuration;
namespace BAL
{
    public class CommonBAL
    {
        SqlCommand cmd;
        public PropertyDDL GetPropertyMasterDDL(Filters360degree objFilter)
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                PropertyDDL objPropertyDDL = new PropertyDDL();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objFilter.Flag);
                cmd.Parameters.AddWithValue("@CPID", objFilter.CPID);
                cmd.Parameters.AddWithValue("@DeveloperId", objFilter.DeveloperId);
                cmd.Parameters.AddWithValue("@IsComplete", objFilter.IsCompleted);
                cmd.Parameters.AddWithValue("@PropertyId", objFilter.PropertyId);
                cmd.Parameters.AddWithValue("@WingId", objFilter.WingId);
                cmd.Parameters.AddWithValue("@EmpId", objFilter.EmpId);
                cmd.Parameters.AddWithValue("@RoleId", objFilter.RoleId);
                cmd.Parameters.AddWithValue("@FloorNo", objFilter.FloorNo);
                cmd.Parameters.AddWithValue("@ApartmentNo", objFilter.ApartmentNo);
                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PROPERTY_DDL");
                if (objFilter.Flag == 1)//For CP Property Mapped
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._PropertyDLL = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._PropertyDLL.Add(dd);
                            }
                        }
                        if (ds.Tables[1].Rows.Count > 0)
                        {
                            objPropertyDDL._IsCompleteDLL = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[1].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._IsCompleteDLL.Add(dd);
                            }
                        }
                    }
                }
                else if (objFilter.Flag == 2) //For Developer Property
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._PropertyDLL = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._PropertyDLL.Add(dd);
                            }
                        }
                        if (ds.Tables[1].Rows.Count > 0)
                        {
                            objPropertyDDL._Wing = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[1].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._Wing.Add(dd);
                            }
                        }
                    }
                }
                else if (objFilter.Flag == 4 && objFilter.RoleId != 12) //Load all Property
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._PropertyDLL = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._PropertyDLL.Add(dd);
                            }
                        }
                    }
                }
                else if (objFilter.Flag == 4 && objFilter.RoleId == 12) //Load All Property with Selected Mapped Property for TeleCaller
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._PropertyDLL = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                dd.SelectedFlag = Convert.ToBoolean(dr["SelectedFlag"]);
                                objPropertyDDL._PropertyDLL.Add(dd);
                            }
                        }
                    }
                }
                else if (objFilter.Flag == 5 || objFilter.Flag == 9) //Load Wings Based on Property
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._Wing = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._Wing.Add(dd);
                            }
                        }
                    }
                }
                else if (objFilter.Flag == 6 || objFilter.Flag == 10) //Load FloorNo based on Property and Wing
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._FloorNo = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._FloorNo.Add(dd);
                            }
                        }
                    }
                }
                else if (objFilter.Flag == 7 || objFilter.Flag == 8 || objFilter.Flag == 12) //Load FlatNo , CarpetArea
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._FlatNo = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._FlatNo.Add(dd);
                            }
                        }
                        if (ds.Tables.Count > 1)
                        {
                            if (ds.Tables[1].Rows.Count > 0)
                            {
                                objPropertyDDL._CarpetArea = new List<Dropdown>();
                                foreach (DataRow dr in ds.Tables[1].Rows)
                                {
                                    dd = new Dropdown();
                                    dd.Id = Convert.ToInt32(dr["Id"]);
                                    dd.Value = Convert.ToString(dr["Value"]);
                                    objPropertyDDL._CarpetArea.Add(dd);
                                }
                            }
                        }
                    }
                }
                else if(objFilter.Flag >= 13)
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            objPropertyDDL._PropertyDLL = new List<Dropdown>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                dd = new Dropdown();
                                dd.Id = Convert.ToInt32(dr["Id"]);
                                dd.Value = Convert.ToString(dr["Value"]);
                                objPropertyDDL._PropertyDLL.Add(dd);
                            }
                        }
                    }
                }

                return objPropertyDDL;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateIsAcceptUserFlag(long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_UPDATE_ISACCEPT_USER_FLAG");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Dropdown> GetFYDDL(Filters360degree objFilter)
        {
            try
            {
                List<Dropdown> objListFy = new List<Dropdown>();
                DataSet ds;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objFilter.Flag);
                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CURRENT_PREVIOUS_FINANCIAL_YEAR");
                if (objFilter.Flag == 1)
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            Dropdown objDropdown = new Dropdown();
                            objDropdown.Id = Convert.ToInt32(dr["Id"]);
                            objDropdown.Value = Convert.ToString(dr["Value"]);
                            objListFy.Add(objDropdown);
                        }
                    }
                }
                return objListFy;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertSubscriber(string SubscriberXML)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", SubscriberXML);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_SUBSCRIBER");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertGeneralLeadMeeting(string LeadMeetingXML)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", LeadMeetingXML);
                cmd.Parameters.AddWithValue("@Flag", 3);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_LEAD_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertUnregisterCPDeveloper(string UnregisterXML, int Flag)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UnregisterXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UNREGISTER_CP_DEVELOPER");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertIntoTest(TestInsert objIns)
        {
            string JString = "";
            cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Data", objIns.Data);
            cmd.Parameters.AddWithValue("@Flag", objIns.Flag);
            DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_TestRealTime");
            JString = Utilities.dtToJson(dt);
            return JString;
        }

        public string InsertMOM(string MOMXML, long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@XMLData", MOMXML);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_MOM_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertBankDetails(string BankDetailsXML, int Flag, long UserId)
        {
            try
            {
                cmd = new SqlCommand();
                string JString = string.Empty;
                cmd.Parameters.AddWithValue("@XMLData", BankDetailsXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@UserId", UserId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_BANK_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string InsertContactUs(string ContactUsXML)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", ContactUsXML);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CONTACT_US");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<KnowledgeCenterArticle> GetArticle(Filters360degree objFilter)
        {
            try
            {
                List<KnowledgeCenterArticle> lstKnowledgeCenterArticle = new List<KnowledgeCenterArticle>();
                cmd = new SqlCommand();
                DataSet dsResult;
                string JString = string.Empty;
                cmd.Parameters.AddWithValue("@Flag", objFilter.Flag);
                cmd.Parameters.AddWithValue("@ArticleId", objFilter.ArticleID);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_KNOWLEDGE_CENTER_ARTICLE");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            KnowledgeCenterArticle objKnowledgeCenterArticle = new KnowledgeCenterArticle();
                            objKnowledgeCenterArticle.ArticleID = Convert.ToInt64(dr["ArticleID"] == DBNull.Value ? 0 : dr["ArticleID"]);
                            objKnowledgeCenterArticle.ArticleDate = Convert.ToString(dr["ArticleDate"]);
                            objKnowledgeCenterArticle.Author = Convert.ToString(dr["Author"]);
                            objKnowledgeCenterArticle.HeaderText = Convert.ToString(dr["HeaderText"]);
                            objKnowledgeCenterArticle.ImagePath = Convert.ToString(dr["ImagePath"]);
                            objKnowledgeCenterArticle.Content = Convert.ToString(dr["Content"]);
                            objKnowledgeCenterArticle.VideoPath = Convert.ToString(dr["VideoPath"]);
                            lstKnowledgeCenterArticle.Add(objKnowledgeCenterArticle);
                        }
                    }
                }
                return lstKnowledgeCenterArticle;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertUnSubscribe(string EmailId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmailId", EmailId);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UNSUBSCRIBE");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DownloadURL GetDownloadURL(Filters360degree objFilter)
        {
            try
            {
                DownloadURL objDownloadURL = new DownloadURL();
                cmd = new SqlCommand();
                DataSet dsResult;
                string JString = string.Empty;
                cmd.Parameters.AddWithValue("@Flag", objFilter.Flag);
                cmd.Parameters.AddWithValue("@DocName", objFilter.DocName);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DOWNLOAD_URL");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        objDownloadURL.RETRIVALPATH = Convert.ToString(dsResult.Tables[0].Rows[0]["RETRIVALPATH"]);
                    }
                }
                return objDownloadURL;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string EditUserCPMapping(string UserCPMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserCPMapping);
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_CP_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetMasterValues(int Flag)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GetMaster");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveUserCPMapping(string UserCPMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserCPMapping);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_CP_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveRMCPMOM(string RMCPMOM, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", RMCPMOM);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_RM_CP_MOM_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Dropdown> RequestedDDL(Filters360degree objDashBoard)
        {
            try
            {
                List<Dropdown> objListDropdown = new List<Dropdown>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", objDashBoard.EmpId);
                cmd.Parameters.AddWithValue("@RoleId", objDashBoard.RoleId);
                cmd.Parameters.AddWithValue("@StatusId", objDashBoard.StatusId);
                cmd.Parameters.AddWithValue("@TargetTypeId", objDashBoard.TargetTypeId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetMaster");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            Dropdown objDropdown = new Dropdown();
                            objDropdown.Id = Convert.ToInt32(dr["Id"] == DBNull.Value ? 0 : dr["Id"]);
                            objDropdown.Value = Convert.ToString(dr["Value"]);
                            if ((objDashBoard.RoleId == 12 && objDashBoard.Flag == 5) || objDashBoard.Flag == 27)
                            {
                                objDropdown.SelectedFlag = Convert.ToBoolean(dr["SelectedFlag"]);
                            }
                            objListDropdown.Add(objDropdown);
                        }
                    }
                }
                return objListDropdown;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserCPDropDown> RequestedUserCPDDL(Filters360degree objDashBoard)
        {
            try
            {
                List<UserCPDropDown> objListDropdown = new List<UserCPDropDown>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", objDashBoard.EmpId);
                cmd.Parameters.AddWithValue("@RoleId", objDashBoard.RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetMaster");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            UserCPDropDown objDropdown = new UserCPDropDown();
                            objDropdown.Id = Convert.ToInt32(dr["Id"] == DBNull.Value ? 0 : dr["Id"]);
                            objDropdown.Value = Convert.ToString(dr["Value"]);
                            objDropdown.IsCPRegister = Convert.ToBoolean(dr["IsCPRegister"]);
                            objListDropdown.Add(objDropdown);
                        }
                    }
                }
                return objListDropdown;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<CPSupportDDL> RequestedCPDDL(Filters360degree objDashBoard)
        {
            try
            {
                List<CPSupportDDL> objListDropdown = new List<CPSupportDDL>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", objDashBoard.EmpId);
                cmd.Parameters.AddWithValue("@RoleId", objDashBoard.RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetMaster");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            CPSupportDDL objDropdown = new CPSupportDDL();
                            objDropdown.Id = Convert.ToInt32(dr["Id"] == DBNull.Value ? 0 : dr["Id"]);
                            objDropdown.Value = Convert.ToString(dr["Value"]);
                            objDropdown.Unit = Convert.ToInt32(dr["Unit"] == DBNull.Value ? 0 : dr["Unit"]);
                            objDropdown.Cost = Convert.ToDecimal(dr["Cost"] == DBNull.Value ? 0 : dr["Cost"]);
                            objListDropdown.Add(objDropdown);
                        }
                    }
                }
                return objListDropdown;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UnregisterCPDeveloper> GetAllUnCP(UnregisterCPDeveloper ObjUnregisterCPDeveloper, int EmpId, int RoleId)
        {
            try
            {
                List<UnregisterCPDeveloper> objListUnCP = new List<UnregisterCPDeveloper>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", ObjUnregisterCPDeveloper.Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_VALIDATE_UNREGISTERCP");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            UnregisterCPDeveloper objUnregisterCP = new UnregisterCPDeveloper();
                            objUnregisterCP.RegistrationId = Convert.ToInt32(dr["REGISTEREDID"] == DBNull.Value ? 0 : dr["REGISTEREDID"]);
                            objUnregisterCP.Name = Convert.ToString(dr["CPNAME"]);
                            objUnregisterCP.Mobile = Convert.ToString(dr["CPMOBILE"]);
                            objUnregisterCP.Email = Convert.ToString(dr["EMAIL"]);
                            objUnregisterCP.Location = Convert.ToString(dr["LOCATION"]);
                            objUnregisterCP.City = Convert.ToString(dr["CITY"]);
                            objUnregisterCP.ReraId = Convert.ToString(dr["RERAID"]);
                            objUnregisterCP.CPType = Convert.ToString(dr["CPTypeName"]);
                            objUnregisterCP.CPTypeId = Convert.ToInt32(dr["CPType"] == DBNull.Value ? 0 : dr["CPType"]);
                            objUnregisterCP.NatureOfBusinessId = Convert.ToString(dr["NatureOfBusiness"]);
                            objUnregisterCP.NatureOfBusiness = Convert.ToString(dr["NatureOfBusinessName"]);
                            objUnregisterCP.UnRegFlag = Convert.ToInt32(dr["UnRegFlag"]);
                            objUnregisterCP.WalkingRating = Convert.ToInt32(dr["WalkingRating"] == DBNull.Value ? 0 : dr["WalkingRating"]);
                            objUnregisterCP.CPRating = Convert.ToInt32(dr["CPRating"] == DBNull.Value ? 0 : dr["CPRating"]);
                            objUnregisterCP.IsEmailAvailable = Convert.ToBoolean(dr["IsEmailAvailable"] == DBNull.Value ? false : dr["IsEmailAvailable"]);
                            objUnregisterCP.IsSMSAvailable = Convert.ToBoolean(dr["IsSMSAvailable"] == DBNull.Value ? false : dr["IsSMSAvailable"]);
                            objUnregisterCP.EmailCount = Convert.ToInt32(dr["EmailCount"] == DBNull.Value ? 0 : dr["EmailCount"]);
                            objUnregisterCP.SMSCount = Convert.ToInt32(dr["SMSCount"] == DBNull.Value ? 0 : dr["SMSCount"]);
                            objUnregisterCP.PropertyId = Convert.ToInt32(dr["PropertyId"] == DBNull.Value ? 0 : dr["PropertyId"]);
                            objUnregisterCP.PropertyName = Convert.ToString(dr["PropertyName"]);
                            objUnregisterCP.SuburbLocationId = Convert.ToInt32(dr["SuburbLocationId"] == DBNull.Value ? 0 : dr["SuburbLocationId"]);
                            objUnregisterCP.SuburbLocation = Convert.ToString(dr["SuburbLocation"]);
                            objUnregisterCP.RMId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["RMId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["RMId"]);
                            objUnregisterCP.RMName = Convert.ToString(dsResult.Tables[0].Rows[0]["RMName"]);
                            objUnregisterCP.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                            objUnregisterCP.CompanyName = Convert.ToString(dr["CompanyName"]);
                            objUnregisterCP.Comments = Convert.ToString(dr["Comments"]);
                            objUnregisterCP.CategoryId = Convert.ToInt32(dr["CategoryId"] == DBNull.Value ? 0 : dr["CategoryId"]);
                            objUnregisterCP.CategoryName = Convert.ToString(dr["CategoryName"]);
                            objUnregisterCP.Type2Id = Convert.ToInt32(dr["Type2Id"] == DBNull.Value ? 0 : dr["Type2Id"]);
                            objUnregisterCP.Type2Name = Convert.ToString(dr["Type2Name"]);
                            objListUnCP.Add(objUnregisterCP);
                        }
                    }
                }
                return objListUnCP;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UnregisterCPDeveloper GetSelectUnCP(UnregisterCPDeveloper ObjUnregisterCPDeveloper, int EmpId, int RoleId)
        {
            try
            {
                UnregisterCPDeveloper objUnregisterCP = new UnregisterCPDeveloper();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", ObjUnregisterCPDeveloper.Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@UNCPID", ObjUnregisterCPDeveloper.RegistrationId);
                cmd.Parameters.AddWithValue("@UnRegFlag", ObjUnregisterCPDeveloper.UnRegFlag);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@IsRegisterCP", ObjUnregisterCPDeveloper.IsRegisterCP);

                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_VALIDATE_UNREGISTERCP");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        objUnregisterCP.IsRegisterCP = Convert.ToBoolean(dsResult.Tables[0].Rows[0]["IsRegisterCP"]);

                        objUnregisterCP.RegistrationId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["REGISTEREDID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["REGISTEREDID"]);
                        objUnregisterCP.Name = Convert.ToString(dsResult.Tables[0].Rows[0]["CPNAME"]);
                        objUnregisterCP.Mobile = Convert.ToString(dsResult.Tables[0].Rows[0]["CPMOBILE"]);
                        objUnregisterCP.Email = Convert.ToString(dsResult.Tables[0].Rows[0]["EMAIL"]);
                        objUnregisterCP.ReraId = Convert.ToString(dsResult.Tables[0].Rows[0]["RERAID"]);
                        objUnregisterCP.CPType = Convert.ToString(dsResult.Tables[0].Rows[0]["CPTypeName"]);
                        objUnregisterCP.CPTypeId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["CPType"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CPType"]);
                        objUnregisterCP.WalkingRating = Convert.ToInt32(dsResult.Tables[0].Rows[0]["WalkingRating"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["WalkingRating"]);
                        objUnregisterCP.CPRating = Convert.ToInt32(dsResult.Tables[0].Rows[0]["CPRating"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CPRating"]);
                        objUnregisterCP.RMName = Convert.ToString(dsResult.Tables[0].Rows[0]["RMName"]);
                        objUnregisterCP.CategoryId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["CategoryId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CategoryId"]);
                        objUnregisterCP.Type2Id = Convert.ToInt32(dsResult.Tables[0].Rows[0]["Type2Id"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["Type2Id"]);
                        objUnregisterCP.CategoryName = Convert.ToString(dsResult.Tables[0].Rows[0]["CategoryName"]);
                        objUnregisterCP.Type2Name = Convert.ToString(dsResult.Tables[0].Rows[0]["Type2Name"]);

                        if (!objUnregisterCP.IsRegisterCP)
                        {
                            objUnregisterCP.Location = Convert.ToString(dsResult.Tables[0].Rows[0]["LOCATION"]);
                            objUnregisterCP.City = Convert.ToString(dsResult.Tables[0].Rows[0]["CITY"]);
                            objUnregisterCP.NatureOfBusinessId = Convert.ToString(dsResult.Tables[0].Rows[0]["NatureOfBusiness"]);
                            objUnregisterCP.NatureOfBusiness = Convert.ToString(dsResult.Tables[0].Rows[0]["NatureOfBusinessName"]);
                            objUnregisterCP.UnRegFlag = Convert.ToInt32(dsResult.Tables[0].Rows[0]["UnRegFlag"]);
                            objUnregisterCP.IsEmailAvailable = Convert.ToBoolean(dsResult.Tables[0].Rows[0]["IsEmailAvailable"] == DBNull.Value ? false : dsResult.Tables[0].Rows[0]["IsEmailAvailable"]);
                            objUnregisterCP.IsSMSAvailable = Convert.ToBoolean(dsResult.Tables[0].Rows[0]["IsSMSAvailable"] == DBNull.Value ? false : dsResult.Tables[0].Rows[0]["IsSMSAvailable"]);
                            objUnregisterCP.EmailCount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["EmailCount"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["EmailCount"]);
                            objUnregisterCP.SMSCount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["SMSCount"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["SMSCount"]);
                            objUnregisterCP.PropertyId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["PropertyId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["PropertyId"]);
                            objUnregisterCP.PropertyName = Convert.ToString(dsResult.Tables[0].Rows[0]["PropertyName"]);
                            objUnregisterCP.SuburbLocationId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["SuburbLocationId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["SuburbLocationId"]);
                            objUnregisterCP.SuburbLocation = Convert.ToString(dsResult.Tables[0].Rows[0]["SuburbLocation"]);
                            objUnregisterCP.RMId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["RMId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["RMId"]);
                            objUnregisterCP.Comments = Convert.ToString(dsResult.Tables[0].Rows[0]["Comments"]);
                            objUnregisterCP.CompanyName = Convert.ToString(dsResult.Tables[0].Rows[0]["CompanyName"]);
                            objUnregisterCP.CategoryId = Convert.ToInt32(dsResult.Tables[0].Rows[0]["CategoryId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CategoryId"]);
                            objUnregisterCP.Type2Id = Convert.ToInt32(dsResult.Tables[0].Rows[0]["Type2Id"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["Type2Id"]);
                            objUnregisterCP.CategoryName = Convert.ToString(dsResult.Tables[0].Rows[0]["CategoryName"]);
                            objUnregisterCP.Type2Name = Convert.ToString(dsResult.Tables[0].Rows[0]["Type2Name"]);
                        }
                    }
                }
                return objUnregisterCP;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateUNCP(string UnCPXML, int EmpId, int UNCPID, int UnRegFlag, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UnCPXML);
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@UNCPID", UNCPID);
                cmd.Parameters.AddWithValue("@UnRegFlag", UnRegFlag);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);

                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_VALIDATE_UNREGISTERCP");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserCPMapping GetUserCPMapping(string objUserXML, int EmpId, int RoleId)
        {
            try
            {
                UserCPMapping objUCPM = new UserCPMapping();
                objUCPM.User = new Users();
                objUCPM.ListOfRegUnRegCP = new List<RegUnRegCP>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", objUserXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_SAVE_USER_CP_MAPPING");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objUCPM.User.UserId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserId"]);
                        objUCPM.User.UserName = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
                        objUCPM.User.UserTypeId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserTypeId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserTypeId"]);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            RegUnRegCP objRegUnCP = new RegUnRegCP();
                            objRegUnCP.CPID = Convert.ToInt32(dr["CPID"] == DBNull.Value ? 0 : dr["CPID"]);
                            objRegUnCP.CPName = Convert.ToString(dr["CPName"]);
                            objRegUnCP.IsCPRegister = Convert.ToBoolean(dr["IsCPRegister"]);
                            objRegUnCP.SD = Convert.ToString(dr["SD"]);
                            objRegUnCP.ED = Convert.ToString(dr["ED"]);
                            objRegUnCP.StartDate = Convert.ToDateTime(dr["StartDate"] == DBNull.Value ? default(DateTime) : dr["StartDate"]);
                            objRegUnCP.EndDate = Convert.ToDateTime(dr["EndDate"] == DBNull.Value ? default(DateTime) : dr["EndDate"]);
                            objRegUnCP.PropertyId = Convert.ToInt32(dr["PropertyId"] == DBNull.Value ? 0 : dr["PropertyId"]);
                            objRegUnCP.PropertyName = Convert.ToString(dr["PropertyName"]);
                            objRegUnCP.MappingId = Convert.ToInt32(dr["MappingId"]);
                            objRegUnCP.IsDelete = Convert.ToBoolean(dr["IsDelete"]);
                            objUCPM.ListOfRegUnRegCP.Add(objRegUnCP);
                        }
                    }
                }
                return objUCPM;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string SaveUserLanguageMapping(string UserLanguageMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserLanguageMapping);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_LANGUAGE_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserLanguageMapping GetUserLanguageMapping(string objUserXML, int EmpId, int RoleId)
        {
            try
            {
                UserLanguageMapping objUserLanguageMapping = new UserLanguageMapping();
                objUserLanguageMapping.User = new Users();
                objUserLanguageMapping.ListOfLanguage = new List<Language>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", objUserXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_SAVE_USER_LANGUAGE_MAPPING");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objUserLanguageMapping.User.UserId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserId"]);
                        objUserLanguageMapping.User.UserName = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
                        objUserLanguageMapping.User.UserTypeId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserTypeId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserTypeId"]);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            Language objLanguage = new Language();
                            objLanguage.LanguageId = Convert.ToInt32(dr["LanguageId"] == DBNull.Value ? 0 : dr["LanguageId"]);
                            objLanguage.LanguageName = Convert.ToString(dr["LanguageName"]);
                            objUserLanguageMapping.ListOfLanguage.Add(objLanguage);
                        }
                    }
                }
                return objUserLanguageMapping;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveUserPropertyMapping(string UserPropertyMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserPropertyMapping);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_PROPERTY_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserPropertyMapping GetUserPropertyMapping(string objUserXML, int EmpId, int RoleId)
        {
            try
            {
                UserPropertyMapping objUserPropertyMapping = new UserPropertyMapping();
                objUserPropertyMapping.User = new Users();
                objUserPropertyMapping.ListOfProperty = new List<PropertyMapping>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", objUserXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_SAVE_USER_PROPERTY_MAPPING");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objUserPropertyMapping.User.UserId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserId"]);
                        objUserPropertyMapping.User.UserName = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
                        objUserPropertyMapping.User.UserTypeId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserTypeId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserTypeId"]);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            PropertyMapping objPM = new PropertyMapping();
                            objPM.PropertyId = Convert.ToInt32(dr["PropertyId"] == DBNull.Value ? 0 : dr["PropertyId"]);
                            objPM.PropertyName = Convert.ToString(dr["PropertyName"]);
                            objPM.SD = Convert.ToString(dr["SD"]);
                            objPM.ED = Convert.ToString(dr["ED"]);
                            objPM.StartDate = Convert.ToDateTime(dr["StartDate"] == DBNull.Value ? default(DateTime) : dr["StartDate"]);
                            objPM.EndDate = Convert.ToDateTime(dr["EndDate"] == DBNull.Value ? default(DateTime) : dr["EndDate"]);
                            objUserPropertyMapping.ListOfProperty.Add(objPM);
                        }
                    }
                }
                return objUserPropertyMapping;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveUserCampaignMapping(string UserCampaignMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserCampaignMapping);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_CAMPAIGN_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserCampaignMapping GetUserCampaignMapping(string objUserXML, int EmpId, int RoleId)
        {
            try
            {
                UserCampaignMapping objUserCampaignMapping = new UserCampaignMapping();
                objUserCampaignMapping.User = new Users();
                objUserCampaignMapping.ListOfCampaign = new List<CampaignMapping>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", objUserXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_SAVE_USER_CAMPAIGN_MAPPING");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objUserCampaignMapping.User.UserId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserId"]);
                        objUserCampaignMapping.User.UserName = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
                        objUserCampaignMapping.User.UserTypeId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserTypeId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["UserTypeId"]);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            CampaignMapping objCM = new CampaignMapping();
                            objCM.CampaignId = Convert.ToInt32(dr["CampaignId"] == DBNull.Value ? 0 : dr["CampaignId"]);
                            objCM.CampaignName = Convert.ToString(dr["CampaignName"]);
                            objCM.SD = Convert.ToString(dr["SD"]);
                            objCM.ED = Convert.ToString(dr["ED"]);
                            objCM.StartDate = Convert.ToDateTime(dr["StartDate"] == DBNull.Value ? default(DateTime) : dr["StartDate"]);
                            objCM.EndDate = Convert.ToDateTime(dr["EndDate"] == DBNull.Value ? default(DateTime) : dr["EndDate"]);
                            objCM.MappingId = Convert.ToInt32(dr["MappingId"] == DBNull.Value ? 0 : dr["MappingId"]);

                            objUserCampaignMapping.ListOfCampaign.Add(objCM);
                        }
                    }
                }
                return objUserCampaignMapping;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateGeoLocationDetails(string GeoLocationXML, int Flag, int UserId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XmlData", GeoLocationXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", UserId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_GEOLOCATION");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetGeoLocation(string latitude, string longitude)
        {
            try
            {
                string GeoLocationAPI = ConfigurationManager.AppSettings.Get("GeoLocationAPI").ToString();
                string locationName = "";
                string url = string.Format(GeoLocationAPI + "&latlng={0},{1}&sensor=false", latitude, longitude);
                XElement xml = XElement.Load(url);
                if (xml.Element("status").Value == "OK")
                {
                    locationName = string.Format("{0}", xml.Element("result").Element("formatted_address").Value);
                }
                return locationName;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertUnRegCP(string XMLData, int EmpId, int RoleId, int Flag)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UNREGISTER_UNIQUE_CP");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string EditUserCampaignMapping(string UserCampaignMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserCampaignMapping);
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_CAMPAIGN_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetUserAttendanceDetails(AttendanceParam oAttendanceParam)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@UserId", oAttendanceParam.UserId);
                cmd.Parameters.AddWithValue("@UsertypeId", oAttendanceParam.UserTypeId);
                cmd.Parameters.AddWithValue("@Month", oAttendanceParam.Month);
                cmd.Parameters.AddWithValue("@Year", oAttendanceParam.Year);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_RPT_GET_USER_ATTENDANCE_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string DeleteUserCPMapping(string UserCPMapping, int EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserCPMapping);
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_USER_CP_MAPPING");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SendWhatssAppFileMessage(string sendNumber, string message, string readFTPFilePath, string createFTPFilePath, string fileName)
        {
            string result = string.Empty;
            try
            {
                FtpSave oFTP = new FtpSave();

                //string number = "918655192333";
                //string message = "https://cremauatdoc.centrum.co.in/PropertyUpdate/2_Silverscape/Whatsapp/SilverscapeWhatsAppBrochure.pdf";

                //string readFTPFilePath = "ftp://172.20.72.11/CremaDoc/PropertyUpdate/2_Silverscape/pdfs/SilverscapeWhatsAppBrochure.pdf";
                //string createFTPFilePath = "ftp://172.20.72.11/CremaDoc/PropertyUpdate/2_Silverscape/Whatsapp/";
                //string fileName = "SilverscapeWhatsAppBrochure.pdf";
                ////
                int IsFileSaved = oFTP.Download_Upload_OnFTP(readFTPFilePath, createFTPFilePath, fileName);
                ////
                if (IsFileSaved == 1)
                {
                    /////Whatsapp Sending Code below///
                    string URL = ConfigurationManager.AppSettings.Get("WhatsApp").ToString();
                    URL = URL + sendNumber + "&message=" + message;
                    using (var client = new System.Net.WebClient())
                    {
                        client.Headers.Add("Content-Type:application/json");
                        client.Headers.Add("Accept:application/json");
                        result = client.DownloadString(URL);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public string SendWhatssAppTextMessage(string sendNumber, string message)
        {
            string result = string.Empty;
            try
            {
                //string number = "918655192333";
                //string message = "HI Testing Started";
                
                /////Whatsapp Sending Code below///
                string URL = ConfigurationManager.AppSettings.Get("WhatsApp").ToString();
                URL = URL + sendNumber + "&message=" + message;
                using (var client = new System.Net.WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    result = client.DownloadString(URL);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
    }

    public class UniversalSearchBAL
    {
        SqlCommand cmd;
        public UniversalSearch GetUniversalSearchMst(int RoleId)
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                UniversalSearch objUniversalSearchMST = new UniversalSearch();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 5); //for Getting Search Master
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_UNIVERSAL_SEARCH");
                if (ds != null && ds.Tables.Count > 0)
                {
                    objUniversalSearchMST.UniversalSearchMST = new List<Dropdown>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objUniversalSearchMST.UniversalSearchMST.Add(dd);
                    }
                }
                return objUniversalSearchMST;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UniversalSearch> GetUniversalSearchResult(CommonSearchFilters objFilters)
        {
            try
            {
                DataTable dt;
                List<UniversalSearch> objlstUniversalSearchResult = new List<UniversalSearch>();
                UniversalSearch objUniversalSearch;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objFilters.Flag);
                cmd.Parameters.AddWithValue("@EMPID", objFilters.EmpId);
                cmd.Parameters.AddWithValue("@RoleId", objFilters.RoleId);
                cmd.Parameters.AddWithValue("@SearchText", objFilters.SearchText);
                cmd.Parameters.AddWithValue("@UserId", objFilters.UserId);
                cmd.Parameters.AddWithValue("@UserTypeId", objFilters.UserTypeId);
                cmd.Parameters.AddWithValue("@PropertyId", objFilters.PropertyId);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_UNIVERSAL_SEARCH");
                if (dt.Rows.Count > 0)
                {
                    if (objFilters.Flag != 6)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            objUniversalSearch = new UniversalSearch();
                            objUniversalSearch.SearchResult = Convert.ToString(dr["SearchResult"]);
                            objUniversalSearch.UserId = Convert.ToInt64(dr["UserId"] == DBNull.Value ? 0 : dr["UserId"]);
                            objUniversalSearch.UserTypeId = Convert.ToInt32(dr["UserTypeId"] == DBNull.Value ? 0 : dr["UserTypeId"]);
                            if (objFilters.Flag == 4 || objFilters.Flag == 21)
                            {
                                objUniversalSearch.IsRegisterCP = Convert.ToBoolean(dr["IsRegisterCP"]);
                            }
                            else
                            {
                                objUniversalSearch.IsRegisterCP = null;
                            }
                            objlstUniversalSearchResult.Add(objUniversalSearch);
                        }
                    }
                    else if (objFilters.Flag == 6)//For UnRegister CP
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            objUniversalSearch = new UniversalSearch();
                            objUniversalSearch.SearchResult = Convert.ToString(dr["SearchResult"]);
                            objUniversalSearch.UserId = Convert.ToInt64(dr["UserId"] == DBNull.Value ? 0 : dr["UserId"]);
                            objUniversalSearch.UserTypeId = Convert.ToInt32(dr["UserTypeId"] == DBNull.Value ? 0 : dr["UserTypeId"]);
                            objUniversalSearch.IsRegisterCP = Convert.ToBoolean(dr["IsRegisterCP"]);
                            objlstUniversalSearchResult.Add(objUniversalSearch);
                        }
                    }
                }
                return objlstUniversalSearchResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetSubMenu(string ComponentName, int RoleId, long EmpId)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ComponentName", ComponentName);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_SUBMENU_BY_COMPONENT");
                Result = Utilities.dtToJson(dtResult);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
