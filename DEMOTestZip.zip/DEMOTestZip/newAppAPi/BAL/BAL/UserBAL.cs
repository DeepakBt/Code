﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BAL
{
    public class UserBAL
    {
        public SqlCommand cmd;

        public UserMasterData GetMasterDataForNewUser()
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                UserMasterData objUserMasterData = new UserMasterData();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_MST_DATA_FOR_NEW_USER");
                if (ds != null && ds.Tables.Count > 0)
                {
                    objUserMasterData = new UserMasterData();
                    objUserMasterData.LanguageMst = new List<Dropdown>();
                    objUserMasterData.RoleMst = new List<Dropdown>();
                    objUserMasterData.SubRoleMst = new List<Dropdown>();

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objUserMasterData.LanguageMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objUserMasterData.RoleMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objUserMasterData.SubRoleMst.Add(dd);
                    }
                }

                return objUserMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertUpdateNewUserData(string strUserXML)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserXML", strUserXML);
                cmd.Parameters.AddWithValue("@Flag", "Insert");
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_USER");
                Result = Utilities.dtToJson(dtResult);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetUsersListOnSeach(string SearchText)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SearchText", SearchText);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_USERS");
                Result = Utilities.dtToJson(dtResult);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public User GetUserAccessData(int UserId)
        {
            try
            {
                DataSet ds;
                User objUser = new User();
                Component objCompo = new Component();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", UserId);

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DETAILS_BY_USERID");
                if (ds != null && ds.Tables.Count > 0)
                {
                    objUser.MappedComponentsList = new List<Component>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        objUser.MappedRole = Convert.ToString(row["RoleName"]);
                        objUser.MappedSubRole = Convert.ToString(row["SubRoleName"]);
                    }
                    foreach (DataRow oRow in ds.Tables[1].Rows)
                    {
                        objCompo = new Component();
                        objCompo.ComponentId = Convert.ToInt32(oRow["ComponentId"]);
                        objCompo.DisplayName = Convert.ToString(oRow["DisplayName"]);
                        objCompo.ComponentName = Convert.ToString(oRow["ComponentName"]);
                        objCompo.IsMapped = Convert.ToInt32(oRow["IsMapped"]);
                        objUser.MappedComponentsList.Add(objCompo);
                    }
                }
                return objUser;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetUserDataById(string TokenId)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TokenId", TokenId);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_USER_DETAILS_BY_TOKENID");
                Result = Utilities.dtToJson(dtResult);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public List<UserActivity> GetUserActivity(UserParam objParam)
        {
            try
            {
                List<UserActivity> objLstUserActivity = new List<UserActivity>();
                cmd = new SqlCommand();
                DataTable dt;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@UserId",objParam.UserId);
                cmd.Parameters.AddWithValue("@UserTypeId",objParam.UserTypeId);
                cmd.Parameters.AddWithValue("@FTD",objParam.FTD);
                cmd.Parameters.AddWithValue("@FromDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate", objParam.ToDate);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_USER_ACTIVITY");
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        UserActivity objUA = new UserActivity();
                        objUA.UserId = Convert.ToInt32(dr["UserId"] == DBNull.Value ? 0 : dr["UserId"]);
                        objUA.UserTypeId= Convert.ToInt32(dr["UserTypeId"] == DBNull.Value ? 0 : dr["UserTypeId"]);
                        objUA.UserName = Convert.ToString(dr["UserName"]);
                        objUA.LoginT = Convert.ToDateTime(dr["LoginT"]==DBNull.Value? default(DateTime): dr["LoginT"]);
                        objUA.LoginTime = Convert.ToString(dr["LoginTime"]);
                        objUA.LogoutT = Convert.ToDateTime(dr["LogoutT"]==DBNull.Value? default(DateTime):dr["LogoutT"]);
                        objUA.LogoutTime = Convert.ToString(dr["LogoutTime"]);
                        objUA.LoginAddress = Convert.ToString(dr["LoginAddress"]);
                        objUA.LogoutAddress = Convert.ToString(dr["LogoutAddress"]);
                        objUA.CPName = Convert.ToString(dr["CPName"]);
                        objLstUserActivity.Add(objUA);
                    }
                }
                return objLstUserActivity;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
