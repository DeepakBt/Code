﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class LoginBAL
    {
        public SqlCommand cmd;

        public bool CheckSession(long EmpId, string TokenId)
        {
            try
            {
                bool Session = false;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@TokenId", TokenId);
                cmd.Parameters.AddWithValue("@Flag", 3);
                DataTable dtSession = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_VALIDATE_USER_LOGIN");
                Session = Convert.ToBoolean(dtSession.Rows[0][0].ToString());
                return Session;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public UserSession LogIn(string UserXML)
        {
            try
            {
                UserSession oUser = new UserSession();
                SubComponent oSubCompo = new SubComponent();

                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@XMLData", UserXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                DataSet oDs = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_VALIDATE_USER_LOGIN");
                if (oDs != null && oDs.Tables.Count > 0)
                {
                    oUser.Result = Convert.ToInt32(oDs.Tables[0].Rows[0]["Result"]);

                    if (oUser.Result == 0)
                    {
                        oUser.Message = Convert.ToString(oDs.Tables[0].Rows[0]["Message"]);
                    }
                    else if (oUser.Result == 1)
                    {
                        oUser.TokenId = Convert.ToString(oDs.Tables[0].Rows[0]["TokenId"]);
                        oUser.Username = Convert.ToString(oDs.Tables[0].Rows[0]["EmpName"]);
                        oUser.LandingPage = Convert.ToString(oDs.Tables[0].Rows[0]["DefaultComponent"]);
                        oUser.Message = Convert.ToString(oDs.Tables[0].Rows[0]["Message"]);
                        oUser.EmpId = Convert.ToInt32(oDs.Tables[0].Rows[0]["EmpId"]);
                        oUser.roleid = Convert.ToInt32(oDs.Tables[0].Rows[0]["RoleID"]);
                        oUser.Login = Convert.ToString(oDs.Tables[0].Rows[0]["UserName"]);
                        oUser.IsAccept = Convert.ToBoolean(oDs.Tables[0].Rows[0]["IsAccept"]);

                        oUser.MappedComponentsList = new List<Component>();
                        Component oComp = new Component();
                        if (oDs.Tables.Count > 1)
                        {
                            foreach (DataRow oRow in oDs.Tables[1].Rows)
                            {
                                oComp = new Component();
                                oComp.ListSubComponent = new List<SubComponent>();
                                oComp.ComponentId = Convert.ToInt32(oRow["ComponentId"]);
                                oComp.ComponentName = Convert.ToString(oRow["ComponentName"]);
                                oComp.DisplayName = Convert.ToString(oRow["DisplayName"]);
                                oComp.IconClass = Convert.ToString(oRow["IconClass"]);
                                if (oRow.Table.Columns.Contains("Flag"))
                                {
                                    oComp.Flag = Convert.ToInt32(oRow["Flag"]);
                                }
                                if(oDs.Tables.Count > 2)
                                {
                                    DataRow[] oSubCompList = oDs.Tables[2].Select("ParentComponentId = "+oComp.ComponentId+"");
                                    if(oSubCompList.Length > 0)
                                    {
                                        foreach(DataRow dr in oSubCompList)
                                        {
                                            oSubCompo = new SubComponent();
                                            oSubCompo.ComponentId = Convert.ToInt32(dr["ComponentId"]);
                                            oSubCompo.ComponentName = Convert.ToString(dr["ComponentName"]);
                                            oSubCompo.DisplayName = Convert.ToString(dr["DisplayName"]);
                                            oSubCompo.IconClass = Convert.ToString(dr["IconClass"]);
                                            oComp.ListSubComponent.Add(oSubCompo);
                                        }
                                    }
                                }
                                oUser.MappedComponentsList.Add(oComp);
                            }
                        }
                    }
                }

                return oUser;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetEmp()
        {
            try
            {
                string JString = "";
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpId", 0);
                cmd.Parameters.AddWithValue("@TokenId", "");
                cmd.Parameters.AddWithValue("@Password", "");
                cmd.Parameters.AddWithValue("@Mode", "Get");
                DataTable dtLogin = Db_Access.ExecuteDataTable(ref cmd, "USP_ValidateEmp");
                if (dtLogin != null)
                {
                    JString = Utilities.dtToJson(dtLogin);
                }
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GenerateOTP(string UserXML)
        {
            try
            {
                string JString = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserXML);                
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_VALIDATE_USER_LOGIN");
                if (dt != null)
                {
                    JString = Utilities.dtToJson(dt);
                }
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public User ValidateOTP(string UserXML)
        {
            try
            {
                User oUser = new User();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                DataSet oDs = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_VALIDATE_USER_LOGIN");
                if (oDs != null && oDs.Tables.Count > 0)
                {
                    oUser.TokenId = Convert.ToString(oDs.Tables[0].Rows[0]["TokenId"]);
                    oUser.Username = Convert.ToString(oDs.Tables[0].Rows[0]["EmpName"]);
                    oUser.LandingPage = Convert.ToString(oDs.Tables[0].Rows[0]["DefaultComponent"]);
                    oUser.Message = Convert.ToString(oDs.Tables[0].Rows[0]["Message"]);
                    oUser.Result = Convert.ToInt32(oDs.Tables[0].Rows[0]["Result"]);
                    oUser.EmpId = Convert.ToInt32(oDs.Tables[0].Rows[0]["EmpId"]);

                    oUser.MappedComponentsList = new List<Component>();
                    Component oComp = new Component();
                    foreach (DataRow oRow in oDs.Tables[1].Rows)
                    {
                        oComp = new Component();
                        oComp.ComponentId = Convert.ToInt32(oRow["ComponentId"]);
                        oComp.ComponentName = Convert.ToString(oRow["ComponentName"]);
                        oComp.DisplayName = Convert.ToString(oRow["MenuName"]);
                        oUser.MappedComponentsList.Add(oComp);
                    }
                }
                return oUser;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string LogOut(string UserXML)
        {
            try
            {
                string JString = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserXML);
                cmd.Parameters.AddWithValue("@Flag", 4);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_VALIDATE_USER_LOGIN");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string ChangePassword(string UserXML, long empid,int RoleId)
        {
            try
            {
                string JString = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", UserXML);
                cmd.Parameters.AddWithValue("@Flag", 5);
                cmd.Parameters.AddWithValue("@EmpId", empid);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_VALIDATE_USER_LOGIN");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string ForgetPassword(ForgetPassword objForgetPassword)
        {
            try
            {
                string JString = "";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objForgetPassword.Flag);
                cmd.Parameters.AddWithValue("@UserName", objForgetPassword.UserName);
                cmd.Parameters.AddWithValue("@OTP", objForgetPassword.OTP);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_RESET_PASSWORD");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
