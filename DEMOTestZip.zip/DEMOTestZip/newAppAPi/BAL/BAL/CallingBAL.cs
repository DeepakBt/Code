﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;
using System.Xml.Linq;
using System.Configuration;
namespace BAL
{
    public class CallingBAL
    {
        SqlCommand cmd;
        public string SendBrochure(int Flag, int LeadId, int EmpId, int RoleId,int PropertyId)
        {
            try
            {
                string JString = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@LeadId", LeadId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@PropertyId", PropertyId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_LEAD_BROCHURES");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<CallingAPI> GetCallingAPI(int TeleCallerId)
        {
            try
            {
                List<CallingAPI> LstCallingAPIObj = new List<CallingAPI>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@TeleCallerId", TeleCallerId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_TELECALLER_API");
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        CallingAPI objCallingAPI = new CallingAPI();
                        objCallingAPI.CallingAPIId = Convert.ToInt32(dr["CallingAPIId"] == DBNull.Value ? 0 : dr["CallingAPIId"]);
                        objCallingAPI.Description = Convert.ToString(dr["Description"]);
                        objCallingAPI.APILink = Convert.ToString(dr["APILink"]);
                        LstCallingAPIObj.Add(objCallingAPI);
                    }
                }
                return LstCallingAPIObj;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public GlobalLeadBucket GetGlobalLead(TCDBParam objParam, int EmpId, int RoleId)
        {
            try
            {
                GlobalLeadBucket objGlobalLeadBucket = new GlobalLeadBucket();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_TELECALLER_CALLING_DASHBOARD");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objGlobalLeadBucket.GlobalLeadCount = Convert.ToInt32(ds.Tables[0].Rows[0]["GlobalLeadCount"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["GlobalLeadCount"]);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        objGlobalLeadBucket._GlobalLeadBucket = new List<_GlobalLeadBucket>();
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            _GlobalLeadBucket objGLC = new _GlobalLeadBucket();
                            objGLC.LeadId = Convert.ToInt32(dr["LeadId"] == DBNull.Value ? 0 : dr["LeadId"]);
                            objGLC.LeadName = Convert.ToString(dr["LeadName"]);
                            objGLC.CreatedDate = Convert.ToString(dr["CreatedDate"]);
                            objGlobalLeadBucket._GlobalLeadBucket.Add(objGLC);
                        }
                    }
                }
                return objGlobalLeadBucket;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ResponseMessage AssignedLeadTC(TCDBParam objParam, int EmpId, int RoleId)
        {
            try
            {
                ResponseMessage objResponse = new ResponseMessage();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);

                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_TELECALLER_CALLING_DASHBOARD");
                if (dt.Rows.Count > 0)
                {
                    objResponse.Result = Convert.ToInt32(dt.Rows[0]["Result"] == DBNull.Value ? 0 : dt.Rows[0]["Result"]);
                    objResponse.Message = Convert.ToString(dt.Rows[0]["Message"]);
                }
                return objResponse;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<TCAssignedLead> GetTCLead(TCDBParam objParam, int EmpId, int RoleId)
        {
            try
            {
                List<TCAssignedLead> lstObjLead = new List<TCAssignedLead>();

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_TELECALLER_CALLING_DASHBOARD");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            TCAssignedLead objTCLead = new TCAssignedLead();
                            objTCLead.CreatedOn = Convert.ToString(dr["CreatedOn"]);
                            objTCLead.LeadId = Convert.ToInt32(dr["LeadId"] == DBNull.Value ? 0 : dr["LeadId"]);
                            objTCLead.LeadName = Convert.ToString(dr["LeadName"]);
                            objTCLead.Mobile = Convert.ToString(dr["Mobile"]);
                            objTCLead.Email = Convert.ToString(dr["Email"]);
                            objTCLead.SubSource = Convert.ToString(dr["SubSource"]);
                            objTCLead.SubSourceId = Convert.ToInt32(dr["SubSourceId"] == DBNull.Value ? 0 : dr["SubSourceId"]);
                            objTCLead.Date = Convert.ToString(dr["Date"]);
                            objTCLead.StatusId = Convert.ToInt32(dr["StatusId"] == DBNull.Value ? 0 : dr["StatusId"]);
                            objTCLead.StatusName = Convert.ToString(dr["StatusName"]);
                            objTCLead.StatusCriteriaId = Convert.ToInt32(dr["StatusCriteriaId"] == DBNull.Value ? 0 : dr["StatusCriteriaId"]);
                            objTCLead.CriteriaName = Convert.ToString(dr["CriteriaName"]);
                            objTCLead.PropertyId = Convert.ToInt32(dr["PropertyId"] == DBNull.Value ? 0 : dr["PropertyId"]);
                            objTCLead.PropertyName = Convert.ToString(dr["PropertyName"]);
                            objTCLead.ResidentialLocationId = Convert.ToInt32(dr["ResidentialLocationId"] == DBNull.Value ? 0 : dr["ResidentialLocationId"]);
                            objTCLead.ResidentialLocation = Convert.ToString(dr["ResidentialLocation"]);
                            objTCLead.Comments = Convert.ToString(dr["Comments"]);
                            objTCLead.FlatConfigurationId = Convert.ToInt32(dr["FlatConfigurationId"] == DBNull.Value ? 0 : dr["FlatConfigurationId"]);
                            objTCLead.FlatConfiguration = Convert.ToString(dr["FlatConfiguration"]);
                            objTCLead._LeadBudget = new List<LeadBudget>();
                            foreach (DataRow d in ds.Tables[1].Rows)
                            {
                                if (objTCLead.LeadId == Convert.ToInt32(d["UserId"] == DBNull.Value ? 0 : d["UserId"]))
                                {
                                    LeadBudget objLeadBudget = new LeadBudget();
                                    objLeadBudget.BudgetMappingId = Convert.ToInt32(d["MappingId"] == DBNull.Value ? 0 : d["MappingId"]);
                                    objLeadBudget.BudgetId = Convert.ToInt32(d["BudgetId"] == DBNull.Value ? 0 : d["BudgetId"]);
                                    objLeadBudget.DisplayName = Convert.ToString(d["DisplayName"]);
                                    objLeadBudget.UserId = Convert.ToInt32(d["UserId"] == DBNull.Value ? 0 : d["UserId"]);
                                    objLeadBudget.UserTypeId = Convert.ToInt32(d["UserType"] == DBNull.Value ? 0 : d["UserType"]);
                                    objTCLead._LeadBudget.Add(objLeadBudget);
                                }
                            }
                            lstObjLead.Add(objTCLead);
                        }
                    }
                }
                return lstObjLead;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public TCAssignedLead GetTCLeadMobile(string XMLData, int EmpId, int RoleId)
        {
            try
            {
                TCAssignedLead ObjLead = new TCAssignedLead();

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INSERT_UPDATE_TELECALLER_LEAD");
                if (ds.Tables.Count > 1)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ObjLead.CreatedOn = Convert.ToString(ds.Tables[0].Rows[0]["CreatedOn"]);
                        ObjLead.LeadId = Convert.ToInt32(ds.Tables[0].Rows[0]["LeadId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["LeadId"]);
                        ObjLead.LeadName = Convert.ToString(ds.Tables[0].Rows[0]["LeadName"]);
                        ObjLead.Mobile = Convert.ToString(ds.Tables[0].Rows[0]["Mobile"]);
                        ObjLead.SubSource = Convert.ToString(ds.Tables[0].Rows[0]["SubSource"]);
                        ObjLead.SubSourceId = Convert.ToInt32(ds.Tables[0].Rows[0]["SubSourceId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["SubSourceId"]);
                        ObjLead.Email = Convert.ToString(ds.Tables[0].Rows[0]["Email"]);
                        ObjLead.Date = Convert.ToString(ds.Tables[0].Rows[0]["Date"]);
                        ObjLead.StatusId = Convert.ToInt32(ds.Tables[0].Rows[0]["StatusId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["StatusId"]);
                        ObjLead.StatusName = Convert.ToString(ds.Tables[0].Rows[0]["StatusName"]);
                        ObjLead.StatusCriteriaId = Convert.ToInt32(ds.Tables[0].Rows[0]["StatusCriteriaId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["StatusCriteriaId"]);
                        ObjLead.CriteriaName = Convert.ToString(ds.Tables[0].Rows[0]["CriteriaName"]);
                        ObjLead.PropertyId = Convert.ToInt32(ds.Tables[0].Rows[0]["PropertyId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["PropertyId"]);
                        ObjLead.PropertyName = Convert.ToString(ds.Tables[0].Rows[0]["PropertyName"]);
                        ObjLead.ResidentialLocationId = Convert.ToInt32(ds.Tables[0].Rows[0]["ResidentialLocationId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["ResidentialLocationId"]);
                        ObjLead.ResidentialLocation = Convert.ToString(ds.Tables[0].Rows[0]["ResidentialLocation"]);
                        ObjLead.Comments = Convert.ToString(ds.Tables[0].Rows[0]["Comments"]);
                        ObjLead.FlatConfigurationId = Convert.ToInt32(ds.Tables[0].Rows[0]["FlatConfigurationId"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["FlatConfigurationId"]);
                        ObjLead.FlatConfiguration = Convert.ToString(ds.Tables[0].Rows[0]["FlatConfiguration"]);
                        ObjLead.RmName = Convert.ToString(ds.Tables[0].Rows[0]["ProspectRM"]);
                        ObjLead.IsProspect = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsProspect"]);
                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        ObjLead._LeadBudget = new List<LeadBudget>();
                        foreach (DataRow d in ds.Tables[1].Rows)
                        {
                            LeadBudget objLeadBudget = new LeadBudget();
                            objLeadBudget.BudgetMappingId = Convert.ToInt32(d["MappingId"] == DBNull.Value ? 0 : d["MappingId"]);
                            objLeadBudget.BudgetId = Convert.ToInt32(d["BudgetId"] == DBNull.Value ? 0 : d["BudgetId"]);
                            objLeadBudget.DisplayName = Convert.ToString(d["DisplayName"]);
                            objLeadBudget.UserId = Convert.ToInt32(d["UserId"] == DBNull.Value ? 0 : d["UserId"]);
                            objLeadBudget.UserTypeId = Convert.ToInt32(d["UserType"] == DBNull.Value ? 0 : d["UserType"]);
                            ObjLead._LeadBudget.Add(objLeadBudget);
                        }
                    }
                }
                return ObjLead;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ResponseMessage InsertUpdateTeleCallerLead(string XMLData, int EmpId, int RoleId, int Flag)
        {
            ResponseMessage objResponse = new ResponseMessage();
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_TELECALLER_LEAD");
                if (dt.Rows.Count > 0)
                {
                    objResponse.Result = Convert.ToInt32(dt.Rows[0]["Result"] == DBNull.Value ? 0 : dt.Rows[0]["Result"]);
                    objResponse.Message = Convert.ToString(dt.Rows[0]["Message"]);
                }
                return objResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable WhatsAppBrochure(Brochure objBrochure, int EmpId, int RoleId,out List<WhatsAppMsg> oWhatsAppMsgList)
        {
            try
            {
                oWhatsAppMsgList = new List<WhatsAppMsg>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objBrochure.Flag);
                cmd.Parameters.AddWithValue("@LeadId", objBrochure.LeadId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@WhatsAppNo", objBrochure.WhatsAppNo);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_LEAD_BROCHURES");
                if(ds!= null && ds.Tables.Count > 0)
                {
                    if(Convert.ToInt32(ds.Tables[0].Rows[0]["Results"])== 1)
                    {
                        foreach(DataRow row in ds.Tables[1].Rows)
                        {
                            WhatsAppMsg oMsg = new WhatsAppMsg();
                            oMsg.WhatsAppMsgId = Convert.ToInt32(row["WhatsAppId"]);
                            oMsg.WhatsAppNumber = Convert.ToString(row["To"]);
                            oMsg.MessageTxt = Convert.ToString(row["Body"]);
                            oMsg.IsPdfLinkMsg = Convert.ToBoolean(row["IsPdfLinkMsg"]);
                            oMsg.BrochureReadLink = Convert.ToString(row["BrochureReadLink"]);
                            oMsg.BrochureWriteLink = Convert.ToString(row["BrochureWriteLink"]);
                            oMsg.BrochureName = Convert.ToString(row["BrochureName"]);
                            oWhatsAppMsgList.Add(oMsg);
                        }
                    }
                }
                return ds.Tables[0];
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataTable UpdateWhatsAppMsgStatus(WhatsAppMsg oMsg, long EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@WhatsAppMsgResponse", oMsg.Response);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@WhatsAppMsgId", oMsg.WhatsAppMsgId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_LEAD_BROCHURES");
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
