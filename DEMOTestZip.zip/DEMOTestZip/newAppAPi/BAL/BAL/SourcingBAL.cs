﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;
using System.Xml.Linq;
using System.Configuration;
namespace BAL
{
    public class SourcingBAL
    {
        SqlCommand cmd;
        public SourcingDashboard GetSourcingDashboard(SourcingParam Param,int EmpId,int RoleId)
        {
            try
            {
                SourcingDashboard objSourcingDashboard = new SourcingDashboard();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@FromDate", Param.FromDate);
                cmd.Parameters.AddWithValue("@ToDate", Param.ToDate);
                cmd.Parameters.AddWithValue("@PropertyId",Param.PropertyId );
                cmd.Parameters.AddWithValue("@Period",Param.Period);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_SOURCING_DASHBOARD");
                if (ds.Tables.Count>7)
                {
                    objSourcingDashboard._CPEmpanel = new CPEmpanel();
                    objSourcingDashboard._CPEmpanel.InitiatedCP = Convert.ToInt32(ds.Tables[0].Rows[0]["InitiatedCP"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["InitiatedCP"]);
                    objSourcingDashboard._CPEmpanel.CompleteEmpanelCP = Convert.ToInt32(ds.Tables[0].Rows[0]["CompleteEmpanelCP"] == DBNull.Value ? 0 : ds.Tables[0].Rows[0]["CompleteEmpanelCP"]);
                    objSourcingDashboard._UNRegCP = new UNRegCP();
                    objSourcingDashboard._UNRegCP.Initiated= Convert.ToString(ds.Tables[1].Rows[0]["InitiatedUNRegCP"]);
                    objSourcingDashboard._UNRegCP.Approved = Convert.ToString(ds.Tables[1].Rows[0]["ApprovedUNRegCP"]);
                    objSourcingDashboard._UNRegCP.ApprovalPending = Convert.ToString(ds.Tables[1].Rows[0]["ApprovalPendingUNRegCP"]);
                    objSourcingDashboard._CPSiteAttendance = new CPSiteAttendance();
                    objSourcingDashboard._CPSiteAttendance.RegCP = Convert.ToInt32(ds.Tables[2].Rows[0]["EmpanelCPAttendee"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["EmpanelCPAttendee"]);
                    objSourcingDashboard._CPSiteAttendance.UnRegCP = Convert.ToInt32(ds.Tables[2].Rows[0]["UNRegCPCPAttendee"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["UNRegCPCPAttendee"]);
                    objSourcingDashboard._CPSiteAttendance.TotalCP = Convert.ToInt32(ds.Tables[2].Rows[0]["AllCPAttendee"] == DBNull.Value ? 0 : ds.Tables[2].Rows[0]["AllCPAttendee"]);
                    objSourcingDashboard._CPMeetingRatingwise = new CPMeetingRatingwise();
                    objSourcingDashboard._CPMeetingRatingwise.ZeroRating = Convert.ToInt32(ds.Tables[3].Rows[0]["CPMeetingDoneZeroRating"] == DBNull.Value ? 0 : ds.Tables[3].Rows[0]["CPMeetingDoneZeroRating"]);
                    objSourcingDashboard._CPMeetingRatingwise.OneRating = Convert.ToInt32(ds.Tables[3].Rows[0]["CPMeetingDoneOneRating"] == DBNull.Value ? 0 : ds.Tables[3].Rows[0]["CPMeetingDoneOneRating"]);
                    objSourcingDashboard._CPMeetingRatingwise.TwoRating = Convert.ToInt32(ds.Tables[3].Rows[0]["CPMeetingDoneTwoRating"] == DBNull.Value ? 0 : ds.Tables[3].Rows[0]["CPMeetingDoneTwoRating"]);
                    objSourcingDashboard._CPMeetingRatingwise.ThreeRating = Convert.ToInt32(ds.Tables[3].Rows[0]["CPMeetingDoneThreeRating"] == DBNull.Value ? 0 : ds.Tables[3].Rows[0]["CPMeetingDoneThreeRating"]);
                    objSourcingDashboard._CPMeetingRatingwise.FourRating = Convert.ToInt32(ds.Tables[3].Rows[0]["CPMeetingDoneForuRating"] == DBNull.Value ? 0 : ds.Tables[3].Rows[0]["CPMeetingDoneForuRating"]);
                    objSourcingDashboard._CPMeetingRatingwise.FiveRating = Convert.ToInt32(ds.Tables[3].Rows[0]["CPMeetingDoneFiveRating"] == DBNull.Value ? 0 : ds.Tables[3].Rows[0]["CPMeetingDoneFiveRating"]);
                    objSourcingDashboard._UnRegCPEmpanel = new UnRegCPEmpanel();
                    objSourcingDashboard._UnRegCPEmpanel.Total= Convert.ToInt32(ds.Tables[4].Rows[0]["TotalUnRegCP"] == DBNull.Value ? 0 : ds.Tables[4].Rows[0]["TotalUnRegCP"]);
                    objSourcingDashboard._UnRegCPEmpanel.Pending = Convert.ToInt32(ds.Tables[4].Rows[0]["UNRegCPEmpanelPending"] == DBNull.Value ? 0 : ds.Tables[4].Rows[0]["UNRegCPEmpanelPending"]);
                    objSourcingDashboard._UnRegCPEmpanel.Done = Convert.ToInt32(ds.Tables[4].Rows[0]["UNRegCPEmpanelDone"] == DBNull.Value ? 0 : ds.Tables[4].Rows[0]["UNRegCPEmpanelDone"]);
                    objSourcingDashboard._CPActiveInActive = new CPActiveInActive();
                    objSourcingDashboard._CPActiveInActive.ActiveCP= Convert.ToInt32(ds.Tables[5].Rows[0]["ActiveCP"] == DBNull.Value ? 0 : ds.Tables[5].Rows[0]["ActiveCP"]);
                    objSourcingDashboard._CPActiveInActive.InActiveCP = Convert.ToInt32(ds.Tables[5].Rows[0]["InActiveCP"] == DBNull.Value ? 0 : ds.Tables[5].Rows[0]["InActiveCP"]);
                    objSourcingDashboard._CPSupportCost = new _CPSupportCost();
                    objSourcingDashboard._CPSupportCost.CPCost = Convert.ToDecimal(ds.Tables[6].Rows[0]["TotalCPCost"] == DBNull.Value ? 0 : ds.Tables[6].Rows[0]["TotalCPCost"]);
                    objSourcingDashboard._CPSupportCost.SiteVisiteDone = Convert.ToInt32(ds.Tables[6].Rows[0]["SiteVisitDone"] == DBNull.Value ? 0 : ds.Tables[6].Rows[0]["SiteVisitDone"]);
                    objSourcingDashboard._CPSupportCost.Booked = Convert.ToInt32(ds.Tables[6].Rows[0]["Booked"] == DBNull.Value ? 0 : ds.Tables[6].Rows[0]["Booked"]);
                    objSourcingDashboard._NonTouchBaseCP = new NonTouchBaseCP();
                    objSourcingDashboard._NonTouchBaseCP.CPMappedToRM= Convert.ToInt32(ds.Tables[7].Rows[0]["CPMappedToRM"] == DBNull.Value ? 0 : ds.Tables[7].Rows[0]["CPMappedToRM"]);
                    objSourcingDashboard._NonTouchBaseCP.CPNotMappedToRM = Convert.ToInt32(ds.Tables[7].Rows[0]["CPNotMappedToRM"] == DBNull.Value ? 0 : ds.Tables[7].Rows[0]["CPNotMappedToRM"]);
                    objSourcingDashboard._NonTouchBaseCP.CPMappedMOMNotFilled = Convert.ToInt32(ds.Tables[7].Rows[0]["CPMappedToRMMOMNotFilled"] == DBNull.Value ? 0 : ds.Tables[7].Rows[0]["CPMappedToRMMOMNotFilled"]);
                }
                return objSourcingDashboard;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string SaveSourcingTarget(string XMLData,int EmpId,int RoleId)
        {
            try
            {
                string JString = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLDate", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_SOURCING_TARGET_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateSourcingTarget(string XMLData, int EmpId, int RoleId)
        {
            try
            {
                string JString = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLDate", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_SOURCING_TARGET_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string DeleteSourcingTarget(string XMLData, int EmpId, int RoleId)
        {
            try
            {
                string JString = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLDate", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_SOURCING_TARGET_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<SourcingTarget> GetSourcingTarget(SourcingTarget objST, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@PropertyId", objST.PropertyId);
                cmd.Parameters.AddWithValue("@UserId", objST.UserId);
                cmd.Parameters.AddWithValue("@UserTypeId", objST.UserTypeId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_UPDATE_SOURCING_TARGET_DETAILS");
                List<SourcingTarget> lstST = new List<SourcingTarget>();
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        SourcingTarget objSourcingTarget = new SourcingTarget();
                        objSourcingTarget.TargetId = Convert.ToInt32(dr["TargetId"]==DBNull.Value?0: dr["TargetId"]);
                        objSourcingTarget.TargetType = Convert.ToString(dr["TargetType"]);
                        objSourcingTarget.TargetTypeId = Convert.ToInt32(dr["TargetTypeId"]==DBNull.Value? null : dr["TargetTypeId"]);
                        objSourcingTarget.TargetTypeValue = Convert.ToString(dr["TargetTypeValue"]);
                        objSourcingTarget.TargetTypeValueId = Convert.ToInt32(dr["TargetTypeValueId"]==DBNull.Value?null :dr["TargetTypeValueId"]);
                        objSourcingTarget.TargetValue = Convert.ToInt32(dr["TargetValue"]==DBNull.Value? null :dr["TargetValue"]);
                        objSourcingTarget.PropertyId = Convert.ToInt32(dr["PropertyId"]==DBNull.Value? null :dr["PropertyId"]);
                        objSourcingTarget.PropertyName = Convert.ToString(dr["PropertyName"]);
                        objSourcingTarget.UserId = Convert.ToInt32(dr["UserId"] ==DBNull.Value?null :dr["UserId"]);
                        objSourcingTarget.UserTypeId = Convert.ToInt32(dr["UserTypeId"] == DBNull.Value ? null : dr["UserTypeId"]);
                        objSourcingTarget.UserName = Convert.ToString(dr["UserName"]);
                        objSourcingTarget.StartDate = Convert.ToDateTime(dr["StartDate"]==DBNull.Value? null :dr["StartDate"]);
                        objSourcingTarget.EndDate = Convert.ToDateTime(dr["EndDate"]==DBNull.Value?null:dr["EndDate"]);
                        objSourcingTarget.SD = Convert.ToString(dr["SD"]);
                        objSourcingTarget.ED = Convert.ToString(dr["ED"]);
                        lstST.Add(objSourcingTarget);
                    }
                }
                return lstST;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetOverAllSourcingSummary(SourcingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                DataSet ds = new DataSet();
                cmd.Parameters.AddWithValue("@Filter", Param.Filter);
                cmd.Parameters.AddWithValue("@PropertyId",Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period",Param.Period);
                cmd.Parameters.AddWithValue("@Drill",0);
                cmd.Parameters.AddWithValue("@isSupported",0);
                cmd.Parameters.AddWithValue("@EmpId",EmpId);
                cmd.Parameters.AddWithValue("@RoleId",RoleId);
                DataSet BaseDataDs = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetBH_Sourcing_Summary_Dashboard");
                DataTable BaseData = new DataTable();
                DataTable BaseTotal = new DataTable();
                BaseData = BaseDataDs.Tables[0].Copy();
                if(BaseDataDs.Tables.Count>1)
                {
                    BaseTotal = BaseDataDs.Tables[1].Copy();
                }
                BaseData.TableName = "BaseData";
                BaseTotal.TableName = "BaseTotal";
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Filter", Param.Filter);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@Drill", 1);
                cmd.Parameters.AddWithValue("@isSupported", 0);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable DrillOne = Db_Access.ExecuteOnlyDataTable(ref cmd, "USP_CREMA_GetBH_Sourcing_Summary_Dashboard");
                DrillOne.TableName = "DrillOne";

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Filter", Param.Filter);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@Drill", 2);
                cmd.Parameters.AddWithValue("@isSupported", 0);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable DrillTwo = Db_Access.ExecuteOnlyDataTable(ref cmd, "USP_CREMA_GetBH_Sourcing_Summary_Dashboard");
                DrillTwo.TableName = "DrillTwo";

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Filter", Param.Filter);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@Drill", 2);
                cmd.Parameters.AddWithValue("@isSupported", 1);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable DrillTwoIsSupported = Db_Access.ExecuteOnlyDataTable(ref cmd, "USP_CREMA_GetBH_Sourcing_Summary_Dashboard");

                DrillTwoIsSupported.TableName = "DrillTwoIsSupported";

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Filter", Param.Filter);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@Drill", 3);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable DrillThree = Db_Access.ExecuteOnlyDataTable(ref cmd, "USP_CREMA_GetBH_Sourcing_Summary_Dashboard");
                DrillThree.TableName = "DrillThree";
                ds.Tables.Add(BaseData);
                ds.Tables.Add(DrillOne);
                ds.Tables.Add(DrillTwo);
                ds.Tables.Add(DrillTwoIsSupported);
                ds.Tables.Add(DrillThree);
                ds.Tables.Add(BaseTotal);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetCPTargetSummary(SourcingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period",Param.Period);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Get_BH_CP_target_Dashboard");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetSourcingMarketing(SourcingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                DataSet ds = new DataSet();
                List<int> LstSourceId = new List<int>();
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@Drill",Param.Drill);
                cmd.Parameters.AddWithValue("@Source", Param.SourceId);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet BaseDataDs = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetBH_Marketing_Summary_Dashboard");

                DataTable BaseData = new DataTable();
                DataTable BaseTotal = new DataTable();

                BaseData = BaseDataDs.Tables[0].Copy();
                if(BaseDataDs.Tables.Count>1)
                {
                    BaseTotal = BaseDataDs.Tables[1].Copy();
                }

                BaseData.TableName = "BaseData";
                BaseTotal.TableName = "BaseTotal";
                ds.Tables.Add(BaseData);
                var query = from row in BaseData.AsEnumerable()
                            orderby row["SourceID"] ascending select row["SourceID"];
                foreach (var SourceId in query)
                {
                    LstSourceId.Add(Convert.ToInt32(SourceId));
                }

                foreach(int i in LstSourceId)
                {
                    cmd = new SqlCommand();
                    cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                    cmd.Parameters.AddWithValue("@Period", Param.Period);
                    cmd.Parameters.AddWithValue("@Drill", 1);
                    cmd.Parameters.AddWithValue("@Source", i);
                    cmd.Parameters.AddWithValue("@EMPID", EmpId);
                    cmd.Parameters.AddWithValue("@RoleId", RoleId);
                    DataTable SourceData = Db_Access.ExecuteOnlyDataTable(ref cmd, "USP_CREMA_GetBH_Marketing_Summary_Dashboard");
                    SourceData.TableName = "Source"+Convert.ToString(i);
                    ds.Tables.Add(SourceData);
                }
                ds.Tables.Add(BaseTotal);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetWeekWiseWalkinDB(SourcingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag",Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Get_BH_WeekWise_Walking_Dashboard");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetTopTenSourcingCPWalkin(SourcingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetBH_TopTenCp_Walkin_Dashboard");
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
