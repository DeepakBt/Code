﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using DAL;
using BAL.Prop;

namespace BAL
{
    public class ProspectBAL
    {
        SqlCommand cmd;

        public RMAssignMasterData GetDataForProspectRMAssign(int PropertyId)
        {
            string JString = string.Empty;
            try
            {
                RMAssignMasterData oRMAssignMasterData = new RMAssignMasterData();
                oRMAssignMasterData.RMProspectDataList = new List<Prospect>();
                oRMAssignMasterData.UnAssignedProspectList = new List<Prospect>();
                oRMAssignMasterData.NewAssignedProspectDataList = new List<Prospect>();

                Prospect oProspect = new Prospect();

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@PropertyID", PropertyId);
                DataSet oDS = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Prospect_RMAssign");
                if(oDS!= null && oDS.Tables.Count > 0)
                {
                    if(oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
                    {
                        foreach(DataRow oRow in oDS.Tables[0].Rows)
                        {
                            oProspect = new Prospect();
                            oProspect.Prospectid = Convert.ToInt32(oRow["PROSPECTID"]);
                            oProspect.MeetingId = Convert.ToInt64(oRow["MeetingId"]); 
                            oProspect.LeadQualification = Convert.ToInt32(oRow["LeadQualify"]);
                            oProspect.FullName = Convert.ToString(oRow["Name"]);
                            oProspect.Mobile = Convert.ToString(oRow["Mobile"]);
                            oProspect.Email = Convert.ToString(oRow["Email"]);
                            oProspect.AssignedSalesRMName = Convert.ToString(oRow["RMName"]);
                            oProspect.UpcomingMeetingDateTime = Convert.ToString(oRow["DateTime"]);
                            oProspect.NoOfVisits = Convert.ToInt32(oRow["VisitCount"]);
                            oProspect.AttendeeArrived = Convert.ToInt32(oRow["AttendeeArrived"]);
                            oRMAssignMasterData.RMProspectDataList.Add(oProspect);
                        }
                    }

                    if (oDS.Tables[1] != null && oDS.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow oRow in oDS.Tables[1].Rows)
                        {
                            oProspect = new Prospect();
                            oProspect.Prospectid = Convert.ToInt32(oRow["PROSPECTID"]);
                            oProspect.MeetingId = Convert.ToInt64(oRow["MeetingId"]);
                            oProspect.LeadQualification = Convert.ToInt32(oRow["LeadQualify"]);
                            oProspect.FullName = Convert.ToString(oRow["Name"]);
                            oProspect.Mobile = Convert.ToString(oRow["Mobile"]);
                            oProspect.Email = Convert.ToString(oRow["Email"]);
                            oProspect.AssignedSalesRMName = Convert.ToString(oRow["RMName"]);
                            oProspect.UpcomingMeetingDateTime = Convert.ToString(oRow["DateTime"]);
                            oProspect.NoOfVisits = Convert.ToInt32(oRow["VisitCount"]);
                            oProspect.AttendeeArrived = Convert.ToInt32(oRow["AttendeeArrived"]);
                            oRMAssignMasterData.NewAssignedProspectDataList.Add(oProspect);
                        }
                    }

                    if (oDS.Tables[2] != null && oDS.Tables[2].Rows.Count > 0)
                    {
                        foreach (DataRow oRow in oDS.Tables[2].Rows)
                        {
                            oProspect = new Prospect();
                            oProspect.Prospectid = Convert.ToInt32(oRow["PROSPECTID"]);
                            oProspect.FullName = Convert.ToString(oRow["Name"]);
                            oProspect.ReligionName = Convert.ToString(oRow["ReligionName"]);
                            oProspect.LanguageName = Convert.ToString(oRow["LanguageName"]);
                            oProspect.VisitorType = Convert.ToString(oRow["VISITORTYPENAME"]);
                            oProspect.CreatedTime = Convert.ToString(oRow["CreatedDate"]);
                            oProspect.CPName = Convert.ToString(oRow["CPNAME"]);                           
                            oRMAssignMasterData.UnAssignedProspectList.Add(oProspect);
                        }
                    }
                }
                return oRMAssignMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ProspectMeeting GetMeetingDetails(int MeetingId)
        {
            try
            {
                ProspectMeeting objProspectMeeting = new ProspectMeeting();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@MeetingId", MeetingId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_PROSPECT_MEETING_DETAILS");
                if(dt.Rows.Count>0)
                {
                    objProspectMeeting.MeetingId = Convert.ToInt32(dt.Rows[0]["MeetingId"] == DBNull.Value ? 0: dt.Rows[0]["MeetingId"]);
                    objProspectMeeting.ProspectId = Convert.ToInt32(dt.Rows[0]["UserId"] == DBNull.Value ? 0 : dt.Rows[0]["UserId"]);
                    objProspectMeeting.MeetingDate = Convert.ToString(dt.Rows[0]["MeetingDate"]);
                    objProspectMeeting.StartTime = Convert.ToString(dt.Rows[0]["StartTime"]);
                    objProspectMeeting.EndTime = Convert.ToString(dt.Rows[0]["EndTime"]);
                    //objProspectMeeting.IsMeetingDone = Convert.ToBoolean(dt.Rows[0]["IsMeetingDone"] == DBNull.Value ? false : dt.Rows[0]["IsMeetingDone"]);
                    //objProspectMeeting.ModeOfContact = Convert.ToInt32(dt.Rows[0]["ModeOfContact"] == DBNull.Value ? 0 : dt.Rows[0]["ModeOfContact"]);
                    //objProspectMeeting.OutcomeTypeId = Convert.ToInt32(dt.Rows[0]["OutcomeTypeId"] == DBNull.Value ? 0 : dt.Rows[0]["OutcomeTypeId"]);
                    objProspectMeeting.ProspectStatus = Convert.ToInt32(dt.Rows[0]["ProspectStatus"] == DBNull.Value ? 0 : dt.Rows[0]["ProspectStatus"]);
                    objProspectMeeting.Comments = Convert.ToString(dt.Rows[0]["Comments"]);
                    objProspectMeeting.AssignedRM = Convert.ToInt32(dt.Rows[0]["AssignedRM"] == DBNull.Value ? 0 : dt.Rows[0]["AssignedRM"]);
                    objProspectMeeting.Agenda= Convert.ToString(dt.Rows[0]["Agenda"]);
                    objProspectMeeting.LeadQualify = Convert.ToInt32(dt.Rows[0]["LeadQualify"] == DBNull.Value ? 0 : dt.Rows[0]["LeadQualify"]);
                    objProspectMeeting.IsFirstMeeting = Convert.ToInt32(dt.Rows[0]["IsFirstMeeting"] == DBNull.Value ? 0 : dt.Rows[0]["IsFirstMeeting"]);
                    objProspectMeeting.isQualify = Convert.ToBoolean(dt.Rows[0]["IsQualified"] == DBNull.Value ? 0 : dt.Rows[0]["IsQualified"]);
                }
                return objProspectMeeting;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetRMListForAssign()
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 3);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_Prospect_RMAssign");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string AssignRMToProspect(Prospect oProspect, int EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", oProspect.Flag);
                cmd.Parameters.AddWithValue("@RMID", oProspect.AssignedSalesRMId);
                cmd.Parameters.AddWithValue("@ProspectID", oProspect.Prospectid);
                cmd.Parameters.AddWithValue("@MeetingID", oProspect.MeetingId);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@Comments", oProspect.Comments);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_Prospect_RMAssign");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetSalesRmList()
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 3);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_Prospect_RMAssign");
                JString = Utilities.dtToJson(oDT);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ProspectMOMQuestions> GetProspectMOMQuestion()
        {
            string JString = string.Empty;
            List<ProspectMOMQuestions> objLstProspectMOMQuestions = new List<ProspectMOMQuestions>();
            try
            {
                cmd = new SqlCommand();
                List<ProspectMOMQuestions> objlstProspectMOMQuestions = new List<ProspectMOMQuestions>();
                ProspectMOMQuestions objProspectMOMQuestions;
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_PROSPECT_MOM_QUESTIONS");
                if(oDT.Rows.Count>0)
                {
                    foreach(DataRow dr in oDT.Rows)
                    {
                        objProspectMOMQuestions = new ProspectMOMQuestions();
                        objProspectMOMQuestions.QuestionId = Convert.ToInt32(dr["QuestionId"] ==DBNull.Value?0: dr["QuestionId"]);
                        objProspectMOMQuestions.Question = Convert.ToString(dr["Question"]);
                        objProspectMOMQuestions.MOMText = Convert.ToString(dr["MOMText"]);
                        objProspectMOMQuestions.ParentHTML = Convert.ToString(dr["ParentHTML"]);
                        objProspectMOMQuestions.ChildHTML = Convert.ToString(dr["ChildHTML"]);
                        objlstProspectMOMQuestions.Add(objProspectMOMQuestions);
                    }
                }
                return objlstProspectMOMQuestions;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateMeetingDetails(string XMLData,int EmpId,int RoleId,int Flag)
        {
            try
            {
                string JString = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_PROSPECT_MEETING_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public MOMMasters GetMOMMasterData()
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                MeetingOutCome Mo;
                StatusCriteria cr;
                MOMMasters objMOMMaster = new MOMMasters();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 1);

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_MOMMaster");

                if (ds != null && ds.Tables.Count > 0)
                {
                    objMOMMaster = new MOMMasters();
                    objMOMMaster.ModeOfContact = new List<Dropdown>();
                    objMOMMaster.MeetingOutcome = new List<MeetingOutCome>();
                    objMOMMaster.LeadQualification = new List<Dropdown>();
                    objMOMMaster.AgendaMaster = new List<Dropdown>();
                    objMOMMaster.CriteriaMaster = new List<StatusCriteria>();

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objMOMMaster.ModeOfContact.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        Mo = new MeetingOutCome();
                        Mo.Id = Convert.ToInt32(dr["Id"]);
                        Mo.Value = Convert.ToString(dr["Value"]);
                        //Mo.Flag = Convert.ToBoolean(dr["ShowPopUp"]);
                        objMOMMaster.MeetingOutcome.Add(Mo);
                    }

                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objMOMMaster.LeadQualification.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[3].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objMOMMaster.AgendaMaster.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[4].Rows)
                    {
                        cr = new StatusCriteria();
                        cr.CriteriaId = Convert.ToInt32(dr["CriteriaId"]);
                        cr.CriteriaName = Convert.ToString(dr["CriteriaName"]);
                        cr.StatusId = Convert.ToInt32(dr["StatusID"]);
                        cr.IsInputNeeded = Convert.ToBoolean(dr["InputNeeded"]);
                        cr.InputLabel = Convert.ToString(dr["InputLabel"]);
                        objMOMMaster.CriteriaMaster.Add(cr);
                    }
                }

                return objMOMMaster;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Prospects360View GetProspect360DegreeView(Filters360degree objDashBoard, int RoleId, long EmpId)
        {
            try
            {
                string Result = string.Empty;
                DataSet dsResult;
                Prospects360View objProspects360View = new Prospects360View();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@ProspectId", objDashBoard.ProspectId);
                cmd.Parameters.AddWithValue("@CommunicationId", objDashBoard.CommunicationId);
                cmd.Parameters.AddWithValue("@Type", objDashBoard.Type);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);

                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PROSPECT_360_DEGREE_VIEW");
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    if(objDashBoard.Flag==1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objProspects360View.ProspectId= Convert.ToInt64(dsResult.Tables[0].Rows[0]["PROSPECTID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["PROSPECTID"]);
                            objProspects360View.Name = Convert.ToString(dsResult.Tables[0].Rows[0]["Name"]);
                            objProspects360View.Address = Convert.ToString(dsResult.Tables[0].Rows[0]["Address"]);
                            objProspects360View.Email = Convert.ToString(dsResult.Tables[0].Rows[0]["Email"]);
                            objProspects360View.Mobile = Convert.ToString(dsResult.Tables[0].Rows[0]["Mobile"]);
                            objProspects360View.SalesRM = Convert.ToString(dsResult.Tables[0].Rows[0]["SalesRM"]);
                            objProspects360View.Occupation = Convert.ToString(dsResult.Tables[0].Rows[0]["Occupation"]);
                            objProspects360View.DOB = Convert.ToString(dsResult.Tables[0].Rows[0]["DOB"]);
                            objProspects360View.LeadStatus = Convert.ToString(dsResult.Tables[0].Rows[0]["LeadStatus"]);
                            objProspects360View.LeadType = Convert.ToString(dsResult.Tables[0].Rows[0]["LeadType"]);
                            objProspects360View.PropertyName = Convert.ToString(dsResult.Tables[0].Rows[0]["PropertyName"]);
                            objProspects360View.MeetingCount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["MeetingCount"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["MeetingCount"]);
                            objProspects360View.SiteVisitCount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["SiteVisitCount"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["SiteVisitCount"]);
                            objProspects360View.CompanyName = Convert.ToString(dsResult.Tables[0].Rows[0]["CompanyName"]);
                            objProspects360View.designation = Convert.ToString(dsResult.Tables[0].Rows[0]["designation"]);
                            objProspects360View.Gender = Convert.ToString(dsResult.Tables[0].Rows[0]["Gender"]);
                            objProspects360View.Religion=Convert.ToString(dsResult.Tables[0].Rows[0]["Religion"]);
                            objProspects360View.Language = Convert.ToString(dsResult.Tables[0].Rows[0]["Language"]);
                            objProspects360View.Entity= Convert.ToString(dsResult.Tables[0].Rows[0]["Entity"]);
                            objProspects360View.CompanyLocation= Convert.ToString(dsResult.Tables[0].Rows[0]["CompanyLocation"]);
                            objProspects360View.SourceName = Convert.ToString(dsResult.Tables[0].Rows[0]["SourceName"]);
                            objProspects360View.InventoryType = Convert.ToString(dsResult.Tables[0].Rows[0]["InventoryType"]);
                            objProspects360View.PosessionTime = Convert.ToString(dsResult.Tables[0].Rows[0]["PosessionTime"]);
                            objProspects360View.Purpose = Convert.ToString(dsResult.Tables[0].Rows[0]["Purpose"]);
                            objProspects360View.Budget = Convert.ToString(dsResult.Tables[0].Rows[0]["Budget"]);
                            objProspects360View.Configuration = Convert.ToString(dsResult.Tables[0].Rows[0]["Configuration"]);
                            objProspects360View.Comments = Convert.ToString(dsResult.Tables[0].Rows[0]["Comments"]);
                            objProspects360View.IsEdit = Convert.ToInt32(dsResult.Tables[0].Rows[0]["isedit"]);
                        }
                    }else if(objDashBoard.Flag==2)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objProspects360View.lstCommunication = new List<Communication>();
                            foreach (DataRow dr in dsResult.Tables[0].Rows)
                            {
                                Communication objCommunication = new Communication();

                                objCommunication.CommunicationId = Convert.ToInt64(dr["CommunicationId"] == DBNull.Value ? 0 : dr["CommunicationId"]);
                                objCommunication.Type = Convert.ToInt32(dr["Type"]==DBNull.Value?0:dr["Type"]);
                                objCommunication.Date = Convert.ToString(dr["Date"]);
                                objCommunication.ModeOfContact = Convert.ToString(dr["ModeOfContact"]);
                                objCommunication.Agenda = Convert.ToString(dr["Agenda"]);
                                objCommunication.ContactPerson = Convert.ToString(dr["ContactPerson"]);
                                objCommunication.LeadStatus = Convert.ToString(dr["LeadStatus"]);
                                objProspects360View.lstCommunication.Add(objCommunication);
                            }
                        }
                    }
                    else if(objDashBoard.Flag==3)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objProspects360View.SelectedCommunication = new Communication();
                            objProspects360View.SelectedCommunication.CommunicationId = Convert.ToInt64(dsResult.Tables[0].Rows[0]["CommunicationId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CommunicationId"]);
                            objProspects360View.SelectedCommunication.Type = Convert.ToInt32(dsResult.Tables[0].Rows[0]["Type"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["Type"]);
                            objProspects360View.SelectedCommunication.Date = Convert.ToString(dsResult.Tables[0].Rows[0]["Date"]);
                            objProspects360View.SelectedCommunication.ModeOfContact = Convert.ToString(dsResult.Tables[0].Rows[0]["ModeOfContact"]);
                            objProspects360View.SelectedCommunication.Agenda = Convert.ToString(dsResult.Tables[0].Rows[0]["Agenda"]);
                            objProspects360View.SelectedCommunication.ContactPerson = Convert.ToString(dsResult.Tables[0].Rows[0]["ContactPerson"]);
                            objProspects360View.SelectedCommunication.MOM = Convert.ToString(dsResult.Tables[0].Rows[0]["MOM"]);
                            objProspects360View.SelectedCommunication.LeadStatus = Convert.ToString(dsResult.Tables[0].Rows[0]["LeadStatus"]);
                        }
                    }
                }
              return objProspects360View;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Lead360Summary GetLead360Summary(Filters360degree objDashBoard, int RoleId, long EmpId)
        {
            try
            {
                DataSet dsResult;
                Lead360Summary objLead360Summary = new Lead360Summary();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@UserId", EmpId);
                cmd.Parameters.AddWithValue("@UserTypeId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PROSPECT_360_SUMMARY");
                if(dsResult.Tables.Count>0)
                {
                    if(objDashBoard.Flag==1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objLead360Summary.LeadCount = new LeadCount();
                            objLead360Summary.LeadCount.NoOfLead = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfLead"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["NoOfLead"]);
                            objLead360Summary.LeadCount.NoOfLeadRevisit = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfLeadRevisit"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["NoOfLeadRevisit"]);
                            objLead360Summary.LeadCount.NoOfLeadQualified = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfLeadQualified"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["NoOfLeadQualified"]);
                            objLead360Summary.LeadCount.NoOfLeadInterested = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfLeadInterested"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["NoOfLeadInterested"]);
                            objLead360Summary.LeadCount.NoOfLeadFollowUp= Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfLeadFollowUp"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["NoOfLeadFollowUp"]);
                        }
                        if(dsResult.Tables[1].Rows.Count>0)
                        {
                            objLead360Summary.Lead360Details = new List<Lead360Details>();
                            foreach (DataRow dr in dsResult.Tables[1].Rows)
                            {
                                Lead360Details objLead360Details = new Lead360Details();
                                objLead360Details.PROSPECTID = Convert.ToInt64(dr["PROSPECTID"]==DBNull.Value?0: dr["PROSPECTID"]);
                                objLead360Details.LeadName = Convert.ToString(dr["LeadName"]);
                                objLead360Details.SourceName = Convert.ToString(dr["SourceName"]);
                                objLead360Details.Qualify= Convert.ToString(dr["QualifyName"]);
                                objLead360Details.ProjectName= Convert.ToString(dr["ProjectName"]);
                                objLead360Details.StatusName = Convert.ToString(dr["StatusName"]);
                                objLead360Details.MobileNo = Convert.ToString(dr["MobileNo"]);
                                objLead360Details.IsQualified= Convert.ToString(dr["IsQualified"]);
                                objLead360Summary.Lead360Details.Add(objLead360Details);
                            }
                        }
                    }
                }
                return objLead360Summary;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
