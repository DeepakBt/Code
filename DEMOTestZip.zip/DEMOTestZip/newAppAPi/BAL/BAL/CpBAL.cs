﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using BAL.Prop;
using Newtonsoft.Json;

namespace BAL
{
    public class CpBAL
    {
        SqlCommand cmd;
        public string InsertCP(string CPXML, long EmpId, int Flag)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CP_Details");
                if (Convert.ToString(dt.Rows[0]["Result"]) == "2")
                {
                    JString = "2";
                }
                else
                {
                    JString = Utilities.dtToJson(dt);
                }
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCP(long EmpId, long CPId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@CpId", CPId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CP_Details");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCityListOnSearch(string SearchCity)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SearchText", SearchCity);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_CITIES");
                Result = Utilities.dtToJson(dtResult);
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCityFromPin(string SearchedPin)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SearchText", SearchedPin);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_CITY_FROM_PINCODE");
                Result = dtResult != null && dtResult.Rows.Count > 0 ? Utilities.dtToJson(dtResult) : "";
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CPMasterData GetMasterDataForNewCP()
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                CPMasterData oCPMasterData = new CPMasterData();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 1);

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetMaster");

                if (ds != null && ds.Tables.Count > 0)
                {
                    oCPMasterData = new CPMasterData();
                    oCPMasterData.CPTypeMst = new List<Dropdown>();
                    oCPMasterData.RelationMst = new List<Dropdown>();
                    oCPMasterData.SalutationMst = new List<Dropdown>();
                    oCPMasterData.BusinessProfMst = new List<Dropdown>();
                    oCPMasterData.AreaOfOperationTypes = new List<Dropdown>();
                    oCPMasterData.BusinessModelTypes = new List<Dropdown>();
                    oCPMasterData.BankAccTypes = new List<Dropdown>();
                    oCPMasterData.LeadSourceTypes = new List<Dropdown>();
                    oCPMasterData.TurnOverSlabs = new List<Dropdown>();
                    oCPMasterData.CategoryMst = new List<Dropdown>();
                    oCPMasterData.Type2Mst = new List<Dropdown>();
                    oCPMasterData.RatingMst = new List<Dropdown>();

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.SalutationMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.CPTypeMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.RelationMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[4].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.BusinessProfMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[5].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.BankAccTypes.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[6].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.BusinessModelTypes.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[7].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.AreaOfOperationTypes.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[8].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.LeadSourceTypes.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[9].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.TurnOverSlabs.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[10].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.CategoryMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[11].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.Type2Mst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[12].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oCPMasterData.RatingMst.Add(dd);
                    }

                    oCPMasterData.DocTypeId = Convert.ToInt32(ds.Tables[3].Rows[0]["DOCID"]);
                    oCPMasterData.ImagPath = Convert.ToString(ds.Tables[3].Rows[0]["DOCPATH"]);
                }

                return oCPMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCpDashboardData(long EmpId, int roleId, int all)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@UserId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", roleId);
                cmd.Parameters.AddWithValue("@All", all);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_Get_Dashboard_Details");
                Result = dtResult != null && dtResult.Rows.Count > 0 ? Utilities.dtToJson(dtResult) : "";
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateCPBasicData(string CPXML, long EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", 3);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CP_Details");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateCPAgreementStatus(string CPXML, long EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", 4);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CP_Details");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateCPDetailedForm(string CPXML, int EmpId, int Flag, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CP_Detailed_FORM");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CP GetCPAllDetails(long CPId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@CpId", CPId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CP_ALL_DETAILS");
                CP oCP = new CP();
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow oRow in ds.Tables[0].Rows)
                    {
                        oCP.CPId = Convert.ToInt32(oRow["CPID"]);
                        oCP.Email = Convert.ToString(oRow["EMAIL"]);
                        oCP.Mobile = Convert.ToString(oRow["MOBILE"]);
                        oCP.CpTypeId = Convert.ToInt32(oRow["CPTYPE"]);
                        oCP.CPSalutation = Convert.ToString(oRow["CPSALUTATION"]);
                        oCP.CPName = Convert.ToString(oRow["CPNAME"]);
                        oCP.ProprieterSalutation = Convert.ToString(oRow["PROPRIETERINTIAL"]);
                        oCP.KartaName = Convert.ToString(oRow["KARTA_NAME"]);
                        oCP.PanCard = Convert.ToString(oRow["PANCARD"]);
                        oCP.Address = Convert.ToString(oRow["COMMUNICATIONADDRESS"]);
                        oCP.PinCode = Convert.ToString(oRow["Pincode"]);
                        oCP.City = Convert.ToString(oRow["CityName"]);
                        oCP.State = Convert.ToString(oRow["StateName"]);
                        oCP.FirstPartnerSalutation = Convert.ToString(oRow["PARTNER1INTIAL"]);
                        oCP.SecondPartnerSalutation = Convert.ToString(oRow["PARTNER2INTIAL"]);
                        oCP.FirstPartnerName = Convert.ToString(oRow["PARTNER1NAME"]);
                        oCP.SecondPartnerName = Convert.ToString(oRow["PARTNER2NAME"]);
                        oCP.FirstDirectorSalutation = Convert.ToString(oRow["DIRECTOR1INTIAL"]);
                        oCP.SecondDirectorSalutation = Convert.ToString(oRow["DIRECTOR2INTIAL"]);
                        oCP.FirstDirectorName = Convert.ToString(oRow["DIRECTOR1NAME"]);
                        oCP.SecondDirectorName = Convert.ToString(oRow["DIRECTOR2NAME"]);
                        oCP.ReraID = Convert.ToString(oRow["RERAID"]);
                        oCP.LocationId = Convert.ToInt32(oRow["LOCATIONID"]);
                        //oCP.ImageData = Convert.ToString(oRow[""]);
                        oCP.ImageName = Convert.ToString(oRow["DOCPATH"]);
                        //oCP.ImagePath = Convert.ToString(oRow[""]);
                        oCP.PermState = Convert.ToString(oRow["PermState"]);
                        oCP.PermCity = Convert.ToString(oRow["PermCity"]);
                        oCP.PermPinCode = Convert.ToString(oRow["PermPincode"]);
                        oCP.hdnPermPinId = Convert.ToString(oRow["PERMLOCATIONID"]);
                        oCP.OfficeNo = Convert.ToString(oRow["OFFICENO"]);
                        oCP.ResNo = Convert.ToString(oRow["RESNO"]);
                        oCP.AadharNo = Convert.ToString(oRow["AADHARNO"]);
                        oCP.GSTNo = Convert.ToString(oRow["GSTNO"]);
                        oCP.P1Contact = Convert.ToString(oRow["PARTNER1CONTACT"]);
                        oCP.P2Contact = Convert.ToString(oRow["PARTNER2CONTACT"]);
                        oCP.IncorpDate = Convert.ToString(oRow["INCORPORATIONDATE"]);
                        oCP.IsRelatedToCentrum = Convert.ToString(oRow["EXISTINGCENTRUMRELATIONSHIP"]);
                        oCP.BuisnessCode = Convert.ToString(oRow["EXISTING_BUSINESS"]);
                        oCP.RERA2Id = Convert.ToString(oRow["RERA2ID"]);
                        oCP.RERAState = Convert.ToString(oRow["MULTIPLERERA_STATE"]);
                        oCP.IsRERAMultiple = Convert.ToString(oRow["ISMULTIPLERERA"]);
                        oCP.BuisnessProfileType = Convert.ToString(oRow["BUSINESSPROFILE"]);
                        oCP.RefName = Convert.ToString(oRow["REF_NAME"]);
                        oCP.RefContact = Convert.ToString(oRow["REF_CONTACTNO"]);
                        oCP.RefAddr = Convert.ToString(oRow["REF_ADDRESS"]);
                        oCP.IsGSTFormAttached = Convert.ToString(oRow["ISGSTFORMATTACHED"]);
                        oCP.ContactName = Convert.ToString(oRow["CONTACTPERSONNAME"]);
                        oCP.ContactOfficeNo = Convert.ToString(oRow["CONTACTOFFICENO"]);
                        oCP.ContactResNo = Convert.ToString(oRow["CONTACTRESNO"]);
                        oCP.ContactMobNo = Convert.ToString(oRow["CONTACTMOBILENO"]);
                        oCP.KartaPan = Convert.ToString(oRow["KartaPAN"]);
                        oCP.PermAddress = Convert.ToString(oRow["PERMANENTADDRESS"]);
                        oCP.Type2Id = Convert.ToInt32(oRow["Type2Id"]);
                        oCP.CategoryId = Convert.ToInt32(oRow["CategoryId"]);
                        oCP.CPRating = Convert.ToInt32(oRow["CPRating"]);
                    }
                    if (ds.Tables.Count > 1)
                    {
                        foreach (DataRow oRow in ds.Tables[1].Rows)
                        {

                            oCP.AcName = Convert.ToString(oRow["ACCOUNTHOLDERNAME"]);
                            oCP.AccountNo = Convert.ToString(oRow["BANKACCOUNTNO"]);
                            oCP.BankName = Convert.ToString(oRow["BANKNAME"]);
                            oCP.IFSCCode = Convert.ToString(oRow["IFSCCODE"]);
                            oCP.MICRCode = Convert.ToString(oRow["MICRCODE"]);
                            oCP.BranchName = Convert.ToString(oRow["BRANCHNAME"]);
                            oCP.BranchAddress = Convert.ToString(oRow["BRANCHADDRESS"]);
                            oCP.AccountTypeId = Convert.ToInt32(oRow["ACCOUNTTYPE"]);
                        }
                    }

                    if (ds.Tables.Count > 2)
                    {
                        foreach (DataRow oRow in ds.Tables[2].Rows)
                        {
                            oCP.InceptionDate = Convert.ToString(oRow["DATEOFINCEPTION"]);
                            oCP.NoOfEmployees = Convert.ToInt32(oRow["NOOFEMPLOYEES"]);
                            oCP.NoOfManagers = Convert.ToInt32(oRow["NOOFMANAGERS"]);
                            oCP.ManagerContact = Convert.ToString(oRow["MANAGERCONTACTDETAILS"]);
                            oCP.NoOfOffices = Convert.ToInt32(oRow["NOOFOFFICES"]);
                            oCP.Location = Convert.ToString(oRow["LOCATION"]);
                            oCP.AnyOtherBusinessLife = Convert.ToString(oRow["ANYOTHERBUSINESSLIFE"]);
                            oCP.OtherBusinessTurnOver = Convert.ToDouble(oRow["TURNOVERINOTHERBUSINESS"]);
                            oCP.OtherBusinessEmpCount = Convert.ToInt32(oRow["OTHER_BUSSI_EMPLOY_COUNT"]);
                            oCP.AssociatedGradeADevelopers = Convert.ToString(oRow["ASSOCIATEDWITHGRADEA"]);
                            oCP.AssociatedGradeBDevelopers = Convert.ToString(oRow["ASSOCIATEDWITHGRADEB"]);
                            oCP.SoleSelling = Convert.ToString(oRow["SOLESELLING"]);
                            oCP.Others = Convert.ToString(oRow["OTHERS"]);
                            oCP.TotalRevenue = Convert.ToDouble(oRow["TOTALREVENUE"]);
                            oCP.IsPastSoleSelling = Convert.ToBoolean(oRow["IS_SOLESELLINGPAST"]);
                            oCP.IsAnyLitigation = Convert.ToBoolean(oRow["ANYLITIGATION"]);
                            oCP.LitigationDetails = Convert.ToString(oRow["LITIGATIONDETAILS"]);
                            oCP.BusinessModelTypes = Convert.ToString(oRow["BUSINESSMODEL"]);
                            oCP.AreaOfOperationTypes = Convert.ToString(oRow["AREAOFOPERATION"]);
                            oCP.LeadSourcesTypes = Convert.ToString(oRow["LEADSOURCE"]);
                            oCP.TurnOverSlabId = Convert.ToInt32(oRow["TURNOVERSLABID"]);
                        }
                    }
                }
                return oCP;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCPDocumentList(DocListFilters objDocListFilters)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objDocListFilters.Flag);
                cmd.Parameters.AddWithValue("@UserId", objDocListFilters.UserId);
                cmd.Parameters.AddWithValue("@EmpId", objDocListFilters.EmpId);
                cmd.Parameters.AddWithValue("@UserTypeId", objDocListFilters.UserTypeId);
                cmd.Parameters.AddWithValue("@CategoryId", objDocListFilters.CategoryId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_DOCUMETLIST");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveCPDocumentList(string CPXML, int EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_DOCUMETLIST");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string ProcessClientwisePayment(Customer oClient,long EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ClientId", oClient.Customer_Id);
                cmd.Parameters.AddWithValue("@PropertyId", oClient.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_UPDATE_CP_CLIENT_PAYMENT_PROCESS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetPDF_EditValue(long cpId)
        {
            DataTable dt;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@CpId", cpId);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_CP_AGREEMENT_PDF_VALUE");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCPElockerDetails(DocListFilters objDocListFilters)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objDocListFilters.Flag);
                cmd.Parameters.AddWithValue("@UserId", objDocListFilters.UserId);
                cmd.Parameters.AddWithValue("@EmpId", objDocListFilters.EmpId);
                cmd.Parameters.AddWithValue("@UserTypeId", objDocListFilters.UserTypeId);
                cmd.Parameters.AddWithValue("@CategoryId", objDocListFilters.CategoryId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_Cp_dashboard_Elocker_details");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetAgreementPdf(int CPID)
        {
            string Result = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@CPID", CPID);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_AGREEMENT_PDF");
                Result = dt != null && dt.Rows.Count > 0 ? Utilities.dtToJson(dt) : "";
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetPDF_EmpanelFormEditValue(long cpId)
        {
            DataTable dt;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@CpId", cpId);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_CP_empanelform_html");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SendDocsEmail(string CPXML)
        {
            string Result = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_DOCS_EMAIL");
                Result = dt != null && dt.Rows.Count > 0 ? Utilities.dtToJson(dt) : "";
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SearchBankFromIFSC(string iFSC)
        {
            string Result = string.Empty;
            try
            {
                DataTable dtResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IFSC", iFSC);
                dtResult = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_BANK_DETAILS_BY_IFSC");
                Result = dtResult != null && dtResult.Rows.Count > 0 ? Utilities.dtToJson(dtResult) : "";
                return Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CPPropertyStatus GetCPPropertyStatusDashBoard(Filters360degree objDashBoard)
        {
            try
            {
                string Result = string.Empty;
                DataSet dsResult;
                CPPropertyStatus objCPPropertyStatus = new CPPropertyStatus();
                objCPPropertyStatus.listLead = new List<ProspectsSiteVisit>();
                ProspectsSiteVisit objProspectsSiteVisit;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@CPID", objDashBoard.CPID);
                cmd.Parameters.AddWithValue("@IsCompleted", objDashBoard.IsCompleted);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_CP_PROPERTY_STATUS");

                if(dsResult.Tables.Count>0)
                {
                    if(objDashBoard.Flag==1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objCPPropertyStatus.PropertyCount = Convert.ToString(dsResult.Tables[0].Rows[0]["PropertyCount"]);
                            objCPPropertyStatus.WalkIn= Convert.ToString(dsResult.Tables[0].Rows[0]["WalkIn"]);
                            objCPPropertyStatus.FollowUp = Convert.ToString(dsResult.Tables[0].Rows[0]["FollowUp"]);
                            objCPPropertyStatus.Booked = Convert.ToString(dsResult.Tables[0].Rows[0]["Booked"]);
                            objCPPropertyStatus.ConversionRatio = Convert.ToString(dsResult.Tables[0].Rows[0]["ConversionRatio"]);
                            objCPPropertyStatus.Qualified = Convert.ToString(dsResult.Tables[0].Rows[0]["Qualified"]);
                        }
                        if(dsResult.Tables[1].Rows.Count>0)
                        {
                            foreach(DataRow dr in dsResult.Tables[1].Rows)
                            {
                                objProspectsSiteVisit = new ProspectsSiteVisit();
                                objProspectsSiteVisit.PROSPECTID= Convert.ToInt64(dr["PROSPECTID"] == DBNull.Value ? 0 : dr["PROSPECTID"]);
                                objProspectsSiteVisit.ProspectName = Convert.ToString(dr["ProspectName"]);
                                objProspectsSiteVisit.Mobile = Convert.ToString(dr["Mobile"]);
                                objProspectsSiteVisit.NoOfVisit = Convert.ToString(dr["NoOfVisit"]);
                                objProspectsSiteVisit.LastVisitDate = Convert.ToString(dr["LastVisitDate"]);
                                objProspectsSiteVisit.LeadStatus = Convert.ToString(dr["StatusName"]);
                                objProspectsSiteVisit.Qualified = Convert.ToString(dr["Qualified"]);
                                objProspectsSiteVisit.RMName = Convert.ToString(dr["RMName"]);
                                objProspectsSiteVisit.NextSiteVisit = Convert.ToString(dr["NextSiteVisit"]);
                                objProspectsSiteVisit.LeadType = Convert.ToString(dr["LeadType"]);
                                objCPPropertyStatus.listLead.Add(objProspectsSiteVisit);
                            }
                        }
                    }
                }
                return objCPPropertyStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CP360View GetCP360DegreeView(Filters360degree objDashBoard)
        {
            try
            {
                string Result = string.Empty;
                DataSet dsResult;
                CP360View objCP360View = new CP360View();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@CPID", objDashBoard.CPID);
                cmd.Parameters.AddWithValue("@CommunicationId", objDashBoard.CommunicationId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CP_360_DEGREE_VIEW");
                if(dsResult.Tables.Count>0)
                {
                    if(objDashBoard.Flag==1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objCP360View.CPID = Convert.ToInt64(dsResult.Tables[0].Rows[0]["CPID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CPID"]);
                            objCP360View.CPName = Convert.ToString(dsResult.Tables[0].Rows[0]["CPNAME"]);
                            objCP360View.Entity = Convert.ToString(dsResult.Tables[0].Rows[0]["Entity"]);
                            objCP360View.Address = Convert.ToString(dsResult.Tables[0].Rows[0]["Address"]);
                            //objCP360View.Address2 = Convert.ToString(dsResult.Tables[0].Rows[0]["Address2"]);
                            objCP360View.PanCard = Convert.ToString(dsResult.Tables[0].Rows[0]["PANCARD"]);
                            objCP360View.GSTNO = Convert.ToString(dsResult.Tables[0].Rows[0]["GSTNO"]);
                            objCP360View.Email = Convert.ToString(dsResult.Tables[0].Rows[0]["EMAIL"]);
                            objCP360View.Mobile = Convert.ToString(dsResult.Tables[0].Rows[0]["MOBILE"]);
                            objCP360View.AadharNo = Convert.ToString(dsResult.Tables[0].Rows[0]["AADHARNO"]);
                            objCP360View.RERAID = Convert.ToString(dsResult.Tables[0].Rows[0]["RERAID"]);
                        }
                    }else if(objDashBoard.Flag==4)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objCP360View.BankDetail = new BankDetails();
                            objCP360View.BankDetail.CPID= Convert.ToInt64(dsResult.Tables[0].Rows[0]["CPID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CPID"]);
                            objCP360View.BankDetail.AccountHolderName=Convert.ToString(dsResult.Tables[0].Rows[0]["ACCOUNTHOLDERNAME"]);
                            objCP360View.BankDetail.BankAccountNO = Convert.ToString(dsResult.Tables[0].Rows[0]["BANKACCOUNTNO"]);
                            objCP360View.BankDetail.BankTypeName = Convert.ToString(dsResult.Tables[0].Rows[0]["BANKTYPENAME"]);
                            objCP360View.BankDetail.BankName = Convert.ToString(dsResult.Tables[0].Rows[0]["BANKNAME"]);
                            objCP360View.BankDetail.IFSCCode = Convert.ToString(dsResult.Tables[0].Rows[0]["IFSCCODE"]);
                            objCP360View.BankDetail.BranchName = Convert.ToString(dsResult.Tables[0].Rows[0]["BRANCHNAME"]);
                            objCP360View.BankDetail.BranchAddress = Convert.ToString(dsResult.Tables[0].Rows[0]["BRANCHADDRESS"]);
                            objCP360View.BankDetail.MICRCode = Convert.ToString(dsResult.Tables[0].Rows[0]["MICRCODE"]);
                        }
                    }else if(objDashBoard.Flag==2)
                    {
                        objCP360View.SelectedCommunication = new Communication();
                        objCP360View.lstCommunication = new List<Communication>();
                        //if (dsResult.Tables[0].Rows.Count > 0)
                        //{
                        //    objCP360View.SelectedCommunication.CommunicationId = Convert.ToInt64(dsResult.Tables[0].Rows[0]["CommunicationId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CommunicationId"]);
                        //    objCP360View.SelectedCommunication.Date = Convert.ToString(dsResult.Tables[0].Rows[0]["Date"]);
                        //    objCP360View.SelectedCommunication.ModeOfContact = Convert.ToString(dsResult.Tables[0].Rows[0]["ModeOfCommunication"]);
                        //    objCP360View.SelectedCommunication.Agenda = Convert.ToString(dsResult.Tables[0].Rows[0]["Agenda"]);
                        //    objCP360View.SelectedCommunication.ContactPerson = Convert.ToString(dsResult.Tables[0].Rows[0]["RMName"]);
                        //    objCP360View.SelectedCommunication.MOM = Convert.ToString(dsResult.Tables[0].Rows[0]["Details"]);
                        //    objCP360View.SelectedCommunication.MailAttachment = Convert.ToString(dsResult.Tables[0].Rows[0]["MailAttachment"]);
                        //}
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dr in dsResult.Tables[0].Rows)
                            {
                                Communication objCommunication = new Communication();
                                objCommunication.CommunicationId = Convert.ToInt64(dr["CommunicationId"] == DBNull.Value ? 0 : dr["CommunicationId"]);
                                objCommunication.Date = Convert.ToString(dr["Date"]);
                                objCommunication.ModeOfContact = Convert.ToString(dr["ModeOfCommunication"]);
                                objCommunication.Agenda = Convert.ToString(dr["Agenda"]);
                                objCommunication.ContactPerson = Convert.ToString(dr["RMName"]);
                                //objCommunication.MOM = Convert.ToString(dr["Details"]);
                                objCP360View.lstCommunication.Add(objCommunication);
                            }
                        }
                    }else if(objDashBoard.Flag==3)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objCP360View.SelectedCommunication = new Communication();
                            objCP360View.SelectedCommunication.CommunicationId= Convert.ToInt64(dsResult.Tables[0].Rows[0]["CommunicationId"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CommunicationId"]);
                            objCP360View.SelectedCommunication.Date = Convert.ToString(dsResult.Tables[0].Rows[0]["Date"]);
                            objCP360View.SelectedCommunication.ModeOfContact = Convert.ToString(dsResult.Tables[0].Rows[0]["ModeOfCommunication"]);
                            objCP360View.SelectedCommunication.Agenda = Convert.ToString(dsResult.Tables[0].Rows[0]["Agenda"]);
                            objCP360View.SelectedCommunication.ContactPerson = Convert.ToString(dsResult.Tables[0].Rows[0]["RMName"]);
                            objCP360View.SelectedCommunication.MOM = Convert.ToString(dsResult.Tables[0].Rows[0]["Details"]);
                            objCP360View.SelectedCommunication.MailAttachment = Convert.ToString(dsResult.Tables[0].Rows[0]["MailAttachment"]);
                        }
                    }
                }

                return objCP360View;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CPPropertyDashboard GetCPPropertyDashboard(Filters360degree objDashBoard)
        {
            try
            {
                string Result = string.Empty;
                DataSet dsResult;
                CPPropertyDashboard objCPPropertyDashboard = new CPPropertyDashboard();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@CPID", objDashBoard.CPID);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@Currency", objDashBoard.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_CP_PROPERTY_DASHBOARD");
                if (dsResult.Tables.Count > 0)
                {
                    if (objDashBoard.Flag == 1)
                    {
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.CPID = Convert.ToInt64(dsResult.Tables[0].Rows[0]["CPID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CPID"]);
                            objCPPropertyDashboard.PropertyCount = Convert.ToString(dsResult.Tables[0].Rows[0]["PropertyCount"]);
                            objCPPropertyDashboard.WalkIn = Convert.ToString(dsResult.Tables[0].Rows[0]["WalkIn"]);
                            objCPPropertyDashboard.FollowUp = Convert.ToString(dsResult.Tables[0].Rows[0]["FollowUp"]);
                            objCPPropertyDashboard.Intrested = Convert.ToString(dsResult.Tables[0].Rows[0]["Intrested"]);
                            objCPPropertyDashboard.Booked = Convert.ToString(dsResult.Tables[0].Rows[0]["Booked"]);
                        }
                        if (dsResult.Tables[1].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.LstLeadType = new List<LeadQualification>();
                            foreach (DataRow dr in dsResult.Tables[1].Rows)
                            {
                                LeadQualification objLQ = new LeadQualification();
                                objLQ.LeadType = Convert.ToString(dr["LeadType"]);
                                objLQ.WalkIn = Convert.ToString(dr["WalkIn"]);
                                objLQ.FollowUp = Convert.ToString(dr["FollowUp"]);
                                objCPPropertyDashboard.LstLeadType.Add(objLQ);
                            }
                        }
                        if (dsResult.Tables[2].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.CPPropertWalkIn = new CPPropertWalkIn();
                            objCPPropertyDashboard.CPPropertWalkIn.CPID = Convert.ToInt64(dsResult.Tables[2].Rows[0]["CPID"] == DBNull.Value ? 0 : dsResult.Tables[2].Rows[0]["CPID"]);
                            objCPPropertyDashboard.CPPropertWalkIn.PropertyCount = Convert.ToString(dsResult.Tables[2].Rows[0]["PropertyCount"]);
                            objCPPropertyDashboard.CPPropertWalkIn.WalkIn = Convert.ToString(dsResult.Tables[2].Rows[0]["WalkIn"]);
                            objCPPropertyDashboard.CPPropertWalkIn.Hot = Convert.ToString(dsResult.Tables[2].Rows[0]["Hot"]);
                            objCPPropertyDashboard.CPPropertWalkIn.Warm = Convert.ToString(dsResult.Tables[2].Rows[0]["Warm"]);
                            objCPPropertyDashboard.CPPropertWalkIn.Cold = Convert.ToString(dsResult.Tables[2].Rows[0]["Cold"]);
                        }
                        if (dsResult.Tables[3].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.CPPaymentDone = new CPPayment();
                            objCPPropertyDashboard.CPPaymentDone.CPID = Convert.ToInt64(dsResult.Tables[3].Rows[0]["CPID"] == DBNull.Value ? 0 : dsResult.Tables[3].Rows[0]["CPID"]);
                            objCPPropertyDashboard.CPPaymentDone.ProjectDone = Convert.ToString(dsResult.Tables[3].Rows[0]["ProjectDone"]);
                            objCPPropertyDashboard.CPPaymentDone.DealDone = Convert.ToString(dsResult.Tables[3].Rows[0]["DealDone"]);
                            objCPPropertyDashboard.CPPaymentDone.TotalPayment = Convert.ToString(dsResult.Tables[3].Rows[0]["TotalPayment"]);
                            objCPPropertyDashboard.CPPaymentDone.PaymentDone = Convert.ToString(dsResult.Tables[3].Rows[0]["PaymentDone"]);
                            objCPPropertyDashboard.CPPaymentDone.AmountDue = Convert.ToString(dsResult.Tables[3].Rows[0]["AmountDue"]);
                        }
                        if (dsResult.Tables[4].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.UpcomingBirthday = new List<UpcomingBirthday>();
                            foreach (DataRow dr in dsResult.Tables[4].Rows)
                            {
                                UpcomingBirthday objUpcomingBirthday = new UpcomingBirthday();
                                objUpcomingBirthday.PROSPECTID = Convert.ToInt64(dr["PROSPECTID"] == DBNull.Value ? 0 : dr["PROSPECTID"]);
                                objUpcomingBirthday.Name = Convert.ToString(dr["Name"]);
                                objUpcomingBirthday.DOB = Convert.ToString(dr["DOB"]);
                                objUpcomingBirthday.Mobile = Convert.ToString(dr["Mobile"]);
                                objUpcomingBirthday.PropertyName = Convert.ToString(dr["PropertyName"]);
                                objCPPropertyDashboard.UpcomingBirthday.Add(objUpcomingBirthday);
                            }
                        }
                        if (dsResult.Tables[5].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.UpcomingEvents = new List<UpcomingEvents>();
                            foreach (DataRow dr in dsResult.Tables[5].Rows)
                            {
                                UpcomingEvents objUpcomingEvents = new UpcomingEvents();
                                objUpcomingEvents.EventId = Convert.ToInt64(dr["PropertyEventId"] == DBNull.Value ? 0 : dr["PropertyEventId"]);
                                objUpcomingEvents.EventName = Convert.ToString(dr["EventName"]);
                                objUpcomingEvents.Location = Convert.ToString(dr["Location"]);
                                objUpcomingEvents.CityName = Convert.ToString(dr["CityName"]);
                                objUpcomingEvents.Date = Convert.ToString(dr["Date"]);
                                objUpcomingEvents.Description = Convert.ToString(dr["Description"]);
                                objCPPropertyDashboard.UpcomingEvents.Add(objUpcomingEvents);
                            }
                        }
                        if (dsResult.Tables[6].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.BookingStatus = new BookingStatus();
                            objCPPropertyDashboard.BookingStatus.BookedFlat = Convert.ToString(dsResult.Tables[6].Rows[0]["BookedFlat"]);
                            objCPPropertyDashboard.BookingStatus.BookedPer = Convert.ToDecimal(dsResult.Tables[6].Rows[0]["BookedPer"] == DBNull.Value ? 0 : dsResult.Tables[6].Rows[0]["BookedPer"]);
                            objCPPropertyDashboard.BookingStatus.Color = Convert.ToString(dsResult.Tables[6].Rows[0]["Color"]);
                        }
                        if (dsResult.Tables[7].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.BookingStatus.BookingStatusSummary = new List<BookingStatusSummary>();
                            foreach (DataRow dr in dsResult.Tables[7].Rows)
                            {
                                BookingStatusSummary objBookingStatusSummary = new BookingStatusSummary();
                                objBookingStatusSummary.MileStoneName = Convert.ToString(dr["MileStoneName"]);
                                objBookingStatusSummary.CustomerCount = Convert.ToString(dr["CustomerCount"]);
                                objBookingStatusSummary.Percentage = Convert.ToDecimal(dr["Percentage"] == DBNull.Value ? 0 : dr["Percentage"]);
                                objBookingStatusSummary.Color = Convert.ToString(dr["Color"]);
                                objCPPropertyDashboard.BookingStatus.BookingStatusSummary.Add(objBookingStatusSummary);
                            }
                        }

                        if (dsResult.Tables[8] != null && dsResult.Tables[8].Rows.Count > 0)
                        {
                            objCPPropertyDashboard.RankList = new List<Entity>();
                            foreach (DataRow dr in dsResult.Tables[8].Rows)
                            {
                                Entity oEntity = new Entity();
                                oEntity.Name = Convert.ToString(dr["Name"]);
                                oEntity.Value = Convert.ToString(dr["RankVal"]);
                                objCPPropertyDashboard.RankList.Add(oEntity);
                            }
                        }
                    }
                }
                return objCPPropertyDashboard;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public PaymentSummary GetPaymentSummary(Filters360degree objDashBoard,int RoleId)
        {
            try
            {
                PaymentSummary objPaymentSummary = new PaymentSummary();
                string Result = string.Empty;
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objDashBoard.Flag);
                cmd.Parameters.AddWithValue("@CPID", objDashBoard.CPID);
                cmd.Parameters.AddWithValue("@PropertyId", objDashBoard.PropertyId);
                cmd.Parameters.AddWithValue("@Currency", objDashBoard.Currency);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_CP_CUSTOMER_PAYMENT_SUMMARY");
                if (dsResult.Tables.Count > 0)
                {
                    if (objDashBoard.Flag == 1)
                    {
                        if(dsResult.Tables[0].Rows.Count>0)
                        {
                            objPaymentSummary.Payment = new CPPayment();
                            objPaymentSummary.Payment.CPID = Convert.ToInt64(dsResult.Tables[0].Rows[0]["CPID"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["CPID"]);
                            objPaymentSummary.Payment.ProjectDone = Convert.ToString(dsResult.Tables[0].Rows[0]["ProjectDone"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["ProjectDone"]);
                            objPaymentSummary.Payment.DealDone = Convert.ToString(dsResult.Tables[0].Rows[0]["DealDone"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["DealDone"]);
                            objPaymentSummary.Payment.TotalPayment = Convert.ToString(dsResult.Tables[0].Rows[0]["TotalPayment"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["TotalPayment"]);
                            objPaymentSummary.Payment.PaymentDone = Convert.ToString(dsResult.Tables[0].Rows[0]["PaymentDone"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["PaymentDone"]);
                            objPaymentSummary.Payment.AmountDue = Convert.ToString(dsResult.Tables[0].Rows[0]["AmountDue"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["AmountDue"]);
                        }
                        if(dsResult.Tables[1].Rows.Count>0)
                        {
                            objPaymentSummary._CPCustomerPaymentSummary = new List<CPCustomerPaymentSummary>();
                            foreach(DataRow dr in dsResult.Tables[1].Rows)
                            {
                                CPCustomerPaymentSummary objCPCustomerPaymentSummary = new CPCustomerPaymentSummary();
                                objCPCustomerPaymentSummary.Customer_ID = Convert.ToInt64(dr["Customer_ID"] == DBNull.Value ? 0 : dr["Customer_ID"]);
                                objCPCustomerPaymentSummary.Date = Convert.ToString(dr["Date"]);
                                objCPCustomerPaymentSummary.CustomerName = Convert.ToString(dr["Name"]);
                                objCPCustomerPaymentSummary.PropertyName = Convert.ToString(dr["PropertyName"]);
                                objCPCustomerPaymentSummary.IsRegistration = Convert.ToBoolean(dr["IsRegistration"]==DBNull.Value?false:dr["IsRegistration"]);
                                objCPCustomerPaymentSummary.InvoiceAmount = Convert.ToString(dr["InvoiceAmount"] == DBNull.Value ? 0 : dr["InvoiceAmount"]);
                                objCPCustomerPaymentSummary.PaymentDone = Convert.ToString(dr["PaymentDone"] == DBNull.Value ? 0 : dr["PaymentDone"])+" %";
                                objCPCustomerPaymentSummary.GenerateInvoice = Convert.ToString(dr["GenerateInvoice"]);
                                objCPCustomerPaymentSummary.ProcessPayment = Convert.ToString(dr["ProcessPayment"]);
                                objCPCustomerPaymentSummary.PropertyId = Convert.ToInt32(dr["PropertyId"]);
                                objPaymentSummary._CPCustomerPaymentSummary.Add(objCPCustomerPaymentSummary);
                            }
                        }
                    }
                }
                return objPaymentSummary;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GenerateInvoiceForClientPayment(Customer oClient, long EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ClientId", oClient.Customer_Id);
                cmd.Parameters.AddWithValue("@PropertyId", oClient.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GENERATE_CP_PAYMENT_INVOICE");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveInvoicePathInDB(Customer oClient, long EmpId)
        {
            string Result = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ClientId", oClient.Customer_Id);
                cmd.Parameters.AddWithValue("@PropertyId", oClient.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@IsInvoiceSaved", 1);
                dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GENERATE_CP_PAYMENT_INVOICE");
                Result = Utilities.dtToJson(dt);
                return Result;
            }
            catch (Exception ex)
            {
                Utilities.ApiErrorLog(ex.Message.ToString(), @"CPBAL\SaveInvoicePathInDB", "API");
                return Result;
            }
        }

        public List<CPSupportCost> GetCPSupportCost(ReportParam objParam)
        {
            try
            {
                List<CPSupportCost> objLstCPCost = new List<CPSupportCost>();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@CPID", objParam.CPID);
                cmd.Parameters.AddWithValue("@IsCPRegister", objParam.IsCPRegister);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_CP_SUPPORT_COST_DETAILS");
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    { 
                        CPSupportCost objCPCost = new CPSupportCost();
                        objCPCost.SupportCostId = Convert.ToInt32(dr["SupportCostId"]==DBNull.Value?0: dr["SupportCostId"]); 
                        objCPCost.CreatedDate = Convert.ToString(dr["CreatedDate"]);
                        objCPCost.SupportTypeId = Convert.ToInt32(dr["SupportTypeId"]==DBNull.Value?0:dr["SupportTypeId"]);
                        objCPCost.SupportType = Convert.ToString(dr["SupportType"]);
                        objCPCost.Unit = Convert.ToInt32(dr["Unit"]==DBNull.Value?0: dr["Unit"]);
                        objCPCost.Cost = Convert.ToDecimal(dr["Cost"] == DBNull.Value ? 0 :dr["Cost"]);
                        objCPCost.TotalCost = Convert.ToDecimal(dr["TotalCost"]==DBNull.Value?0: dr["TotalCost"]);
                        objCPCost.PropertyId = Convert.ToInt32(dr["PropertyId"]==DBNull.Value?0:dr["PropertyId"]);
                        objCPCost.PropertyName = Convert.ToString(dr["PropertyName"]);
                        objLstCPCost.Add(objCPCost);
                    }
                }
                return objLstCPCost;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SaveUpdateCPSupportCost(string XmlData,int EmpId,int Flag)
        {
            try
            {
                string JResult = string.Empty;
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@XmlData", XmlData);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_CP_SUPPORT_COST_DETAILS");
                JResult = Utilities.dtToJson(dt);
                return JResult;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public CPSupportCost GetSelectedCPCost(CPSupportCost objParam)
        {
            try
            {
                CPSupportCost objCPSupport = new CPSupportCost();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@SupportCostId", objParam.SupportCostId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_CP_SUPPORT_COST_DETAILS");
                if(dt.Rows.Count>0)
                {
                    objCPSupport.SupportCostId = Convert.ToInt32(dt.Rows[0]["SupportCostId"]==DBNull.Value?0: dt.Rows[0]["SupportCostId"]);
                    objCPSupport.SupportTypeId = Convert.ToInt32(dt.Rows[0]["SupportTypeId"] == DBNull.Value ? 0 : dt.Rows[0]["SupportTypeId"]);
                    objCPSupport.CPID = Convert.ToInt32(dt.Rows[0]["CPID"] == DBNull.Value ? 0 : dt.Rows[0]["CPID"]);
                    objCPSupport.IsCPRegister = Convert.ToBoolean(dt.Rows[0]["IsCPRegister"]);
                    objCPSupport.CPName = Convert.ToString(dt.Rows[0]["CPName"]);
                    objCPSupport.Cost = Convert.ToDecimal(dt.Rows[0]["Cost"] == DBNull.Value ? 0 : dt.Rows[0]["Cost"]);
                    objCPSupport.Unit = Convert.ToInt32(dt.Rows[0]["Unit"]==DBNull.Value?0: dt.Rows[0]["Unit"]);
                    objCPSupport.SupportTypeId = Convert.ToInt32(dt.Rows[0]["SupportTypeId"]==DBNull.Value?0: dt.Rows[0]["SupportTypeId"]);
                    objCPSupport.PropertyId = Convert.ToInt32(dt.Rows[0]["PropertyId"]==DBNull.Value?0:dt.Rows[0]["PropertyId"]);
                    objCPSupport.PropertyName = Convert.ToString(dt.Rows[0]["PropertyName"]); 
                }
                return objCPSupport;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string UpdateCPDetails(string CPXML, int EmpId, int RoleId,int Flag)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_UPDATE_CP_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string SaveCPAttendance(string CPXML, int UserId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XmlData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EmpId", UserId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_CP_ATTENDANCE");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<_CPAttendance> GetCPAttendance(string CPXML, int UserId, int RoleId)
        {
            try
            {
                List<_CPAttendance> lstObjCPA = new List<_CPAttendance>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XmlData", CPXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", UserId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_SAVE_CP_ATTENDANCE");
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        _CPAttendance objCPA = new _CPAttendance();
                        objCPA.CPName = Convert.ToString(dr["CPName"]);
                        objCPA.IsCPRegister = Convert.ToString(dr["IsCPRegister"]);
                        objCPA.PropertyName = Convert.ToString(dr["PropertyName"]);
                        objCPA.AttendanceDate = Convert.ToString(dr["AttendanceDate"]);
                        objCPA.Mobile = Convert.ToString(dr["Mobile"]);
                        lstObjCPA.Add(objCPA);
                    }
                }
                return lstObjCPA;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
