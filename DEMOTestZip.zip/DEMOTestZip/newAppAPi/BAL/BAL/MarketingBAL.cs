﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;
using System.Xml.Linq;
using System.Configuration;

namespace BAL
{
    public class MarketingBAL
    {
        SqlCommand cmd;
        public DataSet GetMarketingDocDetails(MarketingFilter Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_MARKETING_DOC_DETAILS");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
