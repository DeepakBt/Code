﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using DAL;

namespace BAL
{
    public class LeadBAL
    {
        SqlCommand cmd;

        public LeadMasterData GetMasterDataForSiteEnquiryForm()
        {
            LeadMasterData objLeadMasterData = null;
            try
            {
                DataSet ds;
                Dropdown dd;
                
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_LEAD_MASTER_DATA");

                if (ds != null && ds.Tables.Count > 0)
                {
                    objLeadMasterData = new LeadMasterData();
                    objLeadMasterData.SourceList = new List<Dropdown>();
                    objLeadMasterData.ReligionList = new List<Dropdown>();
                    objLeadMasterData.OccupationList = new List<Dropdown>();
                    objLeadMasterData.VisitorTypeList = new List<Dropdown>();
                    objLeadMasterData.LeadSubSourceList = new List<LeadSubSource>();

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objLeadMasterData.ReligionList.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objLeadMasterData.SourceList.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {
                        LeadSubSource lsd = new LeadSubSource();
                        lsd.Id = Convert.ToInt32(dr["Id"]);
                        lsd.SourceId = Convert.ToInt32(dr["SourceId"]);
                        lsd.SubSource = Convert.ToString(dr["Value"]);
                        objLeadMasterData.LeadSubSourceList.Add(lsd);
                    }

                    foreach (DataRow dr in ds.Tables[3].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objLeadMasterData.OccupationList.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[4].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Value"]);
                        objLeadMasterData.VisitorTypeList.Add(dd);
                    }
                }

                return objLeadMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string InsertSiteEnquiryForm(string LeadXML, long EmpId,int Flag, long RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", LeadXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_SITE_ENQUIRYFORM");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertBasicSiteEnquiryForm(string LeadXML, long EmpId, int Flag, long RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", LeadXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_SITE_ENQUIRYFORM");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetDetailsOnSearch(string SearchText,int Flag)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@SearchText", SearchText);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd,"USP_CREMA_SEARCH");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string VerifyProspectOTP(string LeadXML, long EmpId, int Flag, long RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", LeadXML);
                cmd.Parameters.AddWithValue("@Flag", Flag);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_SITE_ENQUIRYFORM");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetProspectDetailsById(long ProspectId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ProspectId", ProspectId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_PROSPECT_DETAILS_BY_ID");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertGeneralLeadDetails(string LeadXML)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", LeadXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_LEAD_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string InsertTeleCallerLeadDetails(string LeadXML,int EmpId,bool BrochureFlag,int RoleId,out TeleCallerLead ObjTeleCallerLead)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", LeadXML);
                cmd.Parameters.AddWithValue("@Flag", 5);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@BrochureFlag", BrochureFlag);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_LEAD_DETAILS");

                ObjTeleCallerLead = new TeleCallerLead();
                ObjTeleCallerLead.LeadId = Convert.ToInt32(dt.Rows[0]["LeadId"]);
                ObjTeleCallerLead.WhatsAppNo = Convert.ToString(dt.Rows[0]["WhatsAppNo"]);
                dt.Columns.Remove("LeadId");
                dt.Columns.Remove("WhatsAppNo");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public List<SiteVisitLead> GetSiteVisitLead(DashboardSelectedParams objParam)
        {
            try
            {
                List<SiteVisitLead> objLstSV = new List<SiteVisitLead>();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag",objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId",objParam.PropertyId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_LEAD_SITE_VISIT");
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        SiteVisitLead objSV = new SiteVisitLead();
                        objSV.LeadId = Convert.ToInt32(dr["LeadId"] == DBNull.Value ? 0 : dr["LeadId"]);
                        objSV.LeadName = Convert.ToString(dr["LeadName"]);
                        objSV.Mobile = Convert.ToString(dr["Mobile"]);
                        objLstSV.Add(objSV);
                    }
                }
                return objLstSV;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Lead360> GetLeadList(Lead360Param objParam)
        {
            try
            {
                List<Lead360> objLstLead = new List<Lead360>();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag",1);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SearchTxt", objParam.SearchTxt);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_LEAD_360");
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Lead360 objLead = new Lead360();
                        objLead.LeadId = Convert.ToInt32(dr["LeadId"] == DBNull.Value ? 0 : dr["LeadId"]);
                        objLead.LeadName = Convert.ToString(dr["LeadName"]);
                        objLead.Mobile = Convert.ToString(dr["Mobile"]);
                        objLead.Email = Convert.ToString(dr["Email"]);
                        objLead.PropertyName = Convert.ToString(dr["PropertyName"]);
                        objLead.Source = Convert.ToString(dr["SourceName"]);
                        objLead.SiteVisited = Convert.ToString(dr["SiteVisited"]);
                        objLead.LeadStatus = Convert.ToString(dr["LeadStatus"]);
                        objLstLead.Add(objLead);
                    }
                }
                return objLstLead;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public _Lead360Details GetLead360Details(Lead360Param objParam,long EmpId,int RoleId)
        {
            try
            {
                _Lead360Details objlead = new _Lead360Details();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@LeadId", objParam.LeadId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_LEAD_360");
                if (dt.Rows.Count > 0)
                {
                    objlead.LeadId = Convert.ToInt32(dt.Rows[0]["LeadId"] == DBNull.Value ? 0 : dt.Rows[0]["LeadId"]);
                    objlead.LeadName = Convert.ToString(dt.Rows[0]["LeadName"]);
                    objlead.Gender = Convert.ToString(dt.Rows[0]["Gender"]);
                    objlead.Mobile = Convert.ToString(dt.Rows[0]["Mobile"]);
                    objlead.Email = Convert.ToString(dt.Rows[0]["Email"]);
                    objlead.PropertyName = Convert.ToString(dt.Rows[0]["PropertyName"]);
                    objlead.Source = Convert.ToString(dt.Rows[0]["SourceName"]);
                    objlead.SiteVisited = Convert.ToString(dt.Rows[0]["SiteVisited"]);
                    objlead.LeadStatus = Convert.ToString(dt.Rows[0]["LeadStatus"]);
                    objlead.Budget = Convert.ToString(dt.Rows[0]["Budget"]);
                    objlead.Configuration = Convert.ToString(dt.Rows[0]["Configuration"]);
                    objlead.Address = Convert.ToString(dt.Rows[0]["Address"]);
                    objlead.Country = Convert.ToString(dt.Rows[0]["Country"]);
                    objlead.Pincode = Convert.ToString(dt.Rows[0]["Pincode"]);
                    objlead.District = Convert.ToString(dt.Rows[0]["DistrictName"]);
                    objlead.ResidentialLocation = Convert.ToString(dt.Rows[0]["ResidentialLocation"]);
                    objlead.Comments = Convert.ToString(dt.Rows[0]["Comments"]);
                    objlead.LeadTypeId = Convert.ToInt32(dt.Rows[0]["LeadTypeId"]);
                    objlead.LeadStatusId = Convert.ToInt32(dt.Rows[0]["LeadStatusId"]);
                    objlead.CPID = Convert.ToInt32(dt.Rows[0]["CPID"]);
                    objlead.IsCPRegister = Convert.ToBoolean(dt.Rows[0]["IsRegisteredCP"]);
                    objlead.IsEdit = Convert.ToBoolean(dt.Rows[0]["isedit"]);
                    objlead.PropertyId = Convert.ToInt32(dt.Rows[0]["PropertyId"]);
                    objlead.SiteVisitDate = Convert.ToString(dt.Rows[0]["SiteVisitDate"]);
                    objlead.CampaignId = Convert.ToInt32(dt.Rows[0]["CampaignId"]);

                }
                return objlead;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string GetProspectDetails(Prospect oProspect)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ProspectId", oProspect.Prospectid);
                cmd.Parameters.AddWithValue("@IsLead", oProspect.IsLead);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_PROSPECT_DETAILS_BY_ID");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string PostProspectDetails(Prospect oProspect)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ProspectId", oProspect.Prospectid);
                cmd.Parameters.AddWithValue("@IsLead", oProspect.IsLead);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_PROSPECT_DETAILS_BY_ID");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
