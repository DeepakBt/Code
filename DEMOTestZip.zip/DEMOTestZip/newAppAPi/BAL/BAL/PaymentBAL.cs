﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BAL
{
    public class PaymentBAL
    {
        SqlCommand cmd;

        public string GetPaymentPendingClients(long EmpId,int PropertyId,int FlagId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", FlagId);
                cmd.Parameters.AddWithValue("@PropertyId", PropertyId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_PAYMENT_PENDING_CLIENTS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CostSheetMasterData GetCostSheetMasterData(long ClientId)
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                Entity en;
                Tranch tranch1;
                CostSheetMasterData objCostSheetMasterData = new CostSheetMasterData();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ClientId", ClientId);

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_COST_SHEET_MASTER");

                if (ds != null && ds.Tables.Count > 0)
                {
                    objCostSheetMasterData.CostsheetParamMst = new List<Entity>();
                    objCostSheetMasterData.PlanMst = new List<Dropdown>();
                    objCostSheetMasterData.PayScheduleMst = new List<PaySchedule>();
                    objCostSheetMasterData.OtherChargesMst = new List<Entity>();
                    objCostSheetMasterData.TaxTypeMst = new List<Entity>();

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        objCostSheetMasterData.PlanMst.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        en = new Entity();
                        en.Id = Convert.ToInt32(dr["Id"]);
                        en.Name = Convert.ToString(dr["Name"]);
                        en.Value = Convert.ToString(dr["Value"]);
                        objCostSheetMasterData.CostsheetParamMst.Add(en);
                    }

                    foreach (DataRow dr in ds.Tables[3].Rows)
                    {
                        PaySchedule ps = new PaySchedule();
                        ps.tranches = new List<Tranch>();

                        ps.PayScheduleId = Convert.ToInt32(dr["Id"]);
                        ps.PayScheduleName = Convert.ToString(dr["Name"]);
                        ps.PayPerc = Convert.ToDouble(dr["PayPerc"]);
                        ps.AgreementValue = Convert.ToDouble(dr["AgreeVal"]);
                        ps.PrincipalAmt = Convert.ToDouble(dr["PrincAmt"]);
                        ps.GST = Convert.ToDouble(dr["GST"]);
                        ps.TDS = Convert.ToDouble(dr["TDS"]);
                        ps.DueDate = Convert.ToString(dr["DueDate"]);
                        ps.IsPaymentComplete = Convert.ToInt32(dr["IsPaymentComplete"]);
                        ps.IsPaymentInitiated = Convert.ToBoolean(dr["IsPaymentInitiated"]);

                        if (ds.Tables.Count > 8 && ds.Tables[8].Rows.Count > 0)
                        {
                            DataRow[] oTranches = ds.Tables[8].Select("MappingScheduleId = '" + ps.PayScheduleId + "'");
                            if (oTranches.Length > 1)
                            {
                                foreach (DataRow dr1 in oTranches)
                                {
                                    tranch1 = new Tranch();
                                    tranch1.TranchId = Convert.ToInt32(dr1["TranchId"]);
                                    tranch1.PrincipalAmt = Convert.ToDouble(dr1["PrincAmt"]);
                                    tranch1.GST = Convert.ToDouble(dr1["GST"]);
                                    tranch1.TDS = Convert.ToDouble(dr1["TDS"]);
                                    tranch1.DueDate = Convert.ToString(dr1["DueDate"]);
                                    tranch1.IsEdit = Convert.ToInt32(dr1["IsEdit"]);
                                    tranch1.PayScheduleId = Convert.ToInt32(dr1["MappingScheduleId"]);
                                    ps.tranches.Add(tranch1);
                                }
                            }
                        }
                        objCostSheetMasterData.PayScheduleMst.Add(ps);
                    }

                    foreach (DataRow dr in ds.Tables[4].Rows)
                    {
                        en = new Entity();
                        en.Id = Convert.ToInt32(dr["Id"]);
                        en.Name = Convert.ToString(dr["Name"]);
                        en.Value = Convert.ToString(dr["Value"]);
                        objCostSheetMasterData.OtherChargesMst.Add(en);
                    }

                    foreach (DataRow dr in ds.Tables[5].Rows)
                    {
                        en = new Entity();
                        en.Id = Convert.ToInt32(dr["Id"]);
                        en.Value = Convert.ToString(dr["Value"]);
                        en.Name = Convert.ToString(dr["Name"]);
                        objCostSheetMasterData.TaxTypeMst.Add(en);
                    }

                    objCostSheetMasterData.AgreementValue = Convert.ToInt32(ds.Tables[2].Rows[0]["AgreementValue"]);
                    if (ds.Tables.Count > 6 && ds.Tables[6].Rows.Count > 0)
                    {
                        objCostSheetMasterData.PaymentPlanId = Convert.ToInt32(ds.Tables[6].Rows[0]["PaymentPlanId"]);
                    }

                    if (ds.Tables.Count > 7 && ds.Tables[7].Rows.Count > 0)
                    {
                        objCostSheetMasterData.Params = Convert.ToDouble(ds.Tables[7].Rows[0]["Params"]);
                    }
                }

                return objCostSheetMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDocDetails(int FlagId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", FlagId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_DOC_DETAILS");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetClientPaymentsDetail(long clientId, int FlagId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", FlagId);
                cmd.Parameters.AddWithValue("@ClientId", clientId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_CLIENT_PAYMENT_DATA");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertClientCostSheet(string CustomerXML,long EmpId,int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CustomerXML);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_COST_SHEET");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public PaymentMasterData GetPaymentMaster(PaymentPageInputParam oParam)
        {
            try
            {
                DataSet ds;
                Dropdown dd;
                PayScheduleParticular oParticular = new PayScheduleParticular();
                PaymentMasterData oPaymentMasterData = new PaymentMasterData();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ClientId", oParam.ClientId);
                cmd.Parameters.AddWithValue("@IsOtherCharge", oParam.IsOtherCharge);
                cmd.Parameters.AddWithValue("@PaymentScheduleTypeId", oParam.PaymentScheduleTypeId);

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PAYMENTPAGE_MASTER");

                if (ds != null && ds.Tables.Count > 0)
                {
                    oPaymentMasterData.ParticularList = new List<PayScheduleParticular>();
                    oPaymentMasterData.PaymentTypeList = new List<Dropdown>();
                    oPaymentMasterData.PaymentModeList = new List<Dropdown>();
                    oPaymentMasterData.PaymentDueList = new List<Dropdown>();
                    oPaymentMasterData.PaymentTranches = new List<PaymentTranches>();
                    oPaymentMasterData.TranchesList = new List<Tranch>();

                    foreach(DataRow dr in ds.Tables[0].Rows)
                    {
                        oParticular = new PayScheduleParticular();
                        oParticular.Id = Convert.ToInt32(dr["Id"]);
                        oParticular.Name = Convert.ToString(dr["Name"]);
                        oParticular.IsOtherCharges = Convert.ToBoolean(dr["IsOtherChares"]);
                        oParticular.CompulsoryAmt = Convert.ToDouble(dr["CompulsoryAmt"]);
                        oPaymentMasterData.ParticularList.Add(oParticular);
                    }

                    foreach(DataRow dr in ds.Tables[1].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oPaymentMasterData.PaymentTypeList.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[2].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["Id"]);
                        dd.Value = Convert.ToString(dr["Name"]);
                        oPaymentMasterData.PaymentModeList.Add(dd);
                    }

                    foreach (DataRow dr in ds.Tables[3].Rows)
                    {
                        dd = new Dropdown();
                        dd.Id = Convert.ToInt32(dr["PaymentTypeId"]);
                        dd.Value = Convert.ToString(dr["DueAmt"]);
                        oPaymentMasterData.PaymentDueList.Add(dd);
                    }

                    if(ds.Tables.Count > 4 && ds.Tables[4]!= null)
                    {
                        foreach (DataRow dr in ds.Tables[4].Rows)
                        {
                            Tranch ot = new Tranch();
                            ot.TranchId = Convert.ToInt32(dr["TranchId"]);
                            oPaymentMasterData.TranchesList.Add(ot);
                        }

                        foreach (DataRow dr in ds.Tables[5].Rows)
                        {
                            PaymentTranches oTranch = new PaymentTranches();
                            oTranch.TranchId = Convert.ToInt32(dr["TranchId"]);
                            oTranch.Id = Convert.ToInt32(dr["Id"]);
                            oTranch.PaymentTypeId = Convert.ToInt32(dr["PaymentTypeId"]);
                            oTranch.PaymentTypeName = Convert.ToString(dr["TypeName"]);
                            oTranch.Amount = Convert.ToDouble(dr["Amount"]);
                            oTranch.IsPaymentDone = Convert.ToBoolean(dr["IsPaymentDone"]);
                            oTranch.PaymentModeId = Convert.ToInt32(dr["PaymentModeId"]);
                            oTranch.ChequeDate = Convert.ToString(dr["ChequeDate"]);
                            oTranch.ChequeNo = Convert.ToString(dr["ChequeNo"]);
                            oTranch.PaymentDate = Convert.ToString(dr["PaymentDate"]);
                            oTranch.BankId = Convert.ToInt32(dr["BankId"]);
                            oTranch.BankName = Convert.ToString(dr["BankName"]);
                            oTranch.IsEdit = false;
                            oTranch.IsValid = true;
                            oTranch.PaymentScheduleTypeId = Convert.ToInt32(dr["MappingScheduleId"]);
                            oPaymentMasterData.PaymentTranches.Add(oTranch);
                        }
                    }
                }

                return oPaymentMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string PostCPBrokerage(string CustomerXML, long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CustomerXML);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CP_BROKERAGE");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertClientPayment(string PaymentXML, long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", PaymentXML);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CLIENT_PAYMENT");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string PostClientRegFeesPayment(string CustomerXML, long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CustomerXML);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CLIENT_REGISTRATION_FEES");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public PaymentMasterData GetClientPaymentParticulars(PaymentPageInputParam oParam)
        {
            try
            {
                DataSet ds;
                PayScheduleParticular oParticular = new PayScheduleParticular();
                PaymentMasterData oPaymentMasterData = new PaymentMasterData();
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ClientId", oParam.ClientId);
                cmd.Parameters.AddWithValue("@IsOtherCharge", oParam.IsOtherCharge);
                cmd.Parameters.AddWithValue("@Flag", 1);

                ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PAYMENTPAGE_MASTER");

                if (ds != null && ds.Tables.Count > 0)
                {
                    oPaymentMasterData.ParticularList = new List<PayScheduleParticular>();
                   
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        oParticular = new PayScheduleParticular();
                        oParticular.Id = Convert.ToInt32(dr["Id"]);
                        oParticular.Name = Convert.ToString(dr["Name"]);
                        oParticular.IsOtherCharges = Convert.ToBoolean(dr["IsOtherChares"]);
                        oParticular.CompulsoryAmt = Convert.ToDouble(dr["CompulsoryAmt"]);
                        oPaymentMasterData.ParticularList.Add(oParticular);
                    }
                }

                return oPaymentMasterData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetClientRegCharges(string CustomerXML, long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", CustomerXML);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@Flag", 2);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CLIENT_REGISTRATION_FEES");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertClientOtherChargesPayment(string PaymentXML, long EmpId, int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", PaymentXML);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CLIENT_OTHER_CHARGES_PAYMENT");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
