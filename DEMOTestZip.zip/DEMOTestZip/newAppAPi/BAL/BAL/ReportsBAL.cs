﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using DAL;
using BAL.Prop;


namespace BAL
{
    public class ReportsBAL
    {
        SqlCommand cmd;
        public List<ReportCategory> GetListOfReports(int EmpId,int RoleId)
        {
            try
            {
                List<ReportCategory> objLstReportCat = new List<ReportCategory>();
                List<ReportSubCategory> objLstReportSubCat = new List<ReportSubCategory>();
                List<Reports> objLstReport = new List<Reports>();
                List<Param> objLstReportparam = new List<Param>();

                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@UserId",EmpId);
                cmd.Parameters.AddWithValue("@UserTypeId", RoleId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_LIST_OF_REPORTS");
                if(dt.Tables.Count>0)
                {
                    if(dt.Tables[0].Rows.Count>0)
                    {
                        foreach(DataRow dr in dt.Tables[0].Rows)
                        {
                            //Reports objReports = new Reports();
                            //objReports.ReportId = Convert.ToInt32(dr["ReportId"]==DBNull.Value?0: dr["ReportId"]);
                            //objReports.DisplayName = Convert.ToString(dr["ReportName"]);
                            //objReports.SpName = Convert.ToString(dr["SpName"]);
                            //objReports.ConnectionString = Convert.ToString(dr["SpName"]);
                            //objLstReport.Add(objReports);
                            ReportCategory oCat = new ReportCategory();
                            oCat.ListSubCategory = new List<ReportSubCategory>();
                            oCat.CategoryId = Convert.ToInt32(dr["CategoryId"] == DBNull.Value ? 0 : dr["CategoryId"]);
                            oCat.CategoryName = Convert.ToString(dr["CategoryName"]);

                            if(dt.Tables.Count > 1 && dt.Tables[1] != null)
                            {
                                DataRow[] oSubCategories = dt.Tables[1].Select("CategoryId = '" + oCat.CategoryId + "'");
                                if(oSubCategories.Length > 0)
                                {
                                    foreach(DataRow dr1 in oSubCategories)
                                    {
                                        ReportSubCategory oSubCat = new ReportSubCategory();
                                        oSubCat.ListReports = new List<Reports>();
                                        oSubCat.SubCategoryId = Convert.ToInt32(dr1["SubCategoryId"] == DBNull.Value ? 0 : dr1["SubCategoryId"]);
                                        oSubCat.SubCategoryName = Convert.ToString(dr1["SubCategoryName"]);

                                        DataRow[] oReports = dt.Tables[2].Select("SubCategoryId = " + oSubCat.SubCategoryId + " AND CategoryId = "+oCat.CategoryId+"");
                                        if (oReports.Length > 0)
                                        {
                                            foreach (DataRow dr2 in oReports)
                                            {
                                                Reports oReport = new Reports();
                                                oReport.ListParams = new List<Param>();
                                                oReport.ReportId = Convert.ToInt32(dr2["ReportId"] == DBNull.Value ? 0 : dr2["ReportId"]);
                                                oReport.DisplayName = Convert.ToString(dr2["ReportName"]);
                                                oReport.IsDisplay = Convert.ToBoolean(dr2["IsDisplayData"]);

                                                DataRow[] oReportParams = dt.Tables[3].Select("ReportId = " + oReport.ReportId + "");
                                                if (oReportParams.Length > 0)
                                                {
                                                    foreach (DataRow dr3 in oReportParams)
                                                    {
                                                        Param oParam = new Param();
                                                        oParam.ParamId = Convert.ToInt32(dr3["ParamId"] == DBNull.Value ? 0 : dr3["ParamId"]);
                                                        oParam.ParamName = Convert.ToString(dr3["ParamName"]);
                                                        oParam.DefaultValue = Convert.ToString(dr3["DefaultValue"]);
                                                        oReport.ListParams.Add(oParam);
                                                    }
                                                }

                                                oSubCat.ListReports.Add(oReport);
                                            }
                                        }
                                        oCat.ListSubCategory.Add(oSubCat);
                                    }
                                }
                            }

                            objLstReportCat.Add(oCat);
                        }
                    }
                }
                return objLstReportCat;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<RPT_SalesRMWiseData> GetSalesRMWiseData(int EmpId, ReportParam objParam)
        {
            try
            {
                List<RPT_SalesRMWiseData> lstObjSalesRM = new List<RPT_SalesRMWiseData>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", objParam.RMId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_RMWISE_SALES_DATA");
                if (oDT.Rows.Count > 0)
                {
                    foreach (DataRow dr in oDT.Rows)
                    {
                        RPT_SalesRMWiseData objSalesRMWiseData = new RPT_SalesRMWiseData();
                        objSalesRMWiseData.EmpID = Convert.ToInt32(dr["EmpID"] == DBNull.Value ? 0 : dr["EmpID"]);
                        objSalesRMWiseData.EmpName = Convert.ToString(dr["EmpName"]);
                        objSalesRMWiseData.SiteVisit = Convert.ToInt32(dr["SiteVisit"] == DBNull.Value ? 0 : dr["SiteVisit"]);
                        objSalesRMWiseData.Rejected = Convert.ToInt32(dr["Rejected"] == DBNull.Value ? 0 : dr["Rejected"]);
                        objSalesRMWiseData.Followup = Convert.ToInt32(dr["Followup"] == DBNull.Value ? 0 : dr["Followup"]);
                        objSalesRMWiseData.Eoi_Interested = Convert.ToInt32(dr["Eoi_Interested"] == DBNull.Value ? 0 : dr["Eoi_Interested"]);
                        objSalesRMWiseData.Closure = Convert.ToInt32(dr["Closure"] == DBNull.Value ? 0 : dr["Closure"]);
                        objSalesRMWiseData.MOMPending = Convert.ToInt32(dr["MOMPending"] == DBNull.Value ? 0 : dr["MOMPending"]);
                        objSalesRMWiseData.ClosureProductivity = Convert.ToString(dr["ClosureProductivity"]);
                        objSalesRMWiseData.RejectionRatio = Convert.ToString(dr["RejectionRatio"]);
                        lstObjSalesRM.Add(objSalesRMWiseData);
                    }
                }
                return lstObjSalesRM;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<RPT_SalesRMFollowUpData> GetSalesRMFollowUpData(int EmpId, ReportParam objParam)
        {
            try
            {
                List<RPT_SalesRMFollowUpData> objLstSalesRM = new List<RPT_SalesRMFollowUpData>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", objParam.RMId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_FOLLOWUP_SALES_DATA");
                if (oDT.Rows.Count > 0)
                {
                    foreach (DataRow dr in oDT.Rows)
                    {
                        RPT_SalesRMFollowUpData objSalesRMFollowUpData = new RPT_SalesRMFollowUpData();
                        objSalesRMFollowUpData.EmpId = Convert.ToInt32(dr["EmpId"] == DBNull.Value ? 0 : dr["EmpId"]);
                        objSalesRMFollowUpData.EmpName = Convert.ToString(dr["EmpName"]);
                        objSalesRMFollowUpData.SiteVisit = Convert.ToInt32(dr["SiteVisit"] == DBNull.Value ? 0 : dr["SiteVisit"]);
                        objSalesRMFollowUpData.Followup = Convert.ToInt32(dr["Followup"] == DBNull.Value ? 0 : dr["Followup"]);
                        objSalesRMFollowUpData.Followup1 = Convert.ToInt32(dr["Followup1"] == DBNull.Value ? 0 : dr["Followup1"]);
                        objSalesRMFollowUpData.Followup2 = Convert.ToInt32(dr["Followup2"] == DBNull.Value ? 0 : dr["Followup2"]);
                        objSalesRMFollowUpData.Followup3 = Convert.ToInt32(dr["Followup3"] == DBNull.Value ? 0 : dr["Followup3"]);
                        objSalesRMFollowUpData.Greater_than_3 = Convert.ToInt32(dr["Greater_than_3"] == DBNull.Value ? 0 : dr["Greater_than_3"]);
                        objLstSalesRM.Add(objSalesRMFollowUpData);
                    }
                }
                return objLstSalesRM;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<RPT_SalesMeetingCount> GetSalesMeetingCount(int EmpId, ReportParam objParam)
        {
            try
            {
                List<RPT_SalesMeetingCount> lstSalesMeeting = new List<RPT_SalesMeetingCount>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", objParam.RMId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataTable oDT = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_MEETING_COUNT_SALES_DATA");
                if (oDT.Rows.Count > 0)
                {
                    foreach (DataRow dr in oDT.Rows)
                    {
                        RPT_SalesMeetingCount objSMC = new RPT_SalesMeetingCount();
                        objSMC.No_of_Meeting = Convert.ToInt32(dr["No_of_Meeting"] == DBNull.Value ? 0 : dr["No_of_Meeting"]);
                        objSMC.ClosureLeadCount = Convert.ToInt32(dr["ClosureLeadCount"] == DBNull.Value ? 0 : dr["ClosureLeadCount"]);
                        lstSalesMeeting.Add(objSMC);
                    }
                }
                return lstSalesMeeting;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<RPT_CPLoginActivitySummary> GetCPLoginActivitySummary(int EmpId,ReportParam objParam)
        {
            try
            {
                List<RPT_CPLoginActivitySummary> objLstCPLogin = new List<RPT_CPLoginActivitySummary>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@FromDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_RPT_GET_CP_LOGIN_SUMMARY");
                if (dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        RPT_CPLoginActivitySummary objCPAS = new RPT_CPLoginActivitySummary();
                        objCPAS.CPID = Convert.ToInt32(dr["CPID"]);
                        objCPAS.CPCode = Convert.ToString(dr["CPCODE"]);
                        objCPAS.Name = Convert.ToString(dr["CPNAME"]);
                        objCPAS.LoginCount = Convert.ToInt32(dr["LoginCount"]);
                        objLstCPLogin.Add(objCPAS);
                    }
                }
                return objLstCPLogin;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<RPT_StatusWiseRevisit> GetStatusWiseRevisit(int EmpId,ReportParam objParam)
        {
            try
            {
                List<RPT_StatusWiseRevisit> objStatusWiseRV = new List<RPT_StatusWiseRevisit>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@AssignedRm", objParam.AssignedRm);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_GET_STATUS_WISE_REVISIT");
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        RPT_StatusWiseRevisit objRV = new RPT_StatusWiseRevisit();
                        objRV.LeadStatusId = Convert.ToInt32(dr["LeadStatus"]==DBNull.Value?0: dr["LeadStatus"]);
                        objRV.LeadStatusName = Convert.ToString(dr["StatusName"]);
                        objRV.ClientCount = Convert.ToInt32(dr["ClientCount"]==DBNull.Value?0:dr["ClientCount"]);
                        objRV.ReSiteVisitCount = Convert.ToInt32(dr["ReSiteVisitCount"] == DBNull.Value ? 0 : dr["ReSiteVisitCount"]);
                        objRV.ReVisit1 = Convert.ToInt32(dr["revist1"]==DBNull.Value?0: dr["revist1"]);
                        objRV.ReVisit2 = Convert.ToInt32(dr["revist2"] == DBNull.Value ? 0 : dr["revist2"]);
                        objRV.ReVisit3 = Convert.ToInt32(dr["revist3"] == DBNull.Value ? 0 : dr["revist3"]);
                        objRV.ReVisitGreaterThen3 = Convert.ToInt32(dr["revistgreater3"] == DBNull.Value ? 0 : dr["revistgreater3"]);
                        objStatusWiseRV.Add(objRV);
                    }
                }
                return objStatusWiseRV;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetSalesRMWiseDataDs(int EmpId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", objParam.RMId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                cmd.Parameters.AddWithValue("@FromDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate",objParam.ToDate);
                DataSet Ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_RMWISE_SALES_DATA");
                return Ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetSalesRMFollowUpDataDs(int EmpId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", objParam.RMId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                cmd.Parameters.AddWithValue("@FromDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate",objParam.ToDate);
                DataSet Ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_FOLLOWUP_SALES_DATA");
                return Ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetSalesMeetingCountDs(int EmpId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@SelectedEMPID", objParam.RMId);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                cmd.Parameters.AddWithValue("@FromDate",objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate",objParam.ToDate);
                DataSet Ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_MEETING_COUNT_SALES_DATA");
                return Ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetCPLoginActivitySummaryDs(int EmpId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@FromDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@ToDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@Period", objParam.Period);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_RPT_GET_CP_LOGIN_SUMMARY");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetStatusWiseRevisitDs(int EmpId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@AssignedRm", objParam.AssignedRm);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_STATUS_WISE_REVISIT");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetTeleCallerDetailsDs(int EmpId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@StartDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@EndDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_RPT_TELECALLER_DETAILS");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetTeleCallerLeadDetailsDs(long EmpId,int RoleId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@StartDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@EndDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleID", RoleId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_RPT_ALL_TELECALLER_LEAD_DETAILS");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetDatewiseSourcingRatingDs(long EmpId, int RoleId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@StartDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@EndDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleID", RoleId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_RPT_DATEWISE_SOURCING_RATING");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetRMWiseUnregCPCountDs(long EmpId, int RoleId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@StartDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@EndDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleID", RoleId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_RPT_RMWISE_UNREGCP_COUNT");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetProspectCritriaSummaryDs(long EmpId, int RoleId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@StartDate", objParam.FromDate);
                cmd.Parameters.AddWithValue("@EndDate", objParam.ToDate);
                cmd.Parameters.AddWithValue("@Propertyid", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.Parameters.AddWithValue("@Status", objParam.StatusId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_PROSPECT_STATUS_CRITRIA_SUMMARY");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetLeadSummaryDs(long EmpId, int RoleId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@Propertyid", objParam.PropertyId);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_MARKETING_LEAD_STATUS_SUMMARY");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetRegUNRegCPDetailsDs(long EmpId, int RoleId, ReportParam objParam)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_REG_UNREG_CP_DETAILS");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetReportData(string XMLData)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                DataSet dt = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_REPORT_DATA");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
