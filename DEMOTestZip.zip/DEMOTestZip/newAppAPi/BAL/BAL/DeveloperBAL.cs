﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BAL.Prop;
using DAL;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;

namespace BAL
{
    public class DeveloperBAL
    {
        public SqlCommand cmd;
        public DeveloperLiveLeads GetPropertyDeveloperLiveLeads(Filters360degree objParam)
        {
            try
            {
                DeveloperLiveLeads objDeveloperLiveLeads = new DeveloperLiveLeads();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@DeveloperId", objParam.DeveloperId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DEVELOPER_DASHBOARD_LIVE_LEAD");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        objDeveloperLiveLeads.LiveLeads = new List<LiveLeads>();
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            LiveLeads objLiveLeads = new LiveLeads();
                            objLiveLeads.WalkIn = Convert.ToString(dr["WalkIn"]);
                            objLiveLeads.ReSiteVisit = Convert.ToString(dr["ReSiteVisit"]);
                            objLiveLeads.TouchBaseClient = Convert.ToString(dr["TouchBaseClient"]);
                            objDeveloperLiveLeads.LiveLeads.Add(objLiveLeads);
                        }
                    }
                    if (dsResult.Tables[1].Rows.Count > 0)
                    {
                        objDeveloperLiveLeads.BookingStatus = new List<Prop.BookingStatus>();
                        foreach (DataRow dr in dsResult.Tables[1].Rows)
                        {
                            Prop.BookingStatus objBookingStatus = new Prop.BookingStatus();
                            objBookingStatus.Period = Convert.ToString(dr["Period"]);
                            objBookingStatus.Hot = Convert.ToString(dr["Hot"] == DBNull.Value ? 0 : dr["Hot"]);
                            objBookingStatus.Warm = Convert.ToString(dr["Warm"] == DBNull.Value ? 0 : dr["Warm"]);
                            objBookingStatus.Cold = Convert.ToString(dr["Cold"] == DBNull.Value ? 0 : dr["Cold"]);
                            objDeveloperLiveLeads.BookingStatus.Add(objBookingStatus);
                        }
                    }
                    if (dsResult.Tables[2].Rows.Count > 0)
                    {
                        objDeveloperLiveLeads.SourceWiseBreakUp = new List<SourceWiseBreakUp>();
                        foreach (DataRow dr in dsResult.Tables[2].Rows)
                        {
                            SourceWiseBreakUp objSourceWiseBreakUp = new SourceWiseBreakUp();
                            objSourceWiseBreakUp.SourceId = Convert.ToInt32(dr["SourceId"] == DBNull.Value ? 0 : dr["SourceId"]);
                            objSourceWiseBreakUp.SourceName = Convert.ToString(dr["SourceName"]);
                            objSourceWiseBreakUp.CountValue = Convert.ToString(dr["CountValue"] == DBNull.Value ? 0 : dr["CountValue"]);
                            objSourceWiseBreakUp.Percentage = Convert.ToString(dr["Perc"] == DBNull.Value ? 0 : dr["Perc"]) + " %";
                            objSourceWiseBreakUp.Total = Convert.ToString(dr["Total"] == DBNull.Value ? 0 : dr["Total"]);
                            objDeveloperLiveLeads.SourceWiseBreakUp.Add(objSourceWiseBreakUp);
                        }
                    }
                }
                return objDeveloperLiveLeads;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DeveloperLiveInventory GetPropertyDeveloperLiveInventory(Filters360degree objParam)
        {
            try
            {
                DeveloperLiveInventory objDeveloperLiveInventory = new DeveloperLiveInventory();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@DeveloperId", objParam.DeveloperId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Currency", objParam.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DEVELOPER_DASHBOARD_LIVE_INVENTORY");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        objDeveloperLiveInventory.LiveInventory = new List<LiveInventory>();
                        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        {
                            LiveInventory objLiveInventory = new LiveInventory();
                            objLiveInventory.InventoryToSold = Convert.ToString(dr["InventoryToSold"]);
                            objLiveInventory.SoldInventory = Convert.ToString(dr["SoldInventory"]);
                            objLiveInventory.PendingInventory = Convert.ToString(dr["PendingInventory"]);
                            objDeveloperLiveInventory.LiveInventory.Add(objLiveInventory);
                        }
                    }
                }
                return objDeveloperLiveInventory;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DeveloperPaymentStatus GetPropertyDeveloperPaymentStatus(Filters360degree objParam)
        {
            try
            {
                DeveloperPaymentStatus objDeveloperPaymentStatus = new DeveloperPaymentStatus();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@DeveloperId", objParam.DeveloperId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Currency",objParam.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DEVELOPER_DASHBOARD_PAYMENT_STATUS");
                if (dsResult.Tables.Count > 0)
                {
                    if(dsResult.Tables[0].Rows.Count>0)
                    {
                        objDeveloperPaymentStatus.PaymentStatus = new AgreementValue();
                        objDeveloperPaymentStatus.PaymentStatus.AveragePrice = Convert.ToString(dsResult.Tables[0].Rows[0]["AveragePrice"]);
                        objDeveloperPaymentStatus.PaymentStatus.TotalPayment = Convert.ToString(dsResult.Tables[0].Rows[0]["TotalPayment"]);
                        objDeveloperPaymentStatus.PaymentStatus.PaymentDone = Convert.ToString(dsResult.Tables[0].Rows[0]["PaymentDone"]);
                        objDeveloperPaymentStatus.PaymentStatus.PaymentDue = Convert.ToString(dsResult.Tables[0].Rows[0]["PaymentDue"]);
                        objDeveloperPaymentStatus.PaymentStatus.RemainingCLP = Convert.ToString(dsResult.Tables[0].Rows[0]["RemainingCLP"]);
                        objDeveloperPaymentStatus.PaymentStatus.NoOfFlatSold = Convert.ToString(dsResult.Tables[0].Rows[0]["NoOfFlatSold"]);
                    }
                    if(dsResult.Tables[1].Rows.Count>0)
                    {
                        objDeveloperPaymentStatus.LiveInventory = new LiveInventory();
                        objDeveloperPaymentStatus.LiveInventory.InventoryToSold = Convert.ToString(dsResult.Tables[1].Rows[0]["InventoryToSold"]);
                        objDeveloperPaymentStatus.LiveInventory.SoldInventory = Convert.ToString(dsResult.Tables[1].Rows[0]["SoldInventory"]);
                        objDeveloperPaymentStatus.LiveInventory.PendingInventory = Convert.ToString(dsResult.Tables[1].Rows[0]["PendingInventory"]);
                    }
                    if (dsResult.Tables[2].Rows.Count > 0)
                    {
                        objDeveloperPaymentStatus.ThreeMonthCashFlow = new List<ThreeMonthCashFlow>();
                        foreach (DataRow dr in dsResult.Tables[2].Rows)
                        {
                            ThreeMonthCashFlow objThreeMonthCashFlow = new ThreeMonthCashFlow();
                            objThreeMonthCashFlow.Dates = Convert.ToString(dr["Dates"]);
                            objThreeMonthCashFlow.DateString = Convert.ToString(dr["DateString"]);
                            objThreeMonthCashFlow.Value = Convert.ToString(dr["value"] == DBNull.Value ? 0 : dr["value"]);
                            objDeveloperPaymentStatus.ThreeMonthCashFlow.Add(objThreeMonthCashFlow);
                        }
                    }
                    if(dsResult.Tables[3].Rows.Count>0)
                    {
                        objDeveloperPaymentStatus.InventoryBookingStatus = new List<InventoryBookingStatus>();
                        foreach (DataRow dr in dsResult.Tables[3].Rows)
                        {
                            InventoryBookingStatus objInventoryBookingStatus = new InventoryBookingStatus();
                            objInventoryBookingStatus.Name = Convert.ToString(dr["Name"]);
                            objInventoryBookingStatus.TotalFlat = Convert.ToString(dr["TotalFlat"] == DBNull.Value ? 0 : dr["TotalFlat"]);
                            objInventoryBookingStatus.BookedFlat = Convert.ToString(dr["BookedFlat"] == DBNull.Value ? 0 : dr["BookedFlat"]);
                            objDeveloperPaymentStatus.InventoryBookingStatus.Add(objInventoryBookingStatus);
                        }
                    }
                    if (dsResult.Tables[4].Rows.Count > 0)
                    {
                        objDeveloperPaymentStatus.AverageCarpetPrice = new AverageCarpetPrice();
                        objDeveloperPaymentStatus.AverageCarpetPrice.AveragePrice = Convert.ToString(dsResult.Tables[4].Rows[0]["AveragePrice"] == DBNull.Value ? 0 : dsResult.Tables[4].Rows[0]["AveragePrice"]);
                    }
                }
                return objDeveloperPaymentStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetDeveloperInventory(Filters360degree objParam)
        {
            try
            {
                InventoryPlot objInventoryPlot = new InventoryPlot();
                objInventoryPlot.Inventory = new List<Inventory>();
                Inventory objInventory;
                DataSet dsResult;
                int DtCount, DtMaxCount;
                DtCount = 1;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@WingID", objParam.WingId);
                cmd.Parameters.AddWithValue("@DeveloperId", objParam.DeveloperId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_INVENTORY_PLOT");
                if (dsResult.Tables.Count > 0)
                {
                    if (dsResult.Tables[0].Rows.Count > 0)
                    {
                        objInventoryPlot.InventoryPlotProperty = new InventoryPlotProperty();
                        objInventoryPlot.InventoryPlotProperty.Name = Convert.ToString(dsResult.Tables[0].Rows[0]["PropertyName"]);
                        objInventoryPlot.InventoryPlotProperty.Sold = Convert.ToString(dsResult.Tables[0].Rows[0]["Sold"]);
                        objInventoryPlot.InventoryPlotProperty.Wing = Convert.ToString(dsResult.Tables[0].Rows[0]["Wing"]);
                    }
                    if (dsResult.Tables.Count > 1)
                    {
                        DtMaxCount = dsResult.Tables.Count - 1;
                        while (DtMaxCount >= DtCount)
                        {
                            objInventory = new Inventory();
                            objInventory.DeveloperInventory = new List<DeveloperInventory>();
                            foreach (DataRow dr in dsResult.Tables[DtCount].Rows)
                            {
                                DeveloperInventory objDeveloperInventory = new DeveloperInventory();
                                objDeveloperInventory.PropertyId = Convert.ToInt32(dr["PropertyId"] == DBNull.Value ? 0 : dr["PropertyId"]);
                                objDeveloperInventory.FloorNo = Convert.ToInt32(dr["FloorNo"] == DBNull.Value ? 0 : dr["FloorNo"]);
                                objDeveloperInventory.FlatNo = Convert.ToString(dr["FlatNo"]);
                                objDeveloperInventory.Wing = Convert.ToString(dr["Wing"]);
                                objDeveloperInventory.Facing = Convert.ToString(dr["Facing"]);
                                objDeveloperInventory.Name = Convert.ToString(dr["Name"]);
                                objDeveloperInventory.BookedStatus = Convert.ToString(dr["BookedStatus"]);
                                objDeveloperInventory.CarpetArea = Convert.ToString(dr["CarpetArea"]); 
                                objInventory.DeveloperInventory.Add(objDeveloperInventory);
                            }
                            DtCount = DtCount + 1;
                            objInventoryPlot.Inventory.Add(objInventory);
                        }
                    }
                }
                return InventoryJson(objInventoryPlot);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string InventoryJson(InventoryPlot objInv)
        {
            try
            {
            string Jstring = "";
            Jstring = new JavaScriptSerializer().Serialize(objInv);
            List<int> indexes = Jstring.AllIndexesOf("DeveloperInventory");
            JObject objJobject = JObject.Parse(Jstring);
            int objJobjectCount = objJobject["Inventory"].Count();
            List<string> LstFloorNo = new List<string>();
            for (int i = 0; i <= objJobjectCount - 1; i++)
            {
                int incount = objJobject["Inventory"][i]["DeveloperInventory"].Count();
                for (int j = 0; j <= incount - 1; j++)
                {
                    LstFloorNo.Add(Utilities.AddOrdinal(Convert.ToInt32(objJobject["Inventory"][i]["DeveloperInventory"][j]["FloorNo"])));
                }
            }
            LstFloorNo = LstFloorNo.Distinct().ToList();
            string newJson = Jstring;
            for (int i = 0; i <= indexes.Count - 1; i++)
            {
                int indexRemove = newJson.IndexOf("DeveloperInventory");
                newJson = newJson.Remove(indexRemove, 18);
                newJson = newJson.Insert(indexRemove, "FloorData");
                newJson = newJson.Insert(indexRemove - 1, "\"FloorNo\" :\""+ LstFloorNo[i]+"\",");
            }
            return newJson;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string GetDeveloperCashFLowDetails(Filters360degree objParam)
        {
            try
            {
                string JString = "";
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@DeveloperId", objParam.DeveloperId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@FY", objParam.FY);
                cmd.Parameters.AddWithValue("@Currency", objParam.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DEVELOPER_CASHFLOW_DETAILS");
                if (dsResult.Tables.Count > 0)
                {
                    JString = Utilities.dsToJson(dsResult);
                }
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DeveloperPaymentDetailsSummary GetDeveloperPaymentDetails(Filters360degree objParam)
        {
            try
            {
                DeveloperPaymentDetailsSummary objDeveloperPaymentDetailsSummary = new DeveloperPaymentDetailsSummary();
                objDeveloperPaymentDetailsSummary.DeveloperPaymentDetails = new List<DeveloperPaymentDetails>();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@StartDate", objParam.StartDate);
                cmd.Parameters.AddWithValue("@EndDate", objParam.EndDate);
                cmd.Parameters.AddWithValue("@Currency", objParam.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_OnClick_FundComing_CashFlow");
                if(dsResult.Tables.Count>0)
                {
                    if(dsResult.Tables[0].Rows.Count>0)
                    {
                        objDeveloperPaymentDetailsSummary.DeveloperPaymentDetailsSum = new DeveloperPaymentDetailsSum();
                        objDeveloperPaymentDetailsSummary.DeveloperPaymentDetailsSum.ClientCount = Convert.ToInt64(dsResult.Tables[0].Rows[0]["ClientCount"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["ClientCount"]);
                        objDeveloperPaymentDetailsSummary.DeveloperPaymentDetailsSum.PaymentDue = Convert.ToString(dsResult.Tables[0].Rows[0]["PaymentDue"]);
                        objDeveloperPaymentDetailsSummary.DeveloperPaymentDetailsSum.PaymentReceived = Convert.ToString(dsResult.Tables[0].Rows[0]["PaymentReceived"]);
                        objDeveloperPaymentDetailsSummary.DeveloperPaymentDetailsSum.PaymentPending = Convert.ToString(dsResult.Tables[0].Rows[0]["PaymentPending"]);

                    }
                    if (dsResult.Tables[1].Rows.Count>0)
                    {
                        foreach(DataRow dr in dsResult.Tables[1].Rows)
                        {
                            DeveloperPaymentDetails objDev = new DeveloperPaymentDetails();
                            objDev.ClientId = Convert.ToInt64(dr["ClientId"]);
                            objDev.ClientName = Convert.ToString(dr["ClientName"]);
                            objDev.PaymentDue = Convert.ToString(dr["PaymentDue"]==DBNull.Value?0: dr["PaymentDue"]);
                            objDev.PaymentPending = Convert.ToString(dr["PaymentPending"] == DBNull.Value ? 0 : dr["PaymentPending"]);
                            objDev.PaymentReceived = Convert.ToString(dr["PaymentReceived"] == DBNull.Value ? 0 : dr["PaymentReceived"]);
                            objDeveloperPaymentDetailsSummary.DeveloperPaymentDetails.Add(objDev);
                        }
                    }
                }
                return objDeveloperPaymentDetailsSummary;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DeveloperPaymentModuleDetails GetDeveloperPaymentModuleDetails(Filters360degree objParam)
        {
            try
            {
                DeveloperPaymentModuleDetails objDeveloperPaymentModuleDetails = new DeveloperPaymentModuleDetails();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@DeveloperId", objParam.DeveloperId);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Currency", objParam.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DEVELOPER_PAYMENT_DETAILS");
                if(dsResult.Tables.Count>0)
                {
                    if (dsResult.Tables[0].Rows.Count>0)
                    {
                        objDeveloperPaymentModuleDetails.SoldFlatStatus = new SoldFlatStatus();
                        objDeveloperPaymentModuleDetails.SoldFlatStatus.Total = Convert.ToString(dsResult.Tables[0].Rows[0]["Total"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["Total"]);
                        objDeveloperPaymentModuleDetails.SoldFlatStatus.PercentageReceived = Convert.ToString(dsResult.Tables[0].Rows[0]["PercentageReceived"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["PercentageReceived"]) +" %";
                        objDeveloperPaymentModuleDetails.SoldFlatStatus.PayedAmount= Convert.ToString(dsResult.Tables[0].Rows[0]["PayedAmount"] == DBNull.Value ? 0 : dsResult.Tables[0].Rows[0]["PayedAmount"]);
                    }
                    if(dsResult.Tables[1].Rows.Count>0)
                    {
                        objDeveloperPaymentModuleDetails.AgreementValue = new AgreementValue();
                        objDeveloperPaymentModuleDetails.AgreementValue.ClientCount = Convert.ToString(dsResult.Tables[1].Rows[0]["ClientCount"]==DBNull.Value?0: dsResult.Tables[1].Rows[0]["ClientCount"]);
                        objDeveloperPaymentModuleDetails.AgreementValue.TotalPayment = Convert.ToString(dsResult.Tables[1].Rows[0]["TotalPayment"] == DBNull.Value ? 0 : dsResult.Tables[1].Rows[0]["TotalPayment"]);
                        objDeveloperPaymentModuleDetails.AgreementValue.PaymentDone = Convert.ToString(dsResult.Tables[1].Rows[0]["PaymentDone"] == DBNull.Value ? 0 : dsResult.Tables[1].Rows[0]["PaymentDone"]);
                        objDeveloperPaymentModuleDetails.AgreementValue.PaymentDue = Convert.ToString(dsResult.Tables[1].Rows[0]["PaymentDue"] == DBNull.Value ? 0 : dsResult.Tables[1].Rows[0]["PaymentDue"]);
                        objDeveloperPaymentModuleDetails.AgreementValue.RemainingCLP = Convert.ToString(dsResult.Tables[1].Rows[0]["RemainingCLP"] == DBNull.Value ? 0 : dsResult.Tables[1].Rows[0]["RemainingCLP"]);
                    }
                    if(dsResult.Tables[2].Rows.Count>0)
                    {
                        objDeveloperPaymentModuleDetails.AgreementValueDetails = new List<AgreementValueDetails>();
                        foreach(DataRow dr in dsResult.Tables[2].Rows)
                        {
                            AgreementValueDetails objAgreementValueDetails = new AgreementValueDetails();
                            objAgreementValueDetails.Customer_Id= Convert.ToInt64(dr["Customer_ID"] == DBNull.Value ? 0 : dr["Customer_ID"]);
                            objAgreementValueDetails.Name = Convert.ToString(dr["Name"]);
                            objAgreementValueDetails.AgreementValue = Convert.ToString(dr["AgreementValue"] == DBNull.Value ? 0 : dr["AgreementValue"]);
                            objAgreementValueDetails.PayedAmount= Convert.ToString(dr["PayedAmount"] == DBNull.Value ? 0 : dr["PayedAmount"]);
                            objAgreementValueDetails.PaymentDue= Convert.ToString(dr["PaymentDue"] == DBNull.Value ? 0 : dr["PaymentDue"]);
                            objAgreementValueDetails.RemainingCLP= Convert.ToString(dr["RemainingCLP"] == DBNull.Value ? 0 : dr["RemainingCLP"]);
                            objDeveloperPaymentModuleDetails.AgreementValueDetails.Add(objAgreementValueDetails);
                        }
                    }
                    if(dsResult.Tables[3].Rows.Count>0)
                    {
                        objDeveloperPaymentModuleDetails.OtherCharges = new Prop.OtherCharges();
                        objDeveloperPaymentModuleDetails.OtherCharges.ClientCount = Convert.ToString(dsResult.Tables[3].Rows[0]["ClientCount"] == DBNull.Value ? 0 : dsResult.Tables[3].Rows[0]["ClientCount"]);
                        objDeveloperPaymentModuleDetails.OtherCharges.TotalGST = Convert.ToString(dsResult.Tables[3].Rows[0]["TotalGST"] == DBNull.Value ? 0 : dsResult.Tables[3].Rows[0]["TotalGST"]);
                        objDeveloperPaymentModuleDetails.OtherCharges.GSTReceived = Convert.ToString(dsResult.Tables[3].Rows[0]["GSTReceived"] == DBNull.Value ? 0 : dsResult.Tables[3].Rows[0]["GSTReceived"]);
                        objDeveloperPaymentModuleDetails.OtherCharges.GSTDue = Convert.ToString(dsResult.Tables[3].Rows[0]["GSTDue"] == DBNull.Value ? 0 : dsResult.Tables[3].Rows[0]["GSTDue"]);
                        objDeveloperPaymentModuleDetails.OtherCharges.StampDuty = Convert.ToString(dsResult.Tables[3].Rows[0]["StampDuty"] == DBNull.Value ? 0 : dsResult.Tables[3].Rows[0]["StampDuty"]);
                    }
                    if(dsResult.Tables[4].Rows.Count>0)
                    {
                        objDeveloperPaymentModuleDetails.OtherChargesDetails = new List<OtherChargesDetails>();
                        foreach(DataRow dr in dsResult.Tables[4].Rows)
                        {
                            OtherChargesDetails objOtherChargesDetails = new OtherChargesDetails();
                            objOtherChargesDetails.Customer_Id = Convert.ToInt64(dr["Customer_ID"]==DBNull.Value?0: dr["Customer_ID"]);
                            objOtherChargesDetails.Name = Convert.ToString(dr["Name"]);
                            objOtherChargesDetails.TotalGST = Convert.ToString(dr["TotalGST"] == DBNull.Value ? 0 : dr["TotalGST"]);
                            objOtherChargesDetails.GSTReceived = Convert.ToString(dr["GSTReceived"] == DBNull.Value ? 0 : dr["GSTReceived"]);
                            objOtherChargesDetails.GSTDue = Convert.ToString(dr["GSTDue"] == DBNull.Value ? 0 : dr["GSTDue"]);
                            objOtherChargesDetails.RemainingCLPGST = Convert.ToString(dr["RemainingCLPGST"] == DBNull.Value ? 0 : dr["RemainingCLPGST"]);
                            objOtherChargesDetails.StampDuty= Convert.ToString(dr["StampDuty"]); 
                            objDeveloperPaymentModuleDetails.OtherChargesDetails.Add(objOtherChargesDetails);
                        }
                    }
                }
                return objDeveloperPaymentModuleDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public InventoryDrillDown GetInventoryDrillDown(Filters360degree objParam)
        {
            try
            {
                InventoryDrillDown objInventoryDrillDown = new InventoryDrillDown();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@propertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Drill", objParam.DrillId);
                cmd.Parameters.AddWithValue("@CarpetArea", objParam.CarpetArea);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_DEVELOPER_Inventory_Drill_Down");
                if (objParam.Flag == 1)
                {
                    if (dsResult.Tables.Count > 0)
                    {
                        objInventoryDrillDown.InventoryTypologyView = new List<InventoryTypologyView>();
                        foreach(DataRow dr in dsResult.Tables[0].Rows)
                        {
                            InventoryTypologyView objInventoryTypologyView = new InventoryTypologyView();
                            objInventoryTypologyView.DrillId = Convert.ToInt32(dr["DrillId"] == DBNull.Value ? 0 : dr["DrillId"]);
                            objInventoryTypologyView.Name = Convert.ToString(dr["Name"]); 
                            objInventoryTypologyView.FlatsAvailable = Convert.ToString(dr["FlatsAvailable"] == DBNull.Value ? 0 : dr["FlatsAvailable"]);
                            objInventoryTypologyView.SoldFlats = Convert.ToString(dr["SoldFlats"] == DBNull.Value ? 0 : dr["SoldFlats"]);
                            objInventoryTypologyView.Pending = Convert.ToString(dr["Pending"] == DBNull.Value ? 0 : dr["Pending"]);
                            objInventoryTypologyView.CarpetArea= Convert.ToString(dr["CarpetArea"] == DBNull.Value ? 0 : dr["CarpetArea"]);
                            objInventoryDrillDown.InventoryTypologyView.Add(objInventoryTypologyView);
                        }
                    }
                }else if(objParam.Flag==2)
                {
                    if(dsResult.Tables.Count>0)
                    {
                        objInventoryDrillDown.InventoryTypologyViewDrill = new List<InventoryTypologyViewDrill>();
                        foreach(DataRow dr in dsResult.Tables[0].Rows)
                        {
                            InventoryTypologyViewDrill objInventoryTypologyViewDrill = new InventoryTypologyViewDrill();
                            objInventoryTypologyViewDrill.Wing = Convert.ToString(dr["Wing"]);
                            objInventoryTypologyViewDrill.FlatsAvailable= Convert.ToString(dr["FlatsAvailable"] == DBNull.Value ? 0 : dr["FlatsAvailable"]);
                            objInventoryTypologyViewDrill.SoldFlats = Convert.ToString(dr["SoldFlats"] == DBNull.Value ? 0 : dr["SoldFlats"]);
                            objInventoryTypologyViewDrill.Pending = Convert.ToString(dr["Pending"] == DBNull.Value ? 0 : dr["Pending"]);
                            objInventoryDrillDown.InventoryTypologyViewDrill.Add(objInventoryTypologyViewDrill);
                        }
                    }
                }
                else if(objParam.Flag==3)
                {
                    objInventoryDrillDown.InventoryWingView = new List<InventoryWingView>();
                    if(dsResult.Tables.Count>0)
                    {
                        foreach(DataRow dr in dsResult.Tables[0].Rows)
                        {
                            InventoryWingView objInventoryWingView = new InventoryWingView();
                            objInventoryWingView.DrillId = Convert.ToInt32(dr["DrillId"]==DBNull.Value?0: dr["DrillId"]);
                            objInventoryWingView.Wing = Convert.ToString(dr["Wing"]);
                            objInventoryWingView.FlatsAvailable = Convert.ToString(dr["FlatsAvailable"] == DBNull.Value ? 0 : dr["FlatsAvailable"]);
                            objInventoryWingView.SoldFlats = Convert.ToString(dr["SoldFlats"] == DBNull.Value ? 0 : dr["SoldFlats"]);
                            objInventoryWingView.Pending = Convert.ToString(dr["Pending"] == DBNull.Value ? 0 : dr["Pending"]);
                            objInventoryDrillDown.InventoryWingView.Add(objInventoryWingView);
                        }
                    }
                }
                else if(objParam.Flag==4)
                {
                    objInventoryDrillDown.InventoryWingViewDrill = new List<InventoryWingViewDrill>();
                    if(dsResult.Tables.Count>0)
                    {
                        foreach(DataRow dr in dsResult.Tables[0].Rows)
                        {
                            InventoryWingViewDrill objInventoryWingViewDrill = new InventoryWingViewDrill();
                            objInventoryWingViewDrill.Name= Convert.ToString(dr["Name"]);
                            objInventoryWingViewDrill.FlatsAvailable = Convert.ToString(dr["FlatsAvailable"] == DBNull.Value ? 0 : dr["FlatsAvailable"]);
                            objInventoryWingViewDrill.SoldFlats = Convert.ToString(dr["SoldFlats"] == DBNull.Value ? 0 : dr["SoldFlats"]);
                            objInventoryWingViewDrill.Pending = Convert.ToString(dr["Pending"] == DBNull.Value ? 0 : dr["Pending"]);
                            objInventoryDrillDown.InventoryWingViewDrill.Add(objInventoryWingViewDrill);
                        }
                    }
                }
                return objInventoryDrillDown;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCPFunnelForDeveloperDashboard(int propertyId,int EmpId,int RoleId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@PropertyID", propertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_DeveloperDashboard_CPFunnel_Details");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CommunicationFunnel GetCommunicationFunnel(Filters360degree objParam,int EmpId,int RoleId)
        {
            try
            {
                CommunicationFunnel objCommunicationFunnel = new CommunicationFunnel();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_DEVELOPER_COMMUNICATION_FUNNEL");
                if (dsResult.Tables.Count > 0)
                {
                    if(dsResult.Tables[0].Rows.Count > 0)
                    {
                        objCommunicationFunnel.TouchBase = Convert.ToString(dsResult.Tables[0].Rows[0]["TouchBase"]);
                        objCommunicationFunnel.EOI = Convert.ToString(dsResult.Tables[0].Rows[0]["EOI"]);
                        objCommunicationFunnel.SiteVisite = Convert.ToString(dsResult.Tables[0].Rows[0]["SiteVisite"]);
                        objCommunicationFunnel.Booked = Convert.ToString(dsResult.Tables[0].Rows[0]["Booked"]);
                    }
                }
                return objCommunicationFunnel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DeveloperOtherCharges GetDeveloperOtherCharges(Filters360degree objParam)
        {
            try
            {
                DeveloperOtherCharges objDeveloperOtherCharges = new DeveloperOtherCharges();
                DataSet dsResult;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Flag", objParam.Flag);
                cmd.Parameters.AddWithValue("@PropertyID", objParam.PropertyId);
                cmd.Parameters.AddWithValue("@Currency", objParam.Currency);
                dsResult = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Get_Developer_otherCharges_CashFlow_Summary");
                if(dsResult.Tables.Count>0)
                {
                    if(dsResult.Tables[0].Rows.Count>0)
                    {
                        objDeveloperOtherCharges.DevOtherChargesSummary = new DevOtherChargesSummary();
                        objDeveloperOtherCharges.DevOtherChargesSummary.ClientCount = Convert.ToString(dsResult.Tables[0].Rows[0]["ClientCount"]==DBNull.Value?0: dsResult.Tables[0].Rows[0]["ClientCount"]);
                        objDeveloperOtherCharges.DevOtherChargesSummary.OtherCharges = Convert.ToString(dsResult.Tables[0].Rows[0]["OtherCharges"]);
                        objDeveloperOtherCharges.DevOtherChargesSummary.OtherChargesReceived = Convert.ToString(dsResult.Tables[0].Rows[0]["OtherChargesReceived"]);
                        objDeveloperOtherCharges.DevOtherChargesSummary.OtherChargesPending = Convert.ToString(dsResult.Tables[0].Rows[0]["OtherChargesPending"]);
                    }
                    if(dsResult.Tables[1].Rows.Count>0)
                    {
                        objDeveloperOtherCharges.DevOtherChargesDetails = new List<DevOtherChargesDetails>();
                        foreach(DataRow dr in dsResult.Tables[1].Rows)
                        {
                            DevOtherChargesDetails objDevOtherChargesDetails = new DevOtherChargesDetails();
                            objDevOtherChargesDetails.Customer_Id = Convert.ToInt64(dr["Customer_ID"]==DBNull.Value?0: dr["Customer_ID"]);
                            objDevOtherChargesDetails.Name = Convert.ToString(dr["Name"]);
                            objDevOtherChargesDetails.OtherCharges = Convert.ToString(dr["OtherCharges"]);
                            objDevOtherChargesDetails.OtherChargesReceived = Convert.ToString(dr["OtherChargesReceived"]);
                            objDevOtherChargesDetails.OtherChargesPending = Convert.ToString(dr["OtherChargesPending"]);
                            objDeveloperOtherCharges.DevOtherChargesDetails.Add(objDevOtherChargesDetails);
                        }
                    }
                }
                return objDeveloperOtherCharges;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
