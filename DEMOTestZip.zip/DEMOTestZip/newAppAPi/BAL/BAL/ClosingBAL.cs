﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;
using System.Xml.Linq;
using System.Configuration;

namespace BAL
{
    public class ClosingBAL
    {
        SqlCommand cmd;
        public DataSet GetClosingSourceDB(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_CLOSING_PROSPECT_SOURCE_DB");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetClosingRevisitStatusWise(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Get_CLOSING_PROSPECT_REVISIT_STATUS_WISE");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetClosingNoOfTimeRevisit(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CLOSING_PROSPECT_NUMBEROFTIME_REVISIT");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetClosingRevisitAgeing(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CLOSING_PROSPECT_REVISIT_AGEING_WISE");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetClosingActiveRevisit(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@Period", Param.Period);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CLOSING_ACTIVE_PROSPECT_REVISIT");
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet GetProspectCriteriaStatusSummary(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@LeadStatus", Param.LeadStatus);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_Get_CLOSING_PROSPECT_CRITERIA_STATUS_SUMMARY");
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetProspectFTW_RevisitSummary(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_SOURCING_PROSPECT_FTW_REVISIT_SUMMARY");
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetProspectDecisionMakerSummary(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", Param.Flag);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GET_CLOSING_PROSPECT_DECISION_MAKER_SUMMARY");
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetTopTenClosingCPWalkin(ClosingParam Param, int EmpId, int RoleId)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag",1);
                cmd.Parameters.AddWithValue("@PropertyId", Param.PropertyId);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_GetBH_TopTenCp_Walkin_Dashboard");
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
