﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BAL.Prop;
namespace BAL
{
    public class CampaignBAL
    {
        SqlCommand cmd;
        public string SaveCampaign(string XMLData,int EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 1);
                cmd.Parameters.AddWithValue("@EMPID", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CAMPAIGN_DETAILS");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Campaign GetCampaign(string XMLData, int EmpId)
        {
            try
            {
                Campaign objCampaign = new Campaign();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", XMLData);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_CAMPAIGN_DETAILS");
                if(dt.Rows.Count>0)
                {
                    objCampaign.CampaignId = Convert.ToInt32(dt.Rows[0]["CampaignId"] == DBNull.Value ? 0 : dt.Rows[0]["CampaignId"]);
                    objCampaign.CampaignName = Convert.ToString(dt.Rows[0]["CampaignName"]);
                    objCampaign.CampaignType = Convert.ToString(dt.Rows[0]["CampaignType"]);
                    objCampaign.CampaignTypeId = Convert.ToInt32(dt.Rows[0]["CampaignTypeId"]==DBNull.Value?0: dt.Rows[0]["CampaignTypeId"]);
                    objCampaign.CostOfCampaign = Convert.ToDecimal(dt.Rows[0]["CostOfCampaign"] == DBNull.Value ? 0 : dt.Rows[0]["CostOfCampaign"]);
                    objCampaign.StartDate = Convert.ToDateTime(dt.Rows[0]["StartDate"]);
                    objCampaign.EndDate = Convert.ToDateTime(dt.Rows[0]["EndDate"]);
                    objCampaign.SD = Convert.ToString(dt.Rows[0]["SD"]);
                    objCampaign.ED = Convert.ToString(dt.Rows[0]["ED"]);
                    objCampaign.PropertyId = Convert.ToInt32(dt.Rows[0]["PropertyId"]==DBNull.Value?0: dt.Rows[0]["PropertyId"]);
                    objCampaign.PropertyName = Convert.ToString(dt.Rows[0]["PropertyName"]);
                    objCampaign.IsActive = Convert.ToBoolean(dt.Rows[0]["IsActive"]);
                }
                return objCampaign;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
