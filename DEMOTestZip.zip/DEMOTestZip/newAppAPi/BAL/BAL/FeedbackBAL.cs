﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BAL;
using BAL.Prop;
using DAL;
using Newtonsoft.Json;
namespace BAL
{
    public class FeedbackBAL
    {
        public SqlCommand cmd;
        public string SaveFeedback(string FeedbackXML)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLData", FeedbackXML);
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_SERVICE_FEEDBACK");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<ProspectFeedBackQM> GetFeedBackQM()
        {
            try
            {
                List<ProspectFeedBackQM> objListPQM = new List<ProspectFeedBackQM>();
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@Flag", 1);
                DataSet ds = Db_Access.ExecuteDataSet(ref cmd, "USP_CREMA_PROSPECT_FEEDBACK");
                if(ds.Tables.Count>1)
                {
                    if(ds.Tables[0].Rows.Count>0)
                    {
                        foreach(DataRow dr in ds.Tables[0].Rows)
                        {
                            ProspectFeedBackQM objProspectFeedBackQM = new ProspectFeedBackQM();
                            objProspectFeedBackQM.lstOptions = new List<FeedBackQMOptions>();
                            objProspectFeedBackQM.QuestionId = Convert.ToInt32(dr["QuestionId"] == DBNull.Value ? 0 : dr["QuestionId"]);
                            objProspectFeedBackQM.QuestionText = Convert.ToString(dr["QuestionText"]==DBNull.Value?0: dr["QuestionText"]);
                            foreach(DataRow dr1 in ds.Tables[1].Rows)
                            {
                                if (objProspectFeedBackQM.QuestionId == Convert.ToInt32(dr1["QuestionId"] == DBNull.Value ? 0 : dr1["QuestionId"]))
                                {
                                    FeedBackQMOptions objFeedBackQMOptions = new FeedBackQMOptions();
                                    objFeedBackQMOptions.AnswerId=Convert.ToInt32(dr1["AnswerId"]==DBNull.Value?0:dr1["AnswerId"]);
                                    objFeedBackQMOptions.AnswerText = Convert.ToString(dr1["AnswerText"]);
                                    objProspectFeedBackQM.lstOptions.Add(objFeedBackQMOptions);
                                }
                            }
                            objListPQM.Add(objProspectFeedBackQM);
                        }
                    }
                }
                return objListPQM;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public string SaveProspectFeedback(string FeedbackXML,int RoleId,int EmpId)
        {
            string JString = string.Empty;
            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@XMLDate", FeedbackXML);
                cmd.Parameters.AddWithValue("@Flag", 2);
                cmd.Parameters.AddWithValue("@EmpId",EmpId);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                DataTable dt = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_PROSPECT_FEEDBACK");
                JString = Utilities.dtToJson(dt);
                return JString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
