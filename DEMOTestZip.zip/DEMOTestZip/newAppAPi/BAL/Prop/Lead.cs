﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BAL.Prop;
using Newtonsoft.Json;

namespace BAL
{
    public class Lead
    {
        public SqlCommand cmd;

        public string InsertLead(string leadXML)
        {
            DataTable dtSession;
            string JString = "";
            cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@XMLData", leadXML);
            cmd.Parameters.AddWithValue("@Flag", 1);
            dtSession = Db_Access.ExecuteDataTable(ref cmd, "USP_CREMA_INSERT_LEAD_DETAILS");
            JString = Utilities.dtToJson(dtSession);
            return JString;
        }
    }

    public class LeadProp
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string DOB { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public int Pincode { get; set; }
        public int PincodeId { get; set; }
        public int CountryId { get; set; }
        public int OccupationId { get; set; }
        public int ReligionId { get; set; }
        public string BudgetId { get; set; }
        public string IpAddress { get; set; }
        public string CompanyName { get; set; }
        public string LeadStatus { get; set; }
        public string SourceID { get; set; }
        public string LeadQualify { get; set; }
        public string Designation { get; set; }
        public bool IsDirectWalking { get; set; }
        public int CPID { get; set; }
        public string ModeOfContact { get; set; }
        public string CompanyLocation { get; set; }
        public string CreatedBy { get; set; }
        public bool IsNri { get; set; }
        public int Propertyid { get; set; }
        public int PurposeId { get; set; }
        public int LanguageId { get; set; }
        public int InventoryId { get; set; }
        public int PosessionId { get; set; }
        public int VisitorTypeId { get; set; }
        public int CompanyLocationId { get; set; }
        public string Subsource { get; set; }
        public string ConfigurationIds { get; set; }
        public int IsCPRegistered { get; set; }
        public string CPName { get; set; }
        public string CPMobile { get; set; }
        public string CPLocation { get; set; }
        public string Comments { get; set; }
        public long Prospectid { get; set; }
        public int gender { get; set; }
        public string OTP { get; set; }
        public int FlatConfiguration { get; set; }
        public int LeadId { get; set; }
    }

    public class LeadSubSource
    {
        public int Id { get; set; }
        public int SourceId { get; set; }
        public string SubSource { get; set; }
    }

    public class LeadSource
    {
        public int Id { get; set; }
        public int SourceId { get; set; }
        public string SourceName { get; set; }
        public string StrSubSourceList { get; set; }
        public bool IsInput { get; set; }
    }

    public class LeadMasterData
    {
        public List<Dropdown> SourceList { get; set; }
        public List<Dropdown> OccupationList { get; set; }
        public List<Dropdown> ReligionList { get; set; }
        public List<Dropdown> VisitorTypeList { get; set; }
        public List<LeadSubSource> LeadSubSourceList { get;set;}
    }
    
    public class TeleCallerLead
    {
        public int LeadId { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public int PropertyId { get; set; }
        public int CampaignId { get; set; }
        public bool BrochureFlag { get; set; }
        public bool SiteVisitFlag { get; set; }
        public DateTime SiteVisitDate { get; set; }
        public string SiteVisitTime { get; set; }
        public string Comments { get; set; }
        public int CPID { get; set; }
        public bool IsCPRegister { get; set; }
        public int LeadTypeId { get; set; }
        public int LeadStatus { get; set; }
        public bool WhatsAppBrochureFlag { get; set; }
        public string WhatsAppNo { get; set; }

    }

    public class SiteVisitLead
    {
        public int LeadId { get; set; }
        public string LeadName { get; set; }
        public string Mobile { get; set; }
    }
    
    public class Lead360
    {
        public int LeadId { get; set; }
        public string LeadName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string PropertyName { get; set; }
        public string Source { get; set; }
        public string SiteVisited { get; set; }
        public string LeadStatus { get; set; }
    }

    public class _Lead360Details
    {
        public int LeadId { get; set; }
        public string LeadName { get; set; }
        public string Gender { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string PropertyName { get; set; }
        public string Source { get; set; }
        public string SiteVisited { get; set; }
        public string LeadStatus { get; set; }
        public string Budget { get; set; }
        public string Configuration { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }
        public string Pincode { get; set; }
        public string District { get; set; }
        public string ResidentialLocation { get; set; }
        public string Comments { get; set; }
        public int CPID { get; set; }
        public bool IsCPRegister { get; set; }
        public int LeadTypeId { get; set; }
        public int CampaignId { get; set; }
        public int LeadStatusId { get; set; }
        public bool IsEdit { get; set; }
        public int PropertyId { get; set; }
        public string SiteVisitDate { get; set; }

    }

    public class Lead360Param
    {
        public int LeadId { get; set; }
        public int PropertyId { get; set; }
        public string SearchTxt { get; set; }

    }
}