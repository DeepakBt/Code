﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class Meeting
    {
        public long MeetingId { get; set; }
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public DateTime? MeetingDate { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public bool IsMeetingDone { get; set; }
        public int ModeOfContact { get; set; }
        public int OutcomeTypeId { get; set; }
        public string Comments { get; set; }
        public bool IsClosed { get; set; }
        public int LeadQualify { get; set; }
        public bool IsQualified { get; set; }
        public int AssignedRM { get; set; }
        public DateTime? NextMeetingDate { get; set; }
        public List<ProspectMOMQuestionAnswer> _ProspectMOMQuestionAnswer { get; set; }
        public int MeetingAgendaId { get; set; }
        public bool isScheduled { get; set; }
        public DateTime? NextCallDate { get; set; }
        public int LeadStatus { get; set; }
        public string ConfigurationIds { get; set; }
        public string BudgetIds { get; set; }
        public int OccupationId { get; set; }
        public int ResLocationId { get; set; }
        public int CarpetArea { get; set; }
        public string StatusCriteriaIds { get; set; }
        public string BudgetValue { get; set; }
        public string DesiredLocation { get; set; }
        public bool HasVisitedWithfamily { get; set; }
        public bool HasDecisionMakerArrived { get; set; }

    }
}
