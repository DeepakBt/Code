﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class Feedback
    {
        public int? FeedBackId { get; set; }
        public int? QueryRequestId { get; set; }
        public int? UserId { get; set; }
        public int? UserTypeId { get; set; }
        public string FeedBack { get; set; }
    }
    public class ProspectFeedBackQM
    {
        public int QuestionId { get; set; }
        public string QuestionText {get;set;}
        public List<FeedBackQMOptions> lstOptions { get; set; }
    }
    public class FeedBackQMOptions
    {
        public int AnswerId { get; set; }
        public string AnswerText { get; set; }
    }
    public class UserFeedBack
    {
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public int QuestionId { get; set; }
        public int AnswerId { get; set; }
        public string AnswerText { get; set; }
    }
}
