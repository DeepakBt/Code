﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class BankDetails
    {
        public long CPID { get; set; }
        public string AccountHolderName { get; set; }
        public string BankAccountNO { get; set; }
        public string BankTypeName { get; set; }
        public string BankName { get; set; }
        public string IFSCCode { get; set; }
        public string BranchName { get; set; }
        public string BranchAddress { get; set; }
        public string MICRCode { get; set; }
        public bool isDefault { get; set; }
    }
    public class Communication
    {
        public long CommunicationId { get; set; }
        public int Type { get; set; }
        public string Date { get; set; }
        public string ModeOfContact { get; set; }
        public string Agenda { get; set; }
        public string ContactPerson { get; set; }
        public string MOM { get; set; }
        public string LeadStatus { get; set; }
        public string MailAttachment { get; set; }
    }
    public class MileStone
    {
        public string MileStoneName { get; set; }
        public string Date { get; set; }
        public int MileStoneId { get; set; }
        public string CSSClass { get; set; }
    }
    public class UpcomingBirthday
    {
        public long PROSPECTID { get; set; }
        public string Name { get; set; }
        public string DOB { get; set; }
        public string Mobile { get; set; }
        public string PropertyName { get; set; }
    }
    public class UpcomingEvents
    {
        public long EventId { get; set; }
        public string EventName { get; set; }
        public string Location { get; set; }
        public string CityName { get; set; }
        public string Date { get; set; }
        public string Description { get; set; }
    }
    public class UniversalSearch
    {
        public string SearchResult { get; set; }
        public long UserId { get; set; }
        public int UserTypeId { get; set; }
        public bool? IsRegisterCP { get; set; }
        public List<Dropdown> UniversalSearchMST { get; set; }
    }
    public class CommonSearchFilters
    {
        public int Flag { get; set; }
        public int RoleId { get; set; }
        public long EmpId { get; set; }
        public string SearchText { get; set; }
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public int? PropertyId { get; set; }
    }
    public class LeadQualification
    {
        public string LeadType { get; set; }
        public string WalkIn { get; set; }
        public string FollowUp { get; set; }
    }
    public class CPPropertWalkIn
    {
        public long CPID { get; set; }
        public string PropertyCount { get; set; }
        public string WalkIn { get; set; }
        public string Hot { get; set; }
        public string Warm { get; set; }
        public string Cold { get; set; }
    }
    public class CPPayment
    {
        public long CPID { get; set; }
        public string ProjectDone { get; set; }
        public string DealDone { get; set; }
        public string TotalPayment { get; set; }
        public string PaymentDone { get; set; }
        public string AmountDue { get; set; }
    }
    public class PropertyDDL
    {
        public List<Dropdown> _PropertyDLL { get; set; }
        public List<Dropdown> _IsCompleteDLL { get; set; }
        public List<Dropdown> _Wing { get; set; }
        public List<Dropdown> _FloorNo { get; set; }
        public List<Dropdown> _FlatNo { get; set; } 
        public List<Dropdown> _CarpetArea { get; set; }
    }
    public class MeetingOutCome
    {
        public int Id { get; set; }
        public int StatusId { get; set; }
        public string Value { get; set; }
        public bool Flag { get; set; }
    }
    public class Entity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }
    public class DocListFilters
    {
        public int? Flag { get; set; }
        public int? EmpId { get; set; }
        public int? UserId { get; set; }
        public int? UserTypeId { get; set; }
        public int? CategoryId { get; set; }
    }
    public class Subscriber
    {
        public string Email { get; set; }
        public bool isActive { get; set; }
    }
    public class GeneralLeadMeeting
    {
        public string LeadName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public bool IsNri { get; set; }
        public string Comments { get; set; }
        public DateTime MeetingDate { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
    }
    public class UnregisterCPDeveloper
    {
        public int Flag { get; set; }
        public int RegistrationId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string ReraId { get; set; }
        public string Comments { get; set; }
        public string City { get; set; }
        public string Location { get; set; }
        public int CPTypeId { get; set; }
        public string CPType { get; set; }
        public string NatureOfBusinessId { get; set; }
        public string NatureOfBusiness { get; set; }
        public int WalkingRating { get; set; }
        public int CPRating { get; set; }
        public bool IsSMSAvailable { get; set; }
        public bool IsEmailAvailable { get; set; }
        public int SMSCount { get; set; }
        public int EmailCount { get; set; }
        public int UnRegFlag { get;set;}
        public int PropertyId { get; set; }
        public string PropertyName { get; set; }
        public int SuburbLocationId { get; set; }
        public string SuburbLocation { get; set; }
        public int RMId { get; set; }
        public string RMName { get; set; }
        public bool IsRegisterCP { get; set; }
        public string CreatedBy { get; set; }
        public string CompanyName { get; set; }
        public int CategoryId { get; set; }
        public int Type2Id { get; set; }
        public string CategoryName { get; set; }
        public string Type2Name { get; set; }

    }
    public class MOM
    {
        public long MOMId { get; set; }
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public string Agenda { get; set; }
        public string Comments { get; set; }
    }
    public class TestInsert
    {
        public int Flag { get; set; }
        public string Data { get; set; }
    }

    public class ContactUs
    {
        public long ContactUs_Id { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string City { get; set; }
        public string Comments { get; set; }
    }
    public class KnowledgeCenterArticle
    {
        public long ArticleID { get; set; }
        public string ArticleDate { get; set; }
        public string Author { get; set; }
        public string HeaderText { get; set; }
        public string ImagePath { get; set; }
        public string Content { get; set; }
        public string VideoPath { get; set; }
    }
    public class DownloadURL
    {
        public string RETRIVALPATH { get; set; }
    }

    public class GeoLocation
    {
        public int Flag { get; set; }
        public string LoginLatitude { get; set; }
        public string LoginLongitude { get; set; }
        public string LoginAddress { get; set; }
        public string LogoutLatitude { get; set; }
        public string LogoutLongitude { get; set; }
        public string LogoutAddress { get; set; }
        public string appVersion { get; set; }
    }

    public class UserCPMapping
    {
        public Users User { get; set; }
        public List<RegUnRegCP> ListOfRegUnRegCP { get; set; }
    }
    public class Users
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int UserTypeId { get; set; }
    }
    public class RegUnRegCP
    {
        public int CPID { get; set; }
        public bool IsCPRegister { get; set; }
        public string CPName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string SD { get; set; }
        public string ED { get; set; }
        public int? PropertyId { get; set; }
        public string PropertyName { get; set; }
        public int MappingId { get; set; }
        public bool IsDelete { get; set; }

    }

    public class UserLanguageMapping
    {
        public Users User { get; set; }
        public List<Language> ListOfLanguage { get; set; }
    }

    public class UserPropertyMapping
    {
        public Users User { get; set; }
        public List<PropertyMapping> ListOfProperty { get; set; } 
    }
    public class PropertyMapping
    {
        public int PropertyId { get; set; }
        public string PropertyName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string SD { get; set; }
        public string ED { get; set; }
    }

    public class Language
    {
        public int LanguageId { get; set; }
        public string LanguageName { get; set; }

    }

    public class UserCampaignMapping
    {
        public Users User { get; set; }
        public List<CampaignMapping> ListOfCampaign { get; set; }
    }
    public class CampaignMapping
    {
        public int CampaignId { get; set; }
        public string CampaignName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string SD { get; set; }
        public string ED { get; set; }
        public int MappingId { get; set; }
    }

    public class RMCPMOM
    {
        public int MOMId { get; set; }
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public bool IsCPRegister { get; set; }
        public int? SupportId { get; set; }
        public string Comments { get; set; }
        public int PropertyId { get; set; }
        public int? NoOfEntities { get; set; }
        public int? NoOfDays { get; set; }
        public int? ModeOfContact { get; set; }
    }
    public class ResponseMessage
    {
        public int Result { get; set; }
        public string Message { get; set; }
    }
    public class AttendanceParam : Users
    {
        public string Month { get; set; }
        public string Year { get; set; }
    }
}
