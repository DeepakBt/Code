﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class CostSheet
    {
        public List<CostSheetParam> oCostSheetParamList { get; set; }
        public List<PaymentScheduleParam> oPayScheduleParamList { get; set; }
        public List<OtherChargesParam> oOtherChargesList { get; set; }
    }

    public class CostSheetParam
    {
        public int ParamId { get; set; }
        public string ParamName { get; set; }
        public double Value { get; set; } 
    }

    public class PaymentScheduleParam
    {
        public int PaymentScheduleId { get; set; }
        public string PayScheduleName { get; set; }
        public double Value { get; set; }
        public string DueDate { get; set; }
        public double AgreeValue { get; set; }
        public List<Tranch> tranches { get; set; }


    }

    public class OtherChargesParam
    {
        public int ParamId { get; set; }
        public string ParamName { get; set; }
        public double Value { get; set; }
    }

    public class CostSheetMasterData
    {
        public List<Dropdown> PlanMst { get; set; }
        public List<Entity> CostsheetParamMst { get; set; }
        public List<PaySchedule> PayScheduleMst { get; set; }
        public List<Entity> OtherChargesMst { get; set; }
        public List<Entity> TaxTypeMst { get; set; }
        public double AgreementValue { get; set; }
        public int PaymentPlanId { get; set; }
        public int Floor { get; set; }
        public double Params { get; set; }
        public List<PaySchedule> tranches { get; set; }

    }

    public class PaySchedule
    {
        public int PayScheduleId { get; set; }
        public string PayScheduleName { get; set; }
        public double PayPerc { get; set; }
        public double AgreementValue { get; set; }
        public double PrincipalAmt { get; set; }
        public double GST { get; set; }
        public double TDS { get; set; }
        public string DueDate { get; set; }
        public List<Tranch> tranches { get; set; }
        public int IsPaymentComplete { get; set; }
        public bool IsPaymentInitiated { get; set; }
    }

    public class Tranch : PaySchedule
    {
        public int TranchId { get; set; }
        public int IsEdit { get; set; }
    }

    public class Payment
    {
        public int PaymentScheduleTypeId { get; set; }
        public bool IsOtherCharges { get; set; }
        public int PaymentTypeId { get; set; }
        public double Amount { get; set; }
        public int PaymentModeId { get; set; }
        public string PaymentDate { get; set; }
        public string ChequeNo { get; set; }
        public string ChequeDate { get; set; }
        public string BankName { get; set; }

        public int BankId { get; set; }
        public List<FuturePayment> FuturePaymentList { get; set; }
        public string ChallanImgData { get; set; }
        public string ChallanImgName { get; set; }
        public string ChallanImgPath { get; set; }
    }
     
    public class FuturePayment
    {
        public double Amount { get; set; }
        public string NextPaymentDate { get; set; }
        public string Comments { get; set; }
    }
    
    public class PaymentMasterData
    {
        public List<PayScheduleParticular> ParticularList { get; set; }
        public List<Dropdown> PaymentTypeList { get; set; }
        public List<Dropdown> PaymentModeList { get; set; }
        public List<Dropdown> PaymentDueList { get; set; }
        public List<PaymentTranches> PaymentTranches { get; set; }
        public List<Tranch> TranchesList { get; set; }
    }   

    public class PayScheduleParticular
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double CompulsoryAmt { get; set; }
        public bool IsOtherCharges { get; set; }
    }

    public class PaymentPageInputParam
    {
        public long ClientId { get; set; }
        public bool IsOtherCharge { get; set; }
        public int PaymentScheduleTypeId { get; set; }
    }

    public class ClientRegistrationFees
    {
        public double RegistrationAmount { get; set; }
        public double StampDutyAmount { get; set; }
        public string ChallanImgData { get; set; }
        public string ChallanImgName { get; set; }
        public string ChallanImgPath { get; set; }
        public double ScanningCharges { get; set; }
    }

    public class PaymentTranches : Payment
    {
        public int Id { get; set; }
        public string PaymentTypeName { get; set; }
        public bool IsPaymentDone { get; set; }
        public bool IsEdit { get; set; }
        public bool IsValid { get; set; }
        public int TranchId { get; set; }
    }

}
