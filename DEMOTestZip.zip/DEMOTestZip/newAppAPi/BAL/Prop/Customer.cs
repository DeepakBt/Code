﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class Customer
    {
        public long Customer_Id { get; set; }
        public int ApplicantTypeID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string DOB { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string Occupation { get; set; }
        public string Gender { get; set; }
        public string Entity { get; set; }
        public string Language { get; set; }
        public string Religion { get; set; }
        public BookingDetails BookingDetails { get; set; }
        public List<MileStone> CustMileStone { get; set; }
        public Communication SelectedCommunication { get; set; }
        public List<Communication> lstCommunication { get; set; }
        public List<Applicant> Applicant { get; set; }
        public int PaymentPlanId { get; set; }
        public CostSheet oCostSheet { get; set; }

        public Payment ClientPayment { get; set; }
        public Customer360PaymentOverView Customer360PaymentOverView { get; set; }
        public Customer360OtherCharges Customer360OtherCharges { get; set; }

        public ClientRegistrationFees ClientRegistrationFees { get; set; }
        public int PropertyId { get; set; }
        public int CPID { get; set; }
        public double CPBrokeragePercentage { get; set; }
        public List<PaymentTranches> PaymentTranchesList { get; set; }
    }

    public class Applicant
    {
        public long Customer_Id { get; set; }
        public int ApplicantTypeID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string DOB { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string Occupation { get; set; }
        public string Gender { get; set; }
        public string Entity { get; set; }
    }

    public class BookingDetails
    {
        public long Customer_ID { get; set; }
        public long BookingId { get; set; }
        public string PropertyName { get; set; }
        public string PerSqFeetRate { get; set; }
        public string BookingDate { get; set; }
        public string UnitType { get; set; }
        public int Floor { get; set; }
        public string BuildingWing { get; set; }
        public string ParkingAllocated { get; set; }
        public int ApartmentNo { get; set; }
        public string CarpetArea { get; set; }
        public string AgreementValue { get; set; }
        public string Source { get; set; }
        public string PayedAmount { get; set; }

    }
    public class Customer360PaymentOverView
    {
        public PaymentOverView PaymentOverView { get; set; }
        public CustomerProperty CustomerProperty { get; set; }
        public CostAcquisition CostAcquisition { get; set; }
        public StampDuty StampDuty { get; set; }
        public List<OtherChargesOverView> OtherCharges { get; set; }
        public List<PaymentPlanView> PaymentPlanView { get; set; }
        public List<PaymentPlot> PaymentPlot { get; set; }
        public string TotalPaymentPlot { get; set; }
        public List<PaymentDetails> PaymentDetails { get; set; }
        public CustomerPaymentSummary CustomerPaymentSummary { get; set; }
    }
    public class CustomerPaymentSummary
    {
        public string TotalAmount { get; set; }
        public string PayedAmount { get; set; }
        public string PendingAmount { get; set; }
    }
    public class OtherChargesOverView
    {
        public string Name { get; set; }
        public string Amount { get; set; }
    }
    public class StampDuty
    {
        public string Stamp_Duty { get; set; }
        public string RegistrationCharges { get; set; }
        public string RegistrationAppPay { get; set; }
        public string EstimatedCostOfAcquisition { get; set; }
        public string ScanningCharges { get; set; }
    }
    public class CustomerProperty
    {
        public string BookedDate { get; set; }
        public string PropertyName { get; set; }
        public string ApartmentNo { get; set; }
        public string Floor { get; set; }
        public string CarpetArea { get; set; }
        public string PropertyConfig { get; set; }
    }
    public class CostAcquisition
    {
        public string CostOfAcquisition { get; set; }
        public string AgreementValue { get; set; }
        public string GSTonAgreementValue { get; set; }
    }
    public class PaymentOverView
    {
        public string PlanName { get; set; }
        public string SourceName { get; set; }
        public string AgreementValue { get; set; }
    }
    public class PaymentPlanView
    {
        public string ScheduleName { get; set; }
        public string PaymentPerc { get; set; }
        public string AgreementValue { get; set; }
        public string PrincipalAmt { get; set; }
        public string GSTAmt { get; set; }
        public string TDSAmt { get; set; }

    }
    public class PaymentPlot
    {
        public string PaymentDate { get; set; }
        public string Amount { get; set; }
    }

    public class PaymentDetails
    {
        public long MappingScheduleId { get; set; }
        public bool DetailShowFlag { get; set; }
        public string ScheduleName { get; set; }
        public string AgreementValue { get; set; }
        public string Amount { get; set; }
        public string PaymentDate { get; set; }
        public string PaymentDueDate { get; set; }
        public string PendingAmount { get; set; }
        public string DelayedDays { get; set; }
        public string DelayedInterest { get; set; }
        public string TotalPendingDue { get; set; }

    }

    public class Customer360OtherCharges
    {
        public List<PaymentSchedule> PaymentSchedule { get; set; }
        public List<OtherCharges> OtherCharges { get; set; }
    }
    public class PaymentSchedule
    {
        public string ScheduleName { get; set; }
        public string GSTAmount { get; set; }
        public string GSTPaid { get; set; }
        public string TDSAmount { get; set; }
        public string TDSPaid { get; set; }
        public bool GSTFlag { get; set; }
        public bool TDSFlag { get; set; }
    }
    public class OtherCharges
    {
        public string OtherCharge { get; set; }
        public string Amount { get; set; }
        public string PaidAmount { get; set; }
        public string Flag { get; set; }
    }
    public class Customer360Summary
    {
        public CustomerCount CustomerCount { get; set; }
        public List<CustomerDetails> CustomerDetails { get; set; }
    }
    public class CustomerCount
    {
        public string NoOfFlatBooked { get; set; }
        public string NoOfRegistrationDone { get; set; }
        public string NoOfBookingDone { get; set; }
        public string NoOfMeetingCallDone { get; set; }
    }
    public class CustomerDetails
    {
        public long Customer_ID { get; set; }
        public string CustomerName { get; set; }
        public string Typology { get; set; }
        public string Wing { get; set; }
        public string RegistrationDone { get; set; }
        public string PropertyName { get; set; }
        public string Received { get; set; }
    }
    public class ProjectUpdateWrapper
    {
        public List<ProjectUpdate> ProjectUpdate { get; set; }
    }
    public class ProjectUpdate
    {
        public string Date { get; set; }
        public string Title { get; set; }
        public string DocName { get; set; }
        public List<Images> Images { get; set; }
        public List<Files> Files { get; set; }
    }
    public class Images
    {
        public string ImgPath { get; set; }
    }
    public class Files
    {
        public string File { get; set; }
    }

    public class SlabPaymentDetails
    {
        public string SlabName { get; set; }
        public string PaymentDate { get; set; }
        public string Amount { get; set; }
        public string PaymentType { get; set; }
        public string PaymentMode { get; set; }
        public string ChequeDate { get; set; }
        public string ChequeNo { get; set; }
    }

    public class BankLoanProcess
    {
        public int BankId { get; set; }
        public string BankName { get; set; }
        public string BankLogo { get; set; }
        public string InterestRange { get; set; }
        public string ProcessingFeeRange { get; set; }
        public string LoanAmount { get; set; }
        public string TenureRange { get; set; }
        public List<Dropdown> BenefitsList { get; set; }
        public List<Dropdown> ContactDetailsList { get; set; }
        public List<Dropdown> LoanProcessList { get; set; }
    }

    public class CustomerBooking
    {
        public DateTime? DateBooked { get; set; }
        public int? FormNo { get; set; }
        public int? ApplicantTypeId { get; set; }
        public int? ProspectId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CommunicationAddress { get; set; }
        public int? Country { get; set; }
        public string CountryName { get; set; }
        public int? PinId { get; set; }
        public string PinCode { get; set; }
        public string Address { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public bool? IsNRI { get; set; }
        public string LandlineNo { get; set; }
        public DateTime? DOB { get; set; }
        public string DateOfBirth { get; set; }
        public int? OccupationId { get; set; }
        public int? BuildingWing { get; set; }
        public bool? ParkingAllocated { get; set; }
        public int? ApartmentNo { get; set; }
        public int? Floor { get; set; }
        public int? UnitTypeId { get; set; }
        public int? CarpetArea { get; set; }
        public decimal? AgreementValue { get; set; }
        public decimal? BookingAmount { get; set; }
        public int? Gender { get; set; }
        public string GenderName { get; set; }
        public int? EntityId { get; set; }
        public int? PaymentMode { get; set; }
        public int? PropertyId { get; set; }
        public string PropertyName { get; set; }
    }
}
