﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class Reports
    {
        public int ReportId { get; set; }
        public string DisplayName { get; set; }
        public string SpName { get; set; }
        public string ConnectionString { get; set; }
        public List<Param> ListParams { get; set; }
        public bool IsDisplay { get; set; }
    }

    public class ReportParam
    {
        public int ReportId { get; set; }
        public int Flag { get; set; }
        public int? PropertyId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? Period { get; set; }
        public string RMId { get; set; }
        public int? CPID { get; set; }
        public bool IsCPRegister { get; set; }
        public int? AssignedRm { get; set; }
        public int StatusId { get; set; }
        public int? CreatedBy { get; set; }
        public long? EmpId { get; set; }
        public int? EmpTypeId { get; set; }

    }

    public class RPT_SalesRMWiseData
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public int SiteVisit { get; set; }
        public int RevisitCount { get; set; }
        public int Rejected { get; set; }
        public int Followup { get; set; }
        public int Eoi_Interested { get; set; }
        public int Closure { get; set; }
        public string ClosureProductivity { get; set; }
        public string RejectionRatio { get; set; }
        public int MOMPending { get; set; }
    }

    public class RPT_SalesRMFollowUpData
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int SiteVisit { get; set; }
        public int Followup { get; set; }
        public int Followup1 { get; set; }
        public int Followup2 { get; set; }
        public int Followup3 { get; set; }
        public int Greater_than_3 { get; set; }
    }

    public class RPT_SalesMeetingCount
    {
        public int No_of_Meeting { get; set; }
        public int ClosureLeadCount { get; set; }
    }

    public class RPT_CPLoginActivitySummary
    {
        public int CPID { get; set; }
        public string CPCode { get; set; }
        public string Name { get; set; }
        public int LoginCount { get; set; }
    }
    public class RPT_StatusWiseRevisit
    {
        public int LeadStatusId { get; set; }
        public string LeadStatusName { get; set; }
        public int ClientCount { get; set; }
        public int ReSiteVisitCount { get; set; }
        public int ReVisit1 { get; set; }
        public int ReVisit2 { get; set; }
        public int ReVisit3 { get; set; }
        public int ReVisitGreaterThen3 { get; set; }
    }
    public class Param
    {
        public string ParamName { get; set; }
        public string DefaultValue { get; set; }
        public int ParamId { get; set; }
    }

    public class ReportSubCategory
    {
        public string SubCategoryName { get; set; }
        public int SubCategoryId { get; set; }
        public List<Reports> ListReports { get; set; }
    }

    public class ReportCategory
    {
        public string CategoryName { get; set; }
        public int CategoryId { get; set; }
        public List<ReportSubCategory> ListSubCategory { get; set; }
    }

    
}
