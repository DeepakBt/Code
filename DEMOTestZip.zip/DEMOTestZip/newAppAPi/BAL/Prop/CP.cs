﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BAL.Prop;
namespace BAL
{
    public class CP
    {
        public long CPId { get; set; }
        public string Agreementlocation { get; set; }
        public int AgreementlocationId { get; set; }
        public string AgreementDate { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public int CpTypeId { get; set; }
        public string CPSalutation { get; set; }
        public string CPName { get; set; }
        public string ProprieterSalutation { get; set; }
        public string ProprieterName { get; set; }
        public string KartaName { get; set; }
        public int? CPRelationType { get; set; }
        public string CPRelationName { get; set; }
        public string PanCard { get; set; }
        public string Address { get; set; }
        public string PinCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string FirstPartnerSalutation { get; set; }
        public string SecondPartnerSalutation { get; set; }
        public string FirstPartnerName { get; set; }
        public string SecondPartnerName { get; set; }
        public string FirstDirectorSalutation { get; set; }
        public string SecondDirectorSalutation { get; set; }
        public string FirstDirectorName { get; set; }
        public string SecondDirectorName { get; set; }
        public string AuthorisationDate { get; set; }
        public string CIN { get; set; }
        public string AuthorisedSignatorySalutation { get; set; }
        public string AuthorisedSignatoryCompany { get; set; }
        public string ReraID { get; set; }
        public string Office { get; set; }
        public int LocationId { get; set; }
        public string ImageData { get; set; }
        public string ImageName { get; set; }
        public string ImagePath { get; set; }

        public int Status { get; set; }
        public string StatusName { get; set; }

        public string PermState { get; set; }
        public string PermCity { get; set; }
        public string PermPinCode { get; set; }
        public string hdnPermPinId { get; set; }
        public string OfficeNo { get; set; }
        public string ResNo { get; set; }
        public string AadharNo { get; set; }
        public string GSTNo { get; set; }
        public string P1Contact { get; set; }
        public string P2Contact { get; set; }
        public string IncorpDate { get; set; }
        public string IsGSTPresent { get; set; }
        public string IsRelatedToCentrum { get; set; }
        public string BuisnessCode { get; set; }
        public string RERA2Id { get; set; }
        public string RERAState { get; set; }
        public string IsRERAMultiple { get; set; }
        public string BuisnessProfileType { get; set; }
        public string RefName { get; set; }
        public string RefContact { get; set; }
        public string RefAddr { get; set; }
        public string IsGSTFormAttached { get; set; }
        public string IsPermAddrSame { get; set; }
        public string ContactName { get; set; }
        public string ContactOfficeNo { get; set; }
        public string ContactResNo { get; set; }
        public string ContactMobNo { get; set; }
        public string KartaPan { get; set; }
        public string PermAddress { get; set; }
        public string DocumentList { get; set; }
        public int CategoryId { get; set; }
        public int Type2Id { get; set; }
        public string CategoryName { get; set; }
        public string Type2Name { get; set; }
        public int CPRating { get; set; }

        #region BankVariables
        public string AcName { get; set; }
        public string AccountNo { get; set; }
        public string BankName { get; set; }
        public string IFSCCode { get; set; }
        public string MICRCode { get; set; }
        public string BranchName { get; set; }
        public string BranchAddress { get; set; }
        public string AccountType { get; set; }
        public int AccountTypeId { get; set; }
        #endregion

        #region BusinessVar
        public string InceptionDate { get; set; }
        public int? NoOfEmployees { get; set; }
        public int? NoOfManagers { get; set; }

        public string ManagerContact { get; set; }
        public int? NoOfOffices { get; set; }
        public string Location { get; set; }
        public string AnyOtherBusinessLife { get; set; }
        public double OtherBusinessTurnOver { get; set; }
        public int? OtherBusinessEmpCount { get; set; }
        public string AssociatedGradeADevelopers { get; set; }
        public string AssociatedGradeBDevelopers { get; set; }
        public string SoleSelling { get; set; }
        public string Others { get; set; }
        public double? TotalRevenue { get; set; }
        public bool? IsPastSoleSelling { get; set; }
        public bool? IsAnyLitigation { get; set; }
        public string LitigationDetails { get; set; }
        public string BusinessModelTypes { get; set; }
        public string AreaOfOperationTypes { get; set; }
        public string LeadSourcesTypes { get; set; }
        public int? TurnOverSlabId { get; set; }
        public string UserName { get; set; }
        public string OTP { get; set; }

        #endregion
    }

    public class CPMasterData
    {
        public List<Dropdown> SalutationMst { get; set; }
        public List<Dropdown> CPTypeMst { get; set; }
        public List<Dropdown> RelationMst { get; set; }
        public List<Dropdown> BusinessProfMst { get; set; }
        public List<Dropdown> BankAccTypes { get; set; }
        public List<Dropdown> AreaOfOperationTypes { get; set; }
        public List<Dropdown> BusinessModelTypes { get; set; }
        public List<Dropdown> LeadSourceTypes { get; set; }
        public List<Dropdown> TurnOverSlabs { get; set; }
        public List<Dropdown> CategoryMst { get; set; }
        public List<Dropdown> Type2Mst { get; set; }
        public List<Dropdown> RatingMst { get; set; }

        public string ImagPath { get; set; }
        public int DocTypeId { get; set; }
    }

    public class CPPropertyStatus
    {
        public string PropertyCount { get; set; }
        public string WalkIn { get; set; }
        public string FollowUp { get; set; }
        public string Booked { get; set; }
        public string ConversionRatio { get; set; }
        public string Qualified { get; set; }
        public List<ProspectsSiteVisit> listLead { get; set; }
    }

    public class CP360View
    {
        public long CPID { get; set; }
        public string CPName { get; set; }
        public string Entity { get; set; }
        public string Address { get; set; }
        public string PanCard { get; set; }
        public string GSTNO { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string AadharNo { get; set; }
        public string RERAID { get; set; }
        public BankDetails BankDetail { get; set; }
        public Communication SelectedCommunication { get; set; }
        public List<Communication> lstCommunication { get; set; }
    }

    public class CPPropertyDashboard
    {
        public long CPID { get; set; }
        public string PropertyCount { get; set; }
        public string PropertyName { get; set; }
        public string WalkIn { get; set; }
        public string FollowUp { get; set; }
        public string Intrested { get; set; }
        public string Booked { get; set; }
        public List<LeadQualification> LstLeadType { get; set; }
        public CPPropertWalkIn CPPropertWalkIn { get; set; }
        public CPPayment CPPaymentDone { get; set; }
        public List<UpcomingBirthday> UpcomingBirthday { get; set; }
        public List<UpcomingEvents> UpcomingEvents { get; set; }
        public BookingStatus BookingStatus { get; set; }
        public List<Entity> RankList { get; set; }
    }
    public class BookingStatus
    {
        public string BookedFlat { get; set; }
        public decimal BookedPer { get; set; }
        public string Color { get; set; }
        public List<BookingStatusSummary> BookingStatusSummary { get; set; }
    }
    public class BookingStatusSummary
    {
        public string MileStoneName { get; set; }
        public string CustomerCount { get; set; }
        public decimal Percentage { get; set; }
        public string Color { get; set; }
    }

    public class PaymentSummary
    {
        public CPPayment Payment { get; set; }
        public List<CPCustomerPaymentSummary> _CPCustomerPaymentSummary { get; set; }
    }
    public class CPCustomerPaymentSummary
    {
        public long Customer_ID { get; set; }
        public string Date { get; set; }
        public string CustomerName { get; set; }
        public string PropertyName { get; set; }
        public string PaymentDone { get; set; }
        public bool IsRegistration { get; set; }
        public string InvoiceAmount { get; set; }
        public string GenerateInvoice { get; set; }
        public string ProcessPayment { get; set; }
        public int PropertyId { get; set; }
    }
    public class CPSupportCost
    {
        public int Flag { get; set; }
        public int SupportCostId { get; set; }
        public int CPID { get; set; }
        public string CPName { get; set; }
        public bool IsCPRegister { get; set; }
        public string CreatedDate { get; set; }
        public int SupportTypeId { get; set; }
        public string SupportType { get; set; }
        public int Unit { get; set; }
        public decimal Cost { get; set; }
        public decimal TotalCost { get; set; }
        public int PropertyId { get; set; }
        public string PropertyName { get; set; }
    }

    public class CPAttendance
    {
        public int CPID { get; set; }
        public bool IsRegisterCP { get; set; }
        public int PropertyId { get; set; }
    }
    public class _CPAttendance
    {
        public string PropertyName { get; set; }
        public string CPName { get; set; }
        public string IsCPRegister { get; set; }
        public string AttendanceDate { get; set; }
        public string Mobile { get; set; }
    }
}
