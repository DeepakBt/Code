﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class SalesRM
    {
        public string Name { get; set; }
        public DashboardSelectedParams oSelectedParams { get; set; }
    }

    public class SalesRMMasterData
    {
        public List<Dropdown> SalesRMList;
        public List<Dropdown> PropertyList;
        public List<Dropdown> LeadStatusList;
        public List<Dropdown> LeadQualificationList;
        public List<Dropdown> CPList;
        public List<Entity> SessionParams;
    }

    public class DashboardSelectedParams
    {
        public int? PropertyId { get; set; }
        public int? LeadStatusId { get; set; }
        public int? LeadQualiId { get; set; }
        public int Flag { get; set; }
        public int CPId { get; set; }
        public string RMId { get; set; }
        public int FTD { get; set; }
        public string ProspectSearch { get; set; }

    }

    public class SalesRMDashboard
    {
        public string DisplayBlocks { get; set; }
        public string RMProspectDataList { get; set; }
        public string RMTodaysCallList { get; set; }
    }

    public class InventoryStatus
    {
        public long InventoryId { get; set; }
        public string FlatNo { get; set; }
        public bool? UpdatedBookingStatus { get; set; }
        public string BookedStatus { get; set; }
        public string Wing { get; set; }
        public string Facing { get; set; }
        public string Name { get; set; }
        public int StatusId { get; set; }

    }
    public class SalesAnalyticDashboard
    {
        public LeadTypeBreakUp LeadTypeBreakUp { get; set; }
        public LeadSourceBreakUp LeadSourceBreakUp { get; set; }
        public LeadStatusBreakUp LeadStatusBreakUp { get; set; }
        public LeadStatusColor LeadStatusColor { get; set; }
    }
    public class LeadTypeBreakUp
    {
        public int Hot { get; set; }
        public int Warm { get; set; }
        public int Cold { get; set; }
        public bool DataDisplayFlag { get; set; }
    }
    public class LeadSourceBreakUp
    {
        public int CP { get; set; }
        public int Offline { get; set; }
        public int Online { get; set; }
        public int Others { get; set; }
        public bool DataDisplayFlag { get; set; }
    }

    public class LeadStatusBreakUp
    {
        public int InDiscussion { get; set; }
        public int FollowUp { get; set; }
        public int Positive { get; set; }
        public int Closure { get; set; }
        public int BookedEOI { get; set; }
        public int NotInterested { get; set; }
        public int Rejected { get; set; }
        public bool DataDisplayFlag { get; set; }
    }

    public class LeadStatusColor
    {
        public string InDiscussion { get; set; }
        public string FollowUp { get; set; }
        public string Positive { get; set; }
        public string Closure { get; set; }
        public string BookedEOI { get; set; }
        public string NotInterested { get; set; }
        public string Rejected { get; set; }
        public bool DataDisplayFlag { get; set; }
    }
}
