﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BAL
{
    public class User
    {
        #region variable declaration
        public string firstname { get; set; }
        public string middlename { get; set; }
        public string lastname { get; set; }
        public string mobile { get; set; }
        public string email { get; set; }
        public string pan { get; set; }
        public string aadharno { get; set; }
        public string bosscode { get; set; }
        public string joiningdate { get; set; }
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string address3 { get; set; }
        public int roleid { get; set; }
        public int subroleid { get; set; }
        public int languageid { get; set; }
        public int EmpId { get; set; }
        public string MappedRole { get; set; }
        public string MappedSubRole { get; set; }
        public List<Component> MappedComponentsList { get; set; }
        public string OTP { get; set; }
        public string Username { get; set; }

        public string TokenId { get; set; }
        public int Result { get; set; }
        public string Message { get; set; }
        public string LandingPage { get; set; }
        public string Login { get; set; }
        public string DocumentList { get; set; }

        #endregion
    }

    public class UserMasterData
    {
        public List<Dropdown> RoleMst { get; set; }
        public List<Dropdown> SubRoleMst { get; set; }
        public List<Dropdown> LanguageMst { get; set; }
    }

    public class Component
    {
        public int ComponentId { get; set; }
        public string ComponentName { get; set; }
        public string DisplayName { get; set; }
        public string IconClass { get; set; }
        public int IsMapped { get; set; }
        public int Flag { get; set; }
        public List<SubComponent> ListSubComponent { get; set; }
    }

    public class SubComponent : Component
    {
        public int ParentComponentId { get; set; }
    }

    public class UserSession
    {
        public string Username { get; set; }
        public string TokenId { get; set; }
        public int Result { get; set; }
        public string Message { get; set; }
        public string LandingPage { get; set; }
        public string Login { get; set; }
        public int EmpId { get; set; }
        public int roleid { get; set; }
        public List<Component> MappedComponentsList { get; set; }
        public bool IsAccept { get; set; }

    }

    public class UserActivity
    {
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public string UserName { get; set; }
        public DateTime LoginT { get; set; }
        public string LoginTime { get; set; }
        public DateTime LogoutT { get; set; }
        public string LogoutTime { get; set; }
        public string LoginAddress { get; set; }
        public string LogoutAddress { get; set; }
        public string CPName { get; set; }
    }
    public class UserParam
    {
        public int Flag { get; set; }
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public int FTD { get; set; }
         public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}
