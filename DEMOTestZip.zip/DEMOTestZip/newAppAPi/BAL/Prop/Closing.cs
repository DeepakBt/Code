﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class ClosingParam
    {
        public int? Flag { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? PropertyId { get; set; }
        public int? Period { get; set; }
        public int? Filter { get; set; }
        public int? Drill { get; set; }
        public int? isSupported { get; set; }
        public int? SourceId { get; set; }
        public int? LeadStatus { get; set; }
    }
}
