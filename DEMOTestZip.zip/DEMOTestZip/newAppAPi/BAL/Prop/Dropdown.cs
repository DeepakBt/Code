﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class Dropdown
    {
        public int Id { get; set; } 
        public string Value { get; set; }
        public bool SelectedFlag { get; set; }
    }
    public class UserCPDropDown
    {
        public int Id { get; set; }
        public string Value { get; set; }
        public bool IsCPRegister { get; set; }
    }
    public class CPSupportDDL
    {
        public int Id { get; set; }
        public string Value { get; set; }
        public int Unit { get; set; }
        public decimal Cost { get; set; }
    }
}
