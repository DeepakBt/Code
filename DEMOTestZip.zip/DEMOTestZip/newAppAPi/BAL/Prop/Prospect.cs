﻿using BAL.Prop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class Prospect
    {
        public string FirstName { get; set; }
        public string FullName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string DOB { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public int Pincode { get; set; }
        public int PincodeId { get; set; }
        public int CountryId { get; set; }
        public int OccupationId { get; set; }
        public int ReligionId { get; set; }
        public string ReligionName { get; set; }
        public string BudgetIds { get; set; }
        public string IpAddress { get; set; }
        public string CompanyName { get; set; }
        public string ProspectStatus { get; set; }
        public string SourceID { get; set; }
        public string ProspectQualify { get; set; }
        public string Designation { get; set; }
        public bool IsDirectWalking { get; set; }
        public int CPID { get; set; }
        public string ModeOfContact { get; set; }
        public string CompanyLocation { get; set; }
        public string CreatedBy { get; set; }
        public bool IsNri { get; set; }
        public int Propertyid { get; set; }
        public int PurposeId { get; set; }
        public int LanguageId { get; set; }
        public string LanguageName { get; set; }
        public int InventoryId { get; set; }
        public int PosessionId { get; set; }
        public int VisitorTypeId { get; set; }
        public int CompanyLocationId { get; set; }
        public string Subsource { get; set; }
        public string ConfigurationIds { get; set; }
        public int IsCPRegistered { get; set; }
        public string CPName { get; set; }
        public string CPMobile { get; set; }
        public string CPLocation { get; set; }
        public string Comments { get; set; }
        public long Prospectid { get; set; }
        public int AssignedSalesRMId { get; set; }
        public string AssignedSalesRMName { get; set; }
        public int NoOfVisits { get; set; }
        public string UpcomingMeetingDateTime { get; set; }
        public string VisitorType { get; set; }
        public string CreatedTime { get; set; }
        public int gender { get; set; }
        public string OTP { get; set; }
        public int SubsourceId { get; set; }
        public int LeadQualification { get; set; }
        public int? Flag { get; set; }
        public long MeetingId { get; set; }
        public int AttendeeArrived { get; set; }
        public int LeadStatus { get; set; }
        public string StatusComments { get; set; }
        public int IsLead { get; set; }
    }

    public class RMAssignMasterData
    {
        public List<Prospect> RMProspectDataList { get; set; }
        public List<Prospect> NewAssignedProspectDataList { get; set; }
        public List<Prospect> UnAssignedProspectList { get; set; }
    }

    public class MOMMasters
    {
        public List<Dropdown> ModeOfContact { get; set; }
        public List<MeetingOutCome> MeetingOutcome { get; set; }
        public List<Dropdown> LeadQualification { get; set; }
        public List<Dropdown> AgendaMaster { get; set; }
        public List<StatusCriteria> CriteriaMaster { get; set; }
    }
    public class ProspectsSiteVisit
    {
        public long PROSPECTID { get; set; }
        public string ProspectName { get; set; }
        public string Mobile { get; set; }
        public string NoOfVisit { get; set; }
        public string LastVisitDate { get; set; }
        public string LeadStatus { get; set; }
        public string Qualified { get; set; }
        public string RMName { get; set; }
        public string NextSiteVisit { get; set; }
        public string LeadType { get; set; }
    }
    public class Prospects360View
    {
       public long ProspectId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string SalesRM { get; set; }
        public string Occupation { get; set; }
        public string DOB { get; set; }
        public string LeadStatus { get; set; }
        public string LeadType { get; set; }
        public string PropertyName { get; set; }
        public int MeetingCount { get; set; }
        public int SiteVisitCount { get; set; }
        public string CompanyName { get; set; }
        public string designation { get; set; }
        public string Gender { get; set; }
        public string Religion { get; set; }
        public string Language { get; set; }
        public string Entity { get; set; }
        public string CompanyLocation { get; set; }
        public string SourceName { get; set; }
        public string InventoryType { get; set; }
        public string PosessionTime { get; set; }
        public string Purpose { get; set; }
        public string Budget { get; set; }
        public string Configuration { get; set; }
        public string Comments { get; set; }
        public Communication SelectedCommunication { get; set; }
        public List<Communication> lstCommunication { get; set; }
        public int IsEdit { get; set; }
    }

    public class ProspectMOMQuestions
    {
        public int QuestionId { get; set; }
        public string Question { get; set; }
        public string MOMText { get; set; }
        public string ParentHTML { get; set; }
        public string ChildHTML { get; set; }
    }

    public class ProspectMOMQuestionAnswer
    {
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public int AnswerId { get; set; }
        public string AnswerText { get; set; }
    }
    public class ProspectMeeting
    {
        public int MeetingId { get; set; }
        public int ProspectId { get; set; }
        public string MeetingDate { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public bool IsMeetingDone { get; set; }
        public int ModeOfContact { get; set; }
        public int OutcomeTypeId { get; set; }
        public string Comments { get; set; }
        public int AssignedRM { get; set; }
        public string Agenda { get; set; }
        public int LeadQualify { get; set; }
        public bool isQualify { get; set; }
        public int IsFirstMeeting { get; set; }
        public int ProspectStatus { get; set; }
    }

    public class Lead360Summary
    {
        public LeadCount LeadCount { get; set; }
        public List<Lead360Details> Lead360Details { get; set; }

    }
    public class LeadCount
    {
        public string NoOfLead { get; set; }
        public string NoOfLeadRevisit { get; set; }
        public string NoOfLeadQualified { get; set; }
        public string NoOfLeadInterested { get; set; }
        public string NoOfLeadFollowUp { get; set; }

    }
    public class Lead360Details
    {
        public long PROSPECTID { get; set; }
        public string LeadName { get; set; }
        public string SourceName { get; set; }
        public string Qualify { get; set; }
        public string ProjectName { get; set; }
        public string StatusName { get; set; }
        public string MobileNo { get; set; }
        public string IsQualified { get; set; }
    }

    public class StatusCriteria
    {
        public int StatusId { get; set; }
        public int CriteriaId { get; set; }
        public string CriteriaName { get; set; }
        public bool IsInputNeeded { get; set; }
        public string InputLabel { get; set; }
    }
}
