﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BAL
{
    public class Login
    {  
        public string UserName { get; set; }
        public string OTP { get; set; }
        public string Password { get; set; }
        public string TokenId { get; set; }
        public long EmpId { get; set; }
        public string EmpName { get; set; }
        public string newpassword { get; set; }
        public int RoleId { get; set; }

    }
    public class ForgetPassword
    {
        public int? Flag { get; set; }
        public string UserName { get; set; }
        public string OTP { get; set; }
    }
}
