﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class Filters360degree
    {
        public int? Flag { get; set; }
        public long? CPID { get; set; }
        public bool? IsCompleted { get; set; }
        public long? PropertyId { get; set; }
        public long? Customer_ID { get; set; }
        public long? ProspectId { get; set; }
        public long? DeveloperId { get; set; }
        public int? Type { get; set;}
        public long? CommunicationId { get; set; }
        public int? WingId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool? Currency { get; set; }
        public int? DrillId { get; set; }
        public int? FY { get; set; }
        public long? ArticleID { get; set; }
        public long? MappingScheduledId { get; set; }
        public int? OptionId { get; set; }
        public int? POptionId { get; set; }
        public string DocName { get; set; }
        public int? FloorNo { get; set; }
        public int? EmpId { get; set; }
        public int? RoleId { get; set; }
        public int? StatusId { get; set; }
        public int? ApartmentNo { get; set; }
        public int? TargetTypeId { get; set; }
        public int? CarpetArea { get; set; }
    }
}