﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class Brochure
    {
        public int Flag { get; set; }
        public int LeadId { get; set; }
        public int PropertyId { get; set; }
        public string WhatsAppNo { get; set; }
    }
    public class CallingAPI
    {
        public int CallingAPIId { get; set; }
        public string APILink { get; set; }
        public string Description { get; set; }
    }
    public class GlobalLeadBucket
    {
        public int GlobalLeadCount { get; set; }
        public List<_GlobalLeadBucket> _GlobalLeadBucket { get; set; }
    }
    public class _GlobalLeadBucket
    {
        public int LeadId { get; set; }
        public string LeadName { get; set; }
        public string CreatedDate { get; set; }
    }
    public class TCDBParam
    {
        public int Flag { get; set; }
        public int? PropertyId { get; set; }
        public int? Period { get; set; }
    }
    public class AssignedLead
    {
        public int LeadId { get; set; }
    }
    public class TCAssignedLead
    {
        public int Flag { get; set; }
        public string CreatedOn { get; set; }
        public int LeadId { get; set; }
        public string LeadName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Date { get; set; }
        //public string Source { get; set; }
        public int StatusId { get; set; }
        public int StatusCriteriaId { get; set; }
        public string StatusName { get; set; }
        public string CriteriaName { get; set; }
        public int PropertyId { get; set; }
        public string PropertyName { get; set; }
        public int ResidentialLocationId { get; set; }
        public string ResidentialLocation { get; set; }
        public string Comments { get; set; }
        public int FlatConfigurationId { get; set; }
        public string FlatConfiguration { get; set; }
        public int SubSourceId {get;set;}
        public string SubSource { get; set; }
        public bool IsProspect { get; set; }
        public string RmName { get; set; }
        public List<LeadBudget> _LeadBudget { get; set; }
    }
    public class LeadBudget
    {
        public int BudgetMappingId { get; set; }
        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public int BudgetId { get; set; }
        public string DisplayName { get; set; }
    }
    public class WhatsAppMsg
    {
        public int WhatsAppMsgId { get; set; }
        public string WhatsAppNumber { get; set; }
        public string MessageTxt { get; set; }
        public bool IsPdfLinkMsg { get; set; }
        public string BrochureReadLink { get; set; }
        public string BrochureWriteLink { get; set; }
        public string BrochureName { get; set; }
        public string Response { get; set; }

    }
}
