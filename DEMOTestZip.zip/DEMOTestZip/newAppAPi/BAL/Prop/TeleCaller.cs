﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class TeleCaller
    {
        public int Flag { get; set; }
        public int TeleCallerId { get; set; }
        public string TeleCallerCode { get; set; }
        public string TeleCallerName { get; set; }
        public int VendorId { get; set; }
        public string VendorName { get; set; }
        public string MobileNo { get; set; }
        public string WhatsAppNo { get; set; }
        public decimal YearOfExperience { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public int MotherTongueId { get; set; }
        public string MotherTongue { get; set; }
        public DateTime DOJ { get; set; }
        public string DateOfJoining { get; set; }
        public string PANCARD { get; set; }
        public string AADHARNO { get; set; }
        public decimal Cost { get; set; }
        public string Comments { get; set; }
        public bool IsActive { get; set; }
        public int UserTypeId { get; set; }
        public string Location { get; set; }
        public int LocationId { get; set; }
        public bool PropertyMappedFlag { get; set; }
        public Users User { get; set; }
        public List<Language> ListOfLanguage { get; set; }

    }
    public class TeleCallerVendor
    {
        public int Flag { get; set; }
        public int VendorId { get; set; }
        public string VendorCode { get; set; }
        public string Name { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string Location { get; set; }
        public int LocationId { get; set; }
        public string Remark { get; set; }
        public bool IsActive { get; set; }
    }

    public class TeleCallerDashBoard
    {
        public int TotalLead { get; set; }
        public int TotalSiteVisit { get; set; }
        public int TotalFollowUp { get; set; }
        public int TotalRejected { get; set; }
        public bool isLoginToday { get; set; }
    }
    public class TeleCallerSVFollowUp
    {
        public int LeadId { get; set; }
        public string LeadName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public int  PropertyId { get; set; }
        public bool CampaignId { get; set; }
        public bool IsCPRegister { get; set; }
        public int CPID { get; set; }
        public string CPName { get; set; }
        public bool BrochureFlag { get; set; }
        public bool SiteVisitFlag { get; set; }
        public string Comments { get; set; }
        public string Date { get; set; }
        public int LeadStatusId { get; set; }
        public bool WhatsAppBrochureFlag { get; set; }
        public string WhatsAppNo { get; set; }


    }

    public class TelecallerLeaves
    {
        public string TelecallerIds { get; set; }
        public string LoginDate { get; set; }
        public int AttendanceTypeId { get; set; }
    }
}
