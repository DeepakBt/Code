﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class Campaign
    {
        public int CampaignId { get; set; }
        public string CampaignName { get; set; }
        public decimal CostOfCampaign { get; set; }
        public int CampaignTypeId { get; set; }
        public string CampaignType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string SD { get; set; }
        public string ED { get; set; }
        public int PropertyId { get; set; }
        public string PropertyName { get; set; }
        public bool IsActive { get; set; }
    }
}
