﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class SourcingDashboard
    {
        public CPEmpanel _CPEmpanel { get; set; }
        public UNRegCP _UNRegCP { get; set; }
        public CPSiteAttendance _CPSiteAttendance { get; set; }
        public CPMeetingRatingwise _CPMeetingRatingwise { get; set; }
        public UnRegCPEmpanel _UnRegCPEmpanel { get; set; }
        public CPActiveInActive _CPActiveInActive { get; set; }
        public _CPSupportCost _CPSupportCost { get; set; }
        public NonTouchBaseCP _NonTouchBaseCP { get; set; }
    }
    public class CPEmpanel
    {
        public int InitiatedCP { get; set; }
        public int CompleteEmpanelCP { get; set; }
    }
    public class UNRegCP
    {
        public string Initiated { get; set; }
        public string Approved { get; set; }
        public string ApprovalPending { get; set; }
    }
    public class CPSiteAttendance
    {
        public int RegCP { get; set; }
        public int UnRegCP { get; set; }
        public int TotalCP { get; set; }
    }
    public class CPMeetingRatingwise
    {
        public int ZeroRating { get; set; }
        public int OneRating { get; set; }
        public int TwoRating { get; set; }
        public int ThreeRating { get; set; }
        public int FourRating { get; set; }
        public int FiveRating { get; set; }
    }
    public class UnRegCPEmpanel
    {
        public int Pending { get; set; }
        public int Done { get; set; }
        public int Total { get; set; }
    }
    public class CPActiveInActive
    {
        public int ActiveCP { get; set; }
        public int InActiveCP { get; set; }
    }
    public class _CPSupportCost
    {
        public decimal CPCost { get; set; }
        public int SiteVisiteDone { get; set; }
        public int Booked { get; set; }
    }
    public class NonTouchBaseCP
    {
        public int CPMappedToRM { get; set; }
        public int CPNotMappedToRM { get; set; }
        public int CPMappedMOMNotFilled { get; set; }
    }
    public class SourcingParam
    {
        public int? Flag { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? PropertyId { get; set; }
        public int? Period { get; set; }
        public int? Filter { get; set; }
        public int? Drill { get; set; }
        public int? isSupported { get; set; }
        public int?SourceId { get; set; }
        public int?LeadStatus { get; set; }
    }

    public class SourcingTarget
    {
        public int? TargetId { get; set; }
        public int? UserId { get; set; }
        public int? UserTypeId { get; set; }
        public string UserName { get; set; }
        public int? PropertyId { get; set; }
        public string PropertyName { get; set; }
        public int? TargetTypeId { get; set; }
        public string TargetType { get; set; }
        public int? TargetTypeValueId { get; set; }
        public string TargetTypeValue { get; set; }
        public int? TargetValue { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string SD { get; set; }
        public string ED { get; set; }
    }


}
