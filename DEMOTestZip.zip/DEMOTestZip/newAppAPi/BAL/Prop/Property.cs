﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class Property
    {
        public int PropertyId { get; set; }
        public string PropertyName { get; set; }
        public string PropertyStartDate { get; set; }
        public int WalkIn { get; set; }
        public int FollowUp { get; set; }
        public int Booked { get; set; }
        public decimal ConversionRatio { get; set; }
        public int Qualified { get; set; }
        public List<Dropdown> PurposeList { get; set; }
        public List<Dropdown> ConfigList { get; set; }
        public List<Dropdown> InventoryTypeList { get; set; }
        public List<Dropdown> BudgetList { get; set; }
        public List<Dropdown> VisitorTypeList { get; set; }
        public List<Dropdown> OccupationList { get; set; }
        public List<Dropdown> ReligionList { get; set; }
        public List<Dropdown> PosessionTimeList { get; set; }
        public List<LeadSource> LeadSourceList { get; set; }
        public List<Dropdown> GenderList { get; set; }
    }
}
