﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class BusinessBudget
    {
        public int CategoryId { get; set; }
        public int SubCategory { get; set; }
        public int SubCategory2 { get; set; }
        public decimal BudgetedAmount { get; set; }
        public int BudgetedID { get; set; }
        public int PropertyId { get; set; }

    }
    public class BusinessBudgetFilters
    {
        public int? Flag { get; set; }
        public int? CategoryId { get; set; }
        public int? SubCategoryId { get; set; }
        public int? SubCategoryId2 { get; set; }
    }

    public class BusinessBudgetSpent
    {
        public int BudgetSpendId { get; set; }
        public int PropertyId { get; set; }
        public int BudgetedId { get; set; }
        public decimal SpendAmount { get; set; }
        public DateTime SpendDate { get; set; }
    }
}
