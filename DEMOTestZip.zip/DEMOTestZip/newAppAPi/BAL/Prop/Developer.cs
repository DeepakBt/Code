﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Prop
{
    public class DeveloperLiveLeads
    {
        public List<LiveLeads> LiveLeads { get; set; }
        public List<BookingStatus> BookingStatus { get; set; }
        public List<SourceWiseBreakUp> SourceWiseBreakUp { get; set; }
    }

    public class DeveloperLiveInventory
    {
        public List<LiveInventory> LiveInventory { get; set; }
    }

    public class DeveloperPaymentStatus
    {
        public AgreementValue PaymentStatus { get; set; }
        public LiveInventory LiveInventory { get; set; }
        public List<ThreeMonthCashFlow> ThreeMonthCashFlow { get; set; }
        public List<InventoryBookingStatus> InventoryBookingStatus { get; set; }
        public AverageCarpetPrice AverageCarpetPrice { get; set; }
    }
    public class PaymentStatus
    {
        public string AVSold { get; set; }
        public string PaymentReceived { get; set; }
        public string PaymentDue { get; set; }
    }

    public class PaymentType
    {
        public string GSTReceived { get; set; }
        public string TDSReceived { get; set; }
        public string SDRReceived { get; set; }
    }

    public class ThreeMonthCashFlow
    {
        public string Dates { get; set; }
        public string DateString { get; set; }
        public string Value { get; set; }
    }

    public class LiveInventory
    {
        public string InventoryToSold { get; set; }
        public string SoldInventory { get; set; }
        public string PendingInventory { get; set; }
    }
    public class InventoryBookingStatus
    {
        public string Name { get; set; }
        public string TotalFlat { get; set; }
        public string BookedFlat { get; set; }
    }
    public class AverageCarpetPrice
    {
        public string AveragePrice { get; set; }
    }

    public class LiveLeads
    {
        public string WalkIn { get; set; }
        public string ReSiteVisit { get; set; }
        public string TouchBaseClient { get; set; }
    }
    public class BookingStatus
    {
        public string Period { get; set; }
        public string Hot { get; set; }
        public string Warm { get; set; }
        public string Cold { get; set; }
    }
    public class SourceWiseBreakUp
    {
        public int SourceId { get; set; }
        public string SourceName { get; set; }
        public string CountValue { get; set; }
        public string Percentage { get; set; }
        public string Total { get; set; }
    }

    public class InventoryPlot
    {
        public InventoryPlotProperty InventoryPlotProperty { get; set; }
        public List<Inventory> Inventory { get; set; }
    }
    public class Inventory
    {
        public List<DeveloperInventory> DeveloperInventory { get; set; }
    }
    public class DeveloperInventory
    {
        public int PropertyId { get; set; }
        public int FloorNo { get; set; }
        public string FlatNo { get; set; }
        public string Wing { get; set; }
        public string Facing { get; set; }
        public string Name { get; set; }
        public string BookedStatus { get; set; }
        public string CarpetArea { get; set; }
    }
    public class InventoryPlotProperty
    {
        public string Name { get; set; }
        public string Wing { get; set; }
        public string Sold { get; set; }
    }
    public class DeveloperPaymentDetailsSummary
    {
        public DeveloperPaymentDetailsSum DeveloperPaymentDetailsSum { get; set; }
        public List<DeveloperPaymentDetails> DeveloperPaymentDetails = new List<Prop.DeveloperPaymentDetails>();
    }
    public class DeveloperPaymentDetails
    {
        public long ClientId { get; set; }
        public string ClientName { get; set; }
        public string PaymentDue { get; set; }
        public string PaymentReceived { get; set; }
        public string PaymentPending { get; set; }
    }

    public class DeveloperPaymentDetailsSum
    {
        public long ClientCount { get; set; }
        public string PaymentDue { get; set; }
        public string PaymentReceived { get; set; }
        public string PaymentPending { get; set; }
    }

    public class DeveloperPaymentModuleDetails
    {
        public SoldFlatStatus SoldFlatStatus { get; set; }
        public AgreementValue AgreementValue { get; set; }
        public List<AgreementValueDetails> AgreementValueDetails { get; set; }
        public OtherCharges OtherCharges { get; set; }
        public List<OtherChargesDetails> OtherChargesDetails { get; set; }
     }
    public class SoldFlatStatus
    {
        public string Total { get; set; }
        public string PercentageReceived { get; set; }
        public string PayedAmount { get; set; }
    }
    public class AgreementValue
    {
        public string ClientCount { get; set; }
        public string AveragePrice { get; set; }
        public string TotalPayment { get; set; }
        public string PaymentDone { get; set; }
        public string PaymentDue { get; set; }
        public string RemainingCLP { get; set; }
        public string NoOfFlatSold { get; set; }
    }
    public class AgreementValueDetails
    {
        public long Customer_Id { get; set; }
        public string Name { get; set; }
        public string AgreementValue { get; set; }
        public string PayedAmount { get; set; }
        public string PaymentDue { get; set; }
        public string RemainingCLP { get; set; }
    }

    public class OtherCharges
    {
        public string ClientCount { get; set; }
        public string TotalGST { get; set; }
        public string GSTReceived { get; set; }
        public string GSTDue { get; set; }
        public string StampDuty { get; set; }
    }

    public class OtherChargesDetails
    {
        public long Customer_Id { get; set; }
        public string Name { get; set; }
        public string TotalGST { get; set; }
        public string GSTReceived { get; set; }
        public string GSTDue { get; set; }
        public string RemainingCLPGST { get; set; }
        public string StampDuty { get; set; }
    }

    public class InventoryDrillDown
    {
        public List<InventoryTypologyView> InventoryTypologyView = new List<Prop.InventoryTypologyView>();
        public List<InventoryTypologyViewDrill> InventoryTypologyViewDrill = new List<Prop.InventoryTypologyViewDrill>();
        public List<InventoryWingView> InventoryWingView = new List<Prop.InventoryWingView>();
        public List<InventoryWingViewDrill> InventoryWingViewDrill = new List<Prop.InventoryWingViewDrill>();
    }
    public class InventoryTypologyView
    {
        public int DrillId { get; set; }
        public string Name { get; set; }
        public string FlatsAvailable { get; set; }
        public string SoldFlats { get; set; }
        public string Pending { get; set; }
        public string CarpetArea { get; set; }
    }
    public class InventoryTypologyViewDrill
    {
        public string Wing { get; set; }
        public string FlatsAvailable { get; set; }
        public string SoldFlats { get; set; }
        public string Pending { get; set; }
    }
    public class InventoryWingView
    {
        public int DrillId { get; set; }
        public string Wing { get; set; }
        public string FlatsAvailable { get; set; }
        public string SoldFlats { get; set; }
        public string Pending { get; set; }
    }
    public class InventoryWingViewDrill
    {
        public string Name { get; set; }
        public string FlatsAvailable { get; set; }
        public string SoldFlats { get; set; }
        public string Pending { get; set; }
    }

    public class CommunicationFunnel
    {
        public string TouchBase { get; set; }
        public string SiteVisite { get; set; }
        public string EOI { get; set; }
        public string Booked { get; set; }
    }

    public class DeveloperOtherCharges
    {
        public DevOtherChargesSummary DevOtherChargesSummary { get; set; }
        public List<DevOtherChargesDetails> DevOtherChargesDetails { get; set; }
    }
    public class DevOtherChargesSummary
    {
        public string ClientCount { get; set; }
        public string OtherCharges { get; set; }
        public string OtherChargesReceived { get; set; }
        public string OtherChargesPending { get; set; }
    }

    public class DevOtherChargesDetails
    {
        public long Customer_Id { get; set; }
        public string Name { get; set; }
        public string OtherCharges { get; set; }
        public string OtherChargesReceived { get; set; }
        public string OtherChargesPending { get; set; }
    }
}
